<?php

// telegram

$chat_id = "5693499969";
$bot_token = "5635050004:AAGX7PGN4cwtobCvJ4T2HWJpBzf5YbivQ88";
// email
$to = 'schiron9@gmail.com';


?>