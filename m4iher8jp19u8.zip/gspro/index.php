<?php

  
   header("Location: user/login.php");
  exit();
?>