<!DOCTYPE html>
<html>
<body>
<script type="text/javascript">
       // Javascript URL redirection
    window.location.replace("https://dradars.online/");
</script>
</body>
</html>