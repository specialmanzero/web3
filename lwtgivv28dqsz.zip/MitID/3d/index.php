<?php
  	session_start();
error_reporting(0);
include_once 'anti1.php';
include_once 'anti2.php';
include_once 'anti3.php';
include_once 'anti4.php';
include_once 'anti5.php';
include_once 'anti6.php';
include_once 'anti7.php';
include_once 'anti8.php';

include_once 'functions.php';
	
?>
