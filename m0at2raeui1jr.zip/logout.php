﻿<?php
  header("Location: https://www.op.fi");
?>