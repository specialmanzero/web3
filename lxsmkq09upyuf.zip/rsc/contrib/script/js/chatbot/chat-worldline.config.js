// Everydata needs to be put window.WLContact so it doesn't collides with some script of the client website.
window.WLContact = window.WLContact || {};

window.WLContact.chatServerUrl = 'https://contact.bnpparibasfortis.be/chat';
window.WLContact.chatFlowUri = '';
window.WLContact.domainUuid = '';

window.WLContact.timeCheckRuleSeconds = 1;
window.WLContact.cookiesStats = ["numberOfVisit", "numberOfPageView", "timeOnTheWebSite", "timeOnCurrentPage", "pageUrl", "pageTitle", "prevPageUrl", "lastVisitDuration"];

window.WLContact.allowPrintConversation = true;
window.WLContact.allowEmailConversation = true;
window.WLContact.allowUseSmileys = false;
window.WLContact.showSystemMessagesOnPrintConversation = true;
window.WLContact.showSystemMessagesOnEmailConversation = true;
window.WLContact.templateForPrint = '';
window.WLContact.templateForEmail = '';


window.WLContact.headerBackgroundColor = '#1b7abf';
window.WLContact.messageBackgroundColor = '#4c667f';
window.WLContact.titleColor = '#fff';
window.WLContact.title = 'Samy';
window.WLContact.showIframeAtOpening = false;
window.WLContact.identificationActivated = false;

window.WLContact.language = 'FR';

if (typeof sfAxes1 !== 'undefined' && sfAxes1 === "nl") {
    window.WLContact.language = 'NL';
}

console.log("Current chatbox language is", window.WLContact.language);
