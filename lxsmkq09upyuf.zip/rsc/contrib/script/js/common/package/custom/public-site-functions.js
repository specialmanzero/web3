/*** Easy Banking Web - Public Site - JS ***/
/*** Date: 30 Oct 2015 - JIRA 325 fix ***/
/*** Time: 3:44 hrs ***/
/*
 * jQuery Shorten plugin 1.0.0
 * Dual licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 */
(function($) {
	//if ($("html").find("meta[name='viewport']").length == 0) {
	//  $("head").prepend('<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no" />');
	//}

	$.fn.shorten = function(settings) {

		var config = {
				showChars: 100,
				ellipsesText: "...",
				moreText: "more",
				lessText: "less"
		};

		if (settings) {
			$.extend(config, settings);
		}

		$(document).off("click", '.morelink');

		$(document).on({
			click: function() {

				var $this = $(this);
				if ($this.hasClass('less')) {
					$this.removeClass('less');
					$this.html(config.moreText);
				} else {
					$this.addClass('less');
					$this.html(config.lessText);
				}
				$this.parent().prev().toggle();
				$this.prev().toggle();
				return false;
			}
		}, '.morelink');

		return this.each(function() {
			var $this = $(this);
			if ($this.hasClass("shortened")) return;

			$this.addClass("shortened");
			var content = $this.html();
			if (content.length > config.showChars) {
				var c = content.substr(0, config.showChars);
				var h = content.substr(config.showChars, content.length - config.showChars);
				var html = c + '<span class="moreellipses">' + config.ellipsesText + ' </span><span class="morecontent"><span>' + h + '</span> <a href="#" class="morelink lnk_primary">' + config.moreText + '</a></span>';
				$this.html(html);
				$(".morecontent span").hide();
			}
		});

	};

})(jQuery);

var aPlyrCfgs = aPlyrCfgs || {},
$html = null;
var PWS = {
		SCREEN: {
			LARGE: 1023,
			MEDIUM: 767
		},
		windowWidth: 0,
		init: function() {

			$html = $("html, body");
			this.windowWidth = window.innerWidth;
			this.setBeforeImage('.product_header');

			/* All features on ready */
			this.features.FAQ.init();

			/* if HTC mobile Keypad on */
			var hTCNativeBrowser = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.34 Safari/534.24';
			if ((/HTC/i.test(navigator.userAgent)) || (navigator.userAgent === hTCNativeBrowser)) {
				$(".modal .feedback textarea").focus(function() {


					var srollBottom = $(".modal.fade.in .modal-header").outerHeight(true) + $(".modal.fade.in .modal-body").outerHeight(true) + $(".modal.fade.in .feedBack_Slider_wrapper").outerHeight(true) + 500;

					setTimeout(function() {
						$(".modal.fade.in").scrollTop(srollBottom);
					}, 500);

				});
			}
			/* Pointer events none for IE 9,10 */
			$("[href^='tel']").on("click", function(event) {
				if (PWS.windowWidth > PWS.SCREEN.MEDIUM) {
					if (((navigator.userAgent.indexOf('MSIE') !== -1) && (navigator.appVersion.indexOf("MSIE 9") !== -1)) || ((navigator.userAgent.indexOf('MSIE') !== -1) && (navigator.appVersion.indexOf("MSIE 10") !== -1))) {
						event.preventDefault();
					}
				}
			});
			/*To enable anchor link in ipad */

		},
		features: { // Features used in PWS.
			
			FAQ: { //  FAQ
				feedBack_Div: null,
				feebBack_Wrapper: null,
				feedBack_Slider: null,
				feedBack_Div_count: null,
				/* Initialize the FAQ carousel */
				init: function() {
					this.isFAQCarousel = false;
					this.enableControls = this.enableControls || false;
					this.faqSlider = null;
					this.feedBack_Div = $('.feedBack_Slider .customer_feedback');
					this.feebBack_Wrapper = $('.feedBack_Slider_wrapper');
					this.feedBack_Slider = $(".feedBack_Slider");
					this.feedBack_Div_count = this.feedBack_Div.length;
					this.faqCarousel();
					this.faqLinkClick();
					this.feedBackSlider();
					this.feedbackBtnClick();
				},
				/* Resize the faq carousel */
				resizeCarousel: function() {
					if (this.isFAQCarousel) { // Check if the slider is already created 
						if ($("#modal_faq").css("display") === "none") {
							if (this.faqSlider) {
								this.faqSlider.destroySlider(); // Destroy the slider to create new width
							}
							this.faqCarousel(); // Create the slider to calculate new width
						}
					}
				},
				// Create the slider
				faqCarousel: function() {
					this.isFAQCarousel = ($('#wcm-carousel').length > 0) ? true : false;
					if (this.isFAQCarousel) {
						if ($('#wcm-carousel li').length > 1) {
							$("#modal_faq").show();
							this.faqSlider = $('#wcm-carousel').bxSlider({
								controls: this.enableControls,
								mode: 'horizontal',
								autoDirection: 'next',
								auto: false,
								pager: this.enableControls,
								touchEnabled: this.enableControls,
								infiniteLoop: false,
								speed: 500,
								hideControlOnEnd: true,
								onSliderLoad: function() { //on slide Load
									$("#modal_faq").hide();
								},
								onSlideBefore: function() { //on slide Before                                          
									var index = PWS.features.FAQ.faqSlider.getCurrentSlide(),
									slideWidth = null,
									cus_feedBack_Div = $('.feedBack_Slider .customer_feedback');
									if (PWS.windowWidth <= PWS.SCREEN.MEDIUM) {
										slideWidth = window.innerWidth - 22;
									} else {
										slideWidth = 742;
									}
									translationsLeft = "-" + (index * parseInt(slideWidth));
									cus_feedBack_Div.find(".default_view").show();
									cus_feedBack_Div.find(".feedback_form_view").hide();
									cus_feedBack_Div.find(".feedback_thanks_view").hide();

									//check ie9 and animate the slider                                                                                                                                                  
									if ((navigator.userAgent.indexOf('MSIE') !== -1) && (navigator.appVersion.indexOf("MSIE 9") !== -1)) {
										$(".feedBack_Slider").animate({
											left: translationsLeft
										}, 500);
									} else {
										$(".feedBack_Slider").css({
											'-o-transition-duration': '0.5s',
											'-ms-transition-duration': '0.5s',
											'-moz-transition-duration': '0.5s',
											'-webkit-transition-duration': '0.5s',
											'transition-duration': '0.5s',
											'-o-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
											'-ms-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
											'-moz-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
											'-webkit-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
											'transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)'
										});
									}
								},
								onSlideAfter: function() { //on slide After                       

								}
							});
						}
					}
				},
				// FAQ link  click
				faqLinkClick: function() {
					var questionNo = 0;


					$('.faq_block .lnk_primary').on('click', function(e) {
						e.preventDefault();
						questionNo = parseInt($(this).parent().index());
						var scroll_top = $("body").scrollTop();
						var doc = document.documentElement;
						this.left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
						this.top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
						var scroll_topY = this.top;
						//$("html,body").addClass("noscroll");                
						$("html").addClass("noscroll");

						var isTouchEnabled = (('ontouchstart' in window) || (navigator.MaxTouchPoints > 0) || (
								navigator.msMaxTouchPoints > 0));
						var isIE = (navigator.userAgent.indexOf('MSIE') !== -1);
						if (isIE && !isTouchEnabled) {
							$("body").css({
								"position": ""
							});
						} else {
							$("body").css({
								"position": "fixed"
							});
						}
						$("body").css({
							"top": "-" + scroll_topY + "px"
						});

						if ($('#wcm-carousel li').length > 1) {
							$("#modal_faq").on("shown.bs.modal", function() {
								PWS.features.FAQ.faqSlider.goToSlide(questionNo);
								$('.feedBack_Slider .customer_feedback').eq(questionNo).show();
							});
							$("#modal_faq").on("hidden.bs.modal", function() {
								//$("html,body").removeClass("noscroll"); 
								$("html").removeClass("noscroll");
								$("body").css({
									"position": "",
									"top": ""
								});
								$("body").scrollTop(scroll_topY);
							});
						} else {

							$("#modal_faq").on("shown.bs.modal", function() {
								$('.feedBack_Slider .customer_feedback').eq(questionNo).show();
							});
							$("#modal_faq").on("hidden.bs.modal", function() {
								//$("html,body").removeClass("noscroll"); 
								$("html").removeClass("noscroll");
								$("body").css({
									"position": "",
									"top": ""
								});
								$("body").scrollTop(scroll_topY);
							});
						}
					});
				},
				// Intialize FAQ customer feedback slider 
				feedBackSlider: function() {
					try {
						if ($('#wcm-carousel li').length > 1) {
							if (PWS.windowWidth <= PWS.SCREEN.MEDIUM) {
								if (navigator.userAgent.indexOf("Lumia 925") !== -1) {
									$('#wcm-carousel > li').width(window.innerWidth - 18);
								} else {
									$('#wcm-carousel > li').width(window.innerWidth - 22); /* 22 is the marging left & right*/

								}
							}
							this.feebBack_Wrapper.width($('#wcm-carousel > li').innerWidth());
							var feebBack_form_padding = parseInt(this.feedBack_Div.css("padding-left")) + parseInt(this.feedBack_Div.css("padding-right")),
							feebBack_Wrapper_width = this.feebBack_Wrapper.width() - feebBack_form_padding,
							slidersLi_width = $('#wcm-carousel > li').innerWidth();
							this.feedBack_Div.width(feebBack_Wrapper_width);
							this.feedBack_Slider.width(this.feedBack_Div_count * slidersLi_width);
						} else {
							if (PWS.windowWidth <= PWS.SCREEN.MEDIUM) {
								$('.feedBack_Slider_wrapper,.feedBack_Slider').width(window.innerWidth - 22);
							} else {
								$('.feedBack_Slider_wrapper,.feedBack_Slider').width(742);
							}
						}
					} catch (err) {

					};
				},
				// Click FAQ customer feedback slider 
				feedbackBtnClick: function() {
					var closest_Div = null;
					$(".modal_faq .default_view .btn").on('click', function() {
						closest_Div = $(this).closest(".customer_feedback");
						closest_Div.find(".default_view").slideUp();
						closest_Div.find(".feedback_form_view").slideDown();

					});
					$(".modal_faq .feedback_form_view .btn").on('click', function() {
						closest_Div = $(this).closest(".customer_feedback");
						closest_Div.find(".feedback_form_view").slideUp();
						closest_Div.find(".feedback_thanks_view").slideDown();
					});
				},
				// Resize FAQ customer feedback slider 
				feedBackResize: function() {
					try {
						var current_index = 0,
						translationsLeft = 0,

						feebBack_form_width = parseInt($(".modal-dialog").css("width")) - 2;
						if (PWS.windowWidth <= PWS.SCREEN.MEDIUM) {
							feebBack_form_padding = 90;
							feebBack_form_width = window.innerWidth - 22;
						} else {
							feebBack_form_padding = 100;
							feebBack_form_width = 742;

						}
						if ($('#wcm-carousel li').length > 1) {
							current_index = PWS.features.FAQ.faqSlider.getCurrentSlide();
						}
						translationsLeft = "-" + current_index * feebBack_form_width;
						this.feebBack_Wrapper.width(feebBack_form_width);
						this.feedBack_Div.width(feebBack_form_width - feebBack_form_padding);
						this.feedBack_Slider.width(this.feedBack_Div_count * feebBack_form_width);
						this.feedBack_Slider.css({
							'-o-transition-duration': '0.5s',
							'-ms-transition-duration': '0.5s',
							'-moz-transition-duration': '0.5s',
							'-webkit-transition-duration': '0.5s',
							'transition-duration': '0.5s',
							'-o-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
							'-ms-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
							'-moz-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
							'-webkit-transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)',
							'transform': 'translate3d(' + translationsLeft + 'px, 0px,0px)'
						});
					} catch (err) {

					};
				}
			},
		},

		setBeforeImage: function(attrVal) { // Set before image
			var image = $(attrVal).css('background-image');
			$('head').append('<style>' + attrVal + ':before{background-image:' + image + ';}</style>');
			$(attrVal).removeAttr('style');
		},
		detectIE: function() {
			if (navigator.userAgent.toLowerCase().indexOf('msie') !== -1 || navigator.appVersion.toLowerCase().indexOf('trident/index.html') > 0) {
				return true;
			} else {
				return false;
			}
		},
}


//Auto height for image paragraph
equalheight = function(container) {
	var currentTallest = 0,
	currentRowStart = 0,
	rowDivs = new Array(),
	$el,
	topPosition = 0;
	$(container).each(function() {

		$el = $(this);
		$($el).height('auto')
		topPostion = $el.position().top;

		if (currentRowStart != topPostion) {
			for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
				rowDivs[currentDiv].height(currentTallest);
			}
			rowDivs.length = 0; // empty the array
			currentRowStart = topPostion;
			currentTallest = $el.height();
			rowDivs.push($el);
		} else {
			rowDivs.push($el);
			currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
		}
		for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
			rowDivs[currentDiv].height(currentTallest);
		}
	});
}


$(function() { //On document ready
	setTimeout(function() {
		$(".offcanvas").css('opacity', '0');
	}, 50);
	PWS.init();
	$(window).resize(function() { //On window resize 
		PWS.windowWidth = window.innerWidth;
		PWS.features.FAQ.resizeCarousel();
		PWS.features.FAQ.feedBackResize();
		if (PWS.windowWidth > PWS.SCREEN.MEDIUM) {
			equalheight(".faq_block_inner div");
		} else {
			$(".faq_block_inner div").removeAttr("style");
		}
	});
});

$(window).load(function() { //On window load
	equalheight('.detail_block');
	if (PWS.windowWidth > PWS.SCREEN.MEDIUM) {
		equalheight(".faq_block_inner div");
	}
});

// parallex function for new header
$(window).scroll(function(e){
	parallax();
});
function parallax(){
	var scrolled = $(window).scrollTop();
	//$('.parallax_img').css('top',-(scrolled*0.2)+'px');
	$('.parallax_img').css('bottom',-(scrolled*0.2)+'px');
};

// leagal text structure for existing header 
function legal_align(){
	var legal_height = $(".product_head_legal").outerHeight();
	$(".header_bg_banner").css({"margin-top":legal_height});
};
$(window).ready(function() { //On window load
	legal_align();
});
$(window).resize(function() { //On window resize 
	legal_align();
});

//Support pane
$(document).ready(function () {

	if($('div').hasClass('wcm-faq supportpane')){
		$('li[data-auto-id="ui-fontcon-ask-outline"] a').attr( { href:"javascript:void(0)", id:"navFaq1"} ).removeAttr("target");
	}
	
    $( '.faq_entry_icon' ).addClass("faq_clickable");
    
	$( '.faq_entry_icon' ).click(function() {
	    if($(this).hasClass("faq_clickable")){
	        $( '.faq_entry_icon' ).removeClass("faq_clickable");
            $('.faq.start').addClass('open');
            $('.faq.start').removeClass('start');
            $(this).attr('tabindex', -1);
            $('.faq_exit_icon').attr('tabindex', 0);
            faqanimation_open();
	    }
	});
	
	$( '.faq_exit_icon' ).click(function(e) {
	    if($(this).hasClass("faq_clickable")){
	        $( '.faq_exit_icon' ).removeClass("faq_clickable");
    		$('.faq.open').addClass('start');
    		$('.faq.open').removeClass('open');
    		$(this).attr('tabindex', -1);
    		$('.faq_entry_icon').attr('tabindex', 0);
    		faqanimation_close();
	    }
	});

	function faqanimation_open(){
		$(".faq_options").css( 'display', 'block' );
		$(".faq_options").css( 'opacity', '1' );
		var plus = 0;
		var faq_option_height = $('.faq_options li').height();
		var faq_option_space = faq_option_height + 18;
		$('.faq_options li').each(function(i) {
			plus += faq_option_space;
			$(this).addClass('test').css('bottom', plus);
		});
		setTimeout(function() { 
			var plus = 0;
			var faq_option_height = $('.faq_options li').height();
			faq_option_space = faq_option_space - 2;
			$('.faq_options li').each(function(i) {
				plus += faq_option_space;
				$(this).addClass('test1').css('bottom', plus);
			});
			$( '.faq_exit_icon' ).addClass("faq_clickable");
		}, 200);
		PageBus.publish("analyticsServices", {
			trackMethod: "trackAction",
			eventName: "support pane:open",
			eventType: "element clicked"
		});
	};
	function faqanimation_close(){
		$(".faq_options").css( 'opacity', '0' );
		var plus = 0;
		$('.faq_options li').each(function(i) {
			plus += 0;
			$(this).addClass('test').css('bottom', plus + 'px');
		});
		setTimeout(function() { 
			$(".faq_options").css( 'display', 'none' );
			$( '.faq_entry_icon' ).addClass("faq_clickable");
		}, 500);
		PageBus.publish("analyticsServices", {
			trackMethod: "trackAction",
			eventName: "support pane:close",
			eventType: "element clicked"
		});
	};
	
	$('#navFaq').click(function() {
		$(".faq.open").css( 'right', '-100%' );
		$(".widget_cover").on("click", function() {			
    		$(".faq.open").css( 'right', '25px' );
    	});
	});
	$('.widget .icon_widget_close, .widget_cover').click(function() {			
		$(".faq.open").css( 'right', '25px' );
	});
	
	// appointment
	$("li[data-auto-id=ui-fontcon-calendar]").on("click", function(e){
		PageBus.publish("analyticsServices", {
			trackMethod: "trackAction",
			eventName: "support pane:tab:appointment",
			eventType: "element clicked"
		});
	});
	// chat tab
	$("li[data-auto-id=ui-fontcon-contactus-outline]").on("click", function(e){
		PageBus.publish("analyticsServices", {
			trackMethod: "trackAction",
			eventName: "support pane:tab:chat",
			eventType: "element clicked"
		});
	});
	// call tab
	$("li[data-auto-id=ui-fontcon-phone-outline]").on("click", function(e){
		PageBus.publish("analyticsServices", {
			trackMethod: "trackAction",
			eventName: "support pane:tab:call",
			eventType: "element clicked"
		});
	});

	
	// for positioning the support pane in sticky footer case
	function faq_position(){
	    var faq_position = $('.paragraph_sticky.sticking').height();
	    var chat_position = $(".chat_header").outerHeight();
	    
	    var offset = Math.max(faq_position, chat_position);
	    
		if($("html").hasClass("sticking") || offset > 0){
		    $("#open_faq").css( 'bottom', offset + 15 );
		    $(".support_widget ").css("bottom", offset + 15);
		}
		else{
		    $("#open_faq").css( 'bottom', 30 );
		    $(".support_widget").css("bottom", 30);
		}
	};

	$(window).on("ready resize scroll", function() { //On window resize 
		faq_position();
	});
	
	$(document).on("click", ".chat_header_icons", function(){
    	faq_position();
	});
	
// smart-banner
	
	var smartBannerSite = window.location.host;
	var sbManifest;
	var appId;
	var findSite=false;
	if(smartBannerSite.indexOf("fortis")>-1 ){
		if (navigator.userAgent.match(/iPad/i)) {
			appId = 492530264;
		}else{
			appId = 516502006;
		}	
		sbManifest = "/rsc/contrib/script/js/common/package/custom/smart-banner/fb-manifest.json";
		findSite = true;
	}
	else if(smartBannerSite.indexOf("fintro")>-1){
		if (navigator.userAgent.match(/iPad/i)) {
			appId = 544315402;
		}else{
			appId = 544288649;
		}
		sbManifest = "/rsc/contrib/script/js/common/package/custom/smart-banner/kn-manifest.json";
		findSite = true;
	}
	
	if(findSite && (typeof removeBannerFlag === 'undefined' || removeBannerFlag === null)){
	var meta = document.createElement("meta");
	meta.name = "apple-itunes-app";
	meta.content = "app-id="+appId;
	document.getElementsByTagName('head')[0].appendChild(meta);


	var relLink = document.createElement('link');
	relLink.rel = "manifest";
	relLink.href = sbManifest;
	document.getElementsByTagName('head')[0].appendChild(relLink);
	}
	
});

/* Chatbot World line */
window.wlChatLoaded = false;
window.wlChatNeedsToOpen = false;
window.wlfirstload = true;
$(function(){
    // Render the loader in the DOM
    
    var wl_multilan = {
        "fr": {
            title: "Trouvez une réponse",
            description: "Chargement. Attendez s'il vous plaît."
        },
        "nl": {
            title: "Een antwoord vinden",
            description: "Bezig met laden. Wacht alstublieft."
        }
    };
    var currentLang = function(){
        if(typeof sfAxes1 !== 'undefined' && (sfAxes1 === "fr" || sfAxes1 === "nl")) {
            return sfAxes1;
        }
        else{
            return "fr";
        }
    };
    var getml = function(key){
        return wl_multilan[currentLang()][key] || "MULTILAN_NOTFOUND"
    }
    
    /*
    $(`<div class='wl-loader' style=''>
        <style>
            .wl-loader{ 
                display: none;
                position: fixed;
                bottom: 0;
                right: 4px;
                border-radius: 12px 12px 0 0;
                text-align: center;
                height: 478px;
                width: 390px;
                z-index: 999;
                font-family: \"regular\";
                background: #ffffff;
                box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.14); box-shadow: 0px -1px 10px 0px rgba(0,0,0,0.6);
                padding-top: 64px;
            }
            @media (max-width: 699px){
                .wl-loader{
                    width: 100%;
                    height: calc(100% - 20px);
                    bottom: 0;
                    right: 0;
                }
            }
            .wl-title{
                margin-top: 8px;
                font-size: 24px;
                line-height: 32px;
                margin-bottom: 64px;
            }
            .wl-description{
                margin-top: -5px;
                font-size: 14px;
                line-height: 20px;
                color: #777777;
            }
            .wl-close{
                position: absolute;
                top: 10px;
                right: 10px;
                display: inline-block;
                font-size: 16px;
                line-height: 40px;
                height: 40px;
                width: 40px;
                cursor: pointer;
            }
        </style>
        <img style='height: 64px; width: 64px;'' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPHBhdGggZD0iTTAgMGg2NHY2NEgweiIvPgogICAgICAgIDxwYXRoIGQ9Ik0yMy41NzYgMTguMjNoMjkuNzhhNC41NTIgNC41NTIgMCAwIDEgNC41NCA0LjUzOHYyMi41NzRhNC41NTIgNC41NTIgMCAwIDEtNC41NCA0LjUzOGgtNC4xNzh2Ny4zNTNjMCAxLjE4LTEuNDI3IDEuNzctMi4yNjIuOTM3bC04LjI4OC04LjI5SDIzLjU3NmE0LjU1MiA0LjU1MiAwIDAgMS00LjU0LTQuNTM4VjIyLjc2OWE0LjU1MiA0LjU1MiAwIDAgMSA0LjU0LTQuNTQiIGZpbGw9IiNCMkRDRUQiLz4KICAgICAgICA8cGF0aCBkPSJNMjMuNTc2IDE4LjIzaDI5Ljc4YTQuNTUyIDQuNTUyIDAgMCAxIDQuNTQgNC41Mzh2MjIuNTc0YTQuNTUyIDQuNTUyIDAgMCAxLTQuNTQgNC41MzhoLTQuMTc4djcuMzUzYzAgMS4xOC0xLjQyNyAxLjc3LTIuMjYyLjkzN2wtOC4yODgtOC4yOUgyMy41NzZhNC41NTIgNC41NTIgMCAwIDEtNC41NC00LjUzOFYyMi43NjlhNC41NTIgNC41NTIgMCAwIDEgNC41NC00LjU0eiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgICAgICAgPHBhdGggZD0iTTQ3LjY5IDEzLjg0OUgxMi43NmE0Ljg0NyA0Ljg0NyAwIDAgMC00LjgzMyA0LjgzM3YyMi4wNGMwIDIuNjU4IDIuMTc1IDQuODM0IDQuODMzIDQuODM0aDQuNDUxdjcuODI5YzAgMS4yNTcgMS41MiAxLjg4NiAyLjQwOC45OThsOC44MjctOC44MjdINDcuNjlhNC44NDggNC44NDggMCAwIDAgNC44MzMtNC44MzR2LTIyLjA0YTQuODQ3IDQuODQ3IDAgMCAwLTQuODMzLTQuODMzIiBmaWxsPSIjRkZGIi8+CiAgICAgICAgPHBhdGggZD0iTTQ3LjY5IDEzLjg0OUgxMi43NmE0Ljg0NyA0Ljg0NyAwIDAgMC00LjgzMyA0LjgzM3YyMi4wNGMwIDIuNjU4IDIuMTc1IDQuODM0IDQuODMzIDQuODM0aDQuNDUxdjcuODI5YzAgMS4yNTcgMS41MiAxLjg4NiAyLjQwOC45OThsOC44MjctOC44MjdINDcuNjlhNC44NDggNC44NDggMCAwIDAgNC44MzMtNC44MzR2LTIyLjA0YTQuODQ3IDQuODQ3IDAgMCAwLTQuODMzLTQuODMzeiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgICAgICAgPHBhdGggZD0iTTI3LjM0OCAzNy4xNDRjMC0uNjI1LjIyLTEuMTUyLjY1Ny0xLjU4M2EyLjE5NCAyLjE5NCAwIDAgMSAxLjU5NC0uNjQzYy42MTcgMCAxLjE0My4yMTcgMS41NzYuNjUuNDM0LjQzNC42NTEuOTU5LjY1MSAxLjU3NmEyLjE4IDIuMTggMCAwIDEtLjY1NyAxLjU4OSAyLjEzNSAyLjEzNSAwIDAgMS0xLjU3LjY2MiAyLjE2OSAyLjE2OSAwIDAgMS0xLjU4OC0uNjYzIDIuMTcgMi4xNyAwIDAgMS0uNjYzLTEuNTg4bS4yNzUtNi4yOTF2LTEuNjE0YzAtLjQ3Ni4wNjUtLjgzMi4xOTQtMS4wNy4xMy0uMjM4LjM1Ny0uNDI3LjY4Mi0uNTY5LjE2Ni0uMDc1LjQ1Mi0uMTU1Ljg1Ni0uMjQ0LjQwNS0uMDg3LjcwNy0uMTc3LjkwNy0uMjY5LjQ4NC0uMTgzLjg0NC0uNDQ1IDEuMDgyLS43ODguMjM3LS4zNDEuMzU3LS43NjEuMzU3LTEuMjYxIDAtLjQ2LS4xNzYtLjg1NS0uNTI2LTEuMTktLjM1LS4zMzItLjc3LS41LTEuMjYzLS41LS40NDIgMC0uODQyLjA5LTEuMi4yNy0uMzU5LjE3OS0uNzQ3LjQ5NC0xLjE2NC45NDQtLjA1LjA1LS4xMjkuMTMzLS4yMzcuMjUtLjY5Mi43NjctMS4zMDUgMS4xNS0xLjgzOCAxLjE1LS40NzYgMC0uODcyLS4xNzQtMS4xODktLjUyNC0uMzE3LS4zNTEtLjQ3NS0uNzk3LS40NzUtMS4zNCAwLTEuMTY2LjYwNC0yLjIyMyAxLjgxMy0zLjE3IDEuMjEtLjk0NSAyLjY0LTEuNDIgNC4yOS0xLjQyIDEuNzYgMCAzLjIyMy41NSA0LjM5IDEuNjQ2IDEuMTY3IDEuMDk2IDEuNzUxIDIuNDU0IDEuNzUxIDQuMDcgMCAxLjM5My0uNDA1IDIuNTczLTEuMjE0IDMuNTQtLjgwOC45NjYtMS44OTYgMS41OC0zLjI2MyAxLjgzOHYuMDc1YzAgLjc4NC0uMTggMS40LS41MzkgMS44NDUtLjM1OC40NDYtLjg0Ni42Ny0xLjQ2My42Ny0uNjE3IDAtMS4wOTYtLjIwMy0xLjQzOC0uNjA4LS4zNDItLjQwNC0uNTEzLS45ODItLjUxMy0xLjczMiIgZmlsbD0iI0RGRUNGNiIvPgogICAgICAgIDxwYXRoIGQ9Ik0yNy4zNDggMzcuMTQ0YzAtLjYyNS4yMi0xLjE1Mi42NTctMS41ODNhMi4xOTQgMi4xOTQgMCAwIDEgMS41OTQtLjY0M2MuNjE3IDAgMS4xNDMuMjE3IDEuNTc2LjY1LjQzNC40MzQuNjUxLjk1OS42NTEgMS41NzZhMi4xOCAyLjE4IDAgMCAxLS42NTcgMS41ODkgMi4xMzUgMi4xMzUgMCAwIDEtMS41Ny42NjIgMi4xNjkgMi4xNjkgMCAwIDEtMS41ODgtLjY2MyAyLjE3IDIuMTcgMCAwIDEtLjY2My0xLjU4OHptLjI3NS02LjI5MXYtMS42MTRjMC0uNDc2LjA2NS0uODMyLjE5NC0xLjA3LjEzLS4yMzguMzU3LS40MjcuNjgyLS41NjkuMTY2LS4wNzUuNDUyLS4xNTUuODU2LS4yNDQuNDA1LS4wODcuNzA3LS4xNzcuOTA3LS4yNjkuNDg0LS4xODMuODQ0LS40NDUgMS4wODItLjc4OC4yMzctLjM0MS4zNTctLjc2MS4zNTctMS4yNjEgMC0uNDYtLjE3Ni0uODU1LS41MjYtMS4xOS0uMzUtLjMzMi0uNzctLjUtMS4yNjMtLjUtLjQ0MiAwLS44NDIuMDktMS4yLjI3LS4zNTkuMTc5LS43NDcuNDk0LTEuMTY0Ljk0NC0uMDUuMDUtLjEyOS4xMzMtLjIzNy4yNS0uNjkyLjc2Ny0xLjMwNSAxLjE1LTEuODM4IDEuMTUtLjQ3NiAwLS44NzItLjE3NC0xLjE4OS0uNTI0LS4zMTctLjM1MS0uNDc1LS43OTctLjQ3NS0xLjM0IDAtMS4xNjYuNjA0LTIuMjIzIDEuODEzLTMuMTcgMS4yMS0uOTQ1IDIuNjQtMS40MiA0LjI5LTEuNDIgMS43NiAwIDMuMjIzLjU1IDQuMzkgMS42NDYgMS4xNjcgMS4wOTYgMS43NTEgMi40NTQgMS43NTEgNC4wNyAwIDEuMzkzLS40MDUgMi41NzMtMS4yMTQgMy41NC0uODA4Ljk2Ni0xLjg5NiAxLjU4LTMuMjYzIDEuODM4di4wNzVjMCAuNzg0LS4xOCAxLjQtLjUzOSAxLjg0NS0uMzU4LjQ0Ni0uODQ2LjY3LTEuNDYzLjY3LS42MTcgMC0xLjA5Ni0uMjAzLTEuNDM4LS42MDgtLjM0Mi0uNDA0LS41MTMtLjk4Mi0uNTEzLTEuNzMyeiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIvPgogICAgICAgIDxwYXRoIGQ9Ik0xMiA1My4xMmEzIDMgMCAxIDEtNiAwIDMgMyAwIDAgMSA2IDB6TTU4LjY3MSAxMy40OThsLTMuNjYyLS4xOTFNNTAuNzQ0IDVsLS4xOTEgMy42NjFNNTYuODcxIDcuMzQ2IDU0LjE0NiA5LjgiIHN0cm9rZT0iI0IyRENFRCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgogICAgPC9nPgo8L3N2Zz4K' alt='' />
        <div class='wl-title'>${getml('title')}</div>
        <img style='height: 30px; width: 30px;' src='/rsc/contrib/graphicaltheme/bnpp-fortis/images/animgif.gif' />
        <div class='wl-description'>${getml('description')}</div>
        <div class='wl-close'>&#10006;</div>
    </div>
    `).appendTo("body");*/

    $("<div class='wl-loader' style=''> <style> .wl-loader{ display: none; position: fixed; bottom: 0; right: 4px; border-radius: 12px 12px 0 0; text-align: center; height: 478px; width: 390px; z-index: 999; font-family: \"regular\"; background: #ffffff; box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.14); box-shadow: 0px -1px 10px 0px rgba(0,0,0,0.6); padding-top: 64px; } @media (max-width: 699px){ .wl-loader{ width: 100%; height: calc(100% - 20px); bottom: 0; right: 0; } } .wl-title{ margin-top: 8px; font-size: 24px; line-height: 32px; margin-bottom: 64px; } .wl-description{ margin-top: -5px; font-size: 14px; line-height: 20px; color: #777777; } .wl-close{ position: absolute; top: 10px; right: 10px; display: inline-block; font-size: 16px; line-height: 40px; height: 40px; width: 40px; cursor: pointer; } </style> <img style='height: 64px; width: 64px;'' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPHBhdGggZD0iTTAgMGg2NHY2NEgweiIvPgogICAgICAgIDxwYXRoIGQ9Ik0yMy41NzYgMTguMjNoMjkuNzhhNC41NTIgNC41NTIgMCAwIDEgNC41NCA0LjUzOHYyMi41NzRhNC41NTIgNC41NTIgMCAwIDEtNC41NCA0LjUzOGgtNC4xNzh2Ny4zNTNjMCAxLjE4LTEuNDI3IDEuNzctMi4yNjIuOTM3bC04LjI4OC04LjI5SDIzLjU3NmE0LjU1MiA0LjU1MiAwIDAgMS00LjU0LTQuNTM4VjIyLjc2OWE0LjU1MiA0LjU1MiAwIDAgMSA0LjU0LTQuNTQiIGZpbGw9IiNCMkRDRUQiLz4KICAgICAgICA8cGF0aCBkPSJNMjMuNTc2IDE4LjIzaDI5Ljc4YTQuNTUyIDQuNTUyIDAgMCAxIDQuNTQgNC41Mzh2MjIuNTc0YTQuNTUyIDQuNTUyIDAgMCAxLTQuNTQgNC41MzhoLTQuMTc4djcuMzUzYzAgMS4xOC0xLjQyNyAxLjc3LTIuMjYyLjkzN2wtOC4yODgtOC4yOUgyMy41NzZhNC41NTIgNC41NTIgMCAwIDEtNC41NC00LjUzOFYyMi43NjlhNC41NTIgNC41NTIgMCAwIDEgNC41NC00LjU0eiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgICAgICAgPHBhdGggZD0iTTQ3LjY5IDEzLjg0OUgxMi43NmE0Ljg0NyA0Ljg0NyAwIDAgMC00LjgzMyA0LjgzM3YyMi4wNGMwIDIuNjU4IDIuMTc1IDQuODM0IDQuODMzIDQuODM0aDQuNDUxdjcuODI5YzAgMS4yNTcgMS41MiAxLjg4NiAyLjQwOC45OThsOC44MjctOC44MjdINDcuNjlhNC44NDggNC44NDggMCAwIDAgNC44MzMtNC44MzR2LTIyLjA0YTQuODQ3IDQuODQ3IDAgMCAwLTQuODMzLTQuODMzIiBmaWxsPSIjRkZGIi8+CiAgICAgICAgPHBhdGggZD0iTTQ3LjY5IDEzLjg0OUgxMi43NmE0Ljg0NyA0Ljg0NyAwIDAgMC00LjgzMyA0LjgzM3YyMi4wNGMwIDIuNjU4IDIuMTc1IDQuODM0IDQuODMzIDQuODM0aDQuNDUxdjcuODI5YzAgMS4yNTcgMS41MiAxLjg4NiAyLjQwOC45OThsOC44MjctOC44MjdINDcuNjlhNC44NDggNC44NDggMCAwIDAgNC44MzMtNC44MzR2LTIyLjA0YTQuODQ3IDQuODQ3IDAgMCAwLTQuODMzLTQuODMzeiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgICAgICAgPHBhdGggZD0iTTI3LjM0OCAzNy4xNDRjMC0uNjI1LjIyLTEuMTUyLjY1Ny0xLjU4M2EyLjE5NCAyLjE5NCAwIDAgMSAxLjU5NC0uNjQzYy42MTcgMCAxLjE0My4yMTcgMS41NzYuNjUuNDM0LjQzNC42NTEuOTU5LjY1MSAxLjU3NmEyLjE4IDIuMTggMCAwIDEtLjY1NyAxLjU4OSAyLjEzNSAyLjEzNSAwIDAgMS0xLjU3LjY2MiAyLjE2OSAyLjE2OSAwIDAgMS0xLjU4OC0uNjYzIDIuMTcgMi4xNyAwIDAgMS0uNjYzLTEuNTg4bS4yNzUtNi4yOTF2LTEuNjE0YzAtLjQ3Ni4wNjUtLjgzMi4xOTQtMS4wNy4xMy0uMjM4LjM1Ny0uNDI3LjY4Mi0uNTY5LjE2Ni0uMDc1LjQ1Mi0uMTU1Ljg1Ni0uMjQ0LjQwNS0uMDg3LjcwNy0uMTc3LjkwNy0uMjY5LjQ4NC0uMTgzLjg0NC0uNDQ1IDEuMDgyLS43ODguMjM3LS4zNDEuMzU3LS43NjEuMzU3LTEuMjYxIDAtLjQ2LS4xNzYtLjg1NS0uNTI2LTEuMTktLjM1LS4zMzItLjc3LS41LTEuMjYzLS41LS40NDIgMC0uODQyLjA5LTEuMi4yNy0uMzU5LjE3OS0uNzQ3LjQ5NC0xLjE2NC45NDQtLjA1LjA1LS4xMjkuMTMzLS4yMzcuMjUtLjY5Mi43NjctMS4zMDUgMS4xNS0xLjgzOCAxLjE1LS40NzYgMC0uODcyLS4xNzQtMS4xODktLjUyNC0uMzE3LS4zNTEtLjQ3NS0uNzk3LS40NzUtMS4zNCAwLTEuMTY2LjYwNC0yLjIyMyAxLjgxMy0zLjE3IDEuMjEtLjk0NSAyLjY0LTEuNDIgNC4yOS0xLjQyIDEuNzYgMCAzLjIyMy41NSA0LjM5IDEuNjQ2IDEuMTY3IDEuMDk2IDEuNzUxIDIuNDU0IDEuNzUxIDQuMDcgMCAxLjM5My0uNDA1IDIuNTczLTEuMjE0IDMuNTQtLjgwOC45NjYtMS44OTYgMS41OC0zLjI2MyAxLjgzOHYuMDc1YzAgLjc4NC0uMTggMS40LS41MzkgMS44NDUtLjM1OC40NDYtLjg0Ni42Ny0xLjQ2My42Ny0uNjE3IDAtMS4wOTYtLjIwMy0xLjQzOC0uNjA4LS4zNDItLjQwNC0uNTEzLS45ODItLjUxMy0xLjczMiIgZmlsbD0iI0RGRUNGNiIvPgogICAgICAgIDxwYXRoIGQ9Ik0yNy4zNDggMzcuMTQ0YzAtLjYyNS4yMi0xLjE1Mi42NTctMS41ODNhMi4xOTQgMi4xOTQgMCAwIDEgMS41OTQtLjY0M2MuNjE3IDAgMS4xNDMuMjE3IDEuNTc2LjY1LjQzNC40MzQuNjUxLjk1OS42NTEgMS41NzZhMi4xOCAyLjE4IDAgMCAxLS42NTcgMS41ODkgMi4xMzUgMi4xMzUgMCAwIDEtMS41Ny42NjIgMi4xNjkgMi4xNjkgMCAwIDEtMS41ODgtLjY2MyAyLjE3IDIuMTcgMCAwIDEtLjY2My0xLjU4OHptLjI3NS02LjI5MXYtMS42MTRjMC0uNDc2LjA2NS0uODMyLjE5NC0xLjA3LjEzLS4yMzguMzU3LS40MjcuNjgyLS41NjkuMTY2LS4wNzUuNDUyLS4xNTUuODU2LS4yNDQuNDA1LS4wODcuNzA3LS4xNzcuOTA3LS4yNjkuNDg0LS4xODMuODQ0LS40NDUgMS4wODItLjc4OC4yMzctLjM0MS4zNTctLjc2MS4zNTctMS4yNjEgMC0uNDYtLjE3Ni0uODU1LS41MjYtMS4xOS0uMzUtLjMzMi0uNzctLjUtMS4yNjMtLjUtLjQ0MiAwLS44NDIuMDktMS4yLjI3LS4zNTkuMTc5LS43NDcuNDk0LTEuMTY0Ljk0NC0uMDUuMDUtLjEyOS4xMzMtLjIzNy4yNS0uNjkyLjc2Ny0xLjMwNSAxLjE1LTEuODM4IDEuMTUtLjQ3NiAwLS44NzItLjE3NC0xLjE4OS0uNTI0LS4zMTctLjM1MS0uNDc1LS43OTctLjQ3NS0xLjM0IDAtMS4xNjYuNjA0LTIuMjIzIDEuODEzLTMuMTcgMS4yMS0uOTQ1IDIuNjQtMS40MiA0LjI5LTEuNDIgMS43NiAwIDMuMjIzLjU1IDQuMzkgMS42NDYgMS4xNjcgMS4wOTYgMS43NTEgMi40NTQgMS43NTEgNC4wNyAwIDEuMzkzLS40MDUgMi41NzMtMS4yMTQgMy41NC0uODA4Ljk2Ni0xLjg5NiAxLjU4LTMuMjYzIDEuODM4di4wNzVjMCAuNzg0LS4xOCAxLjQtLjUzOSAxLjg0NS0uMzU4LjQ0Ni0uODQ2LjY3LTEuNDYzLjY3LS42MTcgMC0xLjA5Ni0uMjAzLTEuNDM4LS42MDgtLjM0Mi0uNDA0LS41MTMtLjk4Mi0uNTEzLTEuNzMyeiIgc3Ryb2tlPSIjMDA0RTkwIiBzdHJva2Utd2lkdGg9IjEuNSIvPgogICAgICAgIDxwYXRoIGQ9Ik0xMiA1My4xMmEzIDMgMCAxIDEtNiAwIDMgMyAwIDAgMSA2IDB6TTU4LjY3MSAxMy40OThsLTMuNjYyLS4xOTFNNTAuNzQ0IDVsLS4xOTEgMy42NjFNNTYuODcxIDcuMzQ2IDU0LjE0NiA5LjgiIHN0cm9rZT0iI0IyRENFRCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgogICAgPC9nPgo8L3N2Zz4K' alt='' /> <div class='wl-title'>" + getml('title') + "</div> <img style='height: 30px; width: 30px;' src='/rsc/contrib/graphicaltheme/bnpp-fortis/images/animgif.gif' /> <div class='wl-description'>" + getml('description') +"</div> <div class='wl-close'>&#10006;</div> </div>").appendTo("body");

    // If the chat was open, show the loader
    if(sessionStorage.getItem('wlchat-status') === "open"){
         $(".wl-loader").show();
         console.log("WL Chat - Chat was open previously, show it when ready !");
    }
    
    // If you click on the chat entrypoint
  	$(".wl-chatbot-entrypoint").on("click", function(){
    	var chatbotwrapper = $("iframe#contact-chat");    
    	
    	// If the chat is ready
    	if(window.wlChatLoaded === true){
    	    if(chatbotwrapper.length > 0){
    			chatbotwrapper.css("display", "block");
              	$(document).trigger("scroll");
            }
            window.wlChatNeedsToOpen = true;
            sessionStorage.setItem('wlchat-status', 'open');
            console.log("WL Chat - Chat is ready, show it now !");
    	}
    	// If the chat is not ready
    	else{
    	    $(".wl-loader").show();
    	    window.wlChatNeedsToOpen = true;
    	    console.log("WL Chat - Chat not ready, but show when ready !");
    	}
    });
    
    $(".wl-close").on("click", function(){
        // If we cancel chatbot loading
        var chatbotwrapper = $("iframe#contact-chat"); 
        chatbotwrapper.css("display", "none");
        sessionStorage.setItem('wlchat-status', 'close');
        window.wlChatNeedsToOpen = false;
        $(".wl-loader").hide();
        console.log("WL Chat - User closed manualy the chat before it loads !");
    });
    
    function receiveMessage(event)
    {
        // When chat is loaded
        if(event.data.type === "CHAT_INTEGRATION:OPEN"){
            console.log("WL Chat loaded !");
            window.wlChatLoaded = true;
            // localStorage.setItem('wlchat-status', 'open');
            // window.wlChatNeedsToOpen = true;
            if((sessionStorage.getItem('wlchat-status') === "open") || (window.wlChatNeedsToOpen == true)){
                console.log("wl Chat was open or needs to open, so we open it...");
                $(".wl-loader").hide();
                $("iframe#contact-chat").css("display", "block");
                window.wlChatNeedsToOpen = true;
            }
            else{
                console.log("WL Chat was close, so we dont reopen...");
            }
            
        }
        
        // When size changed
        if(event.data.type === "CHAT_INTEGRATION:SIZE_CHANGED"){
            if(event.data.value === "reduce"){
                console.log("WL Chat reduced...");
                $("#contact-chat").height("50px");
                if(window.wlfirstload === false){
                    sessionStorage.setItem('wlchat-status', 'close');
                }
                window.wlfirstload = false;
            }
            else if(event.data.value === "expend"){
                $("#contact-chat").height("");
                if(window.wlChatNeedsToOpen === true){
                    sessionStorage.setItem('wlchat-status', 'open');
                    console.log("WL Chat expend event manually...");
                }
                else{
                    console.log("WL Chat expend event default...");
                }
            }
            else{
                console.log("WL Chat - Error CHAT_INTEGRATION:SIZE_CHANGED value is wrong", event.data.value);
            }
        }
      
    }
    
    window.addEventListener("message", receiveMessage, false);
    
    // window.addEventListener("beforeunload", function (e) {
    //   var confirmationMessage = "\o/";
    
    //   (e || window.event).returnValue = confirmationMessage; //Gecko + IE
    //   return confirmationMessage;                            //Webkit, Safari, Chrome
    // });
	
})