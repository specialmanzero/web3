/**
Get the Query String Parameters As a JSON Object
**/
function getQueryStringParametersAsJSON() {
    var result = {};
    var pairs = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < pairs.length; i++) {
        pair = pairs[i].split('=');
        result[pair[0]] = pair[1];
    }
    return JSON.parse(JSON.stringify(result));
}
/**
Parse the name of the query parameter
**/
function getQueryStringParameterByName(name){
	name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+name+"=([^&#]*)", 
	regex = new RegExp( regexS ),
	results = regex.exec( window.location.href );
	if( results == null ){
		return "";
	} else{
		return decodeURIComponent(results[1].replace(/\+/g, " "));
	}
}
var topicname = getQueryStringParameterByName("renderer");
if(topicname){	
	var dataValue = getQueryStringParameterByName("campaign-id");
	if(dataValue){
		dataValue = dataValue.replace(/;/g,'&');
		dataValue = dataValue.replace(/:/g,'=');
		window.sfIaParam = {};
		window.sfIaParam.param = dataValue;
		window.sfIaParam.topic = topicname;
	}
}

/** 
functions for PCB migration testing
**/
function decodeBase64(s) {
    var e={},i,b=0,c,x,l=0,a,r='';
    var w=String.fromCharCode; 
    var L=s.length;
    var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%2b/index.html";
    for(i=0;i<64;i++){e[A.charAt(i)]=i;}
    for(x=0;x<L;x++){
        c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
        while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
    }
    return r;
}

function getQueryVariable(afContext, paramName) {
    var vars = afContext.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == paramName) {
            return decodeURIComponent(pair[1]);
        }
    }
}

function getAfDataObject(afContext) {
    var afData = {}; 
	var vars = afContext.split('&');
	var pair = "";
	var tempPair = "";
    for (var i = 0; i < vars.length; i++) {
        pair = vars[i].split('=');
		tempPair = pair[0];
        afData[tempPair] = decodeURIComponent(pair[1]);
    }
	//return afData;
	return JSON.stringify(afData)
}
/** 
variable for clb banners
**/
var _wcm_banners_list = [];
var _wcm_banners_flag = [];

$(document).ready(function() {
    
    $(".map_inner h3").css("padding-bottom", "5px");
    
    
	// Map - Branch locator validation code starts - i39857
    var validationZipCode = {
        zipCodeNumericOnly: function(e) {
            // i39857 - to fix the defect - 27301 - starts
			// g43560 - adding '.map_text' class for the branch locator error msg issue in the 'zipCodeNumericOnly' function
            $(".map_text .field_error_message").removeClass("show");
            return true;
            // i39857 - to fix the defect - 27301 - ends
        },
			// g43560 - adding '.map_text' class for the branch locator error msg issue in the 'branchBtnClick' function
        branchBtnClick: function(e) {
            e.preventDefault();
            var zipCodeValue = $(".branch_locator_input").val();
            var errorCodeContentTeam = $(".map_text .field_error_message").text();
            if (zipCodeValue) {

                validationZipCode.branchLocator();

            } else if ((errorCodeContentTeam) && ($(".map_text .field_error_message").length > 0)) {
                $(".map_text .field_error_message").addClass("show");
                return false;
            }
        },

        branchLocator: function() {
            var branch_url = "https://branch.bnpparibasfortis.be/m";
            if(sfAxes3 && sfAxes3 == "kn"){
                branch_url = "https://branch.fintro.be/m"
            }
            else{
                branch_url = "https://branch.bnpparibasfortis.be/m"
            }
            var lang = sfAxes1;
            branch_url = branch_url + "/" + lang;
            //var branch_ur = branch_url + "/" + lang + "/?adr=" + $(".branch_locator_input").val();
            // i39857 - to fix the defect - 27301 - starts
            var url_redirect;
            var searchlocator = $("input[name=searchlocator]:checked").val();
            if (isNaN($(".branch_locator_input").val())) {
                url_redirect = branch_url + "?crit=" + searchlocator + "&adr=" + $(".branch_locator_input").val();
            } else {
                url_redirect = branch_url + "?crit=" + searchlocator + "&adr=" + parseInt($(".branch_locator_input").val(), 10);

            }
            window.open(url_redirect);
            // i39857 - to fix the defect - 27301 - ends
          //fortify defect #8141 fix to validate URL with origin to avoid cross-site scripting
            /*if(branch_ur.includes(window.location.origin) && (branch_ur.split(/[\?|\&]/).length <= 3)){
            	
            }*/
        }
    };
    $(".branch_locator_input").on("keydown", validationZipCode.zipCodeNumericOnly);
    $(".branch_locator_btn").on("click", validationZipCode.branchBtnClick);
	//user story US-206 fix
	$(".branch_locator_input").on('keyup', function (e) {
		if (e.keyCode == 13) {
			validationZipCode.branchBtnClick(e);
		}
	});
    //Map - Branch locator validation code ends - i39857
});


// Co-Browse - Genesys

function dragElementOnMobile(elmnt) {
    elmnt.addEventListener('touchmove', function(e) {
        e.stopPropagation();
        e.preventDefault();
        // grab the location of touch
        var touchLocation = e.targetTouches[0];

        // assign box new coordinates based on the touch.
        elmnt.style.left = verifyIfBoxIsInsideViewport(elmnt, (touchLocation.clientX - 273), "left") + 'px';
        elmnt.style.top = verifyIfBoxIsInsideViewport(elmnt, (touchLocation.clientY - 38), "top") + 'px';
        savePositionStopShare(elmnt.style.left, elmnt.style.top);
        //.stopPropagation();
    });


    elmnt.addEventListener('touchend', function(e) {
        // current box position.
        //$("html").css("position", "relative");
        var x = parseInt(e.target.style.left);
        var y = parseInt(e.target.style.top);
    });

    $(window).on("orientationchange resize load", function(e) {
        
        var positionStopShare = JSON.parse(sessionStorage.getItem("stopshareposition"));
        var leftTemp, topTemp;
        if(positionStopShare && positionStopShare.left && positionStopShare.top){
            leftTemp = verifyIfBoxIsInsideViewport(elmnt, positionStopShare.left, "left") + 'px';
            topTemp = verifyIfBoxIsInsideViewport(elmnt, positionStopShare.top, "top") + 'px';
            //console.log(positionStopShare.left, leftTemp);
            //console.log(positionStopShare.top, topTemp);
        }
        else{
            leftTemp = verifyIfBoxIsInsideViewport(elmnt, 15, "left") + 'px';
            topTemp = verifyIfBoxIsInsideViewport(elmnt, 15, "top") + 'px';
        }
        elmnt.style.left = leftTemp;
        elmnt.style.top = topTemp;
        //savePositionStopShare(leftTemp, topTemp);
        //console.log(verifyIfBoxIsInsideViewport(elmnt, elmnt.offsetLeft, "left"));
        //console.log(verifyIfBoxIsInsideViewport(elmnt, elmnt.offsetTop, "top"));
    });
}

function savePositionStopShare(left, top) {
    sessionStorage.setItem("stopshareposition", JSON.stringify({left: left.replace("px", ""), top: top.replace("px", "")}));
    //console.log("pos", left.replace("px", ""), top.replace("px", ""));
}

function verifyIfBoxIsInsideViewport(el, value, axis) {
    const padding = 15;
    //value = String(value);
    //value = value.replace("px", "");
    var vp_width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    var vp_height = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    
    if (axis === "left") {
        // not out right
      	// not out left (17 width of scroll bar)
        if (parseInt(value) + el.clientWidth + padding + 17 >= vp_width) {
            return vp_width - padding - 17 - el.clientWidth;
        }        
        if (parseInt(value) - padding <= 0) {
            return padding;
        }

        return value;
    }
    if (axis === "top") {
        // not out bottom
        if (parseInt(value) + el.clientHeight + padding >= vp_height) {
            return vp_height - padding - el.clientHeight;
        }
        // not out top
        if (parseInt(value) - padding <= 0) {
            return padding;
        }

        return value;
    }
    console.log("Please provide an axis (as 3th param)...")
    return value;
}


function dragElement(elmnt) {
    var pos1 = 0,
        pos2 = 0,
        pos3 = 0,
        pos4 = 0;
    if (document.getElementById(elmnt.id + "handle")) {
        // if present, the header is where you move the DIV from:
        document.getElementById(elmnt.id + "handle").onmousedown = dragMouseDown;
    } else {
        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt.style.top = verifyIfBoxIsInsideViewport(elmnt, (elmnt.offsetTop - pos2), "top") + "px";
        elmnt.style.left = verifyIfBoxIsInsideViewport(elmnt, (elmnt.offsetLeft - pos1), "left") + "px";
        savePositionStopShare(elmnt.style.left, elmnt.style.top);
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

// Load Genesys Co-Browsing
var sites = {
    "hello-bank": "https://cobrowse.bnpparibasfortis.be/FWCIJ09/cobrowse",    
    "web-banking": "https://cobrowse.bnpparibasfortis.be/FWCIJ09/cobrowse",               
    "fintro": "https://cobrowse.bnpparibasfortis.be/FWCIJ09/cobrowse",
    "hello-bank-qa": "https://cobrowse.qabnpparibasfortis.be/FWCIJ09/cobrowse", 
    "web-banking-qa": "https://cobrowse.qabnpparibasfortis.be/FWCIJ09/cobrowse", 
    "fintro-qa": "https://cobrowse.qabnpparibasfortis.be/FWCIJ09/cobrowse"
};
var cobrowseConfig = {
    src:   "",
    cbUrl: ""
};
var env = "";
if(document.domain.indexOf('qa') > -1) {
    env = "-qa";
}
if(sfSiteId && sites[sfSiteId + env]) {
    cobrowseConfig.src   = sites[sfSiteId + env] + "/js/gcb.min.js";
    cobrowseConfig.cbUrl = sites[sfSiteId + env];
}
(function(d, s, id, o) {
    var fs = d.getElementsByTagName(s)[0],
        e;
    if (d.getElementById(id)) return;
    e = d.createElement(s);
    e.id = id;
    e.src = o.src;
    e.setAttribute('data-gcb-url', o.cbUrl);
    fs.parentNode.insertBefore(e, fs);
})(document, 'script', 'genesys-js', {
    src: cobrowseConfig.src,
    cbUrl: cobrowseConfig.cbUrl,
});
//console.log("Genesys Loaded !");


$(function() {
    var cbEntryPoint = $("[data-topic='cb.open.popup']");
    if (cbEntryPoint) {
        cbEntryPoint = cbEntryPoint.first();
        $("#cb_inject").removeClass("hide");
        $("#cb_inject").insertAfter(cbEntryPoint);
        cbEntryPoint.addClass("cb_entry");
        cbEntryPoint.parents("li").first().addClass("cb_block");
    }

    // find the element that you want to drag.
    var cbrowse = document.getElementById('cb_stopshare');
	
	if(cbrowse){
	    // Make the DIV element draggable:
		dragElement(cbrowse);
		dragElementOnMobile(cbrowse);
	}
});

//for removing the dialog pop-up 
var myPrimaryMedia = {		
    initializeAsync: function(done){ done();},		
    isAgentConnected: function(){ return true;},		
    sendCbSessionToken: function(token){}		
};

var _genesys = {
    //debug: true,
    buttons: {
        cobrowse: false, // inherited default
    },
    
 // for removing the dialog pop-up
    cobrowse: {
    	primaryMedia : myPrimaryMedia,
        css: {
            browser: true
        },
        disableBuiltInUI: true,
        onReady: function(cobrowseApi) {
            //console.log("Cobrowse initiated !");
            // Open the popup
            $(".cb_entry").on("click", function() {
                if($("html").hasClass("cb_stopshare_open")){
                    return;
                }
                if(!$("html").hasClass("cb_open")){
                    $("html").addClass("cb_open");
                }
                else{
                    $("html").removeClass("cb_open");
                    cobrowseApi.exitSession();
                }
            });

            // Close the popup
            $(".cb_popup .cb_close").on("click", function() {
                $("html").removeClass("cb_open");
                //cobrowseApi.exitSession();
            });
            
            var agentJoinedHandler = function(agent, session) {
                var positionStopShare = JSON.parse(sessionStorage.getItem("stopshareposition"));
                if(positionStopShare && positionStopShare.left && positionStopShare.top){
                    $("#cb_stopshare").css("top", positionStopShare.left + "px").css("left", positionStopShare.top + "px");
                }
                else{
                    $("#cb_stopshare").css("top", "15px").css("left", "15px");
                }
                
                $("html").removeClass("cb_open");
                $("html").addClass("cb_stopshare_open");
                $("html").addClass("blink");
                setTimeout(function() {
                    $("html").removeClass("blink");
                }, 3000);
            };

            var sessionStartedHandler = function(session) {
            	
            	// 'data-gcb-service-node' attribute set to 'true' to hide the stopshare button at agent's end	
            	$(".cb_stopshare").attr("data-gcb-service-node", "true");
                $(".cb_startshare").addClass("hide");
                $(".cb_sharebox").removeClass("hide");
                $(".cb_popup_step1").addClass("hide");
				$(".cb_popup_step2").removeClass("hide");
                $(".cb_sharebox span").html(function() {
                    var token = session.token;
                    if (token.length != 9) {
                        console.log("Token Length is wrong! Please contact support!");
                    }
                    return token.substring(0, 3) + " " + token.substring(3, 6) + " " + token.substring(6, 9);
                });
                if(session.agents.length > 0){
                    agentJoinedHandler();
                }
            }

            // On page load - If there is a session
            cobrowseApi.onInitialized.add(function(session) {
                if (!session) {
                    //console.log("No session yet");
                } else {
                    sessionStartedHandler(session);
                }
            });

            // When session is started - Clicking on share button
            cobrowseApi.onSessionStarted.add(sessionStartedHandler);

            // When agent joins my session
            cobrowseApi.onAgentJoined.add(agentJoinedHandler);

            var closeStopshare = function() {
                $("html").removeClass("cb_stopshare_open");
                $(".cb_startshare").removeClass("hide");
                $(".cb_sharebox").addClass("hide");
				$(".cb_popup_step1").removeClass("hide");
				$(".cb_popup_step2").addClass("hide");
            };
            // When user click on stop session
            $(".cb_stopshare .cb_stopsharebutton").on("click", function() {
                cobrowseApi.exitSession();
                closeStopshare();
            });

            // When use click on start share - Start session
            $(".cb_popup .cb_startshare button").on("click", function() {
                cobrowseApi.startSession();
            });

            cobrowseApi.onSessionEnded.add(function(details) {
                var cbEndedMessages = {
                    self: 'You exited Co-browse session. Co-browse terminated',
                    external: 'Co-browse session ended',
                    timeout: 'Co-browse session timed out',
                    inactivityTimeout: 'Agent did not join. Closing Co-browse session.',
                    serverUnavailable: 'Could not reach Co-browse server',
                    sessionsOverLimit: 'Agent is busy in another Co-browse session'
                };
                closeStopshare();
                //alert(cbEndedMessages[details.reason] || 'Something went wrong. Co-browse terminated.');
            });
        }
    }
};


/* FocusFlow MobileFirst */
$(function(){
	$(".focusflow-topnav__closebutton").on("click", function(e){
		e.preventDefault();
		PageBus.publish("mf.focusflow.close.clicked", "");
	});
});