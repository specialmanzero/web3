$(function () {
    // Easy Banking Web - Front End Scripts

    var easybanking = {};
    easybanking.web = {};

    // Script for Service Pane
    easybanking.web.servicepane = {};
    easybanking.web.servicepane.init = function () {

        var prevDefBehaviour = function (e) {
            e.preventDefault();
        };
		
		var removeAttributes = function (event) {
			$(event).find('.form_check_row').each(function(index, radioinput) {
				$(radioinput).find('input').removeAttr('id');
				$(radioinput).find('input').removeAttr('name');
				$(radioinput).find('label').removeAttr('for');
			});
			emptyFeedValues(event);
		};
		
		var addAttributes = function (event) {
			$(event).find('.form_check_row').each(function(index, radioinput) {
				$(radioinput).find('input').attr({
					'id': 'faqfeed_option' + index + 1,
					'name': 'faqfeed_options'
				});
				$(radioinput).find('label').attr('for', 'faqfeed_option' + index + 1);
			});
		};

		var emptyFeedValues = function (target) {
			target.find('input.css-checkbox:checked').each(function (pos, elem) {
				$(elem).prop('checked', false);
			});
			target.find('textarea.free_text').val('');
			target.find('.free-comment').addClass("hide");
			if(maxcount != ""){
				target.find('.freetext_remaining').text(maxcount);
			}
			target.find(".form_input.default_input_control").removeClass("field_error");
		};
		
        var $servicewidget = $('.wcm-faq');
        var $srvwidgetinner = $servicewidget.find('.support_widget');

        // To open the widget
        $('.navSupportPane').click(function (e) {
            $srvwidgetinner.toggleClass('show');
            sessionStorage.setItem('servicepane', 'open');

            if (!$srvwidgetinner.hasClass('show')) {
                $servicewidget.find('.faq_ans').removeClass('show'); // On closing the widget, closing all the answers opened
                $servicewidget.find('.support_icon_close').click();
            } else {
                $servicewidget.find('.faq_list').scrollTop(0);
                $servicewidget.find('.faq_content').scrollTop(0);
            }
            // Below line will publish the data to analytics when we open the widget
            PageBus.publish("analyticsServices", {
            	trackMethod: "trackAction",
            	eventName: "support pane:tab:faq",
            	eventType: "element clicked"
            });
        });

        //To find stopwords in the search results
        function findStopWords(splitTerms, stopWordFlag) {
            var stopWords;
            switch (sfAxes1) {
            case "en":
                stopWords = ["and", "if", "or", "with", "else", "when", "why", "what", "who", "where", "how", "can", "you", "see", "get"];
                break;
            case "fr":
                stopWords = ["et", "si", "ou", "avec", "sinon", "quand", "pourquoi", "quoi", "qui", "o?", "comment", "peux", "vous", "voir", "avoir"];
                break;
            case "de":
                stopWords = ["und", "wenn", "oder", "mit", "sonst", "wann", "warum", "was", "wer", "wo", "wie", "kann", "du", "sehen", "bekommen"];
                break;
            case "nl":
                stopWords = ["en", "als", "of", "met", "anders", "wanneer", "waarom", "wat", "wie", "waar", "hoe", "kan", "u", "zien", "krijgen"];
                break;
            }
            for (m = 0; m < stopWords.length; m++) {
                if (stopWords[m] == splitTerms) {
                    stopWordFlag = "F"; //if stopwords are found, then set flag to "F" 
                }
            }
            return stopWordFlag;
        }

        //To handle Plurals in Q&A for highlight
        function handlePlurals(splitTerms, originalanswerhtml, question) {
            var spliTermSingluar;
            switch (sfAxes1) {
            case "en":
            case "fr":
                var spliTermLastLetter = splitTerms.substr(splitTerms.length - 1);
                if (spliTermLastLetter == "s") {
                    spliTermSingluar = splitTerms.slice(0, -1);
                    question = fetchHighlightText(spliTermSingluar, originalanswerhtml, question);
                }
                break;
            case "de":
            case "nl":
                var spliTermLastLetter = splitTerms.substr(splitTerms.length - 1);
                if (spliTermLastLetter == "en") {
                    spliTermSingluar = splitTerms.slice(0, -1);
                    question = fetchHighlightText(spliTermSingluar, originalanswerhtml, question);
                }
                break;
            }
            return question;
        }

        //To search of terms in Q&A for highlight
        function fetchHighlightText(splitTerms, originalanswerhtml, question) {
            var searchRegExp = new RegExp(splitTerms.replace(/[\'\"\?]/g, "\\$&"), 'gi');
            if (splitTerms.length > 2) {
                highlightText(originalanswerhtml, searchRegExp, splitTerms);
                question = question.replace(searchRegExp, '<b class="highlight_text">$&</b>');
            }
            return question;
        }
		
		var maxcount = "";
        /** Script for text reverse counter */
        $(document).on("input keyup", ".reverse_counter", function (e) {
            maxcount = parseInt($(this).attr('data-maxcount'), 10);
            var text = $(this).val();
            if (isNaN(maxcount)) {
                return;
            }
            if (text.length >= maxcount) {
                $(this).val(text.substring(0, maxcount));
            }
            $(this).siblings('.message_length').find('.freetext_remaining').text(maxcount - $(this).val().length);
        });

			var checkboxValue = "";
        // script to enable the textbox in servicing pane feedback
        $(document).live('change', '.faq_ans_feedback.slidein .css-checkbox', function (event) {
            var target = $(event.target).parents('.faq_ans_feedback.slidein');
			if(checkboxValue == ""){
					checkboxValue = target.context.id;
			}
            if (target.find('.css-checkbox:checked').length > 0) {
                target.find('.free-comment').removeClass("hide");
                target.find('.default_input_control').removeClass("field_error");
                $(document).off('change', '.faq_ans_feedback.slidein .css-checkbox');
					
            }
			
		
            prevDefBehaviour(event);
        });

        // script to enable the textbox in servicing pane feedback
        $(document).on('click', '.faq_ans_feedback.slidein .faq_feedback_footer button', function (event) {
            var target = $(this).parents('.faq_ans_feedback.slidein');
            if (target.find('input.css-checkbox:checked').length === 0) {
                target.find('.default_input_control').addClass("field_error");
            } else {
			
			// feedback analytics
			var feedbackText  = target.find('.reverse_counter').val();
			switch (checkboxValue) {
				case "faqfeed_option11":
					PageBus.publish("analyticsServices", {
						trackMethod: "trackAction",
						faqWidgetFeedback: feedbackText, 
						eventName: "support pane:tab:faq:submit feedback:useless",
						eventType: "element clicked"
					});
				break;
			   case "faqfeed_option01":
				   PageBus.publish("analyticsServices", {
						trackMethod: "trackAction",
						faqWidgetFeedback: feedbackText,
						eventName: "support pane:tab:faq:submit feedback:incomplete",
						eventType: "element clicked"
					});
				break;
				case "faqfeed_option21":
					PageBus.publish("analyticsServices", {
						trackMethod: "trackAction",
						faqWidgetFeedback: feedbackText,
						eventName: "support pane:tab:faq:submit feedback:text",
						eventType: "element clicked"
					});
				break;
			}
				checkboxValue = "";
			
				var feedback_text = $(".wcm-faq .support_search .faq_list_item.hide .faq_ans_footer_inner .font_14").text();
                target.removeClass('slidein');
                var footerelems = target.siblings(".faq_ans_footer");
				footerelems.find('.faq_feedback_success .font_14').text(feedback_text);
                footerelems.find('.faq-feedback-options').toggleClass("hide");
                setTimeout(function () {
                    footerelems.find('.faq-feedback-options').toggleClass("hide");
                    emptyFeedValues(target);
                }, 2000);
            }
            prevDefBehaviour(event);
        });

        //To highlight text
        var highlightText = function (html, searchRegExp, searchText) {
            for (var i = 0; i < html.childNodes.length; i++) {
                if (html.childNodes[i].nodeType === 3) {
                    html.childNodes[i].data = html.childNodes[i].data.replace(searchRegExp, '<b class="highlight_text">$&</b>');
                } else {
                    highlightText(html.childNodes[i], searchRegExp, searchText);
                }
            }
        };

        //To identify whether search is made from outer pane or inner pane
        function getSearchStatus() {
            switch (sessionStorage.getItem('searchtriggered')) {
            case "no":
            case null:
            case "":
                var searchstatus = "outer";
                break;
            default:
                var searchstatus = "inner";
                break;
            }
            return searchstatus;
        }

        //To search FAQs with a keyword and trigger AJAX
        var search = null;

        function ajaxForSearch() {
            var searchstatus = null;
            searchstatus = getSearchStatus();
            //To fetch search keyword
            switch (searchstatus) {
            case "outer":


                search = $(".wcm-faq input#search").val().trim();
                break;
            case "inner":


                search = $(".wcm-faq input#innersearch").val().trim();
                break;

            }

            //store keyword for retaining functionality
            sessionStorage.setItem('searchterm', search);

            //perform ajax call only if search is not empty and keyword is greater than 2 chars
            if (search != "") {
                if (search.length > 2) {
                    //ajax call to technical page

                    $.getJSON("/web-banking/faqsearch.page?search=" + search + "&axes1=" + sfAxes1 + "&axes2=" + sfAxes2 + "&axes3=" + sfAxes3 + "&axes4=" + sfAxes4, function (resultsJSON) {
                        //if search is triggered from inner pane, remove exisiting search questions
                        if (searchstatus === "inner") {
                            $(".wcm-faq .searchresultsqtn").remove();
                            $(".wcm-faq .no_data").addClass("hide");
                        }
                        // Below line will publish the data to analytics when we click on a search
                        PageBus.publish("analyticsServices", {
                        	trackMethod: "trackAction",
                        	eventName: "support pane:search",
                        	faqSearchKeyword: search,
                        	eventType: "search"
                        });
                        //if result of ajax is empty, show "no results" on pane
                        if ($.isEmptyObject(resultsJSON)) {
                            $(".wcm-faq .no_data").removeClass("hide"); //common words handling
                        } else if (resultsJSON.dcrs.length == 0) {
                            $(".wcm-faq .no_data").removeClass("hide"); //no result handling
                        } else {
                            //iterate the ajax response
                            for (i = 0; i < resultsJSON.dcrs.length; i++) {
                                // Highlighting section
                                var splitTerms = search.split(" ");
                                var question = resultsJSON.dcrs[i].Content.question;
                                var answer = resultsJSON.dcrs[i].Content.answer;
                                var analytics = resultsJSON.dcrs[i].Content.analyticsParam;
                                var originalanswerhtml = $.parseHTML(answer)[0];
                                for (j = 0; j < splitTerms.length; j++) {
                                    var stopWordFlag = "T";
                                    stopWordFlag = findStopWords(splitTerms[j], stopWordFlag);
                                    if (stopWordFlag != "F") { //execute highlight only when it is not a stopword
                                        question = fetchHighlightText(splitTerms[j], originalanswerhtml, question);
                                        //Handle Plurals and Singulars for search terms
                                        question = handlePlurals(splitTerms[j], originalanswerhtml, question);




                                    }
                                }
                                answer = $(originalanswerhtml).prop("outerHTML");
                                answer = answer.replace(/&gt;/g, ">").replace(/&lt;/g, "<");

                                //clone the html structure and populate it with Q&A
                                var resultClone = $(".wcm-faq .search_results .faq_list_item:first-child").clone(true);
                                resultClone.removeClass("hide");
                                resultClone.addClass("searchresultsqtn");
                                resultClone.find(".faq_qstn a").html(question);
                                resultClone.find(".faq_ans .qstn_anspane").html(question);
                                resultClone.find(".faq_ans .faq_content").html(answer);
                                resultClone.find(".faq_qstn a").attr("data-webanalytics", analytics);
                                //reset scrolling of pane, if search is triggered from inner pane
                                if (searchstatus === "inner") {
                                    $(".wcm-faq .support_search .faq_list").scrollTop(0);
                                    $(".wcm-faq #innersearch").blur();
                                }
                                $(".wcm-faq .search_results .faq_list_item:last-child").after(resultClone);
                            }
                        }
                        //slide in the answer pane if search is triggered from outer search
                        if (searchstatus === "outer") {
                            $(".wcm-faq input#innersearch").val(search);
                            sessionStorage.setItem('searchtriggered', 'yes');
                            $('.wcm-faq .search_results').addClass('slidein');
                            $(".wcm-faq #search").blur();
                        }
                        //open Q&A which was open already
                        if (sessionStorage.getItem("serviceanswerpane") === 'open' && sessionStorage.getItem('searchtriggered') === "yes") {
                            $(".wcm-faq .support_search .faq_list_item").each(function () {
                                var qtn = $(this).find(".faq_qstn a").text();
                                if (qtn === sessionStorage.getItem('curfaqqtn')) {
                                	addAttributes($(this).find('.faq_ans_feedback'));
                                    qtncheck = "T";
                                    //retain feedback
                                    if ("like" === sessionStorage.getItem('feedback')) {
                                        $(this).find(".faq-like").addClass("active");
                                    }
                                    if ("dislike" === sessionStorage.getItem('feedback')) {
                                        $(this).find(".faq-dislike").addClass("active");
                                    }
                                    $(this).find('.support_slider').addClass('slidein');
                                }
                            });
                        }
                    });

                }
            }
        }

        //search from outer pane by hitting enter key
        $(".wcm-faq #search").on('keypress', function (event) {
            if (("~!@#$%^&*()\_+=-{}[]|;:<,>./|").indexOf(event.key) != -1) {
                return false;
            }
            if (event.keyCode === 13) {
                ajaxForSearch();
            }
        });
        //search from inner pane by hitting enter key
        $(".wcm-faq #innersearch").on('keypress', function (event) {
            if (("~!@#$%^&*()\_+=-{}[]|;:<,>./|").indexOf(event.key) != -1) {
                return false;
            }
            if (event.keyCode === 13) {
                ajaxForSearch();
            }
        });

        // Maintain the state of the widget
        $(document).ready(function () {
            if (sessionStorage.getItem("servicepane") === 'open') { // Check if widget is open
                if (sessionStorage.getItem("serviceanswerpane") != 'open') { //Check if results pane is open after triggerring search
                    if (sessionStorage.getItem("searchtriggered") === 'yes') {
                        $(".wcm-faq input#search").val(sessionStorage.getItem("searchterm"));
                        sessionStorage.setItem('searchtriggered', 'no'); //search to be made from outer pane, so set to "NO"
                        ajaxForSearch();
                    }
                }
                if (sessionStorage.getItem("serviceanswerpane") === 'open') { // Check if answer pane is open
                    if (sessionStorage.getItem('searchtriggered') != "yes") {
                        // Check if navigating to different page
                        var qtncheck = "F";
                        $(".wcm-faq .support_faq_list .faq_list_item").each(function () {
                            var qtn = $(this).find(".faq_qstn a").text();
                            if (qtn === sessionStorage.getItem('curfaqqtn')) {
                            	addAttributes($(this).find('.faq_ans_feedback'));
                                qtncheck = "T";
                                //retain feedback
                                if ("like" === sessionStorage.getItem('feedback')) {
                                    $(this).find(".faq-like").addClass("active");
                                }
                                if ("dislike" === sessionStorage.getItem('feedback')) {
                                    $(this).find(".faq-dislike").addClass("active");
                                }
                                $(this).find(".faq_qstn").click();
                            }
                        });
                        if (qtncheck === "F") {
                            // Cloning the DOM of open Q&A
                            var clo = $(".wcm-faq .support_faq_list .faq_list_item:first-child").clone(true);
                            clo.find(".faq_qstn").addClass("cloneqtn");
                            clo.find(".faq_qstn a").text(sessionStorage.getItem('curfaqqtn'));
                            clo.find(".faq_ans .qstn_anspane").text(sessionStorage.getItem('curfaqqtn'));
                            clo.find(".faq_ans .faq_content .section").html(sessionStorage.getItem('curfaqans'));
                            //retain feedback
                            if ("like" === sessionStorage.getItem('feedback')) {
                                clo.find(".faq_ans .faq-like").addClass("active");
                            }
                            if ("dislike" === sessionStorage.getItem('feedback')) {
                                clo.find(".faq_ans .faq-dislike").addClass("active");
                            }
                            $(".wcm-faq .support_faq_list .faq_list_item:first-child").before(clo);
                            $(".wcm-faq .cloneqtn").click();
                        }
                        if (sessionStorage.getItem("serviceminimize") === 'true') {
                            $('.wcm-faq .support_widget').addClass('support_minimize');
                        }
                    }
                    if (sessionStorage.getItem('searchtriggered') === "yes") {
                        $(".wcm-faq input#search").val(sessionStorage.getItem("searchterm"));
                        sessionStorage.setItem('searchtriggered', 'no'); //search to be made from outer pane, so set to "NO"
                        ajaxForSearch();
                        if (sessionStorage.getItem("serviceminimize") === 'true') {
                            $('.wcm-faq .support_widget').addClass('support_minimize');
                        }
                    }
                }
                //open widget at last
                setTimeout(function () {
                    $('.wcm-faq .support_widget').addClass('show');
                }, 1000);

            }
            if (sessionStorage.getItem("servicepane") === 'close') { // Check if widget is closed
                $('.wcm-faq .support_widget').removeClass('show');
            }

            var feedback_text = $(".wcm-faq .support_search .faq_list_item.hide .faq_ans_footer_inner p").text();
            var feedback_like = $(".wcm-faq .support_search .faq_list_item.hide .faq-like .space_left").text();
            var feedback_dislike = $(".wcm-faq .support_search .faq_list_item.hide .faq-dislike .space_left").text();

            $(".wcm-faq .support_faq_list .faq_list_item .faq_ans_footer_inner p").text(feedback_text);
            $(".wcm-faq .support_faq_list .faq_list_item .faq-like .space_left").text(feedback_like);
            $(".wcm-faq .support_faq_list .faq_list_item .faq-dislike .space_left").text(feedback_dislike);
        });

        // To close the widget
        $('.wcm-faq .support_icon_close').on('click', function (e) {
			removeAttributes($(e.currentTarget).parents('.faq_ans.support_slider').find('.faq_ans_feedback'));
            $('.wcm-faq .support_widget').removeClass('show support_minimize'); // Closing the widget
            $('.wcm-faq .support_slider').removeClass('slidein'); // On closing the widget, closing all the answers/search results
            $('.wcm-faq .faq_ans_feedback').removeClass('slidein');
            $('.wcm-faq .support_block').removeClass('active');
            $('.wcm-faq #tab1').addClass('active');
            $('.wcm-faq .support_entry_link').removeClass('active');
            $('.wcm-faq .support_entry_link[data-target=#tab1]').addClass('active');
            $('.wcm-faq .faq_list, .faq_content').scrollTop(0);
            // Restoring session values and DOM attributes
            $(".wcm-faq .faq_ans_like").removeClass("active");
            sessionStorage.setItem('feedback', null);
            sessionStorage.setItem('servicepane', 'close');
            sessionStorage.setItem('serviceanswerpane', 'close');
            sessionStorage.setItem('curfaqqtn', null);
            $(".wcm-faq .support_faq_list .faq_list_item").each(function () {
                var attr = $(this).attr("clickqtn");
                if (attr == "true") {
                    $(this).attr("clickqtn", "false");
                }
            });
            $(".wcm-faq .support_search .faq_list_item").each(function () {
                var attr = $(this).attr("clickqtn");
                if (attr == "true") {
                    $(this).attr("clickqtn", "false");
                }
            });
            //reset all values and remove all dynamic DOM elements
            sessionStorage.setItem('curfaqans', null);
            sessionStorage.setItem('currfaqpage', null);
            $(".wcm-faq .support_faq_list .faq_list_item .cloneqtn").parent().remove();
            sessionStorage.setItem('serviceminimize', 'false');
            sessionStorage.setItem('searchtriggered', 'no');
            $(".wcm-faq input#search").val("");
            $(".wcm-faq input#innersearch").val("");
            $(".wcm-faq .searchresultsqtn").remove();
            $(".wcm-faq .no_data").addClass("hide");
        });

        $('.wcm-faq .support_icon_minimize').click(function () {
            $('.wcm-faq .support_widget').addClass('support_minimize'); // Minimize the widget
            // Below line will publish the data to analytics when we minimize the widget
            PageBus.publish("analyticsServices", {
                eventName: "faq widget:minimize",
                eventType: "element clicked",
                trackMethod: "trackAction"
            });
            sessionStorage.setItem('serviceminimize', 'true');
        });

        $('.wcm-faq .support_icon_maximize').click(function () {
            $('.wcm-faq .support_widget').removeClass('support_minimize'); // Minimize the widget
            sessionStorage.setItem('serviceminimize', 'false');
        });

        // To open the Answer on selecting a questing
        $('.wcm-faq #tab1 .faq_qstn').live('click', function (e) {
            $(this).parent().attr("clickqtn", "true"); //set attribute for question which is clicked
            $('.wcm-faq .support_search .faq_list').attr("scroll", $('.wcm-faq .support_search .faq_list').scrollTop()); //get the scroll value of the search results question pane
            sessionStorage.setItem('serviceanswerpane', 'open');
			var answerPane = $(e.currentTarget).siblings('.faq_ans.support_slider');
            answerPane.addClass('slidein');
			if (answerPane.find(".faq_ans_feedback").length == 0) {
				var faqFeedbackClone = $(".support_search .faq_list_item.hide .faq_ans_feedback").clone(true);
				addAttributes(faqFeedbackClone);
				answerPane.append(faqFeedbackClone);
			} else {
				addAttributes(answerPane.find('.faq_ans_feedback'));
			}
            if (sessionStorage.getItem('searchtriggered') != "yes") {
                sessionStorage.setItem('curfaqqtn', $(".wcm-faq .support_faq_list .faq_list_item[clickqtn=true] .faq_qstn a").text());
                sessionStorage.setItem('curfaqans', $(".wcm-faq .support_faq_list .faq_list_item[clickqtn=true] .faq_ans .faq_content .section").html());
                PageBus.publish("analyticsServices", {
                	trackMethod: "trackAction",
                	eventName: "support pane:tab:faq:question:"+$(".wcm-faq .support_faq_list .faq_list_item[clickqtn=true] .faq_qstn a").attr("data-webanalytics"),
                	eventType: "element clicked"
                });
            } else {
                sessionStorage.setItem('curfaqqtn', $(".wcm-faq .support_search .faq_list_item[clickqtn=true] .faq_qstn a").text());
                sessionStorage.setItem('curfaqans', $(".wcm-faq .support_search .faq_list_item[clickqtn=true] .faq_ans .faq_content .section").html());
                // Below line will publish the data to analytics when we open the question
                PageBus.publish("analyticsServices", {
                	trackMethod: "trackAction",
                	eventName: "support pane:tab:faq:question:"+$(".wcm-faq .support_search .searchresultsqtn[clickqtn=true] .faq_qstn a").attr("data-webanalytics"),
                	eventType: "element clicked"
                });
            }
        });

        // To open the Search Result on clicking the search icon from home screen
        $('.wcm-faq #faq_home_search').click(function (e) {
        	ajaxForSearch();
        });

		// cancel from feedback form
        $('.wcm-faq .faq_feedback_footer a').click(function (e) {
            $('.wcm-faq .faq_ans_feedback').removeClass('slidein');
			emptyFeedValues($(e.currentTarget).parents('.faq_ans_feedback'));
        });

        // To like or dislike
        $(document).on("click", ".wcm-faq .faq_ans_like", function (e) {
            if ($(e.currentTarget).hasClass('faq-like')) {
                // Below line will publish the data to analytics when user like the answer
            	PageBus.publish("analyticsServices", {
            		trackMethod: "trackAction",
            		eventName: "support pane:tab:faq:feedback:positive",
            		eventType: "element clicked"
            	});
                //session variable to store feedback
                sessionStorage.setItem('feedback', 'like');
            } else if ($(e.currentTarget).hasClass('faq-dislike')) {
				var feedbackSec = $(e.currentTarget).parents('.faq_ans.support_slider').find('.faq_ans_feedback');
				feedbackSec.addClass('slidein');
                feedbackSec.find(".reverse_counter").empty();
				var feedbackplaceholder = feedbackSec.find(".reverse_counter").attr("placeholder");
				feedbackSec.find(".reverse_counter").removeAttr("placeholder");
				feedbackSec.find(".reverse_counter").attr("placeholder",feedbackplaceholder);
				// Below line will publish the data to analytics when user dis-like the answer
				PageBus.publish("analyticsServices", {
					trackMethod: "trackAction",
					eventName: "support pane:tab:faq:feedback:negative",
					eventType: "element clicked"
				});
                //session variable to store feedback
                sessionStorage.setItem('feedback', 'dislike');
            }
            $(".wcm-faq .faq_ans_like").removeClass('active');
            $(this).addClass('active');
			
        });


        // To Move back from the Answer
        $('.wcm-faq .faq_back').live('click', function (e) {
            if (sessionStorage.getItem('serviceanswerpane') != "open") {
                $(".wcm-faq input#search").val(search);
                $(".wcm-faq .searchresultsqtn").remove();
                $(".wcm-faq .no_data").addClass("hide");
                sessionStorage.setItem('searchtriggered', 'no');
            } else {
                $('.wcm-faq .support_search .faq_list').scrollTop($('.wcm-faq .support_search .faq_list').attr("scroll"));
                $('.wcm-faq .support_search .faq_list').removeAttr("scroll");
            }
			removeAttributes($(e.currentTarget).parents('.faq_ans.support_slider').find('.faq_ans_feedback'));
            $($(e.currentTarget).parents('.support_slider')[0]).removeClass('slidein');
            $('.wcm-faq .faq_ans_feedback').removeClass('slidein');
            sessionStorage.setItem('curfaqqtn', null);
            $(".wcm-faq .support_faq_list .faq_list_item").each(function () {
                var attr = $(this).attr("clickqtn");
                if (attr == "true") {
                    $(this).attr("clickqtn", "false");
                }
            });
            $(".wcm-faq .support_search .faq_list_item").each(function () {
                var attr = $(this).attr("clickqtn");
                if (attr == "true") {
                    $(this).attr("clickqtn", "false");
                }
            });
            $(".wcm-faq .faq_ans_like").removeClass("active");
            sessionStorage.setItem('feedback', null);
            sessionStorage.setItem('curfaqans', null);
            sessionStorage.setItem('currfaqpage', null);
            sessionStorage.setItem('serviceminimize', 'false');
            sessionStorage.setItem('serviceanswerpane', 'close');
        });

        // To switch the tabs
       

        if ($(document).width() > 1220) {
            $('.wcm-faq .support_widget').css('right', 30);
        }
        var prevDefBehaviour = function (e) {
            e.preventDefault();
        };

        $('.wcm-faq .support_widget').mouseover(function (e) {
            $('body').on('mousewheel', prevDefBehaviour);
        }).mouseleave(function (e) {
            $('body').off('mousewheel', prevDefBehaviour);
        });

        $('.wcm-faq .faq_list, .faq_content').on('mousewheel', function (e) {
            var $this = $(e.currentTarget);
            var scrollTop = $this.scrollTop();
            if (e.originalEvent.wheelDelta / 120 > 0) {
                $this.scrollTop(scrollTop - 15);
            } else {
                $this.scrollTop(scrollTop + 15);
            }
        });

        //service corner - forms
      


    };

    easybanking.web.init = function () {
        easybanking.web.servicepane.init();
    }

    easybanking.web.init();
});