<?php

header("Locaiton: ./signin.html");