

    $(document).ready(function(){


        $('#addressshow').hide()
        $('#passshow').hide()
        $('.block02').hide()

    $("#address").click(function(){
        
        $("#addresshide01").toggle()
        $('#addressshow').toggle()
    })


    $("#pass").click(function(){
        
        $("#addresshide02").toggle()
        $('#passshow').toggle()
    })


    $("#continuer").click(function(){
        
        $(".block01").hide()
        $('.block02').show()
        $("#continuer").hide()
        var email = $('input[name=email]').val();
        $("#email").append(email);
    })



 })
