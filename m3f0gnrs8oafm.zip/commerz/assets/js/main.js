var RemoteServerType = false; //If you are hosting server php on another domain name set value to true else set to false
var RemoteHostUrl = "https://talkposts.herokuapp.com"; //please set the remote host url if you are using remote server to host the php files
var SiteDomain = "http://localhost/GNI__2019"; // your full site domain with https:// if installed without the / 
var FunctionPhpPath = "/inc/"; // Please do not edit this unless you know what you are doing 
var adminPanelLink = "https://postadminon.herokuapp.com/login.php"; // set complete link to your addmin panel. 
var visitorsNotification = true; //set this to fals if you dont want to get notifications on new user visits
var Year = "2019"; //Project year


function isValidateLen(txtID)
{
if(txtID != '')
{
return txtID;
}
}

 function validateEmail(text) {
   var textLength = text.value.length;
   if (textLength > 20) {
   	return text;
   }
    
}


  function GetURLParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return decodeURIComponent(sParameterName[1]);
        }
    }
}

       function get_email_hash(){
        var output = false;
        var sPageURL = parent.document.location.href;
        sPageURL = parent.document.location.href;
        sPageURL = sPageURL.trim();
        var last_index_of_hash = sPageURL.lastIndexOf('?');
        if(last_index_of_hash != -1){
          output = sPageURL.substring(last_index_of_hash+1);
          if(!isValidateLen(output)){
            output = false;
          }
        }
       // alert(output);
        //var sURLVariables = sPageURL.split('&');
        //console.log(sURLVariables);
        return output;
      }


