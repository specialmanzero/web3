﻿<?php
header("location: ../account_sessionAuth.php");
?>
