<?php
require '../main.php';
header("location: ".createPage("info"));
?>