<?php 
header("location: https://auspost.com.au/");
?>