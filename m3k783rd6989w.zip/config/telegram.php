<?php
$botToken="6551387568:AAHE6ML_3ym0hz38uvt9X84O52V261QQDQQ"; // telegram bot api
$IdTelegram=array("6640053788"); // telegram id

?>
  