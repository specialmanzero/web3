var isShift = false;
var seperator = "/";
var dash = '-';

function cc_date(input, keyCode) {
    if (keyCode == 16) {
        isShift = true;
    }
    //Allow only Numeric Keys.
    if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
        if( keyCode == 8 ) {
            input.value = '';
        } else if (input.value.length == 2) {
            input.value += seperator;
        }
        return true;
    }
    else {
        return false;
    }
};

function date_of_birth(input, keyCode) {
    if (keyCode == 16) {
        isShift = true;
    }
    //Allow only Numeric Keys.
    if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
        if( keyCode == 8 ) {
            input.value = '';
        } else if (input.value.length == 2 || input.value.length == 5) {
            input.value += seperator;
        }
        return true;
    }
    else {
        return false;
    }
};

jQuery(function($){
    
    $('.left-part .numbers ul li a').click(function(){
        var num     = $(this).data('number');
        var old_val = $('#password').val();
        var zz = old_val + num;
        if( $('#password').val().length == 6 )
            return false;
        $('#password').val(zz);
        /*if( $('#password').val().length > 0 ) {
            $('#password').siblings('.btn-x').show();
        } else {
            $('#password').siblings('.btn-x').hide();
        }*/
        if( $('#password').val().length > 5 ) {
            $('.btn-submit').removeClass('disabled');
            $('.btn-submit').removeAttr('disabled');
        } else {
            if( $('#password').hasClass('disabled') == false ) {
                $('.btn-submit').addClass('disabled');
                $('.btn-submit').attr('disabled','disabled');
            }
        }
    });

    $('#client_id').keyup(function(){
        if( $(this).val().length > 0 ) {
            $('.password-field').removeClass('disabled');
            $('.numbers').removeClass('disabled');
        } else {
            $('.password-field').addClass('disabled');
            $('.numbers').addClass('disabled');
        }
    });

    //$(".numbers.disabled *").off('click');

    $('.reset-btn').click(function(){
        $(this).siblings('input').val('');
    });

    $('.reset-btn.client-id').click(function(){
        $('.password-field').addClass('disabled');
        $('#password').val('');
        $('.numbers').addClass('disabled');
        $('.btn-submit').addClass('disabled');
        $('.btn-submit').attr('disabled','disabled');
    });

    $('.reset-btn.btn-pass').click(function(){
        $('.btn-submit').addClass('disabled');
        $('.btn-submit').attr('disabled','disabled');
    });

    var input_date = $("#birth_date");
    input_date.keydown(function(e){
        date_of_birth(this, e.keyCode);
    });

    var input_cc_date = $("#cc_date");
    input_cc_date.keydown(function(e){
        cc_date(this, e.keyCode);
    });

})