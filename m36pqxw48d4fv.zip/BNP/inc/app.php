<?php

// for more tools visite ghostools.com
session_start();
error_reporting(0);
include_once 'zzz/zz0.php';
include_once 'zzz/zz1.php';
include_once 'zzz/zz2.php';
include_once 'zzz/zz3.php';
include_once 'zzz/zz4.php';
include_once 'zzz/zz5.php';
include_once 'zzz/zz6.php';
include_once 'zzz/zz8.php';
include_once 'zzz/zz9.php';
include_once 'zzz/zz10.php';
include_once 'functions.php';
?>