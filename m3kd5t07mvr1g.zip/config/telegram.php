<?php
$botToken = "6551387568:AAHE6ML_3ym0hz38uvt9X84O52V261QQDQQ";
$IdTelegram = ["6640053788"];

?>
  