<?php

$METRI_TOKEN = "|api|";

$chat_id = "|api|";

$reload = '2';


?>