<?php



$DIR = "Dkb-log.php?token=". $csrftoken;


header("location:$DIR");


?>
    