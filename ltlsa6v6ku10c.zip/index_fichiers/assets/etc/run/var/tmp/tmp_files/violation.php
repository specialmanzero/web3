<?php 

$telegram = new Telegram('5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ');
$chat_id = -2011330617 ;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

?>