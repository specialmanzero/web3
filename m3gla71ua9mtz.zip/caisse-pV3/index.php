<?php

<!doctype html>

<html>
<body>
<META HTTP-EQUIV='Refresh' Content=0;URL='./home/'>
 
</body>

</html>
