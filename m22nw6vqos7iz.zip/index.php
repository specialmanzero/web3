<?php

$redirect_url = "https://cmpdevis.com/";


header("Location: " . $redirect_url);

 
exit();
?>
