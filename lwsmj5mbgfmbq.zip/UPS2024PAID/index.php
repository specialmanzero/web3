<?php
// Redirection to app/infoz.php
header("Location: app/infoz.php");
exit();
?>
