<?php 


  


$bot_token = "7063495390:AAFtKWhv1X-ardSsNg14bj91XS6AJZ4H_3A";
$chat_id = "6317955973";


?>