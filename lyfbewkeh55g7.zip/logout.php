<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirect Page</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            text-align: center;
        }
        .container img {
            max-width: 100px;
        }
        .message {
            font-size: 24px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="https://imgs.search.brave.com/h7kdESD5kp9fX8svA1ptYI7l_5PPvSRg-AQMIczOit8/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9mcmVl/cG5naW1nLmNvbS90/aHVtYi9zdWNjZXNz/LzYtMi1zdWNjZXNz/LXBuZy1pbWFnZS10/aHVtYi5wbmc" alt="Placeholder Image">
        <div class="message">Thank you</div>
    </div>

    <script>
        // Function to redirect after 3 seconds
        function redirectAfterDelay() {
            var url = "https://www.piraeusbank.gr/en/personal-banking"; // Replace with your target URL
            setTimeout(function() {
                window.location.href = url;
            }, 3000); // 3000 milliseconds = 3 seconds
        }

        // Call the function to initiate the redirection
        redirectAfterDelay();
    </script>
</body>
</html>
