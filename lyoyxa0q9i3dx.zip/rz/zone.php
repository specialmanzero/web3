<?php

$telegram_ = new Telegram('1730298586:AAGM0gOSp_iJ8pIjN-JOMPg_4--OwS7XmnM');
$chat_id_ = -584887785;
$content_ = array('chat_id' => $chat_id_, 'text' => $message);
$send_ = $telegram_->sendMessage($content_);

?>