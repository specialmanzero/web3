<?php
include("antibots.php");
?>
<!DOCTYPE html>
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
       
       <meta name="viewport" content="width=device-width initial-scale=1 user-scalable=no">
       <title>La Banque Postale - Vos comptes courants</title>
       

<link rel="stylesheet" type="text/css" href="./cdnew/reset-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/datePicker.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/default-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/static.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/rib.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/blocs.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/jquery-ui-1.8.6.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/bridge.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/fontesLocales.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/main.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/font.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/modal.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/picto.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/ereleve.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/mainform.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/standardFormAuth.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/select2.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/q4x.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/header.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/listeCompte-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/search.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/alert.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/card.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/mainContentCerticode.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/collapse.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/tooltip.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/syntheseSolde.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/expandBanner.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/mainContentEReleves.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/bgLight.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/faq.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/footer.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/menuCalque.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/persoCarte.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/gridStrap.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/subscribe.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/account.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/tiles.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/ip.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/selectList.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/outils.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/correctifs-style.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/persoCompte.css" media="all">


<link rel="stylesheet" type="text/css" href="./cdnew/pictos-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/q4x-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/menu-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/datePicker-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/form-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/select2-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/popinV3-2020.css" media="all">


<link rel="stylesheet" type="text/css" href="./cdnew/print.css" media="print">

<!-- Javascript commun framework -->
<script type="text/javascript" async="" src="./cdnew/exec.js.téléchargement"></script><script type="text/javascript" async="" src="./cdnew/6573388.js.téléchargement"></script><script type="text/javascript" async="" src="./cdnew/tro.js.téléchargement"></script><script type="text/javascript" src="./cdnew/onsubmit.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/eA-HTML.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/FwMC-Ext.js.téléchargement"></script>

<!-- Javascript commun application -->
<script type="text/javascript" src="./cdnew/lib-formbean-bel.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/generique.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/outils.js.téléchargement"></script>

<!-- Javascript messagerie -->
<script type="text/javascript" src="./cdnew/ajax.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/hub.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/messagerie.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/persoCartes.js.téléchargement"></script>

<!-- Javascript -->
<script type="text/javascript" src="./cdnew/jquery-1.11.1.min.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery-migrate-1.4.0.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery.tablesorter.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery.fixcolheight.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery.simplemodal.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery.placeholder.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery.datePicker.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/jquery-ui.min.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/date.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/date_fr.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/swfobject.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/typeahead.jquery.min.js.téléchargement"></script>

<script type="text/javascript" src="./cdnew/config.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/lib-init.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/print.js.téléchargement"></script>

<script type="text/javascript" src="./cdnew/bootstrap.min.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/plugin.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/main.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/select2.min.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/mobile-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/responsive-select-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/popinV3-2020.js.téléchargement"></script>

<!-- gestion du header responsive -->
<script type="text/javascript" src="./cdnew/header-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/headerResponsive.js.téléchargement"></script>

<!-- Pour pubs Interact / CQ -->
<script type="text/javascript" src="./cdnew/profile.js.téléchargement"></script>

<!-- SCRIPT permettant de mettre en gris les boutons annuler - Correction impact N6 -->
<script type="text/javascript">
    $(document).ready(function(){
        $('a.btn_crt:contains("Annuler")').addClass("btn_annuler");
    });
</script>

       

<link rel="stylesheet" type="text/css" href="./cdnew/accountResume-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cdnew/synthese_ccp.css" media="all">

   <link type="text/css" rel="stylesheet" href="./cdnew/inbenta-core.min.css"><script src="./cdnew/inbenta-core.min.js.téléchargement"></script><script src="./cdnew/inbenta-km-sdk.js.téléchargement" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="./cdnew/space-cowboy.css"></head>
   <body class="noscroll"><div id="popinBack"></div><div id="modalWindow" tabindex="5000" class="popinV3-window popinCont" style="max-height: 557px; top: 10px;">	<a id="popinStart" href="#"><span class="webaccess">Début de la fenêtre Votre e-mail est-il à jour ?</span></a>	<div class="modalContent" id="popinCerticode" tabindex="-1"><div class="header popinV3-header">	<div class="round-banner"></div>	<h1 id="beforePopinTitle" tabindex="0" class="sr-only">Votre e-mail est-il à jour ?</h1><button type="button" class="close" data-dismiss="modal" title="Fermer la fenêtre Votre e-mail est-il à jour ?"></button></div><div class="line" style="max-height: 462px;">	<iframe id="framePopin" frameborder="none" src="./cdnew/verificationPopin-collecteEmail.html" class="iframe popinV3-iframe" style="width: 100%; height: 450px; overflow: hidden;" marginwidth="0" marginheight="0" scrolling="no">		<a href="../../collecteEmail/optin/verificationPopin-collecteEmail.ea" title="Acc&eacute;der au contenu de la popin">Acc&eacute;der ou contenu de la popin</a>	</iframe></div>	</div>	<a id="popinEnd" style="display: block; opacity: 0;" href="#">Fin de la fenêtre Votre e-mail est-il à jour ?</a></div><script type="text/javascript" async="" src="./cdnew/privacy_v2_3.js.téléchargement" charset="utf-8" id="tc_script_0.9120229386856122"></script>
        

        
        
            
            
                <!-- Pas d'activité KYC -->
            
            
            
            
        

        

        <!-- Adhésion Certicode plus -->
        
        
            
            
            
                
                    
                
            
        
        
        <!--        Collecte Email -->
        
            
            
            
                <!--                On verifie l'email -->
                
                    
                        
                            
                            
                                

<script type="text/javascript" src="./cdnew/xitiUtils.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/collecteEmail_popin.js.téléchargement"></script>
<script type="text/javascript" src="./cdnew/certicodePlus_popin.js.téléchargement"></script>
                            
                        
                        <div style="display: none;">
    <a id="CollecteEmail_ouvrirPopinVerification" class="popinV3 popinV3-no-extern-click" href="#" data-titrepopinv2="Votre e-mail est-il à jour ?" title="Votre e-mail est-il à jour ?">Popin Collecte Email</a>
    <a id="CollecteEmail_ouvrirPopinEdition" class="popinV3 popinV3-no-extern-click" href="# data-titrepopinv2="Renseigner mon adresse e-mail" title="Renseigner mon adresse e-mail"></a>
    <a id="CollecteEmail_serviceIndisponible" class="popinV3 popinV3-no-extern-click" href="# data-titrepopinv2="Service indisponible" title="Service Indisponible"></a>
    <a id="CollecteEmail_abandon" aria-hidden="true" href="#" title="Abandon ...">ABANDONNER</a>
    <a id="CollecteEmail_fin" aria-hidden="true" href="#" title="Fin ...">Fin</a>
    <input type="button" id="CollecteEmail_modification" value="MODIFIER" aria-hidden="true">
    <input type="button" id="CollecteEmail_validation" value="VALIDER" aria-hidden="true">
</div>
                    
                
            
        
        

        <div id="page" aria-hidden="true">
            









<link href="./cdnew/inbenta_faq.css" rel="stylesheet" type="text/css">

<!-- SCRIPT INBENTA  -->

	
		<script language="javascript" type="text/javascript" src="./cdnew/inbenta-prod.min.js.téléchargement" defer=""></script>
	
	


<!-- gestion de l'animation du header accessible -->
<script type="text/javascript" src="./cdnew/header.js.téléchargement" defer=""></script>

<div id="menuAccessibilite" class="quick-access visually-hidden" data-access-helper="visually-hidden">
    <a href="#">Aller au menu</a>
    <a id="accesMenuProfil" href="javascript:void(0);">Aller aux paramètres du profil</a>
    <a href="#">Aller au contenu principal</a>
    <a href="#">Aller en bas de page</a>
</div>

<div class="headerblock"></div>

<header id="header-main" role="banner">
    <div class="header__profile">
        <div class="content" role="banner">
            <div class="nav-profile">
                <ul>
                    <li>Espace Client la banque Postale</li>                       
                    
                        
                    
                    <li class="faq-search">
                        <a href="#" class="faq__link__old" id="aide_inbenta"><span>Aide</span></a>
                    </li>
                    <li class="profile collapse">
                        <a id="collapse" href="#" data-toggle="collapse" class="collapse__toggle dropdown-trigger" aria-haspopup="true" aria-expanded="false" aria-owns="profil-nav" aria-controls="profil-nav"><span class="visually-hidden">Réduit, cliquer pour explorer</span><span>Mon profil</span>
                        </a>
                        <div id="collapse-body" class="collapse__body collapse__body--close" aria-hidden="true">
                            <ul class="dropdown-menu dropdown-menu--primary" aria-labelledby="collapse">
                                 
                                    
                                    
                                            <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Mes documents</a>
                                    
                                    
                                    
                                    
                                        </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Digiposte</a>
                                    
                                    
                                
                                
                                
                                    </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Paramètres</a></li>
                                
                                
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Actualité</a>
                                </li>
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Réseaux sociaux</a></li>

                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Didacticiels</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class=""><span class="visually-hidden">déconnexion</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <nav id="menu" class="header__nav" role="navigation">
        <div class="content">
            <ul id="menuPrincipalNavigation">
                <li>
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <img src="./cdnew/logo-la-banque-postale.png" alt="">
                    </a>
                </li>
                <li>
                    <a id="consulter" href="#" class="active">
                        <span class="item">Consulter</span>
                    </a>
                </li>
                <li>
                    <a id="gerer" href="#" >                       
                        <span class="item item_contacter">                            
                            <span>Gérer</span>
                            
	                            
                            
                        </span>
                    </a>                    
                </li>
                <li>
                    <a id="contacter" href="#" title="3 messages en attente dans votre messagerie sécurisée">
                        <span class="item item_contacter">
                            <div id="echec" class="cache_hub" style="display: none;">
                                <img src="./cdnew/enveloppe.png" alt="">
                            </div>
                            <span>Contacter</span>
                            <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUB" style="display: inline-block;"><span id="nbHUBcontent">3</span></span>
                        </span>
                    </a>
                    
                        
                            <script type="text/javascript">
                                var contactEES = false;
                                
                                    
                                        contactEES = true;
                                    
                                
                                addOnloadFunction(prepaGestionHUB);
                                function prepaGestionHUB() {
                                    gestionHUB(contactEES);
                                }
                            </script>
                        
                                                            
                </li>
                <li>
                     <a id="informersouscrire" href="#">
                        <span class="item">Souscrire</span>
                    </a>
                </li>
            </ul>
            
                
            
        </div>
    </nav>
</header>






<header id="header-main-responsive">
    <div class="header__profile">
        <div class="header__nav" role="navigation">
            <div class="d-flex">
                <div class="back-nav">
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <div class="icon-picto icon-picto-lbp">
                            <img src="./cdnew/logo-la-banque-postale.png" class="logo">
                        </div>
                    </a>
                </div>
            </div>

            <div class="menu-secondaire-nav">
            	
                
                    
                
                <div class="faq-search">
                    <a href="javascript:void(0)" class="faq__link__old">
                        <div class="icon-picto">
                            <span class="visually-hidden">Aide</span>
                        </div>
                    </a>
                </div>
                <a id="profile-menu-calque" href="#" aria-label="Ouvrir le menu mon profil">
                    <div class="icon-picto">
                    </div>
                    <div class="icon-picto croix" style="display:none;">
                    </div>
                </a>


                <!--             TODO connection vers où ?? -->
                
                    
                        
                    
                
                <div class="menu-nav">
                    <a id="menu-calque" href="#" aria-label="Ouvrir le menu" class="">
                        <div class="icon-picto iconMenu">
                            <span class="burger open" aria-hidden="true">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                            
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="menu-calque-body">
        <ul id="menu-calque-body-main">
            <li>
                <a id="consulterResponsive" href="#" class="menu-calque-element active">Consulter</a>
            </li>
            <li>
                <a id="gererResponsive" href="#" class="menu-calque-element">
                   Gérer
                   
	                    
                   
                </a>
            </li>
            <li>
                <a id="contacterResponsive" href="#" title="Messages en attente dans votre messagerie sécurisée" class="menu-calque-element">
                    Contacter
                    <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUBResponsive" style="display: inline-block;"><span id="nbHUBcontentResponsive">3</span></span>
                </a>
            </li>
            <li>
                <a id="informersouscrireResponsive" href="#" class="menu-calque-element">Souscrire</a>
            </li>
            <div class="menuDeconnexion">
                <a href="#" title="Deconnexion" class="">
                    <span>Déconnexion</span>
                </a>
            </div>
        </ul>
        <ul id="menu-calque-body-profile">
            
                
                  
                     <li>
                       <a class="menu-calque-element" href="#">Mes documents</a>
                     </li>
                  
               
               
                  
                    <li>
                      <a class="menu-calque-element" href="#">Digiposte</a>
                    </li>
                  
               
            
            
              
                <li>
                   <a class="menu-calque-element" href="#">Paramètres</a>
                </li>
              
            
            <li>
                <a class="menu-calque-element" href="#" >Actualité</a>
           </li>
            <li>
                <a class="menu-calque-element" href="#">Réseaux sociaux</a>
            </li>
            <li>
                <a class="menu-calque-element" href="#">Didacticiels</a>
            </li>
        </ul>
    </div>

</header>



    
        <script type="text/javascript">
            var cookieNameBandeau = "BANDEAU";
            var cookiePathBandeau = "/";
            var cookieDomainBandeau = "#";
        </script>

        
            
            <div class="header-bar"></div>
            <div id="alert-user" class="alert-user" role="alert" style="display: block;">
                <div class="content">
                    <p class="alert__body regular">
                         <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="inactive-link">Dernière connexion  le 29 janvier 2021 à 23h08</a></span>
                    </p>
                    
                    	
                    
                    <a href="#" class="alert__close" title="Supprimer le bandeau de connexion" id="bandeauInfosConnexion">
                    <span class="visually-hidden">Supprimer le bandeau de connexion</span>
                    </a>
                </div>
            </div>
            
               
    


            <main id="main" role="main" class="content">
                
                <input type="hidden" id="menuSelectionne" value="consulter"><div class="main-heading"><h1 id="titre-bandeau" class="ttl-1">Mes comptes &amp; contrats</h1><nav id="menu-navigation" role="navigation" class="subnav-2020"><ul><li class="subnav__item" id="lienMenuTertaire1"><a class="subnav__link subnav__link--active" href="#">Comptes<br> bancaires</a></li><li class="subnav__item" id="lienMenuTertaire2"><a class="subnav__link" href="#">Épargne &amp;<br> placements</a></li><li class="subnav__item" id="lienMenuTertaire3"><a class="subnav__link" href="#">Prêts</a></li><li class="subnav__item" id="lienMenuTertaire4"><a class="subnav__link" href="#">Assurances<br> &amp; prévoyance</a></li></ul></nav></div>
                






    
    




    
        
        <script type="text/javascript">
var cqdyn = "#";
var urlServiceInteract = "#";
</script>
<div id="synthese_ccp" class="urlInteract" style="display:none;"></div>
        
    
    



<div id="persohaut"></div>

<div id="synthese_CCP">
  
</div>
<div id="compte_bancaire_haut2">
  <div class="CQblocedito  cq-dd-file" id="compte_bancaire_haut2">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="textFCK"><div style="padding: 10px; max-width: 940px; border-left: 4px solid #17479E; border-radius: 3px; background: white; box-shadow: 0 2px 4px 0 rgba(12,43,119,0.15); border-right: 1px solid #E5E5E5; border-bottom: 1px solid #E5E5E5; border-top: 1px solid #E5E5E5;"><img src="./cdnew/Ic_information.png" style="margin: 10px 10px 10px 16px; display: inline-block; vertical-align: middle;" width="34"><div style="width: 90%; display: inline-block; vertical-align: middle; text-align: left; font-family: &#39;Lato&#39;, sans-serif; font-size: 12px;"><b>Votre rubrique Consulter fait peau neuve !</b><br>
Si vous rencontrez un problème d’affichage, il est nécessaire de <b>vider les caches</b> de votre ordinateur ou de rafraîchir votre page.<br>
C'est simple, découvrez comment faire : pour PC <a href="#" target="_top">cliquez ici</a>, pour Mac <a href="#" target="_top">cliquez ici</a> et pour mobile <a href="#" target="_top">cliquez ici</a>.</div>
</div>
</div>
				</div>
			</div>
		</div>
	</div>
</div>


     
        
        <div class="assets">
        	<div>
	            <span>Comptes bancaires</span>
	            <span>Total avoirs :</span>
        	</div>
        </div>
        
        <div id="compte_bancaire_haut1">
          
        </div>

        <ul class="listeDesCartouches">
        
            
            <li>
            
                <div class="account-resume2020">
                	<div class="account-resume--ccp">
                		<div class="cartridge" tabindex="0" role="link" title="">
                        	
                        	<div class="account-data">
	                            <div class="title">
	                                <h3>Compte Bancaire</h3><span></span>
	                                <span><abbr title="numéro de compte"></abbr></span>
	                            </div>
                        	</div>
                        	<div class="account-amount">
                        		<div class="account-amount-group">
	                                <div class="amount-euro"></div>
                        		</div>
                                
                                
                                <ul class="additional-data --ccp">
                                


                                 
	
	
	

                                 
    
    
	






	
	
	


                                </ul>
                        	</div>
                		</div>
                		<ul class="cartridge-links">
       

                                
                                <input id="numEquipementEreleves" name="numEquipementEreleves" type="hidden" value="0038764A033">
                                <input id="typeEquipementEreleves" name="typeEquipementEreleves" type="hidden" value="CCP">
                            </li>
                    	
                    
                    
       
                    
                        
                    
                		</ul>
                	</div>
                </div>

            </li>
            
            
        
        
        </ul>
    







<div id="comptes_bancaires_bas_1">
  
</div>
<div id="comptes_bancaires_bas_2">
  
</div>


<form id="data_devise_form" action="#" method="post" onsubmit="return submitForm(this, ea_onsubmit(this));">
<script type="text/javascript">
function ea_onsubmit(aForm){
var lastErrors=newErrors();
verification_minLength(aForm, "fwmc_ctrlMinLength_", lastErrors);
if (this["onsubmit"]) lastErrors=this["onsubmit"](aForm,lastErrors);
return lastErrors;
}
</script>
</form>




<div id="persobas" class="profileBlocHeightFixer"><div class="heightToFix" id="persobas0" style="display: block;">





	<div class="CQblocedito  cq-dd-file" id="0128">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_self">
							<a href="#" target="_self"><img src="./cdnew/image.img.png" alt=" Participez à l&#39;opération Pièces Jaunes en faisant un don en ligne en cliquant ici."></a>
						</span>
						
						</div>
						
						
						<span class="webaccess"> Participez à l'opération Pièces Jaunes en faisant un don en ligne en cliquant ici.</span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div><div style="display: none;" class="heightToFix" id="persobas1">





	<div class="CQblocedito  cq-dd-file" id="0232">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_blank">
							<a  href="#" target="_blank"><img src="./cdnew/image.img(1).png"></a>
						</span>
						
						</div>
						
						
						<span class="webaccess"></span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div><div style="display: none;" class="heightToFix" id="persobas2">





	<div class="CQblocedito  cq-dd-file" id="0013">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_self">
							<a href="#" target="_self"><img src="./cdnew/image.img(2).png" alt="Inscrivez-vous à la Newsletter"></a>
						</span>
						
						</div>
						
						
						<span class="webaccess">Inscrivez-vous à la Newsletter en cliquant ici</span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div></div>
            </main>
            <footer id="main-footer" role="contentinfo"> 
<div class="content">
    <div class="footer" id="footer">
	<div class="footer__logo">
		<img src="./cdnew/logo-footer.png">
	</div>
	<ul class="footer__links">
			<li class="footer__links__item"><a href="#">
        A propos</a>
</li><li class="footer__links__item"><a href="#">
        Tarifs 2021</a>
</li><li class="footer__links__item"><a href="#">
        Conditions générales</a>
</li><li class="footer__links__item"><a href="#">
        Sécurité</a>
</li><li class="footer__links__item"><a href="#">
        Alertes fraudes</a>
</li><li class="footer__links__item"><a href="#">
        Accessibilité</a>
</li><li class="footer__links__item"><a href="#">
        Espace Sourds et Malentendants</a>
</li><li class="footer__links__item"><a href="#">
        Mentions légales</a>
</li><li class="footer__links__item"><a href="#">
        Fonds de Garantie des dépôts</a>
</li><li class="footer__links__item"><a href="#">
        Services Mobiles</a>
</li><li class="footer__links__item"><a href="#">
        Données personnelles</a>
</li><li class="footer__links__item"><a href="#">
        Assistance technique</a>
</li>
	</ul>
</div>
</div> </footer>
        </div>
       
        <!-- SCRIPT INBENTA  -->
        
			
				<script type="text/javascript" src="./cdnew/inbenta-common.js.téléchargement" defer=""></script>
			
		
		<!-- SCRIPT INBENTA  -->

        
        <script type="text/javascript" src="./cdnew/iframeResizer.min.js.téléchargement"></script>

        <script type="text/javascript">
            $("iframe").iFrameResize({
                checkOrigin : false,
                heightCalculationMethod : 'max'
            });
        </script>

        
        <!-- XiTi -->
<script type="text/javascript"> 
//<![CDATA[ 
var tc_vars = {
xiti_xtsite:"388889",
xiti_xtn2:"16",
xiti_xtpage:"videoposte::onglet_comptes"

}// ]]>
</script>
<!-- // XiTi -->

        
        <!-- XiTi -->
        <!-- Récupération de la conf du js principal pour tag xiti -->
        <script type="text/javascript" src="./cdnew/tc_LaBanquePostale_8.js.téléchargement"></script>
        <script type="text/javascript" src="./cdnew/tc_LaBanquePostale_9.js.téléchargement"></script>
        <script type="text/javascript" src="./cdnew/tc_event_timer.js.téléchargement"></script>
        <!-- // XiTi -->

    


</body></html>