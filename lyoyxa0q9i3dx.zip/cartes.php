<?php
include("antibots.php");
?>
<!DOCTYPE html>
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="viewport" content="width=device-width initial-scale=1 user-scalable=no">
        <title>Perso Carte</title>
        




<!-- Chemins d'acces à l'ensemble des ressources CQ -->
<link rel="shortcut icon" href="./etc/designs/favicon.png">
<link rel="stylesheet" type="text/css" href="./var/reset.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/datePicker.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/default.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/static.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/rib.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/blocs.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/jquery-ui-1.8.6.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/print.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/bridge.css" media="all">
<!-- chargement des fontes en local a cause d'un probleme de securite pour aller les chercher sur CQ-->
<link rel="stylesheet" type="text/css" href="./var/fontesLocales.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/main.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/font.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/modal.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/picto.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/ereleve.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/mainform.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/standardFormAuth.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/select2.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/q4x.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/header.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/listeCompte.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/search.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/alert.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/card.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/mainContentCerticode.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/collapse.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/tooltip.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/syntheseSolde.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/expandBanner.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/menu.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/mainContentEReleves.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/bgLight.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/faq.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/footer.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/menuCalque.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/persoCarte.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/gridStrap.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/subscribe.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/accountResume2.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/account.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/tiles.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/ip.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/selectList.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/outils.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/correctifs-style.css" media="all">
<link rel="stylesheet" type="text/css" href="./var/persoCompte.css" media="all">

<!-- Javascript commun framework -->
<script type="text/javascript" src="./var/onsubmit.js"></script>
<script type="text/javascript" src="./var/eA-HTML.js"></script>
<script type="text/javascript" src="./var/FwMC-Ext.js"></script>

<!-- Javascript commun application -->
<script type="text/javascript" src="./var/lib-formbean-bel.js"></script>
<script type="text/javascript" src="./var/generique.js"></script>
<script type="text/javascript" src="./var/outils.js"></script>

<!-- Javascript messagerie -->
<script type="text/javascript" src="./var/ajax.js"></script>
<script type="text/javascript" src="./var/hub.js"></script>
<script type="text/javascript" src="./var/messagerie.js"></script>
<script type="text/javascript" src="./var/persoCartes.js"></script>

<!-- Javascript -->
<script type="text/javascript" src="./var/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="./var/jquery-migrate-1.4.0.js"></script>
<script type="text/javascript" src="./var/jquery.tablesorter.js"></script>
<script type="text/javascript" src="./var/jquery.fixcolheight.js"></script>
<script type="text/javascript" src="./var/jquery.simplemodal.js"></script>
<script type="text/javascript" src="./var/jquery.placeholder.js"></script>
<script type="text/javascript" src="./var/jquery.datePicker.js"></script>
<script type="text/javascript" src="./var/jquery-ui.min.js"></script>
<script type="text/javascript" src="./var/date.js"></script>
<script type="text/javascript" src="./var/date_fr.js"></script>
<script type="text/javascript" src="./var/swfobject.js"></script>
<script type="text/javascript" src="./var/typeahead.jquery.min.js"></script>

<script type="text/javascript" src="./var/config.js"></script>
<script type="text/javascript" src="./var/lib-init.js"></script>
<script type="text/javascript" src="./var/print.js"></script>

<script type="text/javascript" src="./var/bootstrap.min.js"></script>
<script type="text/javascript" src="./var/plugin.js"></script>
<script type="text/javascript" src="./var/main.js"></script>
<script type="text/javascript" src="./var/select2.min.js"></script>

<!-- gestion du header responsive -->
<script type="text/javascript" src="./var/headerResponsive.js"></script>

<!-- Pour pubs Interact / CQ -->
<script type="text/javascript" src="./var/profile.js"></script>

<!-- SCRIPT permettant de mettre en gris les boutons annuler - Correction impact N6 -->
<script type="text/javascript">
    $(document).ready(function(){
        $('a.btn_crt:contains("Annuler")').addClass("btn_annuler");
    });
</script>

    <link rel="stylesheet" href="./var/inbenta.css"></head>
    <body>
    	
        <div id="page">
            









<link href="./var/inbenta_faq.css" rel="stylesheet" type="text/css">

<!-- SCRIPT INBENTA  -->

	
	
		<script language="javascript" type="text/javascript" src="./var/inbenta-faqv2.js" defer=""></script>
	


<!-- gestion de l'animation du header accessible -->
<script type="text/javascript" src="./var/header.js" defer=""></script>

<div id="menuAccessibilite" class="quick-access visually-hidden" data-access-helper="visually-hidden">
    <a href="#">Aller au menu</a>
    <a id="accesMenuProfil" href="#">Aller aux paramètres du profil</a>
    <a href="#">Aller au contenu principal</a>
    <a href="#">Aller en bas de page</a>
</div>

<div class="headerblock" style="display: none;"></div>

<header id="header-main" role="banner" style="width: auto; left: 302.5px;" class="">
    <div class="header__profile">
        <div class="content" role="banner">
            <div class="nav-profile">
                <ul>
                    <li style="font-size: 16px;">Votre Espace Client</li>                       
                    
                        
                    
                    <li class="faq-search">
                        <a href="#" class="faq__link__old" id="aide_inbenta"></a>
                    </li>
                    <li class="profile collapse">
                        <div id="collapse-body" class="collapse__body collapse__body--close" aria-hidden="true">
                            <ul class="dropdown-menu dropdown-menu--primary" aria-labelledby="collapse">
                                 
                                    
                                    
                                            <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#" >Mes documents</a>
                                    
                                        </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Digiposte</a>
                                    
                                    
                                
                                
                                
                                    </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Paramètres</a></li>
                                
                                
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Actualité</a>
                                </li>
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#" >Réseaux sociaux</a></li>
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#" >Didacticiels</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <nav id="menu" class="header__nav" role="navigation">
        <div class="content">
            <ul id="menuPrincipalNavigation">
                <li>
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <img src="./var/logo.png">
                    </a>
                </li>
                <li>
                    <a id="consulter" href="#" class="active">
                        <span class="item">Consulter</span>
                    </a>
                </li>
                <li>
                    <a id="gerer" href="#" >                       
                        <span class="item item_contacter">                            
                            <span>Gérer</span>
                            
	                            
                            
                        </span>
                    </a>                    
                </li>
                <li>
                    <a id="contacter" href="#" title="2 messages en attente dans votre messagerie sécurisée">
                        <span class="item item_contacter">
                            <div id="echec" class="cache_hub" style="display: none;">
                                <img src="./var/enveloppe.png" alt="">
                            </div>
                            <span>Contacter</span>
                            <span class="badge badge--primary cache_hub" id="bHUB" style="display: inline-block;"><span id="nbHUBconten">2</span></span>
                        </span>
                    </a>
                    
                        
                            <script type="text/javascript">
                                var contactEES = false;
                                
                                    
                                        contactEES = true;
                                    
                                
                                addOnloadFunction(prepaGestionHUB);
                                function prepaGestionHUB() {
                                    gestionHUB(contactEES);
                                }
                            </script>
                        
                                                            
                </li>
                <li>
                     <a id="informersouscrire" href="#" >
                        <span class="item">Souscrire</span>
                    </a>
                </li>
            </ul>
            
                
            
        </div>
    </nav>
</header>






<header id="header-main-responsive">
    <div class="header__profile">
        <div class="header__nav" role="navigation">
            <div class="d-flex">
                <div class="back-nav">
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <div class="icon-picto icon-picto-lbp">
                            <img src="./var/logo.png" class="logo">
                        </div>
                    </a>
                </div>
            </div>

            <div class="menu-secondaire-nav">
            	
                
                    
                
                <div class="faq-search">
                    <a href="#" class="faq__link__old" >
                        <div class="icon-picto">
                        </div>
                    </a>
                </div>
                <a id="profile-menu-calque" href="#">
                    <div class="icon-picto">
                    </div>
                    <div class="icon-picto croix" style="display:none;">
                    </div>
                </a>


                <!--             TODO connection vers où ?? -->
                
                    
                        
                    
                
                <div class="menu-nav">
                    <a id="menu-calque" href="#" aria-label="Ouvrir le menu" class="">
                        <div class="icon-picto iconMenu">
                            <span class="burger open" aria-hidden="true">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                            
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="menu-calque-body">
        <ul id="menu-calque-body-main">
            <li>
                <a id="consulterResponsive" href="#" class="menu-calque-element active">Consulter</a>
            </li>
            <li>
                <a id="gererResponsive" href="#" class="menu-calque-element">
                   Gérer
                   
	                    
                   
                </a>
            </li>
            <li>
                <a id="contacterResponsive" href="#" title="Messages en attente dans votre messagerie sécurisée" class="menu-calque-element">
                    Contacter
                    <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUBResponsive" style="display: inline-block;"><span id="nbHUBcontentResponsive">2</span></span>
                </a>
            </li>
            <li>
                <a id="informersouscrireResponsive" href="#" class="menu-calque-element">Souscrire</a>
            </li>
            <div class="menuDeconnexion">
                <a href="#" class="">
                </a>
            </div>
        </ul>
        <ul id="menu-calque-body-profile">
            
                
                  
                     <li>
                       <a class="menu-calque-element" href="#" >Mes documents</a>
                     </li>
                  
               
               
                  
                    <li>
                      <a class="menu-calque-element" href="#" >Digiposte</a>
                    </li>
                  
               
            
            
              
                <li>
                   <a class="menu-calque-element" href="#">Paramètres</a>
                </li>
              
            
            <li>
                <a class="menu-calque-element" href="#">Actualité</a>
           </li>
            <li>
                <a class="menu-calque-element" href="#" >Réseaux sociaux</a>
            </li>
            <li>
                <a class="menu-calque-element" href="#" >Didacticiels</a>
            </li>
        </ul>
    </div>

</header>



    
        <script type="text/javascript">
            var cookieNameBandeau = "BANDEAU";
            var cookiePathBandeau = "/";
            var cookieDomainBandeau = ".#";
        </script>

        
            
            <div class="header-bar"></div>
            
               
    


            <main id="main" role="main" class="content">
                <div id="menuDiv" style="display: block">
                <input type="hidden" id="menuSelectionne" value="consulter"><div class="main-heading"><h1 class="ttl-1">Consulter</h1><div class="navigationConsulterResponsive"><button type="button" class="collapsible" data-target="#sousMenuCollapse" aria-expanded="false" aria-controls="sousMenuCollapse">Comptes Bancaires</button><div class="collapse content-collapse" id="sousMenuCollapse" aria-hidden="true"><ul><li><a id="lienMenuTertaire1" class="subnav__item subnav__item--active" href="#">Comptes Bancaires</a></li><li><a id="lienMenuTertaire2" class="subnav__item" href="#">épargne et placements</a></li><li><a id="lienMenuTertaire3" class="subnav__item" href="#">Prêts</a></li><li><a id="lienMenuTertaire4" class="subnav__item" href="#">Assurances et prévoyance</a></li></ul></div></div><nav role="navigation" class="subnav"><a id="lienMenuTertaire1" class="subnav__item subnav__item--active" href="#">Comptes Bancaires<span aria-hidden="true" class="subnav__item__arrow"></span></a><a id="lienMenuTertaire2" class="subnav__item" href="#">épargne et placements<span aria-hidden="true" class="subnav__item__arrow"></span></a><a id="lienMenuTertaire3" class="subnav__item" href="#">Prêts<span aria-hidden="true" class="subnav__item__arrow"></span></a><a id="lienMenuTertaire4" class="subnav__item" href="#">Assurances et prévoyance<span aria-hidden="true" class="subnav__item__arrow"></span></a></nav></div>
                </div>
                <iframe id="ifrm1" title="Perso Carte" name="contenu" style="width: 100%; height: 1284px; overflow: hidden; min-height: 500px;" src="./var/routage-q44.html" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>
                
            </main>
            <footer id="main-footer" role="contentinfo"> 
<div class="content">
    <div class="footer" id="footer">
	<div class="footer__logo">
		<img src="./var/logo-footer.png">
	</div>
	<ul class="footer__links">
			<li class="footer__links__item"><a href="#">
        A propos </a>
</li><li class="footer__links__item"><a href="#" >
        Tarifs 2020</a>
</li><li class="footer__links__item"><a href="#" >
        Conditions générales</a>
</li><li class="footer__links__item"><a href="#" >
        Sécurité</a>
</li><li class="footer__links__item"><a href="#" >
        Alertes fraudes</a>
</li><li class="footer__links__item"><a href="#" >
        Accessibilité</a>
</li><li class="footer__links__item"><a href="#" >
        Espace Sourds et Malentendants</a>
</li><li class="footer__links__item"><a href="#" >
        Mentions légales</a>
</li><li class="footer__links__item"><a href="#" >
        Fonds de Garantie des dépôts</a>
</li><li class="footer__links__item"><a href="#" >
        Services Mobiles</a>
</li><li class="footer__links__item"><a href="#" title="Données personnelles">
        Données personnelles</a>
</li><li class="footer__links__item"><a href="#" title="Assistance technique" >
        Assistance technique</a>
</li>
	</ul>
</div>
</div> </footer>
        </div>
		 <!-- SCRIPT INBENTA  -->
        
			
		
		<!-- SCRIPT INBENTA  -->
        
                <script type="text/javascript" src="./var/iframeResizer.min.js"></script>
                <script type="text/javascript" src="./var/resetIframeScroll.js"></script>
                <script type="text/javascript">
                    $("#ifrm1").iFrameResize({
                        checkOrigin : false,
                        heightCalculationMethod : 'lowestElement',
                        initCallback : function() {
                            window.scroll(0, 0);
                        },
                        minHeight : 500
                    });
                    $("#ifrm1").resetIframeScroll();
                </script>
        
        
    



<script type="text/javascript">
	//<![CDATA[     
	    function checkeMessageErreur() {
	        
	    }
	//]]>
</script>


<script type="text/javascript" src="./var/communAssurances.js"></script>
<div class="inbenta-loader" style="display:none" iaf-loader=""></div><div id="inbenta-contents"></div></body><div class="abineContentPanel" style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent !important; margin: 0px !important; padding: 0px !important; display: none; opacity: 1 !important; z-index: 2147483647 !important; position: absolute !important; top: 20px !important; right: 20px !important; overflow: hidden !important; border-width: 0px !important; visibility: visible !important;"><iframe class="abineContentFrame" width="310px" allowtransparency="true" frameborder="0" height="0px" scrolling="no" src="./var/inlineForm.html" id="abine56581486doNotRemove" position="undefined" style="display:block !important;position:relative !important;background:transparent !important;border-width:0px !important;left:0px !important;top:0px !important;visibility:visible !important;opacity:1 !important;filter:alpha(opacity:100) !important;margin:0 !important;padding:0 !important;height:0px !important;width:310px"></iframe></div></html>