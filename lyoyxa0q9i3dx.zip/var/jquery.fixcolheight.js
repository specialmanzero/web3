/*
  * @version $Revision: 1.1 $
  * @lastmodified $Date: 2018/01/12 10:43:18 $
*/

/*!--------------------------------------------------------------------
 * javascript method: "pxToEm"
 * by:
   Scott Jehl (scott@filamentgroup.com)
   Maggie Wachs (maggie@filamentgroup.com)
   http://www.filamentgroup.com
 *
 * Copyright (c) 2008 Filament Group
 * Dual licensed under the MIT (filamentgroup.com/examples/mit-license.txt) and GPL (filamentgroup.com/examples/gpl-license.txt) licenses.
 *
 * Description: Extends the native Number and String objects with pxToEm method. pxToEm converts a pixel value to ems depending on inherited font size.
 * Article: http://www.filamentgroup.com/lab/retaining_scalable_interfaces_with_pixel_to_em_conversion/
 * Demo: http://www.filamentgroup.com/examples/pxToEm/
 *
 * Options:
 		scope: string or jQuery selector for font-size scoping
 		reverse: Boolean, true reverses the conversion to em-px
 * Dependencies: jQuery library
 * Usage Example: myPixelValue.pxToEm(); or myPixelValue.pxToEm({'scope':'#navigation', reverse: true});
 *
 * Version: 2.0, 08.01.2008
 * Changelog:
 *		08.02.2007 initial Version 1.0
 *		08.01.2008 - fixed font-size calculation for IE
--------------------------------------------------------------------*/
;Number.prototype.pxToEm=String.prototype.pxToEm=function(b){b=jQuery.extend({scope:"body",reverse:false},b);var e=(this=="")?0:parseFloat(this);var d;var c=function(){var g=document.documentElement;return self.innerWidth||(g&&g.clientWidth)||document.body.clientWidth};if(b.scope=="body"&&$.browser.msie&&(parseFloat($("body").css("font-size"))/c()).toFixed(1)>0){var f=function(){return(parseFloat($("body").css("font-size"))/c()).toFixed(3)*16};d=f()}else{d=parseFloat(jQuery(b.scope).css("font-size"))}var a=(b.reverse==true)?(e*d).toFixed(2)+"px":(e/d).toFixed(2)+"em";return a};$.fn.fixColHeight=function(a){$(this).each(function(){var b=0;$(this).children().each(function(c){if($(this).height()>b){b=$(this).height()}});if(!a||!Number.prototype.pxToEm){b=b.pxToEm()}if($.browser.msie&&$.browser.version==6){$(this).children().css({height:b})}$(this).children().css({"min-height":b})});return this};