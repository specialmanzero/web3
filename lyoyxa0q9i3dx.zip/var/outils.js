// -------------------- OPENWINDOW --------------------
/*var variation
var zoom

if (is.ns) variation = (is.mac)?1:5;
if (is.ie) variation = (is.mac)?-25:0;*/

function openWindow(url,nom,dimx,dimy,type) {
	featur0 = "top=20,left=20,toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width="+ dimx + ",height=" + dimy;
	featur1 = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,width="+ dimx + ",height=" + dimy;
	featur2 = "toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=no,resizable=no,width="+ dimx + ",height=" + dimy;
	props = eval('featur'+type);
	window.open(url,nom,props);
}
// -------------------- EcPx ---------------------------
function EcPx(x0,y0,x1,y1){
	var r=0;
	for(var i=0; i<Taburl.length; i++){
		r=i;
		if(cherche.match(Taburl[i][0])!=null){break;}
	}
	var chaine='';
	chaine+='<img src="'+chem+'pix.gif" border="0" width="'+eval('x'+r)+'" height="'+eval('y'+r)+'">';
	document.write(chaine);
	document.close();
}

var urlcht = '';
var csscht = '';

var Taburl=new Array();
//Taburl[n]=new Array('type','lien''css');
//Taburl[0]=new Array('bagoo','bagoo','bagoo');
//Taburl[1]=new Array('lpf','lpf','lpf');

for(var i=0; i<Taburl.length; i++){
	if(cherche.match(Taburl[i][0])!=null){
		urlcht=Taburl[i][1];csscht=Taburl[i][2];break;
	} else {
		urlcht=Taburl[1][1];
		csscht=Taburl[1][2];
	}
}

function EcDeconnex(){
	var chaine='';
	urlcht = '';
	//chaine+='<a href="../../authentification/deconnexion.ea" target="_top" onmouseover="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+='<a href="../../securite/deconnexion/init-deconnexion.ea" target="_top" ><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+=' name="deconex"';
	chaine+=' src="'+chem+'deconnexion.gif" border="0"></a>';
	document.write(chaine);
	document.close();
}

function EcDeconnex2(){
	var chaine='';
	urlcht = '';
	//chaine+='<a href="../authentification/deconnexion.ea" target="_top" onmouseover="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+='<a href="../securite/deconnexion/init-deconnexion.ea" target="_top" ><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+=' name="deconex"';
	chaine+=' src="'+chem+'deconnexion.gif" border="0"></a>';
	document.write(chaine);
	document.close();
}



/*
function EcDeconnex(){
	var chaine='';
	urlcht = '';
	//chaine+='<a href="../../authentification/deconnexion.ea" target="_top" onmouseover="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+='<a href="../../authentification/deconnexion.ea" target="_top" onmouseover="MM_swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="MM_swapImgRestore()"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+=' name="deconex"';
	chaine+=' src="'+chem+'deconnexion.gif" border="0"></a>';
	document.write(chaine);
	document.close();
}

function EcDeconnex2(){
	var chaine='';
	urlcht = '';
	//chaine+='<a href="../authentification/deconnexion.ea" target="_top" onmouseover="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+='<a href="../authentification/deconnexion.ea" target="_top" onmouseover="MM_swapImage(\'deconex\',\''+urlcht+'deconnexion.gif\')" onmouseout="MM_swapImgRestore()"><img  onclick="javascript:alert(\'Message de confirmation \\n Votre demande de d\351connexion a bien \351t\351 prise en compte.\');"';
	chaine+=' name="deconex"';
	chaine+=' src="'+chem+'deconnexion.gif" border="0"></a>';
	document.write(chaine);
	document.close();
}


*/

// Overture pop-up
function openDetail(url) {
	var title  = "Detailecriture";
	var option = "width=650,height=350,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no";
	var top    = (screen.height/2)-200;
	var left   = (screen.width/2)-320;
	var option = option + ",top=" + top + ",left="+left;
	var detail = window.open(url, title, option);
	detail.focus();
	return;
}

// utilisation de la foncton onload
function addOnloadFunction(f) { 
  if (window.addEventListener) { 
    window.addEventListener("load",f, false); 
  } else if (document.addEventListener) { 
    document.addEventListener("load",f, false); 
  } else if (window.attachEvent) { 
    window.attachEvent("onload",f); 
  }
}  