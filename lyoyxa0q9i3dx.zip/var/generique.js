

	nbJourMois = new Array(31,29,31,30,31,30,31,31,30,31,30,31);

	

 	function isNombre(chaine)

    {

        var i,nbVirgule;

        var a = ' ';

        

        nbVirgule = 0;

        for (i=0; i<chaine.length; i++)

        {

            a = chaine.substring(i, i+1);

            //alert(a);

            if(a == '.')

                nbVirgule++;

            if ((a<'0' && a!='.' && a!='-') || (a>'9' && a!='.' && a!='-') || (a=='-' && i!=0) || nbVirgule>1)

            {

                //alert("Ce n'est pas un nombre !!!");

                return false;

            }

        }

        

        //alert("C'est un nombre.");

        return true;

    }

 	

 	function point(chaine)

  	{

  	    var i;

  	    var chaineOut;

  	    i = chaine.indexOf(",");

  	    if (i == -1)

  	    {

  	        chaineOut = chaine;

  	    }

  	    else

  	    {

  	        chaineOut = chaine.substring(0, i) + "." + chaine.substring(i+1, chaine.length);

  	    }

  	    return(chaineOut);

  	}

  	

  	function virgule(chaine)

  	{

  	    var i;

  	    var chaineOut;

  	    i = chaine.indexOf(".");

  	    if (i == -1)

  	    {

  	        chaineOut = chaine;

  	    }

  	    else

  	    {

  	        chaineOut = chaine.substring(0, i) + "," + chaine.substring(i+1, chaine.length);

  	    }

  	    return(chaineOut);

  	}

  	

  	function formatCompte(chaine)

  	{
return chaine;
  	    var i,j;

  	    var chaineOut = "";

  	    

  	    if (chaine == "XXX")

  	        return chaine;

  	    

  	    for (j=0; j<3; j++)

  	    {

  	        i = chaine.indexOf("|");

  	        chaineOut = chaineOut + chaine.substring(0, i);

  	        chaine = chaine.substring(i+1, chaine.length);

  	    }

  	    

  	    return chaineOut;

  	}

  	    

  	

  	function formatMontant(chaine)

  	{

  	    var i,nbDec;

  	    var chaineOut;

  	    i = chaine.indexOf(".");

  	    nbDec = chaine.length - chaine.indexOf(".") - 1;

  	    

  	    if (i == -1)

  	    {

  	        chaineOut = chaine + "00";

  	    }

  	    else if (nbDec == 0)

  	    {

  	        chaineOut = chaine.substring(0, i) + "00";

  	    }

  	    else if (nbDec == 1)

  	    {

  	        chaineOut = chaine.substring(0, i) + chaine.substring(i+1, chaine.length) + "0";

  	    }

  	    else

  	    {

  	        chaineOut = chaine.substring(0, i) + chaine.substring(i+1, chaine.length);

  	    }

  	    

  	    return(chaineOut); 

  	}

  	

  	function formatDate(chaine)

  	{

  	    var chaineOut;

  	    var chaineTemp;

  	    var i;

  	    var mois;

  	    var jour;

  	    var ans;

  	    var anChar;

  	    

  	    chaineTemp = chaine;

  	    

  	    i = chaineTemp.indexOf("/");

  	    if (i != 2)

  	    {

  	        return("XXX");

  	    }

  	    chaineOut = chaineTemp.substring(0, i);

  	    chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);

  	    jour = chaineOut;

  	    

  	    i = chaineTemp.indexOf("/");

  	    if (i != 2)

  	    {

  	        return("XXX");

  	    }

  	    chaineOut = chaineTemp.substring(0, i) + chaineOut;

  	    mois = chaineTemp.substring(0, i);

  	    chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);

  	    

  	    

  	    if (chaineTemp.length != 4)

  	    {

  	        return("XXX");

  	    }

  	    chaineOut = chaineTemp + chaineOut;

  	    ans = chaineTemp;

  	    

  	    if (!isNombre(chaineOut))

  	    {

  	        return("XXX");

  	    }

  	    

  	    if (mois < 1 || mois > 12)

  	    {

  	        return("YYY");

  	    }

  	    ans = ans/4;

  	    anChar = ans.toString();

  	    if (jour == 29 && mois == 02 && anChar.indexOf(".") != -1)

  	    {

  	        return("YYY");

  	    }

  	    else if (jour < 1 || jour > nbJourMois[mois-1] )

  	    {

  	        return("YYY");

  	    }

  	    

  	    return(chaineOut); 

  	}

  	

  	function formatDateHidden(chaine)

  	{

  	    var chaineOut;

  	    var chaineTemp;

  	    var i;

  	    

 	    chaineTemp = chaine;

 	        

  	    i = chaineTemp.indexOf("/");

  	    chaineOut = chaineTemp.substring(0, i);

  	    chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);

  	    

  	    i = chaineTemp.indexOf("/");

  	    chaineOut = chaineTemp.substring(0, i) + chaineOut;

  	    chaineTemp = chaineTemp.substring(i+1, chaineTemp.length);

  	    

  	    chaineOut = chaineTemp + chaineOut;

  	    

  	    return(chaineOut); 

  	}

  	

  	

  	function jsTrim(chaine)

	{	

    	var i,j,k;

    	var longueur;

    	var chaineResult;

    	chaineResult=""

    	longueur = chaine.length;

    	if (longueur > 0)

    	{

    		i=0;

    		while(i < longueur && chaine.charAt(i) == " ")

    		{

    			i = i + 1;

    		}

    		if (i != longueur)

    		{

    			j=longueur-1;

    			while(j>=0 && chaine.charAt(j) == " ")

    			{

    				j = j - 1;

    			}

    		}

    		for (k=0;k<j-i+1;k++)

    		{

    			chaineResult=chaineResult + chaine.charAt(k+i);

    		}

    	}					
    	return(chaineResult);

	}


