//Variable utilisee pour l'ajax
var URL_BASE = "../../";


/**
 * fonction d\351finissant l'appel ajax
 */
function appelEligibiliteClo() {
	var url = "persoCartes/eligibilitePph-persoCartes.ea";
	requeterEnAjax(url, "", succesRequeteAjaxPC, erreurRequeteAjaxPC, "get");
}

//fonction de callBack succes
function succesRequeteAjaxPC(fluxJson) {
	var response = JSON.parse(fluxJson);
	if (response.clientEligibleCLO) {
		$('#lienCashBack').attr('aria-hidden', 'false').show();
	}
}

//fonction de callBack erreur
function erreurRequeteAjaxPC(textAjax) {
	console.log(textAjax);
}

/**
 * appel ajax pour l'eligibilite a clo
 */
function gestionCashback() {
	appelEligibiliteClo();
}




