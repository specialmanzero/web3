var previousIframeHeight;

$(document).ready(function(){
	//Supprimer les headers actifs
	$("#menu.header__nav").find("li").each( function(elmt){
		$(this).find("a").removeClass("active");
	});

    //Supprimer les headers actifs
    $("#menu-calque-body").find("li").each( function(elmt){
        $(this).find("a").removeClass("active");
    });

    //repositionner le header actif
    var headerSelectionne = $("#menuSelectionne").val();
    $("#" + headerSelectionne).addClass("active");
    $("#" + headerSelectionne + "Responsive").addClass("active");
	
	//Fonctions d'accessbilit� - menu cach� + focus sur la croix de fermeture du bandeau
	var effectuerFermeture = true;
	if(typeof cookieNameBandeau == 'undefined' || typeof cookieDomainBandeau == 'undefined' || typeof cookiePathBandeau == 'undefined'){
		effectuerFermeture = false;
		cookieNameBandeau = "";
		cookieDomainBandeau = "";
		cookiePathBandeau = "";
	}

	$("#bandeauInfosConnexion").on("click",appelFermetureBandeau(cookieNameBandeau,cookieDomainBandeau,cookiePathBandeau,effectuerFermeture));
	$("#accesMenuProfil").on("click",clicAccesMenuProfil);
	
	/**
	 * Code pour l'accessibilit�
	 * permettant lors du focus sur un lien du menu cach� de l'afficher
	 */
	var classeInvisibilite = $('#menuAccessibilite').attr('data-access-helper');  
	
	//Afficher le menu cach� quand on arrive dessus et focus le premier lien
	$("#menuAccessibilite a").on('focus', function(e){
		if( $('#menuAccessibilite').hasClass(classeInvisibilite)){
			$('#menuAccessibilite').removeClass(classeInvisibilite);
		}
	});
	//Remettre le menu cach� invisible
	$("#menuAccessibilite a").on('blur', function(e){
    	$('#menuAccessibilite').addClass(classeInvisibilite);
	});
    //Lors de l'appui sur Entr�e sur un menu cach�, envoie vers le menu correspondant
	$('#menuAccessibilite').on('keydown.access', 'a', function(e) {
		if (e.keyCode === 13) {
			var target = $(this).attr("href");
			if (target.indexOf('#') !== -1) {
				e.preventDefault();
				$(target).find('a:visible').first().focus();
			}
		}
	});
});

/**
 * Modification du cookie pour indiquer la fermeture du bandeau de connexion
 * @param nomCookie
 * @param domaineCookie
 * @param cheminCookie
 */
function appelFermetureBandeau(nomCookie, domaineCookie, cheminCookie, effectuerFermeture){
	return function() {
		$('#menuPrincipalNavigation').find('a:visible').last().focus();
		if(effectuerFermeture){
			document.cookie = nomCookie + "=false;" + ";domain=" + domaineCookie + ";path=" + cheminCookie;
		}
	};
}

/**
 * Permet lors du clic sur ce lien d'aller directement sur le menu Mon Profil et de l'ouvrir
 */
function clicAccesMenuProfil(){
	$('.dropdown-trigger').click();
	$('.dropdown-trigger').focus();
}

window.addEventListener('message', receiveMessage, false);
function receiveMessage(evt) {

	switch (evt.data) {
		case 'cacher_sous_menu_carte_bancaire':
			// cacher sous menu carte bancaire
			$('#menuDiv').hide();
			break;
		case 'title_programme_cashback':
			// renomme le titre de la page
			window.parent.document.title = 'La Banque Postale - Programme Cashback Visa';
			break;
		case 'cartes_bancaires_plafonds':
			window.parent.document.title = 'La Banque Postale - Modification de Plafond';
			break;
		case 'cartes_bancaires_cartes':
			window.parent.document.title = 'La Banque Postale - Perso Carte';
			break;
		case 'cartes_bancaires_acquittement':
			window.parent.document.title = 'La Banque Postale - Confirmation';
			break;
		case 'cartes_bancaires_certicode':
			window.parent.document.title = 'La Banque Postale - V\u00e9rification';
			break;
		case 'cartes_bancaires_opposition':
			window.parent.document.title = 'La Banque Postale - Mise en opposition';
			$('#lienMenuTertaire1').removeClass('subnav__item--active');
			$('#lienMenuTertaire2').removeClass('subnav__item--active');
			$('#lienMenuTertaire3').addClass('subnav__item--active');
			$('#lienMenuTertaire4').removeClass('subnav__item--active');
			break;	
		case 'cartes_bancaires_from_opposition':
			window.parent.document.title = 'La Banque Postale - Perso Carte';
			break;	
		case 'western_union_ok':
			// Gestion d'affichage menu, sous menu WU
			$('#menuDiv').show();
			break;	
		case 'cacher_menu_parapheur_q4x':
			afficherModalQ44();
			// cacher menu pour l'affichage de docaposte
			$('#menu , #menuDiv, #alert-user, #main-footer').hide();
			// Ajout de l'attribut tabindex permettant d'isoler la popin docaposte
			$('#page, #menuAccessibilite a, #menu a, #header-main-responsive a, #header-main a')
					.attr("tabindex", "-1");
			break;	
		case 'cacher_menu_parapheur_q4x_loader':
			afficherModalQ44Loader();
			// cacher menu pour l'affichage de docaposte
			$('#menu , #menuDiv, #alert-user, #main-footer').hide();
			break;	
		case 'afficher_menu_parapheur_q4x':
			supprimerModalQ44();
			// afficher menu pour l'affichage de docaposte
			$('#menu , #menuDiv, #alert-user, #main-footer').show();
			// Suppression de l'attribut tabindex ajouté précédement
			$('#page, #menuAccessibilite a, #menu a, #header-main-responsive a, #header-main a')
					.removeAttr("tabindex");
			break;	
		case 'declencher_rappel_q4x':
			// Rechargement de q4x
			top.location.replace("../../securite/authentification/recupererPointEntree-identif.ea?q44.itemMenu=GERER.16&origin=particuliers&entree=q44&q44.module=parapheur&syndicationParapheurOk=false");
			break;	
		case 'focus_iframe':
			// focus de l'iframe
			$('#ifrm1').focus();
			break;	
		case 'scroll_top':
			$(document).scrollTop(0);
			break;
		default:
			console.log("PostMessage non reconnu : ",evt.data);
			break;
	}

}


function afficherModalQ44(){
	previousIframeHeight = $('#ifrm1').css('height');
	var haut = window.innerHeight;
	if(!$('#q44-modal').length){    		
		$('#page').append("<div id='q44-modal'></div>");
	}
	$('#ifrm1').css('height', 'calc('+ haut +'px - 100px)');
	$('#ifrm1').css('max-height', 'calc('+ haut +'px - 100px)');
	$('#ifrm1').css('position','relative');
	$('#ifrm1').css('z-index','10002');
	$('#ifrm1').css('margin-top','10px');
	$('#ifrm1').css('margin-bottom','10px');
}

function afficherModalQ44Loader(){
	previousIframeHeight = $('#ifrm1').css('height');
	var haut = window.innerHeight;
	$('#ifrm1').css('height', 'calc('+ haut +'px - 100px)');
	$('#ifrm1').css('max-height', 'calc('+ haut +'px - 100px)');
	$('#ifrm1').css('position','relative');
	$('#ifrm1').css('z-index','10002');
	$('#ifrm1').css('margin-top','10px');
	$('#ifrm1').css('margin-bottom','10px');
}

function supprimerModalQ44(){
	$('#q44-modal').remove();
	$('#ifrm1').css('height', previousIframeHeight);
	$('#ifrm1').css('margin-top','0px');
	$('#ifrm1').css('max-height', '');
}