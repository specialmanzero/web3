$(document).ready(function() {

function hideElement(e) {
    // e.css('display', 'none');
    e.css('visibility', 'hidden');
    e.css('transform', 'translateX(-580px)');
}

function showElement(e) {
    e.css('display', 'block');
    e.css('visibility', 'visible');
    e.css('transform', 'translateX(0)');
}

function showMenu(menuID) {
    var menuTop = $('#header-main-responsive').find('div.header__profile').height();
    var menuHeight = '100vh' - menuTop;

    // Affichage background du calque en grise
    $('body').append('<div id="menu-calque-background"></div>');
    $('#menu-calque-background').css('top', menuTop + 'px');

    // Afficher le menu
    showElement($('#menu-calque-body'));
    if (menuID === 'menu-calque-body-main') {
        $('#menu-calque-body-profile').hide();
        $('#menu-calque-body-main').show();
    } else {
        $('#menu-calque-body-profile').show();
        $('#menu-calque-body-main').hide();
    }
    $('#menu-calque-body').css('top', menuTop + 'px');
    $('#menu-calque-body').css('height', menuHeight + 'px');
}

function hideMenu() {
    hideElement($('#menu-calque-body'));
    setTimeout(function(){
        $('#menu-calque-background').remove();
    }, 350);

}

function onClientViewScroll(clientViewWidth) {
    if ($(window).width() <= clientViewWidth) {
        // Recuperation de la position du scroll
        var scrollPos = $(document).scrollTop();
        var header = $('#header-main-responsive').find('.header__profile');
        var banner = header.find('.content');
        var headerNav = header.find('.header__nav');
        var headerHeight = header.height();
        var bannerHeight = banner.height();
        if (scrollPos > bannerHeight) {
            hideElement(banner);
            header.css('position', 'fixed');
            header.css('top', '0');
            header.css('z-index', '10000');
            header.css('width', '100%');
            header.attr('class', 'header__profile scroll');
            // Pas beson du headerblock et headerbar: affichs par header dock natif
            hideElement($('.headerblock'));
            hideElement($('.header-bar'));
        } else if (header.css('position') === 'fixed') {
            header.css('position', 'relative');
            header.css('top', '0');
            header.css('z-index', '0');
            header.removeClass('scroll');
            showElement(banner);
        }
        // Si le menu-calque est visible on doit le recaler
        if ($('#menu-calque-background').length > 0 && $('#menu-calque-background').css('display') === 'block') {
            var menuTop = $('#header-main-responsive').find('div.header__profile').height();
            var windowHeight = $(window).height();
            var menuHeight = '100vh' - menuTop;
            $('#menu-calque-background').css('top', menuTop + 'px');
            $('#menu-calque-background').css('height', menuHeight + 'px');
            $('#menu-calque-body').css('top', headerHeight + 'px');
            $('#menu-calque-body').css('height', menuHeight + 'px');
        }
    }
}

function onMenuClick() {
    var menu = $('#menu-calque');
    var menuIcon = menu.find('.burger.open');

    if (menuIcon.length > 0) {
        // Ajouter une class  menu-secondaire-nav pour grer la disparition des icones aide et profil
        $('.menu-secondaire-nav').addClass('menu-ouvert');

        // Afficher le menu et l'icone delete
        menuIcon.attr('class', 'burger close');
        menu.attr('aria-label', "Fermer le menu");
        showMenu('menu-calque-body-main');
        $('#menu-calque-background').click(onMenuClick);
        $('body').css('max-height', '100vh').css('overflow', 'hidden');
        function hideMain() {
            $('.alert-user').css('display', 'none');
            $('#main').css('display', 'none');
            $('#main-footer').css('display', 'none');
        }
        setTimeout(hideMain, 500);

    } else {
        // Supprimer une class  menu-secondaire-nav pour grer la disparition des icones aide et profil
        $('.menu-secondaire-nav').removeClass('menu-ouvert');

        // Cacher le menu et reafficher le burger
        menu.find('.burger.close').attr('class', 'burger open');
        menu.attr('aria-label', "Ouvrir le menu");
        hideMenu();
        $('body').css('max-height', 'auto').css('overflow', 'auto');
        $('.alert-user').css('display', 'block');
        $('#main').css('display', 'block');
        $('#main-footer').css('display', 'block');
    }
}

function onProfileClick() {
    var profileIcon = $('#profile-menu-calque').find('i.icon-picto-profil');

    if ($('#menu-calque-background').length === 0) {
        //modifier le aria-label des icones pour l'accessibilite
        $('#profile-menu-calque').attr("aria-label","Fermer le menu mon profil");

        // Afficher le menu et l'icone delete
        $('#profile-menu-calque .croix').css("display","flex");
        showMenu('menu-calque-body-profile');
        $('#menu-calque-background').click(onProfileClick);
        $('body').css('max-height', '100vh').css('overflow', 'hidden');
        $('.menu-nav #menu-calque').css('display', 'none');
        function hideMain() {
            $('.alert-user').css('display', 'none');
            $('#main').css('display', 'none');
            $('#main-footer').css('display', 'none');
        }
        setTimeout(hideMain, 500);

        // Icone profile sous fond bleu
        profileIcon.parent().addClass('icon-picto-active-back');
        profileIcon.addClass('font-white');
    } else {
        // Cacher le menu profil et reafficher le burger
        profileIcon.attr('class', 'icon-picto-profil font-size-xl');

        //modifier le aria-label des icones pour l'accessibilite
        $('#profile-menu-calque').attr("aria-label","Ouvrir le menu mon profil");

        $('#profile-menu-calque .croix').css("display","none");
        $('.menu-nav #menu-calque').css('display', 'block');
        hideMenu();
        $('body').css('max-height', 'auto').css('overflow', 'auto');
        $('.alert-user').css('display', 'block');
        $('#main').css('display', 'block');
        $('#main-footer').css('display', 'block');

        // Icone profile sous fond blanc
        profileIcon.parent().removeClass('icon-picto-active-back');
        profileIcon.removeClass('font-white');
    }
}


// Gestion de l'affichage du menu
$('#menu-calque').click(onMenuClick);
$('#profile-menu-calque').click(onProfileClick);
// Gestion du header dock
$(document).scroll(function () {
    // La largeur cible c'est 767px
    onClientViewScroll(767);
});





// MENU BLEU

    var coll = document.getElementsByClassName("collapsible");
    var i;

    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
            this.classList.toggle("active");
            this.parentNode.classList.toggle('active');
            var content = this.nextElementSibling;

            if (content.style.maxHeight){
                content.style.maxHeight = null;
                content.style.visibility = "hidden";
                content.setAttribute('aria-hidden', 'true');
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
                content.style.visibility = "visible";
                content.setAttribute('aria-hidden', 'false');
            }

        });
    }

});
