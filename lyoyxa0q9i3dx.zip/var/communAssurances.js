//accueil.js

// appel pour fonction onload	
addOnloadFunction(checkeMessageErreur);

/*
* fonction d'affichage du message d'erreur
* * @param libelle
*/
function afficherMsgErreur(libelle) {
	libelle = libelle.replace("'","\'");
	libelle = libelle.replace("\t","");
	libelle = libelle.replace("\n","");
	alert(libelle);
}

/*
* fonction de valorisation du champ hidden associe au champ passe en parametre 
* @param champ
*/
function mettreAJourChampHidden(champ) {
	var champHidden = document.getElementById(champ.id + 'Hidden');
	if(champHidden !== null) {
		champHidden.value = champ.value;
	}
}
	
/*
* fonction de focus du champ dont l'id est passe en parametre
* @param idChamp
*/
function focusChamp(idChamp) {
	var champAFocus = document.getElementById(idChamp);
	if(champAFocus !== null) {
		//champAFocus.disabled = false;
		champAFocus.focus();
	}	
}	

/*
 * Formattage pour affichage arrondi , avec deux decimales
 * Gestion des lettres et signe negatif
 * 
 */
function formatterValeurPourAfficher(nombreAFormat) {
	var nombreAFormatter = nombreAFormat.toFixed(2);
	nombreAFormatter = nombreAFormatter.replace(".", ",");
	//cas d'un chiffre negatif --> remplacer par 0
	if (nombreAFormatter.indexOf('-') !== -1) {
		nombreAFormatter = "0";
	}
	
	//cas de pas de d�cimales
	if (nombreAFormatter.indexOf(',') === -1) {
		nombreAFormatter = nombreAFormatter.concat(",00");
	}
	else{
		//cas de 1 seule decimale
		var splitChaine = nombreAFormatter.split(',');
		if (splitChaine[1].length === 1){
			nombreAFormatter = nombreAFormatter.concat("0");
		}
	}
	return nombreAFormatter.replace("NaN","0");
};


/*
 * Arrondir un chiffre a 2 decimales. Renvoi un number
 * 
 */
function arrondirNumberDeuxDecimales(nombreAFormatter) {
	
	var nombreAFormatterArrrondi = nombreAFormatter;
	nombreAFormatterArrrondi = nombreAFormatterArrrondi.toFixed(2);
	nombreAFormatterArrrondi = parseFloat(nombreAFormatterArrrondi);
	
	return nombreAFormatterArrrondi;
}

