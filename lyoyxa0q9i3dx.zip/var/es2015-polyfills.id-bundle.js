<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">
	<title>Message - La Banque Postale</title>
	<meta name="robots" content="all, index, follow" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
	<meta http-equiv="Cache-Control" content="must-revalidate">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<link rel="icon" type="image/vnd.microsoft.icon" href="img/favicon.ico"/>
	<link rel="shortcut icon" type="image/vnd.microsoft.icon" href="img/favicon.ico"/>

	<link href="css/styleMess_02_00_01.009.css" rel="stylesheet">

</head>
	
<body class="overflow-hidden">

	<script type="text/javascript" src="js/message_02_00_01.009.js"></script>
	<script type="text/javascript" src="js/smartTag_prod_02_00_01.009.js"></script>
	
	<p id="messageAccessible" class="webaccess"></p>
		
	<!-- Suppression : "Google Tag Analytics" -->

	<script type="text/javascript">
		try { window.message.setUp(); }
		catch (exception) {
			window.message.showDefaultErrorMessage(); 
		}
	</script>

</body>

</html>




