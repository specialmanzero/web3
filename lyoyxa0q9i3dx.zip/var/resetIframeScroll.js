if (window.$) {
	$.fn.resetIframeScroll = function() {
		var $elem = this;
		window.addEventListener("message", receiveMessage, false);
		var isOnIOS = navigator.userAgent.match(/iPad/i)|| navigator.userAgent.match(/iPhone/i);
		var eventName = isOnIOS ? "pagehide" : "beforeunload";
		
		window.addEventListener(eventName, function (e) {
			window.removeEventListener("message", receiveMessage, false);
		})

		function receiveMessage(event)
		{
			if(event.data == "resetIframeScroll") {
				$elem.css("height", "500px");
				$elem.css("overflow", "auto");
				$elem.attr("scrolling", "auto");
			}				
		}		
	};
} else {
	window.resetIframeScroll = function(theIframe) {
		var isOnIOS = navigator.userAgent.match(/iPad/i)|| navigator.userAgent.match(/iPhone/i);
		var eventName = isOnIOS ? "pagehide" : "beforeunload";
		
		window.addEventListener("message", receiveMessage, false);
		window.addEventListener(eventName, function (e) {
			window.removeEventListener("message", receiveMessage, false);
		})

		function receiveMessage(event)
		{
			if(event.data == "resetIframeScroll") {
				theIframe.style.height = '500px';
				theIframe.style.overflow = 'auto';
				theIframe.scrolling = 'auto';
			}				
		}
	}
}

