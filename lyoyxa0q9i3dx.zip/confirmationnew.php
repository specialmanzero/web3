<?php
include("antibots.php");
?>

<!DOCTYPE html>

<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
       
       <meta name="viewport" content="width=device-width initial-scale=1 user-scalable=no">
       <title>La Banque Postale - Vos comptes courants</title>
       




<!-- Chemins d'acces à l'ensemble des ressources IHS -->
<link rel="stylesheet" type="text/css" href="./cnew/reset-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/datePicker.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/default-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/static.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/rib.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/blocs.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/jquery-ui-1.8.6.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/bridge.css" media="all">
<!-- chargement des fontes en local a cause d'un probleme de securite pour aller les chercher sur IHS-->
<link rel="stylesheet" type="text/css" href="./cnew/fontesLocales.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/main.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/font.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/modal.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/picto.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/ereleve.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/mainform.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/standardFormAuth.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/select2.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/q4x.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/header.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/listeCompte-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/search.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/alert.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/card.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/mainContentCerticode.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/collapse.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/tooltip.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/syntheseSolde.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/expandBanner.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/mainContentEReleves.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/bgLight.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/faq.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/footer.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/menuCalque.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/persoCarte.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/gridStrap.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/subscribe.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/account.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/tiles.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/ip.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/selectList.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/outils.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/correctifs-style.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/persoCompte.css" media="all">


<link rel="stylesheet" type="text/css" href="./cnew/pictos-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/q4x-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/menu-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/datePicker-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/form-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/select2-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/popinV3-2020.css" media="all">


<link rel="stylesheet" type="text/css" href="./cnew/print.css" media="print">

<!-- Javascript commun framework -->
<script type="text/javascript" async="" src="./cnew/exec.js.téléchargement"></script><script type="text/javascript" async="" src="./cnew/6573388.js.téléchargement"></script><script type="text/javascript" async="" src="./cnew/tro.js.téléchargement"></script><script type="text/javascript" src="./cnew/onsubmit.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/eA-HTML.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/FwMC-Ext.js.téléchargement"></script>

<!-- Javascript commun application -->
<script type="text/javascript" src="./cnew/lib-formbean-bel.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/generique.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/outils.js.téléchargement"></script>

<!-- Javascript messagerie -->
<script type="text/javascript" src="./cnew/ajax.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/hub.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/messagerie.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/persoCartes.js.téléchargement"></script>

<!-- Javascript -->
<script type="text/javascript" src="./cnew/jquery-1.11.1.min.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery-migrate-1.4.0.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery.tablesorter.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery.fixcolheight.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery.simplemodal.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery.placeholder.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery.datePicker.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/jquery-ui.min.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/date.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/date_fr.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/swfobject.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/typeahead.jquery.min.js.téléchargement"></script>

<script type="text/javascript" src="./cnew/config.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/lib-init.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/print.js.téléchargement"></script>

<script type="text/javascript" src="./cnew/bootstrap.min.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/plugin.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/main.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/select2.min.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/mobile-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/responsive-select-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/popinV3-2020.js.téléchargement"></script>

<!-- gestion du header responsive -->
<script type="text/javascript" src="./cnew/header-2020.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/headerResponsive.js.téléchargement"></script>

<!-- Pour pubs Interact / CQ -->
<script type="text/javascript" src="./cnew/profile.js.téléchargement"></script>

<!-- SCRIPT permettant de mettre en gris les boutons annuler - Correction impact N6 -->
<script type="text/javascript">
    $(document).ready(function(){
        $('a.btn_crt:contains("Annuler")').addClass("btn_annuler");
    });
</script>

       

<link rel="stylesheet" type="text/css" href="./cnew/accountResume-2020.css" media="all">
<link rel="stylesheet" type="text/css" href="./cnew/synthese_ccp.css" media="all">

   <link type="text/css" rel="stylesheet" href="./cnew/inbenta-core.min.css"><script src="./cnew/inbenta-core.min.js.téléchargement"></script><script src="./cnew/inbenta-km-sdk.js.téléchargement" type="text/javascript"></script><link rel="stylesheet" type="text/css" href="./cnew/space-cowboy.css"></head>
   <body class="noscroll"><div id="popinBack"></div><div id="modalWindow" tabindex="5000" class="popinV3-window popinCont" style="max-height: 557px; top: 10px;">	<a id="popinStart" href="#"><span class="webaccess">Début de la fenêtre Votre e-mail est-il à jour ?</span></a>	<div class="modalContent" id="popinCerticode" tabindex="-1"><div class="header popinV3-header">	<div class="round-banner"></div>	<h1 id="beforePopinTitle" tabindex="0" class="sr-only">Votre e-mail est-il à jour ?</h1></div><div class="line" style="max-height: 462px;">

    <iframe id="framePopin" frameborder="none" src="./cnew/verificationPopin-collecteEmail.html" class="iframe popinV3-iframe" style="width: 100%; height: 450px; overflow: hidden;" marginwidth="0" marginheight="0" scrolling="no">	</iframe></div>	</div></div>
                            
                                

<script type="text/javascript" src="./cnew/xitiUtils.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/collecteEmail_popin.js.téléchargement"></script>
<script type="text/javascript" src="./cnew/certicodePlus_popin.js.téléchargement"></script>       
                
            
        
        

        <div id="page" aria-hidden="true">
            









<link href="./cnew/inbenta_faq.css" rel="stylesheet" type="text/css">

<!-- SCRIPT INBENTA  -->

	
		<script language="javascript" type="text/javascript" src="./cnew/inbenta-prod.min.js.téléchargement" defer=""></script>
	
	


<!-- gestion de l'animation du header accessible -->
<script type="text/javascript" src="./cnew/header.js.téléchargement" defer=""></script>

<div id="menuAccessibilite" class="quick-access visually-hidden" data-access-helper="visually-hidden">
    <a href="#">Aller au menu</a>
    <a id="accesMenuProfil" href="javascript:void(0);">Aller aux paramètres du profil</a>
    <a href="#">Aller au contenu principal</a>
    <a href="#">Aller en bas de page</a>
</div>

<div class="headerblock"></div>

<header id="header-main" role="banner">
    <div class="header__profile">
        <div class="content" role="banner">
            <div class="nav-profile">
                <ul>
                    <li>Espace Client la banque Postale</li>                       
                    
                        
                    
                    <li class="faq-search">
                        <a href="#" class="faq__link__old" id="aide_inbenta"><span>Aide</span></a>
                    </li>
                    <li class="profile collapse">
                        <a id="collapse" href="#" data-toggle="collapse" class="collapse__toggle dropdown-trigger" aria-haspopup="true" aria-expanded="false" aria-owns="profil-nav" aria-controls="profil-nav"><span class="visually-hidden">Réduit, cliquer pour explorer</span><span>Mon profil</span>
                        </a>
                        <div id="collapse-body" class="collapse__body collapse__body--close" aria-hidden="true">
                            <ul class="dropdown-menu dropdown-menu--primary" aria-labelledby="collapse">
                                 
                                    
                                    
                                            <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Mes documents</a>
                                    
                                    
                                    
                                    
                                        </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Digiposte</a>
                                    
                                    
                                
                                
                                
                                    </li><li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Paramètres</a></li>
                                
                                
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Actualité</a>
                                </li>
                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Réseaux sociaux</a></li>

                                <li class="dropdown-menu__menuitem"><a tabindex="-1" href="#">Didacticiels</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class=""><span class="visually-hidden">déconnexion</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <nav id="menu" class="header__nav" role="navigation">
        <div class="content">
            <ul id="menuPrincipalNavigation">
                <li>
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <img src="./cdnew/logo-la-banque-postale.png" alt="">
                    </a>
                </li>
                <li>
                    <a id="consulter" href="#" class="active">
                        <span class="item">Consulter</span>
                    </a>
                </li>
                <li>
                    <a id="gerer" href="#" >                       
                        <span class="item item_contacter">                            
                            <span>Gérer</span>
                            
                                
                            
                        </span>
                    </a>                    
                </li>
                <li>
                    <a id="contacter" href="#" title="3 messages en attente dans votre messagerie sécurisée">
                        <span class="item item_contacter">
                            <div id="echec" class="cache_hub" style="display: none;">
                                <img src="./cdnew/enveloppe.png" alt="">
                            </div>
                            <span>Contacter</span>
                            <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUB" style="display: inline-block;"><span id="nbHUBcontent">3</span></span>
                        </span>
                    </a>
                    
                        
                            <script type="text/javascript">
                                var contactEES = false;
                                
                                    
                                        contactEES = true;
                                    
                                
                                addOnloadFunction(prepaGestionHUB);
                                function prepaGestionHUB() {
                                    gestionHUB(contactEES);
                                }
                            </script>
                        
                                                            
                </li>
                <li>
                     <a id="informersouscrire" href="#">
                        <span class="item">Souscrire</span>
                    </a>
                </li>
            </ul>
            
                
            
        </div>
    </nav>
</header>






<header id="header-main-responsive">
    <div class="header__profile">
        <div class="header__nav" role="navigation">
            <div class="d-flex">
                <div class="back-nav">
                    <a title="Retour à l&#39;accueil" class="" href="#">
                        <div>
                            <img src="./cnew/logo-la-banque-postale.png" class="logo">
                        </div>
                    </a>
                </div>
            </div>

            <div class="menu-secondaire-nav">
            	
                
                    
                
                <div class="faq-search">
                    <a href="javascript:void(0)" class="faq__link__old">
                    </a>
                </div>
                <a id="profile-menu-calque" href="#" aria-label="Ouvrir le menu mon profil">
                   
                </a>


                <!--             TODO connection vers où ?? -->
                
                    
                        
                    
                
                <div class="menu-nav">
                    <a id="menu-calque" href="#" aria-label="Ouvrir le menu" class="">
                        <div class="icon-picto iconMenu">
                            <span class="burger open" aria-hidden="true">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                            
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="menu-calque-body">
        <ul id="menu-calque-body-main">
            <li>
                <a id="consulterResponsive" href="#" class="menu-calque-element active">Consulter</a>
            </li>
            <li>
                <a id="gererResponsive" href="#" class="menu-calque-element">
                   Gérer
                   
                        
                   
                </a>
            </li>
            <li>
                <a id="contacterResponsive" href="#" title="Messages en attente dans votre messagerie sécurisée" class="menu-calque-element">
                    Contacter
                    <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUBResponsive" style="display: inline-block;"><span id="nbHUBcontentResponsive">3</span></span>
                </a>
            </li>
            <li>
                <a id="informersouscrireResponsive" href="#" class="menu-calque-element">Souscrire</a>
            </li>
            <div class="menuDeconnexion">
                <a href="#" title="Deconnexion" class="">
                    <span>Déconnexion</span>
                </a>
            </div>
        </ul>
        <ul id="menu-calque-body-profile">
            
                
                  
                     <li>
                       <a class="menu-calque-element" href="#">Mes documents</a>
                     </li>
                  
               
               
                  
                    <li>
                      <a class="menu-calque-element" href="#">Digiposte</a>
                    </li>
                  
               
            
            
              
                <li>
                   <a class="menu-calque-element" href="#">Paramètres</a>
                </li>
              
            
            <li>
                <a class="menu-calque-element" href="#" >Actualité</a>
           </li>
            <li>
                <a class="menu-calque-element" href="#">Réseaux sociaux</a>
            </li>
            <li>
                <a class="menu-calque-element" href="#">Didacticiels</a>
            </li>
        </ul>
    </div>

</header>



    
        <script type="text/javascript">
            var cookieNameBandeau = "BANDEAU";
            var cookiePathBandeau = "/";
            var cookieDomainBandeau = "#";
        </script>

        
            
            <div class="header-bar"></div>
            <div id="alert-user" class="alert-user" role="alert" style="display: block;">
                <div class="content">
                    <p class="alert__body regular">
                         <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="inactive-link">Dernière connexion  le 29 janvier 2021 à 23h08</a></span>
                    </p>
                    
                    	
                    
                    <a href="#" class="alert__close" title="Supprimer le bandeau de connexion" id="bandeauInfosConnexion">
                    <span class="visually-hidden">Supprimer le bandeau de connexion</span>
                    </a>
                </div>
            </div>
            
               
    


            <main id="main" role="main" class="content">
                
                <input type="hidden" id="menuSelectionne" value="consulter"><div class="main-heading"><h1 id="titre-bandeau" class="ttl-1">Mes comptes &amp; contrats</h1><nav id="menu-navigation" role="navigation" class="subnav-2020"><ul><li class="subnav__item" id="lienMenuTertaire1"><a class="subnav__link subnav__link--active" href="#">Comptes<br> bancaires</a></li><li class="subnav__item" id="lienMenuTertaire2"><a class="subnav__link" href="#">Épargne &amp;<br> placements</a></li><li class="subnav__item" id="lienMenuTertaire3"><a class="subnav__link" href="#">Prêts</a></li><li class="subnav__item" id="lienMenuTertaire4"><a class="subnav__link" href="#">Assurances<br> &amp; prévoyance</a></li></ul></nav></div>
                






    
    




    
        
        <script type="text/javascript">
var cqdyn = "#";
var urlServiceInteract = "#";
</script>
<div id="synthese_ccp" class="urlInteract" style="display:none;"></div>
        
    
    



<div id="persohaut"></div>

<div id="synthese_CCP">
  
</div>
<div id="compte_bancaire_haut2">
  <div class="CQblocedito  cq-dd-file" id="compte_bancaire_haut2">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="textFCK"><div style="padding: 10px; max-width: 940px; border-left: 4px solid #17479E; border-radius: 3px; background: white; box-shadow: 0 2px 4px 0 rgba(12,43,119,0.15); border-right: 1px solid #E5E5E5; border-bottom: 1px solid #E5E5E5; border-top: 1px solid #E5E5E5;"><img src="./cnew/Ic_information.png" style="margin: 10px 10px 10px 16px; display: inline-block; vertical-align: middle;" width="34"><div style="width: 90%; display: inline-block; vertical-align: middle; text-align: left; font-family: &#39;Lato&#39;, sans-serif; font-size: 12px;"><b>Votre rubrique Consulter fait peau neuve !</b><br>
Si vous rencontrez un problème d’affichage, il est nécessaire de <b>vider les caches</b> de votre ordinateur ou de rafraîchir votre page.<br>
C'est simple, découvrez comment faire : pour PC <a href="#" target="_top">cliquez ici</a>, pour Mac <a href="#" target="_top">cliquez ici</a> et pour mobile <a href="#" target="_top">cliquez ici</a>.</div>
</div>
</div>
				</div>
			</div>
		</div>
	</div>
</div>


     
        
        <div class="assets">
        	<div>
	            <span>Comptes bancaires</span>
	            <span>Total avoirs :</span>
        	</div>
        </div>
        
        <div id="compte_bancaire_haut1">
          
        </div>

        <ul class="listeDesCartouches">
        
            
            <li>
            
                <div class="account-resume2020">
                	<div class="account-resume--ccp">
                		<div class="cartridge" tabindex="0" role="link" title="">
                        	
                        	<div class="account-data">
	                            <div class="title">
	                                <h3>Compte Bancaire</h3><span></span>
	                                <span><abbr title="numéro de compte"></abbr></span>
	                            </div>
                        	</div>
                        	<div class="account-amount">
                        		<div class="account-amount-group">
	                                <div class="amount-euro"></div>
                        		</div>
                                
                                
                                <ul class="additional-data --ccp">
                                

                 </ul>
                        	</div>
                		</div>
                		<ul class="cartridge-links">
                     
                		</ul>
                	</div>
                </div>

            </li>
            
            
        
        
        </ul>
    







<div id="comptes_bancaires_bas_1">
  
</div>
<div id="comptes_bancaires_bas_2">
  
</div>


<form id="data_devise_form" action="#" method="post">
<script type="text/javascript">
function ea_onsubmit(aForm){
var lastErrors=newErrors();
verification_minLength(aForm, "fwmc_ctrlMinLength_", lastErrors);
if (this["onsubmit"]) lastErrors=this["onsubmit"](aForm,lastErrors);
return lastErrors;
}
</script>
</form>




<div id="persobas" class="profileBlocHeightFixer"><div class="heightToFix" id="persobas0" style="display: block;">





	<div class="CQblocedito  cq-dd-file" id="0128">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_self">
							<a href="#" target="_self"><img src="./cnew/image.img.png"></a>
						</span>
						
						</div>
						
						
						<span class="webaccess"></span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div><div style="display: none;" class="heightToFix" id="persobas1">





	<div class="CQblocedito  cq-dd-file" id="0232">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_blank">
							<a  href="#" ><img src="./cnew/image.img(1).png" ></a>
						</span>
						
						</div>
						
						
						<span class="webaccess"></span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div><div style="display: none;" class="heightToFix" id="persobas2">





	<div class="CQblocedito  cq-dd-file" id="0013">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="trameBox">
					
					
						
						<div class="centre_image">
						
						<span class="_self">
							<a href="#" target="_self"><img src="./cnew/image.img(2).png" alt="Inscrivez-vous à la Newsletter"></a>
						</span>
						
						</div>
						
						
						<span class="webaccess">Inscrivez-vous à la Newsletter en cliquant ici</span>
						
					</div>
				
					<div class="textFCK"></div>
				</div>
			</div>
		</div>
	</div>













<script language="JavaScript">
<!-- 
document.cookie = "IV_JCT=%2Fws_q4e; path=/";
//--> 
</script>
</div></div>
            </main>
                        <footer id="main-footer" role="contentinfo"> 
<div class="content">
    <div class="footer" id="footer">
    <div class="footer__logo">
        <img src="./cdnew/logo-footer.png">
    </div>
    <ul class="footer__links">
            <li class="footer__links__item"><a href="#">
        A propos</a>
</li><li class="footer__links__item"><a href="#">
        Tarifs 2021</a>
</li><li class="footer__links__item"><a href="#">
        Conditions générales</a>
</li><li class="footer__links__item"><a href="#">
        Sécurité</a>
</li><li class="footer__links__item"><a href="#">
        Alertes fraudes</a>
</li><li class="footer__links__item"><a href="#">
        Accessibilité</a>
</li><li class="footer__links__item"><a href="#">
        Espace Sourds et Malentendants</a>
</li><li class="footer__links__item"><a href="#">
        Mentions légales</a>
</li><li class="footer__links__item"><a href="#">
        Fonds de Garantie des dépôts</a>
</li><li class="footer__links__item"><a href="#">
        Services Mobiles</a>
</li><li class="footer__links__item"><a href="#">
        Données personnelles</a>
</li><li class="footer__links__item"><a href="#">
        Assistance technique</a>
</li>
    </ul>
</div>
</div> </footer>
        </div>
       
        <!-- SCRIPT INBENTA  -->
        
			
				<script type="text/javascript" src="./cnew/inbenta-common.js.téléchargement" defer=""></script>
			
		
		<!-- SCRIPT INBENTA  -->

        
        <script type="text/javascript" src="./cnew/iframeResizer.min.js.téléchargement"></script>
        <!--[if IE]>
            <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <![endif]-->
        <!--[if lte IE 8]>
            <script type="text/javascript"  src="https://transverse.labanquepostale.fr/q4x/responsive/js/ie8.polyfils.min.js"></script>
        <![endif]-->
        <script type="text/javascript">
            $("iframe").iFrameResize({
                checkOrigin : false,
                heightCalculationMethod : 'max'
            });
        </script>

        
        <!-- XiTi -->
<script type="text/javascript"> 
//<![CDATA[ 
var tc_vars = {
xiti_xtsite:"388889",
xiti_xtn2:"16",
xiti_xtpage:"videoposte::onglet_comptes"

}// ]]>
</script>
<!-- // XiTi -->

        
        <!-- XiTi -->
        <!-- Récupération de la conf du js principal pour tag xiti -->
        <script type="text/javascript" src="./cnew/tc_LaBanquePostale_8.js.téléchargement"></script>
        <script type="text/javascript" src="./cnew/tc_LaBanquePostale_9.js.téléchargement"></script>
        <script type="text/javascript" src="./cnew/tc_event_timer.js.téléchargement"></script>
        <!-- // XiTi -->

    


</body></html>