<?php

$METRI_TOKEN = "https://api.telegram.org/bot5998675279:AAGlrl1WF1PT2v9uRlxgf-m2kRledqVB6ss";

$chat_id = "-4161595881";



?>