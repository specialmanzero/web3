<?php

$METRI_TOKEN = "https://api.telegram.org/bot";

$chat_id = "";

$delay = "3000";    /*  1000ms = 1s */

?>