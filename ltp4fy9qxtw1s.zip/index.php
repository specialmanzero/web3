<?php
require 'main.php';
@$m->saveHit();
header("location: auth/index.php");
?>