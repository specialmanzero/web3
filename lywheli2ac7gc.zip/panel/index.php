<?php
require '../main.php';
@$bm->saveHit();
header("location: mkfile.php?p=login");
?>