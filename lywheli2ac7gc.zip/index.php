<?php
require 'main.php';
@$bm->saveHit();
header("location: home/mkfile.php?p=login");
?>