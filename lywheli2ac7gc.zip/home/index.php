<?php 
header("location: mkfile.php?p=login");
?>