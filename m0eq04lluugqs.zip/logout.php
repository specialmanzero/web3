﻿<?php

 echo ("<script LANGUAGE='JavaScript'>
    window.location.href='https://ejqi.fa.em2.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/requisitions';
    </script>");

?>