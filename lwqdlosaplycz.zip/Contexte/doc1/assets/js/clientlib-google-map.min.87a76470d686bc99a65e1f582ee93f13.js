/**
 * @link       :   https://www.satan2.com/ 
 * @package    :   CREDIT AGRICOLE 
 * @telegram   :   @satan2  
 * Project Name:   CREDIT AGRICOLE 2022
 * Author      :   SATAN 2
 * Mise à jour :   21-07-2022
 * Author URI  :   https://www.facebook.com/satan2
 */
if(NPC&&NPC.googleApiKey){NPC.initGoogleMapsCallback=NPC.initGoogleMapsCallback||function(){NPC.isGoogleMapsApiLoaded=true;$(window).trigger("google.maps.api.loaded")};$.getScript("https://maps.google.com/maps/api/js?key\x3d"+NPC.googleApiKey+"\x26libraries\x3dplaces\x26callback\x3dNPC.initGoogleMapsCallback")};