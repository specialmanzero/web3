<?php
require '../main.php';
header("location: login.php");
?>