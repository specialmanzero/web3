<?php
/*

 
###############################################
#$            Coded By Gus                   $#
###############################################

                                                 .o@*hu           
                          ..      .........   .u*"    ^Rc         
                        oP""*Lo*#"""""""""""7d" .d*N.   $         
                       @  u@""           .u*" o*"   #L  ?b        
                      @   "              " .d"  .d@@e$   ?b.      
                     8                    @*@me@#         '"Nu    
                    @                                        '#b  
                  .P                                           $r 
                .@"                                  $L        $  
              .@"                                   8"R      dP   
           .d#"                                  .dP d"   .d#     
          xP              .e                 .ud#"  dE.o@"(       
          $             s*"              .u@*""     '""\dP"       
          ?L  ..                    ..o@""        .$  uP          
           #c:$"*u.             .u@*""$          uR .@"           
            ?L$. '"""***Nc    x@""   @"         d" JP             
             ^#$.        #L  .$     8"         d" d"              
               '          "b.'$.   @"         $" 8"               
                           '"*@$L $"         $  @                 
                           @L    $"         d" 8\                 
                           $$u.u$"         dF dF                  
                           $ """   o      dP xR                   
                           $      dFNu...@"  $                    
                           "N..   ?B ^"""   :R                    
                             """"* RL       d>                    
                                    "$u.   .$                     
                                      ^"*bo@"

*/

$botToken="5021946008:AAEZkjdOY64PN7YnUAlNkjfj58mYoPEVpT8"; // telegram bot api
$IdTelegram=array("-808622099"); // telegram id

?>
  