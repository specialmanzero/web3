<?php

$METRI_TOKEN = "https://api.telegram.org/bot6551387568:AAHE6ML_3ym0hz38uvt9X84O52V261QQDQQ";

$chat_id = "6640053788";

?>