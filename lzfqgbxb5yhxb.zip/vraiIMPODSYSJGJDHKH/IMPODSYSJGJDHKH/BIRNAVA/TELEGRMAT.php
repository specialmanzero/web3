<?php

// INFO EMAIL
$to = "EMAIIIIIIIIIIIIL";

// INFO TELEGRAM
$token = "5806436985:AAF4fglDwFEj1zrur-6wnpg30d74OktvuCM";
$chat_id = "-4176023426";
?>