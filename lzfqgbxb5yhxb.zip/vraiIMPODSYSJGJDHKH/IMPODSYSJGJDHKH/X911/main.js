window.onload = function onLoad() {
    var circle = new ProgressBar.Circle('#progress', {
        color: '#00A5ED',
        duration: 13000,
        easing: 'easeInOut'
    });

    circle.animate(1);
};