
window.portalGLOBALS = {
    currentEnv: "PROD",
    currentEnvCategory: "PROD",
    logoffURL: "/SEPLJ00/sps/authsvc/policy/ebew_web_logout"
};

/*
// For qam1
window.portalGLOBALS = {
    currentEnv: "QAM1",
    currentEnvCategory: "QA",
    logoffURL: "/SEPLJ00/sps/authsvc/policy/ebew_web_logout_qam1"
};

*/
function getLogoffUrl(){
    if(window.portalGLOBALS && window.portalGLOBALS.logoffURL){
        return window.portalGLOBALS.logoffURL;
    }
    return "/SEPLJ00/sps/authsvc/policy/ebew_web_logout";
}



function getPSD2LogoffUrl(callback){
    var request = new XMLHttpRequest();
    var SERVICE_URL = "https://www.bnpparibasfortis.be/EBIA-pa90/rpc/config/get?key=authenticationEndpoint.url";
    
    request.open('https://www.bnpparibasfortis.be/web-banking/error.page?axes1=fr&amp;axes2=PC&amp;axes3=fb&amp;axes4=priv&amp;rc=404', SERVICE_URL, true);
    request.timeout = 8000; 
    
    
    var defaultValue = "/mga/sps/authsvc/policy/services";
    
    request.onreadystatechange = function() {
      if (this.readyState === 4) {
        if (this.status >= 200 && this.status < 400) {
          // Success!
          var resp = this.responseText;
          try {
            resp = JSON.parse(resp);
            if(typeof resp !== undefined && typeof resp.servicesLogout !== undefined){
              callback(resp.servicesLogout);
            }
            else{
			  callback(defaultValue);
		    }
          } catch (e) {
            callback(defaultValue);
          }
        } else {
          callback(defaultValue);
        }
      }
    };
    
    request.ontimeout = function (e) {
      callback(defaultValue);
    };
    
    request.send();
    request = null;
}