var ebannerBuild="2022-03-25 10:15:03";

/*
* e-banner.js
*/
// Browser
/* globals document, window, sessionStorage   */
// Libs
/* globals $, PageBus   */
// Sf
/* globals sfAxes1, sfAxes3, sfAxes4, sfNodeId, _satellite,
    digitalData, sfHP, sfCustomerDacLevel   */
// Mobile
/* globals level4, pageId */
/* eslint no-unused-vars: ["error", { "args": "none" }] */


/*
* Helpers
*/

window.isIP = function(address) {
    if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(address)) {
        return (true)
    }
    return (false)
} 

window.setCookieEbanner = function (cname, cvalue, exdays) {
    //console.log("In set cookie");
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    var domainPath = "";
    if (isIP(window.location.hostname)) {   
        domainPath = window.location.hostname;
    } else {             
        domainPath = "." + window.location.hostname.split(".").splice(-2, 2).join(".");
    }
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;domain=" + domainPath + ";";
}

function getCookieData(name) {
    try {
        var pairs = document.cookie.split("; ");
        var count = pairs.length;
        var parts;
        while (count--) {
            parts = pairs[count].split("=");
            if (parts[0] === name) {
                return parts[1];
            }
        }
        return false;
    } catch (ex) { /* Do nothing... */ }
}


function checkTypeOfUrl(alias) {
    if (alias.indexOf("https://www.bnpparibasfortis.be/en/") > -1 || alias.indexOf("https://www.bnpparibasfortis.be/fr/") > -1
        || alias.indexOf("https://www.bnpparibasfortis.be/nl/") > -1 || alias.indexOf("https://www.bnpparibasfortis.be/de/") > -1
        || window.location.pathname.substring(1) === ""
        || window.location.pathname.substring(1) === "https://www.bnpparibasfortis.be/") {
        // normal
        return "";
    }

    if (alias.indexOf("pm_") > -1) {
        return "C0020S2000P0000F0000A0000M00B0";
    }

    if (alias.indexOf("app_") > -1 || alias.indexOf("web_") > -1) {
        // technical
        return "";
    }
    if (alias.indexOf(".asp") > -1 || alias.indexOf(".page") > -1
        || alias.indexOf("lnk_") > -1 || alias.indexOf("BNPP_") > -1) {
        // technical
        return "";
    }
    if (alias.indexOf("anon/index.html") > -1 || alias.indexOf("logoff/index.html") > -1) {
        // technical
        return "";
    }
	if (alias.indexOf("bnpparibasfortis.be") > -1 && alias.indexOf("/itsme/enrol") > -1) {
        return "C0011S1111P0000F0000A0000M00B0";
    }
	if (alias.indexOf("hellobank.be") > -1 && alias.indexOf("/itsme/enrol") > -1) {
        return "C0011S1111P0000F0000A0000M00B1";
    }
	if (alias.indexOf("bnpparibasfortis.be") > -1 && alias.indexOf("/lucy") > -1) {
        return "";
    }
	if (alias.indexOf("idp.bnpparibasfortis.be") > -1 || alias.indexOf("idp.qabnpparibasfortis.be") > -1) {
        return "";
    }
    return "C0100S0001P0000F0000A0000M00B0";
}

// The below function is used to add or modify elements in component array
function addOrModifyComponent(_componentType, _attributeValue) {
    var _flagComponentTypeExist = false;
    for (var nrOfComponents = 0; nrOfComponents < digitalData.component.length; nrOfComponents++) {
        if (digitalData.component[nrOfComponents].category.componentType == _componentType) {
            digitalData.component[nrOfComponents].attributes.searchedBranch = _attributeValue;
            _flagComponentTypeExist = true;
            break;
        }
    }
    if (_flagComponentTypeExist === false) {
        var component = {
            componentInfo: '',
            category: {
                componentType: _componentType
            },
            attributes: {
                searchedBranch: _attributeValue
            }
        };
        digitalData.component.push(component);
    }
}



// The below function is used to add or modify elements (componentType and componentInfo) in component array
function addOrModifyComponentforRTIM(_componentType, _componentInfo, _componentID) {
	/*
		* For RTIM , there can be multiple banners, component array to have multiple elements for each banner.
		* if component array length == 0 , create a new element
		* if component array length !== 0 and contains componentType , create a new element
		* if component array length !== 0 and no componentType , update componentType and componentInfo
	*/

    var _createNewElement = true;
    for (var nrOfComponents = 0; nrOfComponents < digitalData.component.length; nrOfComponents++) {
        if (digitalData.component[nrOfComponents].category.componentType !== null || typeOf (digitalData.component[nrOfComponents].category.componentType !== 'undefined')) {
            _createNewElement = true;
            
        } else {
        	digitalData.component[nrOfComponents].category.componentType = _componentType;
            digitalData.component[nrOfComponents].componentInfo = _componentInfo;
        	 _createNewElement = false;
        }
    }
    if (_createNewElement === true) {
        var component = {
            componentInfo: _componentInfo,
	    	componentID: _componentID,
            category: {
                componentType: _componentType
            }
        };
        digitalData.component.push(component);
    }
}




/*The below function is to detect the site used is transactional as well its a small screen*/
function isSwitchtoLargeDevice() {
    var _isScreenSmall = false;
    if (document.getElementsByClassName('alt_screen').length) {
        if (window.getComputedStyle(document.getElementsByClassName('alt_screen')[0]).getPropertyValue('display') !== "none") {
            _isScreenSmall = true;
        }
    }
    return _isScreenSmall;
}



/*
* For the mobile flows
*/

if(location.search.indexOf("client_id") > -1){
    var url = new URL(https://www.bnpparibasfortis.be/local/errors/default.html?errorinfo=ID17425059513295272086);
    var valueForClientId = url.searchParams.get("client_id");
    try{
        var reg = /^\d+$/;
        if(reg.test(valueForClientId)){
            sessionStorage.setItem('zoomitId', valueForClientId);
        }
    }
    catch (ex) { /* Do nothing... */ }
}


if(location.search.indexOf("consent_type") > -1){
    var url = new URL(https://www.bnpparibasfortis.be/local/errors/default.html?errorinfo=ID17425059513295272086);
    var valueForCookie = url.searchParams.get("consent_type");
    valueForCookie = decodeURI(valueForCookie);
    
    var valueToStore = "";
    var valueToCheck = valueForCookie.split("|");
    var blockStorageCC = false;
    
    for (let i = 0; i < valueToCheck.length; i++) {
        var allowedValues = ["cc_default", "cc_functional", "cc_comfort", "cc_version"];
        var keyValue = valueToCheck[i].split(":");
        if(allowedValues.indexOf(keyValue[0]) === -1){
            blockStorageCC = true;
            console.log("Wrong Synthax for Cookie value");
        }
        valueToStore += keyValue.join(":") + "|";
    }
    valueToStore = valueToStore.slice(0, -1);
    
    if(!blockStorageCC){
        console.log("CookieConsent override for mobile");
        setCookieEbanner("COOKIES_SETTINGS", valueToStore, 180);
    }
}


/*
* Content
*/

var mobileBridge;
try {
    var isIOS = !!window.iOSBridge;
    var isAndroid = !!window.AndroidBridge;

    if (isIOS) {
        mobileBridge = window.iOSBridge;
        mobileBridge.url = window.iOSBridge.getBaseURL();
    } else if (isAndroid) {
        mobileBridge = window.AndroidBridge;
        mobileBridge.url = window.AndroidBridge.getAjaxBaseUrl();
    }
} catch (err) {
    mobileBridge = false;
    mobileBridge.url = "";
}



var isWeb = true;
try {
    if ((window.location.href).substring(0, 6) === 'file:/') {
        isWeb = false;
    } else {
        isWeb = true;
    }
} catch (err) { /* Do nothing... */ }



var nodeId = "";
var flagIsSmallScreen = "";
var level4BackUp = "";
try {
    if (typeof(sfNodeId) != 'undefined') {
        if (sfNodeId == 'null') {
            nodeId = "error page";
        } else {
            nodeId = sfNodeId.substring(0, sfNodeId.length - 3);
        }
    }
} catch (err) { /* Do nothing... */ }



var errorServiceFailed = false;

var digitalDataObj = function() {

    var digitalObject = {};
    var demoMode = "";

    /********************************************* Adding User information Starts ****************************************************/


    var getUser = function() {

        var profile = {
            profileInfo: {
                profileID: ''
            },
            attributes: {
                authenticationStatus: '',
                status: '',
                analyticsId: '',
                marketingCloudId: ''
            },
            segment: {
                customerType: '',
            }
        };
        try {
            var status = function(authenticationStatus) {
                var _dlstatusStr = "";
                if (authenticationStatus === "5" || authenticationStatus === "3") {
                    _dlstatusStr = "loggedon";
                } else {
                    _dlstatusStr = "loggedoff";
                }

                return _dlstatusStr;
            };

            var authStatus = '';
            var _customerType = '';
            var _userType = '';

            if (isWeb) {

                profile.attributes.authenticationStatus = (typeof(sfCustomerDacLevel) !== 'undefined') ? sfCustomerDacLevel : "";
                authStatus = profile.attributes.authenticationStatus;

                var fetchCustomerId = function(status) {
                    var _customerId = "";
                    if (status === "5" || status === "3") {
                        try {
                             _customerId = sessionStorage.getItem('zoomitId');
                        } catch (err) { /* Do nothing... */ }
                    }
                    var cc_cookie = getCookieData("COOKIES_SETTINGS");
                    if(!cc_cookie){
                        _customerId = "";
                    }
                    if(cc_cookie){
                        cc_cookie = cc_cookie.split("|");
                        cc_cookie.forEach(function(element) {
                            var current_cc = element.split(":");
                            var cookiename = current_cc[0];
                            var cookievalue = current_cc[1];
                            if(cookiename == "cc_functional" && cookievalue == 0){
                                _customerId = "";
                            }
                        });
                    }

                    // The un authentication check for _customerId is completely removed in MR1 16

                    return _customerId;

                };

                profile.profileInfo.profileID = fetchCustomerId(profile.attributes.authenticationStatus);
                try {
                    _customerType = sessionStorage.getItem('clientType');
                } catch (err) { /* Do nothing... */ }

            } else {
                profile.attributes.authenticationStatus = mobileBridge.getCustomConfiguration('authenticationStatus');
                authStatus = profile.attributes.authenticationStatus;

                profile.profileInfo.profileID = mobileBridge.getCustomConfiguration('amcSDKaltid');
                profile.attributes.analyticsId = mobileBridge.getCustomConfiguration('amcSDKaid');
                profile.attributes.marketingCloudId = mobileBridge.getCustomConfiguration('amcSDKmid');
                _customerType = mobileBridge.getCustomConfiguration('clientType');
                _userType = mobileBridge.getCustomConfiguration('blueFlag');
                switch (_userType) {
                    case "1":
                        profile.attributes.userType = "G";
                        break;
                    case "2":
                        profile.attributes.userType = "GM";
                        break;
                    case "3":
                        profile.attributes.userType = "BM";
                        break;
                    case "4":
                        profile.attributes.userType = "B";
                        break;
                    default:
                        profile.attributes.userType = "";
                }
                // To show the 'C' to all the authenticated hybrid pages
                try {
                    if (sessionStorage.getItem('downGradedFromBlueFlag') === _userType) {
                        profile.attributes.userType = "C";
                    }
                } catch (err) { /* Do nothing... */ }
            }

            profile.attributes.status = status(authStatus);
            switch (_customerType) {
                case "00":
                    profile.segment.customerType = "Expats";
                    break;
                case "01":
                    profile.segment.customerType = "Mixed professionals and private";
                    break;
                case "02":
                    profile.segment.customerType = "Mixed professionals and wealth";
                    break;
                case "03":
                    profile.segment.customerType = "Private";
                    break;
                case "04":
                    profile.segment.customerType = "Wealth";
                    break;
                case "05":
                    profile.segment.customerType = "Retail (particuliers)";
                    break;
                case "06":
                    profile.segment.customerType = "Professional";
                    break;
                default:
                    profile.segment.customerType = "";
            }
        } catch (err) { /* Do nothing... */ }
        return profile;
    };
    /********************************************* Adding User information Ends ****************************************************/

    /********************************************* Adding FAQ Starts ****************************************************/
    var getFaq = function() {
        var faqObj = {
            faqTopicList: "",
            itemListExpand: "",
            faqSearchKeyword: ""
        };

        return faqObj;
    };
    /********************************************* Adding FAQ Ends ****************************************************/

    /********************************************* Adding Component Starts ****************************************************/

    var mediaFileName = function(Name) {
        var fileName = "";
        if (Name !== "" && Name !== undefined) {
            var _fullName = Name;
            var _spiltName = _fullName.split('_');
            var _arrayLen = _spiltName.length;
            var temp = "";
            for (var a = 1; a < _arrayLen - 1; a++) {
                if (_spiltName[a] !== "") {
                    temp = temp + '_' + _spiltName[a];
                }
            }
            fileName = temp.substring(1, temp.length);
        }
        return fileName;
    };

    var getComponentArray = function() {

        var components = [];

        try {
            var component = {
                componentInfo: '',
                componentID: '',
                category: {},
                attributes: {}
            };
            if (window.aPlyrCfgs !== undefined) {
                $.each(window.aPlyrCfgs, function() {
                    var _Name = '',
                        _componentType = '',
                        _componentsLength = '';
                    if (this.mediaType === "audio") {
                        _Name = mediaFileName(this.media.mp4a);
                        _componentType = "audio";
                    }
                    if (this.mediaType === "video") {
                        _Name = mediaFileName(this.media.smil);
                        _componentType = "video";
                    }
                    component.componentInfo = _Name;
                    component.category.componentType = _componentType;
                    _componentsLength = window.jwplayer().getDuration();
                    component.attributes.componentsLength = _componentsLength;
                    components.push(component);
                });
            }

            $(document).find('.margin_col .ls-area-body .wcm-banner').each(function(index) {
                component.attributes = {
                    bannerType: "homepage",
                    bannerPosition: "",
                    targetBannerFlag: 0,
                    playerType: "Belgacom Streaming Service",
                    campaignID: '',
                    componentsLength: ''
                };
                component.componentInfo = $(this).find('img').attr('data-bannerid');
                component.attributes.campaignID = $(this).find('img').attr('data-campaignid');
                component.attributes.bannerPosition = "pos" + index;
                components.push(component);
            });
        } catch (err) { /* Do nothing... */ }
        return components;
    };
    /********************************************* Adding Component Ends ****************************************************/


    /********************************************* Adding Page Element Starts **************************************************/

    var getPage = function() {

        var getLevel = function() {
            var level4 = '';
            try {

                var navHeadEle = $('.mm_link_title');
                if (typeof(navHeadEle) != 'undefined') {
                    navHeadEle.click(function(e) {

                        var level4Str = $(e.target).attr('data-webanalytics'),

                            level4Arry = '';

                        if (level4Str != undefined) {
                            level4Arry = level4Str.split('.')[1];
                        }

                        switch (level4Arry) {

                            case 'moneytransfers':
                                level4 = "payments";
                                break;

                            case 'standingorders':
                                level4 = "payments";
                                break;

                            case 'beneficiarymanagement':
                                level4 = "payments";
                                break;

                            case 'directdebits':
                                level4 = "payments";
                                break;

                            case 'accounts':
                                level4 = "accounts";
                                break;

                            case 'cards':
                                level4 = "cards";
                                break;

                            case 'overview':
                                level4 = "accounts";
                                break;

                            case 'zoomit':
                                level4 = "zoomit";
                                break;

                            case 'contact-usb13':
                            case 'contact-us-authenticatedc1a':
                            case 'contact-usbff':
                            case 'contact-us-authenticated41a':
                                level4 = "contact us";
                                break;

                            case 'faq':
                                level4 = "faq";
                                break;

                            case 'disclaimer-unauthenticated818':
                                level4 = "disclaimer";
                                break;

                            default:
                                level4 = "";
                                break;

                        }

                    });
                }
                if (level4 == undefined || level4 == "") {
                    var current_sfNodeId;
                    if(typeof(sfNodeId) !== 'undefined'){
                        current_sfNodeId= sfNodeId;
                    }
                    if (current_sfNodeId == "index4b2") {
                        level4 = "home individuals";
                    }
                    if ((nodeId.indexOf("accounts") > -1) || (current_sfNodeId == "index1e5")) {
                        level4 = "accounts and cards";
                    }
                    if (nodeId.indexOf("Transactionseed") > -1) {
                        level4 = "accounts";
                    }
                    if (nodeId.indexOf("Zoom") > -1) {
                        level4 = "zoomit";
                    }
                    if (nodeId.indexOf("standing") > -1) {
                        level4 = "payments";
                    }
                    if (nodeId.indexOf("Cardtransaction") > -1) {
                        level4 = "cards";
                    }
                    if (nodeId.indexOf("benef") > -1) {
                        level4 = "payments";
                    }
                    if (nodeId.indexOf("Send-Money") > -1) {
                        level4 = "payments";
                    }
                    if (nodeId.indexOf("sepa-direct-debit") > -1) {
                        level4 = "payments";
                    }
                    if (sfNodeId.indexOf("contact-us") > -1) {
                        level4 = "contact us";
                    }
                    if ((sfNodeId.indexOf("faq") > -1) || (sfNodeId.indexOf("Faq") > -1)) {
                        level4 = "faq";
                    }
                    if (sfNodeId.indexOf("null") > -1) {
                        level4 = "error page";
                    }
                    if ((sfNodeId.indexOf("privacy") > -1) || (sfNodeId.indexOf("Privacy") > -1)) {
                        level4 = "privacy";
                    }
                    if ((sfNodeId.indexOf("cookies") > -1) || (sfNodeId.indexOf("Cookies") > -1)) {
                        level4 = "cookies";
                    }
                    if ((sfNodeId.indexOf("disclaimer") > -1) || (sfNodeId.indexOf("Disclaimer") > -1)) {
                        level4 = "disclaimer";
                    }
                    if ((sfNodeId.indexOf("borrow-capacity") > -1) || (sfNodeId.indexOf("fin-plan") > -1) || (sfNodeId.indexOf("solar-configurator") > -1) || (sfNodeId.indexOf("orientationScreen") > -1)) {
                        level4 = "mortgage";
                    }
                    // level4 for analytics settings
                    if ((sfNodeId.indexOf("besettings6b6") > -1) || (sfNodeId.indexOf("Contact-data829") > -1) || (sfNodeId.indexOf("consent-managementda0") > -1) || (sfNodeId.indexOf("accshowhidefae") > -1) || (sfNodeId.indexOf("minorsae4") > -1) || (sfNodeId.indexOf("i-message2a1") > -1) || (sfNodeId.indexOf("phone-banking-access113") > -1) ) {
                        level4 = "settings";
                    }

                }

            } catch (err) { /* Do nothing... */ }
            return level4;
        };

        var pageObj = {
            pageInfo: {
                pageID: '',
                pageName: '',
                url: '',
				psd2_channel: '',
                searchKeyword: '',
                searchSegment: '',
                searchResult: '',
                personalMessageID: '',
				trackMethod: ''
            },
            attributes: {
                sysEnv: '',
                primaryCategory: '',
                language: '',
                subCategory1: '',
                subCategory2: '',
                pageLoadTime: '',
                level4: '',
                hub: '',
                template: '',
                templateVersion: '',
                errorMessage: '',
                viewType: '',
                digitalChannel: '',
                pageLevel: '',
                previousPageName: ''
            }
        };

        var channel = '';

        if (isWeb) {
            channel = getCookieData('distributorid');
            if ((channel !== undefined) && (channel !== null) && (channel !== false)) {
                pageObj.attributes.sysEnv = channel.substring(0, 2);
            }
            pageObj.attributes.primaryCategory = (typeof(sfAxes3) !== 'undefined') ? sfAxes3 : "";
            pageObj.attributes.language = (typeof(sfAxes1) !== 'undefined') ? sfAxes1 : "";
            pageObj.attributes.subCategory1 = (typeof(sfAxes4) !== 'undefined') ? sfAxes4 : "";

            try {
                if (typeof(sfHP) !== 'undefined' && (sfHP !== null)) {
                    if (sfHP == '') {
                        pageObj.attributes.subCategory2 = "daily banking"; // if subCategory 2 is not having any value ,set to default as daily banking
                    } else {
                        if(window.location.pathname.indexOf("error.page") > -1){
                            pageObj.attributes.subCategory2 = "general";
                        } else {
                            var coi;
                            if (sfHP.indexOf(';') > -1) {
                                var temp = sfHP.split(';');
                                var coiTemp = temp[0];
                                coi = coiTemp.substring(0, coiTemp.length - 3);
                                pageObj.attributes.subCategory2 = (typeof(coi) !== 'undefined') ? coi.replace(/-/g, " ") : "daily banking"; // if subCategory 2 is not having any value ,set to default as daily banking
                            } else {
                                coi = sfHP.substring(0, sfHP.length - 3);
                                pageObj.attributes.subCategory2 = coi.replace(/-/g, " ");
                            }
                        }
                    }
                } else {
                    pageObj.attributes.subCategory2 = "";
                }
            } catch (err) {
                pageObj.attributes.subCategory2 = "";
            }
            pageObj.attributes.level4 = getLevel();
            try {
                pageObj.attributes.pageLoadTime = (window.performance.timing.loadEventEnd - window.performance.timing.navigationStart);
            } catch (err) {
                pageObj.attributes.pageLoadTime = "";
            }
            try {
                var pageUrl = window.location.href.split('https://www.bnpparibasfortis.be/');
                pageObj.pageInfo.url = "https://" + pageUrl[2];
            } catch (err) {
                pageObj.pageInfo.url = "";
            }

            pageObj.pageInfo.pageID = nodeId;
			
			if (sfNodeId.indexOf("index746") > -1 || sfNodeId.indexOf("paymentse8e") > -1 || sfNodeId.indexOf("accounts93b") > -1){
				pageObj.pageInfo.psd2_channel = "EBW";
			
			} else if (sfNodeId.indexOf("ebb-payments802") > -1 || sfNodeId.indexOf("ebblogon9b9") > -1 || sfNodeId.indexOf("ebb-contract-selectione10") > -1){
				pageObj.pageInfo.psd2_channel = "EBB";
			}

            // searched keyword gets traced while tapping Magnify search button
            try {
                if (sessionStorage.getItem('searchKeyword') !== '') {
                    pageObj.pageInfo.searchKeyword = sessionStorage.getItem('searchKeyword');
                    sessionStorage.setItem('searchKeyword', '');
                }
            } catch (err) { /* Do nothing... */ }

            // The public search results count getting updated when searched
            if (typeof PageBus != "undefined") {
                PageBus.subscribe("publicSearchResult", this, function(data, msg) {
                    if (typeof msg.searchResult != "undefined") {
                        try {
                            pageObj.pageInfo.searchResult = msg.searchResult.toString();
                        } catch (e) {
                            pageObj.pageInfo.searchResult = msg.searchResult;
                        }
                        try {
                            _satellite.track('search');
                        } catch (e) { /* Do nothing... */ }
                    }
                });
            }

        } else {
            pageObj.attributes.sysEnv = mobileBridge.getCustomConfiguration('sysEnv');
            pageObj.attributes.primaryCategory = mobileBridge.getCustomConfiguration('primaryCategory');
            pageObj.attributes.language = mobileBridge.getAxesLanguage();
            pageObj.attributes.subCategory1 = mobileBridge.getCustomConfiguration('subCategory1');
            pageObj.attributes.subCategory2 = mobileBridge.getCustomConfiguration('subCategory2');
            pageObj.attributes.level4 = (typeof(level4) !== 'undefined') ? level4 : getLevel();
            pageObj.attributes.viewType = mobileBridge.getCustomConfiguration('viewType');

            nodeId = (typeof(pageId) !== 'undefined') ? pageId : nodeId;
            demoMode = mobileBridge.getCustomConfiguration('DEMO_MODE');
            if (demoMode == "true") {
                pageObj.pageInfo.pageID = nodeId + ":demo";
            } else {
                pageObj.pageInfo.pageID = nodeId;
            }

            pageObj.pageInfo.url = mobileBridge.url;
        }
        return pageObj;

    };



    /********************************************* Adding Page Element Ends ****************************************************/



    /********************************************* Adding Messagent Starts **********************************************/



    // Adding messagent container in the DLO
    var getOnlineSalesAndServiceFlows = function() {

        var onlineSalesAndServiceFlows = {
            flowName: "",
            flowType: "",
            stepName: "",
            stepSeq: "",
            stpFlag: "", // This Flag value Will be updated by Messagent
            product: []

        };

        return onlineSalesAndServiceFlows;
    };


    /********************************************* Adding Messagent Ends ****************************************************/


    /********************************************* Adding DataLayerMetadata Starts **********************************************/
    var getDataLayerMetadata = function() {

        var DataLayerMetadataObj = {
            dataLayerVersion: "V3.0",
            pageReady: "Y"
        };

        return DataLayerMetadataObj;
    };
    /********************************************* Adding DataLayerMetadata Ends ****************************************************/


    /********************************************* Adding DataLayerMetadata Starts **********************************************/
    var getTransation = function() {

        var transaction = {
            transferType: '',
            variableAmount: ''
        };

        // The Transfer Type Getting Updated in sepa confirmation screen
        if (typeof PageBus != "undefined") {
            PageBus.subscribe("sepaTransferType", this, function(data, msg) {
                if (typeof msg.transferType != "undefined") {
                    transaction.transferType = msg.transferType;
                }
            });
        }

        return transaction;
    };
    /********************************************* Adding DataLayerMetadata Ends ****************************************************/


    digitalObject.user = new getUser();
    digitalObject.faq = new getFaq();
    digitalObject.page = new getPage();
    digitalObject.event = [{
        eventInfo: {
            eventAction: "",
            eventName: "",
            eventType: ""
        }
    }]; //initializing event as an array.
    digitalObject.component = new getComponentArray();
    digitalObject.DataLayerMetadata = new getDataLayerMetadata();
    digitalObject.onlineSalesAndServiceFlows = new getOnlineSalesAndServiceFlows();
    digitalObject.transaction = new getTransation();

    var count = 0;
    if (typeof PageBus != "undefined") {
        PageBus.subscribe("progress.start", this, function(subj, msg) {
            count++;
            digitalObject.DataLayerMetadata.pageReady = "N";
        });

        PageBus.subscribe('wcm.sf.displayError', this, function(subj, msg, data) {
            digitalObject.page.attributes.errorMessage = msg.message;

            // Update global variable to tell the unload function that we had an error
            errorServiceFailed = true;
        });

        PageBus.subscribe("progress.stop", this, function(subj, msg) {
            count--;
            if (count < 1) {
                digitalObject.DataLayerMetadata.pageReady = "Y";
                // To Capture the pageReadyTime(Unload to IA Load) once IA Loaded
                // The Value will be set if no sever error other wise wait for 200 ms and set
                if (isWeb) {
                    try {
                        digitalData.DataLayerMetadata.pageReadyTime = (Date.now() - window.performance.timing.navigationStart);
                    } catch (e) {
                        digitalData.DataLayerMetadata.pageReadyTime = "";
                    }
                }
            }
        });

        PageBus.subscribe("changeView", this, function(data, msg) {
            if (typeof _satellite != "undefined") {
                if (typeof msg.moduleId != "undefined" && typeof msg.stepNumber != "undefined") {
                    var flowName = msg.moduleId;
                    var screenId = msg.screenId;
                    var screenNo = msg.stepNumber;

                    if (flowName === "ftuf:downgrade") {
                        // Once First Time User Flow Completed(Green User Downgraded to Blue User)
                        flowName = "first time user flow"; // only for facebook and double click
                        if (screenNo === "1") {
                            screenId = "flowStart"; // only for facebook and double click
                        }
                        var userType = digitalObject.user.attributes.userType;
                        var authenticated = (digitalData.user.attributes.status === "loggedoff") ? "no" : "yes";
                        var cat = "ha42";
                        var type = "hg25";
                        if (screenNo === "4") {
                            //set to session storage to trace the values all over the screens
                            digitalObject.user.attributes.userType = "C";
                            try {
                                sessionStorage.setItem('downGradedFromBlueFlag', '1');
                            } catch (err) { /* Do nothing... */ }
                            cat = "ha43";
                            screenId = "flowEnd"; // only for facebook and double click
                        }
                        // FaceBook Tracking Implementation for FTUF Module during downgrade
                        var _fbTrackingParameters = {
                            "actionType": screenId,
                            "userType": userType,
                            "authenticated": authenticated,
                            "flowName": flowName
                        };
                        if (screenNo === 1 || screenNo === 4) {
                            PageBus.publish("analytics.ftuf.facebook.event.logger", _fbTrackingParameters);
                        }
                        // Double Click Pixel Implementation for FTUF Module during downgrade
                        var axel = Math.random() + "";
                        var a = axel * 10000000000000;
                        var doubleClickLink = "https://4155716.fls.doubleclick.net/activityi;src=4155716;type=" + type + ";cat=" + cat + ";u17=" + userType + ";u18=" + authenticated + ";u19=" + flowName + ";u20=" + screenNo + ";ord=" + a + "?";
                        var iframe = document.createElement('iframe');
                        iframe.frameBorder = 0;
                        iframe.width = "1";
                        iframe.height = "1";
                        iframe.setAttribute("src", doubleClickLink);
                        iframe.setAttribute("style", "display:none");
                        if (screenNo === 1 || screenNo === 4) {
                            // $(".ftuf_content").append(iframe);
                        }
                        flowName = "ftuf:downgrade"; // Rechanged to default after facebook and double click activities
                        if (screenNo === "4") {
                            screenId = "confirmation"; // Rechanged to default after facebook and double click activities
                        } else if (screenNo === "1") {
                            screenId = "information"; // Rechanged to default after facebook and double click activities
                        }
                        digitalData.page.pageInfo.pageID = "downgrade";
                        digitalData.page.attributes.subCategory2 = "daily banking";
                    } else if (flowName === "ftuf:new") {
                        digitalData.page.pageInfo.pageID = "new";
                        digitalData.page.attributes.subCategory2 = "daily banking";
                    }

                    digitalObject.onlineSalesAndServiceFlows.flowName = flowName;
                    digitalObject.onlineSalesAndServiceFlows.stepName = screenId;
                    digitalObject.onlineSalesAndServiceFlows.stepSeq = screenNo;

                    if (screenNo === "1" && digitalObject.transaction.transferType !== "" && flowName === "sepa") {
                        digitalObject.transaction.transferType = "";
                    }
                    try {
                        if (screenNo !== "1" && screenNo != "undefined") {
                            switch (flowName) {

                                case 'sepa':
                                    _satellite.track("paymentSteps");
                                    break;

                                case 'standingOrders':
                                    _satellite.track("permanentOrderSteps");
                                    break;

                                case 'beneficiaries':
                                    _satellite.track("beneficiariesSteps");
                                    break;

                                case 'addProduct':
                                    _satellite.track("addproduct");
                                    break;

                                case 'digitalProtect ':
                                    _satellite.track("digitalprotect");
                                    break;

                            }

                        }
                        switch (flowName) {
                            case 'ftuf:downgrade':
                                _satellite.track("ftuf_down");
                                break;

                            case 'ftuf:new':
                                _satellite.track("ftuf_new");
                                break;
                        }
                    } catch (e) { /* Do nothing... */ }
                }
            }
        });
        if (isWeb) {
            // pagebus event getting triggered when magnify button tapped in header search
            PageBus.subscribe("searchengine.searchquery", this, function(data, msg) {
                try {
                    sessionStorage.setItem('searchKeyword', msg.searchquery);
                } catch (err) { /* Do nothing... */ }
            });
        }
    }
    return digitalObject;
};

digitalData = new digitalDataObj();
var _dataLayerCreated;


$(document).ready(function() {
    try {
    	  if (isWeb) {
    	  	digitalData.page.attributes.sourcetag = checkTypeOfUrl(window.location.href);
    	  }
        
    } catch (err) { /* Do nothing... */ }
    // pageLevel determines the DAC level of the page using WCM Classes
    try {
        if (($('.ls-canvas.portal_wrapper').attr('id').match('Unauthenticated') !== null) || ($('.ls-canvas.portal_wrapper').attr('id').match('publicPortal') !== null)) {
            if ($('#loginintermediate_overlayer').length === 1) {
                digitalData.page.attributes.pageLevel = "authenticated";
            } else {
                digitalData.page.attributes.pageLevel = "public";
            }
        } else {
            if ($('#searchEngine').length === 1) { // A special Condition for search IA
                digitalData.page.attributes.pageLevel = "public";
            } else {
                digitalData.page.attributes.pageLevel = "authenticated";
            }
        }
		_dataLayerCreated = "1";
    } catch (err) { /* Do nothing... */ }
});


$(window).load(function() {
    try {
        if (typeof(mobileBridge) != 'undefined') {
            var demoModeVar = mobileBridge.getCustomConfiguration('DEMO_MODE');
            if (demoModeVar == "true") {
                digitalData.page.pageInfo.pageID = nodeId + ":demo";
            } else {
                digitalData.page.pageInfo.pageID = nodeId;
            }
        }
    } catch (err) {
        digitalData.page.pageInfo.pageID = nodeId;
    }

    // While current page size in transactional site is small the pageId and level 4 is set to "switch to large device"
    try {
        if (isSwitchtoLargeDevice()) {
            var _nodeId = "switch to large device";
            flagIsSmallScreen = true;
            digitalData.page.pageInfo.pageID = _nodeId;
            level4BackUp = digitalData.page.attributes.level4;
            digitalData.page.attributes.level4 = _nodeId;
            _satellite.track('small_screen');
        } else {
            flagIsSmallScreen = false;
        }
    } catch (err) {
        digitalData.page.pageInfo.pageID = nodeId;
    }
    // This is to inform DTM level4 and pageId Fields are Updated
    if (digitalData.page.pageInfo.pageID === "error page") {
        try {
            _satellite.track('errorPage');
        } catch (e) { /* Do nothing... */ }
    }
    try {
        if ($(".fade.in.alert_messages_error").hasClass("show_active")) {
            digitalData.page.attributes.errorMessage = $(".fade.in.alert_messages_error.show_active").find('.alert_message_content p').text();
            _satellite.track('errorMessage');
        } else {
            digitalData.page.attributes.errorMessage = "";
        }
    } catch (err) {
        digitalData.page.attributes.errorMessage = "";
    }

    try {
        digitalData.page.attributes.pageLoadTime = (window.performance.timing.domContentLoadedEventEnd - window.performance.timing.navigationStart);
    } catch (err) {
        digitalData.page.attributes.pageLoadTime = "";
    }

    // searched segment value when tapping magnify search button
    try {
        var _searchSegment = $('.sidebar input:radio[class=css-checkbox]:checked').parent().find('label').text();
        if (_searchSegment !== "")
            digitalData.page.pageInfo.searchSegment = _searchSegment;
    } catch (err) { /* Do nothing... */ }
    // Splash Page Banner Information
    try {
        var _splashBannerComponentInfo = $('.wcm-custom-axes-selection').parents().find('.wcm-severity-message .alert_message_content').find('p').text();
        var _componentType = "banner";
        if (_splashBannerComponentInfo !== "") {
            var component = {
                componentInfo: _splashBannerComponentInfo,
                category: {
                    componentType: _componentType
                },
                attributes: {}
            };
            digitalData.component.push(component);
        }
    } catch (err) { /* Do nothing... */ }
    // check for IA present or not and set the pageReadyTime based on this
    // Its deciding the navigation start from other site or not
    try {
        if (isWeb) {
            digitalData.DataLayerMetadata.pageReadyTime = (Date.now() - window.performance.timing.navigationStart);
        }
    } catch (err) {
        digitalData.DataLayerMetadata.pageReadyTime = "";
    }
    try {
        var _dlitemlistexpand = $('.module_content_inner').find('.dropdown-active .accordion_l1__inner h4').text();
        if (_dlitemlistexpand !== undefined) {
            digitalData.faq.faqTopicList = _dlitemlistexpand;
        }
    } catch (err) {
        digitalData.faq.faqTopicList = "";
    }
    try {

        $('body').on('click', '.accordion_header.dropdown_arrow', function(e) {
            var _topicName = $(this).find('h4').text();
            digitalData.faq.faqTopicList = _topicName;
        });
    } catch (err) {
        digitalData.faq.faqTopicList = "";
    }

    try {

        // Event getting triggered when branch locator is searched in Home Page and in right side of accounts screen after login

        $('body').on('click tap', '.map_inner .block_btn', '#branch_loc_btn', function() {
            var _componentType = "branchlocator";
            var _searchedBranch = $('.default_input_field .branch_locator_input').val() || $('.default_input_field #branch_locator').val();
            addOrModifyComponent(_componentType, _searchedBranch);
        });

        // Event getting triggered when user clicked the Enter button in Branch Locator in Home Page and in right side of accounts screen after login

        $('body').on('keyup', '.default_input_field .branch_locator_input', '.default_input_field #branch_loc_btn', function(event) {
            var _componentType = "branchlocator";
            var _searchedBranch = $(event.target).val();
            if (event.keyCode === 13 && _searchedBranch.length > 1) {
                addOrModifyComponent(_componentType, _searchedBranch);
            }
        });

        // Event getting triggered when user clicked the search button in IA

        $('body').on('click', '#searchEngine .search_icon', function(event) {
            var _searchInput = $(event.target).parents().find('#searchEngine .search_input').val();
            if (_searchInput.length > 1)
                digitalData.page.pageInfo.searchKeyword = _searchInput;
        });

        // Event getting triggered when user clicked the Enter button in search box in IA

        $('body').on('keyup', '#searchEngine .search_input', function(event) {
            var _searchInput = $(event.target).val();
            if (event.keyCode === 13 && _searchInput.length > 1) {
                digitalData.page.pageInfo.searchKeyword = _searchInput.toLowerCase();
            }
        });

        // Event getting triggered when user clicked refined search

        $('body').on('click', '.sidebar .search_segment', function() {
            try {
                digitalData.page.pageInfo.searchSegment = $('.sidebar input:radio[class=css-checkbox]:checked').parent().find('label').text();
            } catch (err) { /* Do nothing... */ }
        });


        $('body').on('click', '.accordion_main.content_l2_list_item', function(e) {
            var topicName = $(this).find('.faq_question').text();
            digitalData.faq.itemListExpand = topicName;
        });



        $('body').on('click', '.save_profile__check', function(e) {
            var _idName = $(this).attr('id');
            digitalData.page.pageInfo.personalMessageID = _idName;
        });

        $('.faq-page .fontcon-search').click(function(e) {
            var faqKeywordSearch = $('.default_input_field input').val();
            digitalData.faq.faqSearchKeyword = faqKeywordSearch;
        });

        // Event getting triggered when user navigating from step1 to step 2 in pimped send money screens
        $('#ebws_dailybanking_newTransfer').on('click', '.navigation_btns .buttondefault', function() {
            if (digitalData.onlineSalesAndServiceFlows.stepSeq === "1") {
                if ($('input[name="USER-DATA.beneficiary-input-choice"]:checked', '#ebws_dailybanking_newTransfer').val() === "1") {
                    digitalData.transaction.transferType = "own account";
                } else if ($('input[name="USER-DATA.beneficiary-input-choice"]:checked', '#ebws_dailybanking_newTransfer').val() === "2") {
                    digitalData.transaction.transferType = "known beneficiary";
                } else if ($('input[name="USER-DATA.beneficiary-input-choice"]:checked', '#ebws_dailybanking_newTransfer').val() === "3") {
                    digitalData.transaction.transferType = "known beneficiary";
                } else if ($('input[name="USER-DATA.beneficiary-input-choice"]:checked', '#ebws_dailybanking_newTransfer').val() === "4") {
                    if ($("#benefStore").is(':checked'))
                        digitalData.transaction.transferType = "known beneficiary";
                    else
                        digitalData.transaction.transferType = "unknown beneficiary";
                }
            }
        });

    } catch (err) { /* Do nothing... */ }

    try {
        if (sfNodeId == "credits-fs-simulation7cf") {
            var firsttimeSimulation = true;

            $(document).on("change", "#creditTypeCode", function() {
                if (!digitalData.onlineSalesAndServiceFlows.loanSimulation) {
                    digitalData.onlineSalesAndServiceFlows.loanSimulation = {};
                }
                var loanType;
                switch ($(this).val()) {
                    case "01":
                        loanType = "car loan - new";
                        break;
                    case "02":
                        loanType = "car loan - second hand";
                        break;
                    case "03":
                        loanType = "renovation loan";
                        break;
                    case "05":
                        loanType = "personal loan";
                        break;
                    case "07":
                        loanType = "energy loan";
                        break;
                    case "08":
                        loanType = "loan with object";
                        break;
                }
                digitalData.onlineSalesAndServiceFlows.loanSimulation.loanType = loanType;
            });

            $(document).on("click", "#amountButton, #durationButton", function() {
                if (firsttimeSimulation) {
                    _satellite.track('creditSimulation_firstResult');
                    firsttimeSimulation = false;
                } else {
                    _satellite.track('creditSimulation_updateResult');
                }
            });
        }
    } catch (e) { /* Do nothing... */ }
    
    /* SNIPPET TO DETECT IF A PAGE IS STATIC OR NOT */
    var checkIfStatic = function(){
      var counter = 0;

      var all_IA = $('div[data-url-context], .data_ia');
      all_IA.each(function() {
          counter++;
          if($(this).attr('id') == "ia-notifications"){
              counter--;
          }
      });

      if(counter > 0) {
          return false;
      }
      else {
          return true;
      }
    }
    digitalData.page.attributes.isStaticPage = checkIfStatic() ? "Y" : "N";
    
    /* SNIPPET TO DETECT THE PAGE TEMPLATE */
    
    if (isWeb) {
        if(!checkIfStatic()){
        
    		if ($('.login-container').length > 0) {
				digitalData.page.attributes.template = "login page";
			}
			
    		else if((sfHP.indexOf("msgnt") > -1) || (sfNodeId.indexOf("msgnt") > -1)){
    			digitalData.page.attributes.template = "sales-flow page";
    		} 
    		
       		else {
    			digitalData.page.attributes.template = "self-service page";
    		}
    	}
	    else if(getCookieData("axes")==false || sfNodeId.substring(0, sfNodeId.length - 3) == "axesSelection"){
			digitalData.page.attributes.template = "splash page";
		} 

		else if ($('.wcm-contactus').length > 0 || (sfNodeId.indexOf("contact-usb13") > -1) ) {
			digitalData.page.attributes.template = "contact-us page";
		}
		
		else if (($('.wcm-product-card').length > 0) || ($('.wcm-product-category-alt1').length > 0) || ($('.wcm-product-overview').length > 0)) {
			digitalData.page.attributes.template = "product page";
		} 
		
		else if ($('.wcm-home-header').length > 0) {
			digitalData.page.attributes.template = "home page";
		} 
		
		else if ((sfNodeId.indexOf("faq") > -1) || (sfNodeId.indexOf("Faq") > -1)) {
            digitalData.page.attributes.template = "faq page";
        }
		
		else if (sfNodeId.indexOf("null") > -1) {
	          digitalData.page.attributes.template = "error page";
	    } 
	    
	    else {
	     	 digitalData.page.attributes.template = "content Page";
	    }
	    
	    
	    //Exceptions - fortis
	    
	    if (sfNodeId.indexOf("upgrademypack-1c7") > -1){
	    	digitalData.page.attributes.template = "landing Page"; 
	    }
	            
	 	if ((sfNodeId.indexOf("general-terms-and-conditionse25") > -1) || (sfNodeId.indexOf("policies45e") > -1) || (sfNodeId.indexOf("scale-of-charges3fe") > -1) || (sfNodeId.indexOf("deposit-guaranteee97") > -1) || (sfNodeId.indexOf("opinion-unauth1b1") > -1) || (sfNodeId.indexOf("Securitye8a") > -1)) {
           digitalData.page.attributes.template = "content page"; 
    	}
    	
    	 //Exceptions - fintro
    	
    	if ((sfNodeId.indexOf("general-terms-and-conditions955")  > -1) || (sfNodeId.indexOf("policies852") > -1) || (sfNodeId.indexOf("scale-of-charges8c8") > -1) || (sfNodeId.indexOf("deposit-guarantee704") > -1) || (sfNodeId.indexOf("opinion-unauth9d1") > -1) || (sfNodeId.indexOf("security66f") > -1)) { 
           digitalData.page.attributes.template = "content page"; 
    	} 
	    
    } else {
    
    	digitalData.page.attributes.template = "app page";
    }
});



// EBWCM-5: Call for "newCarouselImage" home-slider change.
function notifyDTM_HomeSliderChanged() {
    try {
        _satellite.track('newCarouselImage');
    } catch (e) { /* Do nothing... */ }
}





// While page is getting Unload while navigating the Start Timer for PageReadyTime is set to start
$(window).unload(function() {
    // Si les call sont fini
    if (isWeb && !errorServiceFailed) {
        // If the visitor leave the page before the page is DOM loaded
        if (!digitalData.DataLayerMetadata.pageReadyTime) {
            try {
                digitalData.DataLayerMetadata.pageReadyTime = (Date.now() - window.performance.timing.navigationStart);
            } catch (e) {
                digitalData.DataLayerMetadata.pageReadyTime = -1;
            }
            try {
                _satellite.track('leavePageLoad');
            } catch (e) { /* Do nothing... */ }
        } else {
            if (digitalData.DataLayerMetadata.pageReady == "N") {
                try {
                    digitalData.DataLayerMetadata.pageReadyTime = (Date.now() - window.performance.timing.navigationStart);
                } catch (e) {
                    digitalData.DataLayerMetadata.pageReadyTime = -1;
                }
                try {
                    _satellite.track('leavePageLoad');
                } catch (e) { /* Do nothing... */ }
            }
            // Otherwise Nothing
        }

    }
    // If a service failed
    else {
        try {
            digitalData.DataLayerMetadata.pageReadyTime = (Date.now() - window.performance.timing.navigationStart);
        } catch (e) {
            digitalData.DataLayerMetadata.pageReadyTime = -1;
        }
        try {
            _satellite.track('leavePageLoadFailed');
        } catch (e) { /* Do nothing... */ }
    }

});

// While minimizing the page in transactional site the pageId is set to "switch to large device"
$(window).resize(function() {
    try {
        if (isSwitchtoLargeDevice()) {
            if (flagIsSmallScreen === false) {
                var _nodeId = "switch to large device";
                flagIsSmallScreen = true;
                digitalData.page.pageInfo.pageID = _nodeId;
                digitalData.page.attributes.level4 = _nodeId;
                _satellite.track('small_screen');
            }
        } else {
            if (flagIsSmallScreen === true) {
                flagIsSmallScreen = false;
                digitalData.page.pageInfo.pageID = nodeId;
                digitalData.page.attributes.level4 = level4BackUp;
            }
        }
    } catch (err) {
        digitalData.page.pageInfo.pageID = nodeId;
    }
});

if (isWeb) {
    var currentWindowLocationHostName = (typeof(window.location.hostname) !== 'undefined') ? window.location.hostname : "";
    var brand = (typeof(sfAxes3) !== 'undefined') ? sfAxes3 : "";

    var currentPathSatelliteHttps = currentWindowLocationHostName;
    var currentPathSatelliteHttp = currentWindowLocationHostName;

    switch (brand) {

        case 'fb':
            currentPathSatelliteHttps += "/rsc/contrib/script/js/bnpp-fortis/adobe";
            currentPathSatelliteHttp += "/rsc/contrib/script/js/bnpp-fortis/adobe";
            break;

        case 'hb':
            currentPathSatelliteHttps += "/rsc/contrib/script/js/hello-bank/adobe";
            currentPathSatelliteHttp += "/rsc/contrib/script/js/hello-bank/adobe";
            break;

        case 'kn':
            currentPathSatelliteHttps += "/rsc/contrib/script/js/bnpp-fortis/adobe";
            currentPathSatelliteHttp += "/rsc/contrib/script/js/bnpp-fortis/adobe";
            break;
    }

    _satellite = {
        "override": {
            "host": {
                "http": currentPathSatelliteHttp,
                "https": currentPathSatelliteHttps
            }
        }
    };
}



try {
        if (typeof PageBus != "undefined") {
            /*
             * Creation of an alias of "analytics_stepsequence" named "analyticsServices"
             */
            PageBus.subscribe("analyticsServices", this, function(data, msg) {
                PageBus.publish("analytics_stepsequence", msg);
            });
            /*
             * EBWCM-281: Event subscription for analytics on step sequence based module
             * RuleType: direct_call_rules
             *
             * @param msg.stepSeq String Number of the step
             * @param msg.stepName String Name of the step
             * @param msg.trackName String Satellite Rule Name
             * */
            PageBus.subscribe("analytics_stepsequence", this, function(data, msg) {
                try{

                    if (!digitalData.onlineSalesAndServiceFlows.loanSimulation) {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation = {};
                    }
					if (!digitalData.transaction) {
                        digitalData.transaction = {};
                    }
                    if (typeof msg.pageID != "undefined") {
                        digitalData.page.pageInfo.pageID = msg.pageID;
                    }
                    if (typeof msg.pageName != "undefined") {
                        digitalData.page.pageInfo.pageName = msg.pageName;
                    }
                    if (typeof msg.flowType != "undefined") {
                    	digitalData.page.attributes.template = msg.flowType;
                        digitalData.onlineSalesAndServiceFlows.flowType = msg.flowType;
                    }
                    var eventObj;
                    try{
                        if (typeof msg.eventAction != "undefined") {
                            if (digitalData.event !== undefined && digitalData.event.length!== 0 && digitalData.event[0].eventInfo!== undefined) {
                            digitalData.event[0].eventInfo.eventAction = msg.eventAction;
                            } else {
                                eventObj = {};
                                eventObj.eventInfo = {};
                                eventObj.eventInfo.eventAction = msg.eventAction;
                                digitalData.event[0] = eventObj;
                            }
                        }
                    } catch(ex){ /* Do nothing... */ }
                    try{
                        if (typeof msg.eventName != "undefined") {
                            if (digitalData.event !== undefined && digitalData.event.length!== 0 && digitalData.event[0].eventInfo!== undefined) {
                            digitalData.event[0].eventInfo.eventName = msg.eventName;
                            } else {
                                eventObj = {};
                                eventObj.eventInfo = {};
                                eventObj.eventInfo.eventName = msg.eventName;
                                digitalData.event[0] = eventObj;
                            }
                        }
                    }catch(ex){ /* Do nothing... */ }
                    try{
                        if (typeof msg.eventType != "undefined") {
                            if (digitalData.event !== undefined && digitalData.event.length!== 0 && digitalData.event[0].eventInfo!== undefined) {
                            digitalData.event[0].eventInfo.eventType = msg.eventType;
                            } else {
                                eventObj = {};
                                eventObj.eventInfo = {};
                                eventObj.eventInfo.eventType = msg.eventType;
                                digitalData.event[0] = eventObj;
                            }
                        }
                    }catch(ex){ /* Do nothing... */ }

                    if (typeof msg.level4 != "undefined") {
                        digitalData.page.attributes.level4 = msg.level4;
                    }
                    if (typeof msg.language != "undefined") {
                        digitalData.page.attributes.language = msg.language;
                    }
                    if (typeof msg.stepSeq != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.stepSeq = msg.stepSeq;
                    }
                    if (typeof msg.flowName != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.flowName = msg.flowName;
                    }
                    if (typeof msg.stpFlag != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.stpFlag = msg.stpFlag;
                    }
                    if (typeof msg.stepName != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.stepName = msg.stepName;
                    }
                    if (typeof msg.origin != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.origin = msg.origin;
                    }
                    try{
                        if (typeof msg.productName != "undefined") {
                            if(typeof msg.productName === "string"){
                            var productObj = {};
                                productObj.productInfo = {};
                                productObj.productInfo.productName = msg.productName;
                                digitalData.onlineSalesAndServiceFlows.product[0] = productObj;
                            }else if(typeof msg.productName === "object"){
                            digitalData.onlineSalesAndServiceFlows.product = msg.productName;
                            }
                        }
                    }catch(ex){ /* Do nothing... */ }

                    if (typeof msg.optionType != "undefined") {
                        digitalData.transaction.optionType = msg.optionType;
                    }
                    if (typeof msg.paymentType != "undefined") {
                        digitalData.transaction.paymentType = msg.paymentType;
                    }
                    if (typeof msg.currencyCode != "undefined") {
                        digitalData.transaction.currencyCode = msg.currencyCode;
                    }
                    if (typeof msg.countryCode != "undefined") {
                        digitalData.transaction.countryCode = msg.countryCode;
                    }
                    if (typeof msg.costType != "undefined") {
                        digitalData.transaction.costType = msg.costType;
                    }
                    if (typeof msg.inAppMessage != "undefined") {
                        if (digitalData.engagement !== undefined) {
                            digitalData.engagement.inAppMessage = msg.inAppMessage;
                        } else {
                            digitalData.engagement = {};
                            digitalData.engagement.inAppMessage = msg.inAppMessage;
                        }
                    }
                    if (typeof msg.visualisationType  != "undefined") {
                        if (digitalData.engagement !== undefined) {
                            digitalData.engagement.visualisationType = msg.visualisationType;
                        } else {
                            digitalData.engagement = {};
                            digitalData.engagement.visualisationType = msg.visualisationType;
                        }
                    }
                    if (typeof msg.errorMessage != "undefined") {
                        digitalData.page.attributes.errorMessage = msg.errorMessage;
                    }
                    if (typeof msg.appointmentReason != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.contact.appointmentReason = msg.appointmentReason;
                    }
                    if (typeof msg.beneficiaryType != "undefined") {
                        digitalData.transaction.beneficiaryType = msg.beneficiaryType;
                    }
                    if (typeof msg.branchID != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.branchID = msg.branchID;
                    }
                    if (typeof msg.loginType != "undefined") {
                        digitalData.user.attributes.loginType = msg.loginType;
                    }
                    if (typeof msg.transferType != "undefined") {
                        digitalData.transaction.transferType = msg.transferType;
                    }
					if (typeof msg.creditScore != "undefined") {
                        digitalData.transaction.creditScore = msg.creditScore;
                    }
                    if (typeof msg.visualisationType != "undefined") {
                        digitalData.engagement.visualisationType = msg.visualisationType;
                    }
                    if (typeof msg.viewType != "undefined") {
                        digitalData.page.attributes.viewType = msg.viewType;
                    }
                    if (typeof msg.searchedBranch != "undefined") {
                        digitalData.component[0].attributes.searchedBranch = msg.searchedBranch;
                    }
                    if (typeof msg.contractDuration != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.duration = msg.contractDuration;
                    }
                    if (typeof msg.contractValue != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.amountRange = msg.contractValue;
                    }
                    if (typeof msg.deviceEligibility != "undefined") {
                        digitalData.user.attributes.deviceEligibility = msg.deviceEligibility;
                    }
                    if (typeof msg.existingCustomer != "undefined") {
                        digitalData.user.segment.existingCustomer = msg.existingCustomer;
                    }
                    if (typeof msg.faqItemListExpand != "undefined") {
                        digitalData.faq.itemListExpand = msg.faqItemListExpand;
                    }
                    if (typeof msg.faqSearchKeyword != "undefined") {
                        digitalData.faq.faqSearchKeyword = msg.faqSearchKeyword;
                    }
                    if (typeof msg.faqTopicList != "undefined") {
                        digitalData.faq.faqTopicList = msg.faqTopicList;
                    }
                    if (typeof msg.faqWidgetFeedback != "undefined") {
                    	digitalData.faq.faqWidgetFeedback = msg.faqWidgetFeedback;
                    }
                    if (typeof msg.flowID != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.flowID = msg.flowID;
                    }
                    if (typeof msg.loanDetail != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanDetails = msg.loanDetail;
                    }
                    if (typeof msg.loanType != "undefined") {
                        if (!digitalData.onlineSalesAndServiceFlows.loanSimulation) {
                            digitalData.onlineSalesAndServiceFlows.loanSimulation = {};
                        }
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanType = msg.loanType;
                    }
					if (typeof msg.loanDetails != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanDetails = msg.loanDetails;
                    }
					if (typeof msg.loanAmount != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanAmount = msg.loanAmount;
                    }
					if (typeof msg.loanDuration != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanDuration = msg.loanDuration;
                    }
					if (typeof msg.loanMonthlyPayment != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanMonthlyPayment = msg.loanMonthlyPayment;
                    }
					if (typeof msg.loanTAEG != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.loanSimulation.loanTAEG = msg.loanTAEG;
                    }
                    if (typeof msg.loginMessage != "undefined") {
                        digitalData.page.attributes.loginMessage = msg.loginMessage;
                    }
                    if (typeof msg.logoffType != "undefined") {
                        digitalData.user.attributes.logoffType = msg.logoffType;
                    }
                    if (typeof msg.revenue != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.revenues = msg.revenue;
                    }
                    if (typeof msg.searchResult != "undefined") {
                        digitalData.page.pageInfo.searchResult = msg.searchResult;
                    }
                    if (typeof msg.searchSegment != "undefined") {
                        digitalData.page.pageInfo.searchSegment = msg.searchSegment;
                    }
                    if (typeof msg.searchTerm != "undefined") {
                        digitalData.page.pageInfo.searchKeyword = msg.searchTerm;
                    }
                    if (typeof msg.transactionID != "undefined") {
                        digitalData.onlineSalesAndServiceFlows.transactionID = msg.transactionID;
                    }
                    if (typeof msg.transferedAmount != "undefined") {
                        digitalData.transaction.transferedAmount = msg.transferedAmount;
                    }
                    if (typeof msg.transferType != "undefined") {
                        digitalData.transaction.transferType = msg.transferType;
                    }
                    if (typeof msg.activeTasks != "undefined") {
                        digitalData.page.attributes.activeTasks = msg.activeTasks;
                    }
                    if (typeof msg.alertType != "undefined") {
                        digitalData.page.attributes.alertType = msg.alertType;
                    }
                    if (typeof msg.digitalChannel != "undefined") {
                        digitalData.page.attributes.digitalChannel = msg.digitalChannel;
                    }
                    if (typeof msg.primaryCategory != "undefined") {
                        digitalData.page.attributes.primaryCategory = msg.primaryCategory;
                    }
                    if (typeof msg.subCategory1 != "undefined") {
                        digitalData.page.attributes.subCategory1 = msg.subCategory1;
                    }
                    if (typeof msg.subCategory2 != "undefined") {
                        digitalData.page.attributes.subCategory2 = msg.subCategory2;
                    }
                    if (typeof msg.componentType != "undefined") {
                       addOrModifyComponentforRTIM(msg.componentType, msg.componentName, msg.componentID);
                    }
                    if (typeof msg.authenticationStatus != "undefined") {
                        digitalData.page.attributes.authenticationStatus = msg.authenticationStatus;
                    }
                    if (typeof msg.pageLevel != "undefined") {
                        digitalData.page.attributes.pageLevel = msg.pageLevel;
                    }
                    if (typeof msg.sysEnv != "undefined") {
                        digitalData.page.attributes.sysEnv = msg.sysEnv;
                    }
                    if (typeof msg.profileID != "undefined") {
                        ddigitalData.user.profileInfo.profileID = msg.profileID;
                    }
                    if (typeof msg.url != "undefined") {
                        digitalData.page.pageInfo.url = msg.url;
                    }
                    if (typeof msg.url != "undefined") {
                        digitalData.page.pageInfo.url = msg.url;
                    }
					if (typeof msg.trackMethod != "undefined") {
                        digitalData.page.pageInfo.trackMethod = msg.trackMethod;
                    }
					if (typeof msg.variableAmount != "undefined") {
	                        digitalData.transaction.variableAmount = msg.variableAmount;
	                }
					if (typeof msg.previousPageName != "undefined") {
						digitalData.page.attributes.previousPageName = msg.previousPageName;
                    }
                    
                } catch(ex){ /* Do nothing... */ }
                // DTM Call
                if (typeof msg.trackName != "undefined") {
                    try {
                        _satellite.track(msg.trackName);
                    } catch (e) { /* Do nothing... */ }
                }
                if (typeof msg.trackMethod != "undefined") {
                    try {
                        _satellite.track(msg.trackMethod);
                    } catch (e) { /* Do nothing... */ }
                }

            });
        }

} catch (e) { /* Do nothing... */ }

try {
    if (isWeb) {
        var logoutType = sessionStorage.getItem('logoutMethod');

        if (logoutType != null) {
            switch (logoutType) {
                case "inactivePopupTimeout":
                    digitalData.user.attributes.logoffType = "session_inactivity";
                    break;

                case "absoluteTimeout":
                    digitalData.user.attributes.logoffType = "session";
                    break;

                case "sessionConfirm":
                    digitalData.user.attributes.logoffType = "session_confirm";
                    break;

                case "userInitiated":
                    digitalData.user.attributes.logoffType = "default";
                    break;

                default:
                    digitalData.user.attributes.logoffType = "default";
                    break;
            }
        }
    }
} catch (e) { /* Do nothing... */ }

if (isWeb) {
    //Check for splash page
    if(getCookieData("axes")==false || sfNodeId.substring(0, sfNodeId.length - 3) == "axesSelection"){
        digitalData.page.pageInfo.pageID = "splash page";
        digitalData.page.attributes.level4 = "";
        digitalData.page.attributes.subCategory1 = "all";
        digitalData.page.attributes.subCategory2 = "general";
    }
}

//cookie policy ad-blocker fallback link
$(window).bind('load', function() {
    if(!document.getElementById("cc_iframe1")){
        var brand = (typeof(sfAxes3) !== 'undefined') ? sfAxes3 : "";
        var alias = "/web_"+brand+"_cookie";
        var cookieLink = $('a[data-topic="cc.policy.popup"]');
        cookieLink.attr({href: alias, target: "_blank"}).removeAttr("data-data data-topic class");
        cookieLink.unbind('click');
    }
});

try {
    _satellite.track("_dataLayerCreated")
  } catch (e) { console.log(/* Do Nothing */)}

 _dataLayerCreated = "0";
 
 
 
 /**
 * 
  * This function has been used to over write 
  * 
  * @param pageId (by default it has sfNodeID value)
 * @param level4 (optional, by default from DOM value)
 * @param flowName (to be filled in case of SF applications)
 * @param stepName
 * @param flowType
 * @param stepSeq
 * @param eventAction
 */
 function updateDataLayer(pageId, level4, flowName, stepName, flowType, stepSeq, eventAction){
	   if(typeof(pageId) !== 'undefined' || pageID !== ""){
	                 digitalData.page.pageInfo.pageID = pageId;
	   }
	   if(typeof(level4) !== 'undefined' || level4 !== ""){
	                 digitalData.page.attributes.level4 = level4;
	   }
	   if(typeof(flowName) !== 'undefined'){
	                 digitalData.onlineSalesAndServiceFlows.flowName = flowName;
	   }
	   if(typeof(stepName) !== 'undefined'){
	                 digitalData.onlineSalesAndServiceFlows.stepName = stepName;
	   }
	   if(typeof(flowType) !== 'undefined'){
	                 digitalData.onlineSalesAndServiceFlows.flowType = flowType;
	   }
	   if(typeof(stepSeq) !== 'undefined'){
	                 digitalData.onlineSalesAndServiceFlows.stepSeq = stepSeq;
	   }
	   if(typeof(eventAction) !== 'undefined'){
	                 digitalData.event[0].eventInfo.eventAction = eventAction;
	   }
	   _satellite.track('flow');
 }

  
