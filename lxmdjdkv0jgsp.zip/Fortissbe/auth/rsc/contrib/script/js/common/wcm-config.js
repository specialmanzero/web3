/*global require */
require.config({
    baseUrl: '/',
    // Loads non-AMD libraries and declares their dependencies
    shim: {
        jquery: {
            exports: '$'
        },
        pagebus: {
            exports: 'PageBus'
        },
        'underscore': {
            exports: '_'
        },
        'backbone': {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        'rivets': {
            exports: 'rivets'
        },
        'nicescroll': {
            exports: 'niceScroll'
        },
        'modernizer': {
            exports: 'Modernizr'
        }

    },

    map: {
        '*': {
            'modernizr': 'modernizer'
        }
    },
    // Location of libraries
    paths: {
        jquery: 'rsc/contrib/script/js/common/lib/jquery-1.9.1.min',
        d3:'/rsc/contrib/script/js/common/lib/d3-V3-min',
        pagebus: '/rsc/sys/script/js/pagebus/pagebus',
        sf: '/rsc/contrib/script/js/common/lib/sf-min',
        text: '/rsc/contrib/script/js/common/lib/require-text/text',
        css: '/rsc/contrib/script/js/common/lib/require-css/css',
        normalize: '/rsc/contrib/script/js/common/lib/require-css/normalize',
        backbone: '/rsc/contrib/script/js/common/lib/backbone',
        underscore: '/rsc/contrib/script/js/common/lib/underscore',
        'backbone-deep-model': '/rsc/contrib/script/js/common/lib/backbone-deep-model',
        'underscore-deepExtend': '/rsc/contrib/script/js/common/lib/underscore-deepExtend',
        rivets: '/rsc/contrib/script/js/common/lib/rivets',
        rivetConfig: '/rsc/contrib/script/js/common/lib/rivetConfig',
        nicescroll: '/rsc/contrib/script/js/common/lib/nicescroll',
        modernizer: '/rsc/sys/script/js/modernizr/modernizr-min',
        'comp': '/rsc/contrib/script/js/common/lib/sf-comp',
        redirect: '/rsc/contrib/script/js/common/package/custom/redirection',
        widget : '/rsc/contrib/script/js/bnpp-fortis/chat/lib/chat-widget',

        unauthenticatedcustom: '/rsc/contrib/script/js/common/package/custom/unauthenticated',
        authenticatedcustom: '/rsc/contrib/script/js/common/package/custom/authenticated',
        wcmcommons: '/rsc/contrib/script/js/common/package/custom/commons',
        cookie: '/rsc/contrib/script/js/common/package/custom/cookieConfig',
        pwsSliders: '/rsc/contrib/script/js/common/package/custom/pwsSliders',
        publicsitescript: '/rsc/contrib/script/js/common/package/custom/publicSiteScript',
        photocard: '/rsc/contrib/script/js/common/package/custom/photocard',
        fbunauthenticated: '/rsc/contrib/script/js/bnpp-fortis/package/custom/unauthenticated',
        fbauthenticated: '/rsc/contrib/script/js/bnpp-fortis/package/custom/authenticated',
        fbcommons: '/rsc/contrib/script/js/bnpp-fortis/package/custom/commons',
        psd2UnauthCommons: '/rsc/contrib/script/js/psd2/common/package/unauth/commons',
        psd2logout: '/rsc/contrib/script/js/psd2/common/package/disconnect/logout/logout',

        hbunauthenticated: '/rsc/contrib/script/js/hello-bank/package/custom/unauthenticated',
        hbauthenticated: '/rsc/contrib/script/js/hello-bank/package/custom/authenticated',
        hbcommons: '/rsc/contrib/script/js/hello-bank/package/custom/commons',

        pageredirection: '/rsc/contrib/script/js/common/package/custom/pageRedirection',


        errorMessage: '/rsc/contrib/script/js/common/package/custom/errorMessage',
        transition: '/rsc/contrib/script/js/common/lib/transition',
        tooltip: '/rsc/contrib/script/js/common/lib/jquery.tooltipster',
        collapse: '/rsc/contrib/script/js/common/lib/collapse',
        stickyMojo: '/rsc/contrib/script/js/common/lib/stickyMojo',
        analytics: '/rsc/contrib/script/js/common/package/custom/analytics',
        flexnav: '/rsc/contrib/script/js/common/lib/jquery.flexnav',
        prop: '/rsc/contrib/script/js/common/lib/prop',
        placeholder: '/rsc/contrib/script/js/common/lib/placeholder',
        progress: '/rsc/contrib/script/js/common/package/custom/progressIndicator'
    },
    waitSeconds: 0,
    packages: [{
            name: 'loginv4',
            location: '/EBIA-pr01/app/authentication-v4'
        },{
            name: 'loginv3',
            location: '/EBIA-pr01/app/authentication-itsme'
        },{
            name: 'loginIntermediate',
            location: '/static/IA/ebw/tfpl-pr01/intermediateLogon'
        }, {
            name: 'pmessage',
            location: '/TFPL-pr01/app/pmessage'
        }, {
            name: 'messagentSign',
            location: '/TFPL-pr01/app/messagentSign'
        }, {
            name: 'minors',
            location: '/TFPL-pr01/app/minors'
        }, {
            name: 'commons',
            location: '/rsc/contrib/script/js/common/plugins/commons' //'/DBPL-pr01/app/commons'
        }, {
            name: 'accountlist',
            location: '/DBPL-pr01/app/accountlist'
        }, {
            name: 'accountdetail',
            location: '/DBPL-pr01/app/accountdetail'
        }, {
            name: 'cardheader',
            location: '/NDPL-pr01/app/cardheader'
        }, {
            name: 'cardtransactions',
            location: '/NDPL-pr01/app/cardtransactions'
        }, {
            name: 'cardlist',
            location: '/NDPL-pr01/app/cardlist'
        }, {
            name: 'carddetail',
            location: '/NDPL-pr01/app/carddetail'
        }, {
            name: 'modifyCard',
            location: '/NDPL-pr01/app/modifyCard'
        }, {
            name: 'flexpayemb',
            location: '/NDPL-pr01/app/flexpayemb'
        }, {
            name: 'flexpay',
            location: '/NDPL-pr01/app/flexpay'
        }, {
            name: 'debitdetail',
            location: '/NDPL-pr01/app/debitdetail'
        }, {
            name: 'estatements',
            location: '/CRPL-pr01/app/estatements'
        }, {
            name: 'sepa',
            location: '/static/IA/ebw/dbpl-pr02/sepa'
        }, {
            name: 'zoomit',
            location: '/ZMPL-pr50/app/zoomit'
        },

        {
            name: 'transactions',
            location: '/DBPL-pr01/app/transactions'
        }, {
            name: 'accountsheader',
            location: '/DBPL-pr01/app/accountsheader'
        }, {
            name: 'disconnect',
            location: '/rsc/contrib/script/js/common/package/disconnect'
        }, {
            name: 'ocu',
            location: '/OCPL-pr01/app/OCU'
        }, {
            name: 'contactdata',
            location: '/OCPL-pr01/app/contactdata'
        },
        {
            name: 'contactdata_old',
            location: '/OCPL-pr01/app/contactdata_old'
        },
 	   // Consent Management.
 	   {
 	   		name: 'consentManagement',
 	   		location: '/OCPL-pr01/app/consentManagement'
 	   },
 	   {
	   		name: 'customerCorner',
	   		location: '/OCPL-pr01/app/customerCorner'
	   },
 	   {
            name: 'smsSecurity',
            location: '/OCPL-pr01/app/smssecurity'
        },
        // ARM IA
        {
            name: 'arm',
            location: '/OCPL-pr01/app/ARM'
        },
        //E-Lending IA.
        {
            name: 'efrrequestlist',
            location: '/LEFR-pr02/app/efrrequestlist'
        }, {
            name: 'efrspider',
            location: '/LEFR-pr02/app/efrspider'
        }, {
            name: 'commonsignature',
            location: '/PAPL-pr02/app/commonsignature'
        },
        {
            name: 'faq',
            location: '/rsc/contrib/script/js/common/package/custom/faq'
        },
        // Insurance pimping IA components
        {
            name: 'insurancelogon',
            location: '/PSP3-pr50/app/insurancelogon'
        },

        {
            name: 'insurancedetails',
            location: '/PSP3-pr50/app/insurancedetails'
        },

        {
            name: 'insurancepayment',
            location: '/PSP3-pr50/app/insurancepayment'
        },

        // credits pimping

        {
            name: 'creditsrondosimulation',
            location: '/PSP6-pr50/app/creditsrondosimulation'
        },

        {
            name: 'creditsrondorequest',
            location: '/PSP6-pr50/app/creditsrondorequest'
        },

        {
            name: 'panoramalivingdetails',
            location: '/PSP6-pr50/app/creditspanoramaliving'
        },

        {
            name: 'creditsfsviewdemand',
            location: '/PSP6-pr50/app/creditsfsviewdemand'
        },

        {
            name: 'creditsfssimulation',
            location: '/PSP6-pr50/app/filmstarsimluations'
        },


        {
            name: 'creditslogon',
            location: '/PSP6-pr50/app/creditsPanorama'
        }, {
            name: 'creditslogonProf',
            location: '/PSP6-pr50/app/creditsPanoramaProf'
        },

        {
            name: 'creditslivingsimulation',
            location: '/PSP6-pr50/app/creditslivingsimulation'
        },
        // NDPL

        {
            name: 'photoCard',
            location: '/NDPL-pr03/app/photoCard'
        },
        {
            name: 'easyPhotoCard',
            location: '/NDPL-pr03/app/easyPhotoCard'
        },
        //PIGGY - EASYSAVE
        {
            name: 'easysave',
            location: '/PYPL-pr01/app/piggy'
        },
        {
            name: 'piggyOverview',
            location: '/static/IA/ebw/dbpl-pr02/piggy'
        },


        //PIMPING - Save and Invest

        {
            name: 'virtualPortfolio',
            location: '/PSP5-pr50/app/virtualPortfolio'
        },

        {
            name: 'portfolioReporting',
            location: '/PSP5-pr50/app/portfolioReporting'
        },

        {
            name: 'securityAccountFlow',
            location: '/PSP5-pr50/app/securityAccountFlow'
        },

        {
            name: 'evaluatePortfolio',
            location: '/PSP5-pr50/app/evaluatePortfolio'
        },

        {
            name: 'simplesearch',
            location: '/PSP5-pr50/app/searchToolFlow'
        },

        {
            name: 'panoSaveAndInvest',
            location: '/PSP5-pr50/app/panoSaveAndInvest'
        }, {
            name: 'investFunds',
            location: '/PSP5-pr50/app/investFunds'
        },

        {
            name: 'investBonds',
            location: '/PSP5-pr50/app/investBonds'
        },

        {
            name: 'investShares',
            location: '/PSP5-pr50/app/investShares'
        },

        {
            name: 'savingCertificates',
            location: '/PSP5-pr50/app/savingCertificates'
        },

        {
            name: 'investStockMarkets',
            location: '/PSP5-pr50/app/investStockMarkets'
        },

        {
            name: 'investCurrencyMarkets',
            location: '/PSP5-pr50/app/investCurrencyMarkets'
        },

        {
            name: 'marketInterestRates',
            location: '/PSP5-pr50/app/marketInterestRates'
        },

        {
            name: 'investCommodityMarkets',
            location: '/PSP5-pr50/app/investCommodityMarkets'
        }, {
            name: 'allFunctionsSI',
            location: '/PSP5-pr50/app/allFunctionsSI'
        }, {
            name: 'manageOrders',
            location: '/PSP5-pr50/app/manageOrders'
        }, {
            name: 'flexiInvestPlans',
            location: '/PSP5-pr50/app/flexiInvestPlans'
        }, {
            name: 'custodyAccount',
            location: '/PSP5-pr50/app/custodyAccount'
        }, {
            name: 'wealthPanorama',
            location: '/PSP5-pr50/app/wealthPanorama'
        }, {
            name: 'portfolioAnalysis',
            location: '/PSP5-pr50/app/portfolioAnalysis'
        }, {
            name: 'portfolioSimulation',
            location: '/PSP5-pr50/app/portfolioSimulation'
        }, {
            name: 'investmentProfile',
            location: '/PSP5-pr50/app/investmentProfile'
        }, {
            name: 'openPensionAccount',
            location: '/PSP5-pr50/app/openPensionAccount'
        }, {
            name: 'ordersEnvelop',
            location: '/PSP5-pr50/app/ordersEnvelop'
        }, {
            name: 'pensionAccountOverview',
            location: '/PSP5-pr50/app/pensionAccountOverview'
        }, {
            name: 'yourReports',
            location: '/PSP5-pr50/app/yourReports'
        }, {
            name: 'knowledgeAndExperience',
            location: '/PSP5-pr50/app/knowledgeAndExperience'
        }, {
          	name: 'flexinvest',
            location: '/FXIA-pr50/app/flexinvest'
        },


        // Pimping - Cards

        {
            name: 'cardopen',
            location: '/PSP2-pr50/app/cardopen'
        },

        {
            name: 'cardmodify',
            location: '/PSP2-pr50/app/cardmodify'
        },

        {
            name: 'modifycarddetails',
            location: '/PSP2-pr50/app/modifycarddetails'
        },

        {
            name: 'carddetails',
            location: '/PSP2-pr50/app/carddetails'
        },

        {
            name: 'photocarduploadphoto',
            location: '/PSP2-pr50/app/photocarduploadphoto'
        }, {
            name: 'creditCardOpen',
            location: '/PSP2-pr50/app/creditCardOpen'
        },

        {
            name: 'creditCardModify',
            location: '/PSP2-pr50/app/creditCardModify'
        },


        // Pimping - Daily Banking
        {
            name: 'paperPreferences',
            location: '/EBWS-pr50/app/paperPreferences'
        },

        {
            name: 'paperThirdPartyPreferences',
            location: '/EBWS-pr50/app/paperThirdPartyPreferences'
        },

        {
            name: 'paperConsultation',
            location: '/EBWS-pr50/app/paperConsultation'
        },

        {
            name: 'paperThirdPartyConsultation',
            location: '/EBWS-pr50/app/paperThirdPartyConsultation'
        },

        {
            name: 'archiveRetrieval',
            location: '/EBWS-pr50/app/archiveRetrieval'
        },

        {
            name: 'openPrivateAccount',
            location: '/AC52-pr01/app/openPrivateAccount'
        },

        {
            name: 'savingAccountSimulatorDebit',
            location: '/EBWS-pr50/app/savingAccountSimulatorDebit'
        },

        {
            name: 'savingAccountConsultInterest',
            location: '/EBWS-pr50/app/savingAccountConsultInterest'
        },

        {
            name: 'msmcOverview',
            location: '/EBWS-pr50/app/msmcOverview'
        },

        {
            name: 'iMessage',
            location: '/EBWS-pr50/app/iMessage'
        },

        {
            name: 'consultBonusLSP',
            location: '/EBWS-pr50/app/consultBonusLSP'
        },

        {
            name: 'blockinglinks',
            location: '/PSP9-pr50/app/blockinglinks'
        }, {
            name: 'solvablelinks',
            location: '/PSP9-pr50/app/solvablelinks'
        }, {
            name: 'accountclosure',
            location: '/PSP9-pr50/app/accountclosure'
        }, {
            name: 'beneficiariesList',
            location: '/EBWS-pr50/app/beneficiaries'
        }, {
            name: 'internationalBeneficiaries',
            location: '/EBWS-pr50/app/internationalBeneficiaries'
        }, {
            name: 'newTransfer',
            location: '/EBWS-pr50/app/dailyTransfer'
        }, {
            name: 'transferEnvelope',
            location: '/EBWS-pr50/app/transferEnvelope'
        }, {
            name: 'listEuroDirectDebit',
            location: '/EBWS-pr50/app/listOfSDDCollections'
        }, {
            name: 'refuseEuroDirectDebit',
            location: '/EBWS-pr50/app/sddAccountRefusalMgmt'
        }, {
            name: 'euroDirectDebitMandates',
            location: '/EBWS-pr50/app/sddDebtorMandates'
        }, {
            name: 'securitySms',
            location: '/EBWS-pr50/app/securitySMS'
        }, {
            name: 'phoneBankingAccess',
            location: '/EBWS-pr50/app/phoneBanking'
        }, {
            name: 'activateAccountStatements',
            location: '/EBWS-pr50/app/activateOnlineAccountStatements'
        },

        //Chat on Premises

        {
            name: 'chopwidget',
            location: '/PAPL-pr02/app/chat'
        },
        {
            name: 'chatwidget',
            location: '/TFPL-pr01/app/chat'
        },

        //EZ Terms
        {
            name: 'termDepositConsult',
            location: '/EZP1-pr50/app/termDepositConsult'
        },
        //Princing And Packages
        {
            name: 'openCurrentAccount',
            location: '/PKP1-pr50/app/openCurrentAccount'
        }, {
            name: 'managePackage',
            location: '/PKP1-pr50/app/managePackage'
        }, {
            name: 'lifeStagePackage',
            location: '/EBWS-pr50/app/lifeStagePackage'
        },


        // sepadd is for MR2 SEPA Direct Debit IA
        {
            name: 'sepadd',
            location: '/static/IA/ebw/dbpl-pr02/sdd'
        },
        // beneficiary is for MR2 Beneficiary IA
        {
            name: 'beneficiary',
            location: '/PFPL-pr01/app/beneficiary'
        }, {
            name: 'PAPLCommons',
            location: '/PAPL-pr01/app/commons'
        }, {
            name: 'searchengine',
            location: '/PAPL-pr01/app/searchengine'
        },
        // illicominus
        {
            name: 'illicominus',
            location: '/PAPL-pr02/app/illicominus'
        },
        // standingorder is for MR2 Standing Order IA
        {
            name: 'standingorder',
            location: '/static/IA/ebw/dbpl-pr02/sto'
        }, {
            name: 'onlineAgenda',
            location: '/ABAG-pr50/app/onlineAgenda'
        },

        //hideunhide
        {
            name: 'hideunhide',
            location: '/PFPL-pr01/app/hideunhide'
        }, {
            name: 'loanspanorama',
            location: '/COPL-pr02/app/loanspanorama'
        },

        {
            name: 'mortgageloans',
            location: '/COPL-pr02/app/mortgageloans'
        }, {
            name: 'consumerloans',
            location: '/COPL-pr02/app/consumerloans'
        }, {
            name: 'loansHeader',
            location: '/COPL-pr02/app/loansHeader'
        },
        {
            name: 'magicbutton',
            location: '/CRPL-pr01/app/MagicButton'
        },
        //My Advisor
        {
            name: 'myBranch',
            location: '/TFPL-pr01/app/myBranch'
        },
         //AG I
	  	{
            name: 'contractDetails',
            location: '/INPL-pr50/app/contractDetails'
       },
	   {
            name: 'insurancePanorama',
            location: '/INPL-pr50/app/insurancePanorama'
       },
       {
   		name: 'bonus',
   		location: '/AC52-pr01/app/bonus'
   	   },
	   //Itsme
	   {
	   		name: 'itsmeLogon',
	   		location: 'EBIA-pr01/app/itsme-logon'
	   },
	   // subcribe-funds.
	   {
	   		name: 'subscribefunds',
	   		location: '/rsc/contrib/script/js/common/lib/app/subscribeFunds'
	   },
	   // subcribe-bonds.
	   {
	   		name: 'subscribebonds',
	   		location: '/rsc/contrib/script/js/common/lib/app/subscribeBonds'
	   },
	   // subcribe-flex-invest.
	   {
	   		name: 'subscribeflexinvest',
	   		location: '/rsc/contrib/script/js/common/lib/app/subscribeFlexInvest'
	   },
	   // deposit-pension-funds.
	   {
	   		name: 'depositpensionfunds',
	   		location: '/rsc/contrib/script/js/common/lib/app/depositPensionFunds'
	   },
	   //open-credit-card
	   {
           name: 'opencreditcard',
           location: '/NDPL-pr01/app/opencreditcard'
       },
       //card profiler
       {
    	   name: 'cardprofiler',
    	   location: '/NDPL-pr01/app/cardprofiler'
       },

       // PSD2
       {
    	   name: 'psd2Disconnect',
    	   location: '/rsc/contrib/script/js/psd2/common/package/disconnect'
       },

       //PSD2 CAF
        {
			name: 'connectedServices',
			location: '/OCPL-pr01/app/connectedServices'
 		},
 		
 		//Loginv5
 		{
            name: 'loginv5',
            location: '/EBIA-pr01/app/authentication-v5'
        }

    ]
});

if (typeof jQuery === 'function') {
    //jQuery already loaded, just use that
    define('jquery', function() {
        return jQuery;
    });
}

if (typeof PageBus === 'Object') {
    //PageBus already loaded, just use that
    define('pagebus', function() {
        return PageBus;
    });
}

if (typeof Modernizr === 'Object') {
    //Modernizr already loaded, just use that
    define('modernizer', function() {
        return Modernizr;
    });
}

require(["sf", "comp", "progress"], function(sf, comp, progress) {
    'use strict';
    sf.errlog.config({
        debug: true,
        preventDefault: false
    });
});
