(function () {
    'use strict';

    function getLocation(file) {
        return new RegExp('(.*?)/' + file).exec($('script[src$="' + file + '.js"]').attr('src'))[1];
    }

    var protocolRegEx = /[^\:\/]*:\/\/([^\/])*/;
    var absUrlRegEx = /^(\/|data:)/;

    function absoluteURI(uri, base) {
        var curPart;

        if (uri.substr(0, 2) == 'index.html')
            uri = uri.substr(2);

        // absolute urls are left in tact
        if (uri.match(absUrlRegEx) || uri.match(protocolRegEx))
            return uri;

        var baseParts = base.split('https://www.bnpparibasfortis.be/');
        var uriParts = uri.split('https://www.bnpparibasfortis.be/');

        baseParts.pop();

        while (curPart = uriParts.shift())
            if (curPart == '..')
                baseParts.pop();
            else
                baseParts.push(curPart);

        return baseParts.join('https://www.bnpparibasfortis.be/');
    };

    require.config({
        context: 'wcm',
        paths: {
            comp: absoluteURI(getLocation('sf-comp-wcm-config') + '/sf-comp', $('base').attr('href') || window.location.href)
        }
    });
})();