// to process celebrus cookies
function processOptedCookie(optChoice, overlayContainerClass) {
	if(optChoice === 'celebrus-optout') {
		window.CelebrusDynamicInsert.setCollection(false, true); 
	}else{
		window.CelebrusDynamicInsert.setCollection(true, true); 	
	}
	
	var params = {};
	params.isStaticOverlay = true;
	params.overlayContainer = '.'+ overlayContainerClass;
	PageBus.publish('nextgen.showModalDialog', params);
	var ae = $('.'+ overlayContainerClass).find('a.postPagebusMessage');
	if(ae.length > 0) {
		if (typeof ae.attr("data-data") !== typeof undefined && ae.attr("data-data") !== false) {
			ae.removeAttr("data-data");
		}
		if (typeof ae.removeAttr("data-topic") !== typeof undefined && ae.removeAttr("data-topic") !== false) {
			ae.removeAttr("data-topic");
		}
		ae.attr('data-dismiss','modal');
	}
}

$(document).ready(function() {
	if($('a.celebrus-optin').length > 0) {
		$('a.celebrus-optin').attr('href','javascript:void(0)');
		$('a.celebrus-optin').on('click', function(e){
		    e.preventDefault();
			//window.BNPPFCSAoptIn();
			processOptedCookie('celebrus-optin', 'overlayOptedInCookie');
		});
	}
	if($('a.celebrus-optout').length > 0) {
		$('a.celebrus-optout').attr('href','javascript:void(0)');
		$('a.celebrus-optout').on('click', function(e){
		    e.preventDefault();
			//window.BNPPFCSAoptOut();
			processOptedCookie('celebrus-optout', 'overlayOptedOutCookie');
		});
	}
});