window.onload = function() {
    var cookieValue = getCookie('acc_browser');
    if (cookieValue !== null && cookieValue !== undefined) {
        //do nothing
    } else {
        showMessage();
    }
}

var u = 'unknown',
    x = 'X',
    m = function(r, h) {
        for (var i = 0; i < h.length; i = i + 1) {
            r = r.replace(h[i][0], h[i][1]);
        }
        return r;
    },
    c = function(i, a, b, c) {
        var r = {
            name: m((a.exec(i) || [u, u])[1], b)
        };
        r[r.name] = true;
        r.version = (c.exec(i) || [x, x, x, x])[3];
        if (r.name.match(/safari/) && r.version > 400) {
            r.version = '2.0';
        }
        if (r.name === 'presto') {
            r.version = ($.browser.version > 9.27) ? 'futhark' : 'linear_b';
        }
        r.versionNumber = parseFloat(r.version, 10) || 0;
        r.versionX = (r.version !== x) ? (r.version + '').substr(0, 1) : x;
        r.className = r.name + r.versionX;
        return r;
    };
a = navigator.userAgent;
a = (a.match(/Opera|Navigator|Minefield|KHTML|Chrome/) ? m(a, [
    [/(Firefox|MSIE|KHTML,\slike\sGecko|Konqueror)/, ''],
    ['Chrome Safari', 'Chrome'],
    ['KHTML', 'Konqueror'],
    ['Minefield', 'Firefox'],
    ['Navigator', 'Netscape']
]) : a).toLowerCase();
var browser = c(a, /(camino|chrome|firefox|netscape|konqueror|lynx|msie|opera|safari|rv|Edge)/, [], /(camino|chrome|firefox|netscape|netscape6|opera|version|konqueror|lynx|msie|safari|rv|Edge)(\/|\s)([a-z0-9\.\+]*?)(\;|dev|rel|\s|$)/);
var layout = c(a, /(gecko|konqueror|msie|opera|webkit)/, [
    ['konqueror', 'khtml'],
    ['msie', 'trident'],
    ['opera', 'presto']
], /(applewebkit|rv|konqueror|msie)(\:|\/|\s)([a-z0-9\.]*?)(\;|\)|\s)/);
var os = {
    name: (/(win|mac|linux|sunos|solaris|iphone|ipad)/.exec(navigator.platform.toLowerCase()) || [u])[0].replace('sunos', 'solaris')
};
var d = document.getElementsByTagName('html');
d[0].className = d[0].className + " " + [os.name, browser.name, browser.className, layout.name, layout.className].join(' ');


;


function get_browser() {
    var ua = navigator.userAgent,
        tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE ' + (tem[1] || '');
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\bOPR\/(\d+)/)
        if (tem != null) {
            return 'Opera ' + tem[1];
        }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) {
        M.splice(1, 1, tem[1]);
    }
    return M[0];
}

function get_browser_version() {
    var ua = navigator.userAgent,
        tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE ' + (tem[1] || '');
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\bOPR\/(\d+)/)
        if (tem != null) {
            return 'Opera ' + tem[1];
        }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) {
        M.splice(1, 1, tem[1]);
    }
    return M[1];
}


function showMessage() {

    var userAgentInfo = navigator.userAgent;
    var browserName = ["Opera", "IE", "Chrome", "Safari", "Firefox"];
    var browserVersions = [100, 8, 0, 0, 0];
    var index;
    var selectedBrowserName = this.get_browser().replace(/[0-9 ]/g, '');
    var selectedBrowserVersion = this.get_browser_version().replace(/[a-zA-Z ]/g, '');


    if (parseInt(selectedBrowserVersion) <= browserVersions[browserName.indexOf(selectedBrowserName)]) {
        var vers = document.getElementById('browserVersion');

        if (vers !== undefined) {
            vers.innerHTML = parseInt(selectedBrowserVersion);
            /*var obj = document.getElementsByClassName('overlayUnsupportedBrowser');
            obj[0].parentNode.className = obj[0].parentNode.className + " show_active";
            obj[0].className = obj[0].className + " show_active";*/
            var data ={};
        	data.overlayid = "overlayUnsupportedBrowser";
        	PageBus.publish('nextgen.showModalDialog',data);


            if (document.getElementsByClassName("overlayUnsupportedBrowser") !== undefined) {
                var el = document.getElementsByClassName("overlayUnsupportedBrowser")[0];
                el = el.getElementsByClassName("btn_primary")[0];
                el.addEventListener("click", function(event) {
                    hideBrowserPopup();
                    updateCookie();

                }, false);
            }

            if (document.getElementsByClassName("overlayUnsupportedBrowser") !== undefined) {
                var el1 = document.getElementsByClassName("overlayUnsupportedBrowser")[0];
                el1 = el1.getElementsByClassName("popup_close")[0];
                el1.addEventListener("click", function(event) {
                    hideBrowserPopup();
                    updateCookie();

                }, false);
            }
        }
    }
}

function hideBrowserPopup() {
  /*  var obj = document.getElementsByClassName('overlayUnsupportedBrowser');
    obj[0].parentNode.className = obj[0].parentNode.className.replace(/show_active/g, '');
    obj[0].className = obj[0].className.replace(/show_active/g, '');*/
	var data ={};
	data.overlayid = "overlayUnsupportedBrowser";
	PageBus.publish('nextgen.removeModalDialog',data);
}

function updateCookie() {
    var cookieName = "acc_browser";
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + 365);
    var cookieValue = (true) + ";path=/" + ("; expires=" + exdate.toUTCString());
    document.cookie = cookieName + "=" + cookieValue+";"+"secure";
}

function getCookie(cookieName) {
    var cookieValue = document.cookie;
    var cStart = cookieValue.indexOf(" " + cookieName + "=");
    if (cStart == -1) {
        cStart = cookieValue.indexOf(cookieName + "=");
    }
    if (cStart === -1) {
        cookieValue = null;
    } else {
        cStart = cookieValue.indexOf("=", cStart) + 1;
        var cEnd = cookieValue.indexOf(";", cStart);
        if (cEnd === -1) {
            cEnd = cookieValue.length;
        }
        cookieValue = (cookieValue.substring(cStart, cEnd));
    }
    return cookieValue;

}
/**
            * Method for setting the cookie
            * @param cookieName: Name of the cookie that needs to be setted
            * @param value : value of the cookie
            * @param exdays : expiry date of the cookie
            */
           function setCookieParam(cookieName, value, exdays,cookieSecure) {
             var exdate = new Date();
             exdate.setDate(exdate.getDate() + exdays);
				var cookieValue = (value)+ ";path=/"+((exdays === null) ? "" : "; expires="+ exdate.toUTCString());
             document.cookie = cookieName + "=" + cookieValue+";"+cookieSecure;
            }



function setCookie(cookieName, value, exdays) {
                  var exdate = new Date();
                  exdate.setDate(exdate.getDate() + exdays);
                  var cookieValue = (value)+ ";path=/"+((exdays === null) ? "" : "; expires="+ exdate.toUTCString());
                  document.cookie = cookieName + "=" + cookieValue;
            }
//EURO POLICY OPTIN Settings
setCookieParam("europolicy", "optin",365,"secure");

