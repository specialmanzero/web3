//var sfSiteId = $("meta[name='siteid']").attr("content"); 
var variation = "/" + sfAxes1 + "/" + sfAxes2 + "/" + sfAxes3 + "/" + sfAxes4 + "/";

var sfIaTargetList = {
    "web-banking": {
        "target.ia.cardsHeader.showCardHeader": variation + "Cardtransaction913",
        "target.ia.cardsHeader.cardProfiler": variation + "Cardprofiler2fe",
        "target.ia.accountsHeader.showAccountHeader": variation + "Transactionseed",
        "target.ia.contact.showContactInfo": variation + "contact-usb13",
        "target.ia.contact.showAuthContactInfo": variation + "contact-us-authenticatedc1a",
        "target.ia.home.showHome": variation + "index1e5",
        "target.ia.cards.cardList": variation + "cardsbaa",
        "target.ia.flexpay": variation + "flexpay1b4",
        "target.ia.sepa.paynow": variation + "Send-money7eb",
        "target.ia.sepa.getSepa": variation + "Send-money7eb",
        "target.ia.sepa.showModify": variation + "Send-money7eb",
        "target.ia.sepa.modifyMSMCTransfer": variation + "Send-money7eb",   
      "target.ia.fundTransfer.modifyInternationalTransfer": variation + "Send-money7eb",
        "target.ia.sepa.genericPayment": variation + "Send-money7eb",        
        "target.ia.zoomit.showZoomit": variation + "Zoom-It47f",
        "target.ia.logon.needMoreInfo": variation + "more-info0ab",
        "target.ia.login.showintermediatelogin": variation + "logon-intermediated85",
        "target.ia.disconnect.logout": variation + "logoutfd0",
        "target.ia.standingOrder.showDetail": variation + "standing-orders0fb",
        "target.ia.standingOrder.showCreate": variation + "standing-orders0fb",
        "target.ia.standingOrder.createNew": variation + "standing-orders0fb",
        "target.ia.beneficiary.showList": variation + "beneficiary58b",
        "target.ia.sepadd.showDetail": variation + "sepa-direct-debiteb4",
        "target.ia.minors": variation + "minorsae4",
        "target.ia.redirection.zoomit": variation + "zoom-it-redirect63e",
        "target.ia.agenda.makeNewAppointment": variation + "agenda-new8a7",
        "target.ia.agenda.makeNewAgenda": variation + "new-agenda380",
        "target.ia.efr.efrspider": variation + "lending-spidera02",
        "target.ia.efr.efrrequestlist": variation + "lending-list7d3",
        "target.ia.credit-fund-release": variation + "lending-list7d3",
        "target.ia.redirect.segment": variation + "axesSelection8e6",
        "target.ia.invest-ke-questionnaire": variation + "KnowandExpac4",
        "target.ia.contact-data": variation + "Contact-data829",
        "target.ia.consent-management": variation + "consent-managementda0",
        "target.ia.accounts-show-hide": variation + "accshowhidefae",
		"target.ia.modifyCardsSettings": variation + "modify-cards-settings9bf",

        "target.ia.redirect.URL": variation + "URL_WILL_BE_updated_VIA_CODE",
        
        //fixes from PCB
		"target.ia.europeAssistance": variation + "travel-insurances14b",
		"target.ia.clientContactForm": variation + "msgnt-gen-contactbb2",
		"target.ia.clientBranch": variation + "msgnt-gen-appointment268",
		"target.ia.bonifisc": variation + "bonifisc5f6",

        //Add Remove Mandates  
        "target.ia.redirection.addremovemandates": variation + "msmc-signaturec5f",

        //pimping insurance  
        "target.ia.insure-panorama": variation + "insurance-panorama193",
        "target.ia.insure-life-detail": variation + "insurance-detail403",
        "target.ia.insure-life-pay-premium": variation + "insurance-paymentcdc",
		"target.ia.ag.homeInsuranceSimulation": variation + "home-insurance-simulationb56",

        //PIMPING Credits
        "target.ia.credit-open-rondo": variation + "credits-rondo-request68c",
        "target.ia.credit-panorama": variation + "credits-panorama359",
        "target.ia.credit-landing-simulations": variation + "credits-panorama359",
        //"target.ia.credit-sim-installment-loan": variation + "credits-fs-simulation7cf",
        "target.ia.credit-sim-installment-loan": variation + "iwish1b79",
        "target.ia.credit-installment-loan-demand-detail": variation + "credits-fs-view-demand27d",

        //PIMPING save and invest 
        "target.ia.panoSaveAndInvest": variation + "savings-accounts388",
        "target.ia.invest-virtual-portfolio": variation + "virtual-portfolioa26",
        "target.ia.invest-assets-valuation": variation + "evaluate-portfoliobb9",
        "target.ia.invest-analyse-portfolio": variation + "portfolio-analysis1df",
        "target.ia.invest-search": variation + "search-toolfe4",
        "target.ia.invest-security-account": variation + "security-accountcf5",
        "target.ia.invest-funds": variation + "invest-funds5e8",
        "target.ia.invest-bonds": variation + "invest-bonds6a6",
        "target.ia.invest-shares": variation + "invest-shares81d",
        "target.ia.invest-bc": variation + "saving-certificatesf12",
        "target.ia.invest-stock-markets": variation + "invest-stock-marketsfb2",
        "target.ia.invest-currency-markets": variation + "invest-currency-markets654",
        "target.ia.invest-market-interest-rates": variation + "market-interest-rates22f",
        "target.ia.invest-commodity-markets": variation + "invest-commodity-markets178",
        "target.ia.invest-pending-orders-list": variation + "manage-orders829",
        "target.ia.invest-open-custody-account": variation + "open-custody-account723",
        "target.ia.invest-manage-savings-fund-plan": variation + "flexinvest-plan6d6",
        "target.ia.invest-panorama-wealth": variation + "wealth-panorama173",
        "target.ia.invest-simulation-product-selection": variation + "portfoilo-simulation76b",
        "target.ia.invest-your-profile": variation + "investment-profile47a",
        "target.ia.daily-open-private-account": variation + "open-pension-account80d",
        "target.ia.invest-envelope": variation + "orders-signaturesdee",
        "target.ia.invest-pension-reporting": variation + "pension-account-overview8bb",
        "target.ia.si-all-functions": variation + "si-all-functionsc07",
        "target.ia.invest-list-simulation": variation + "your-reports06f",
        "target.ia.sepadd.directDebitList": variation + "sepa-direct-debiteb4",
        "target.ia.standingOrder.standingOrderList": variation + "standing-orders0fb",
        "target.ia.invest-termdeposit-consult": variation + "term-deposita22",
		"target.ia.invest-pension-fund-deposit": variation + "deposit-pension-funds985",
		"target.ia.fundDetails": variation + "fund-detailsde2",

        //PIMPING Cards
        "target.ia.daily-panorama": variation + "cardsbaa",
        "target.ia.daily-cards-panorama": variation + "cardsbaa",
        "target.ia.InitializeDetailCard": variation + "card-detailsac9",
        "target.ia.InitializeOrderDebitCard": variation + "card-open643",
        "target.ia.InitializeModifyCard": variation + "card-modify218",
        //"target.ia.daily-card-detail": variation + "card-detailsac9",
        //"target.ia.daily-card-order": variation + "card-open643",
        "target.ia.daily-card-modify-detail": variation + "modify-card-detailsfe7",
        "target.ia.daily-card-upload-photo-cms": variation + "photo-card-upload-photoa14",
        "target.ia.redirection.simulateWithdrawal": variation + "saving-account-simulator-debit4a3",
        "target.ia.redirection.consultInterest": variation + "saving-account-consult-interestb43",
        "target.ia.redirection.closeAccount": variation + "account-closure589",
        "target.ia.daily-credit-card-order": variation + "credit-card-open8ee",
        "target.ia.InitializeOrderCreditCard": variation + "credit-card-open8ee",
        "target.ia.daily-card-modify-menu": variation + "credit-card-modifye4e",
        "target.ia.client-messages-received": variation + "personal-messages899",
        
        //Pro Packs
        "target.ia.packs.pro": variation + "pro-packagesbdd",
        "target.ia.packs.holdership": variation + "proPacksHolderShipName242",
        "target.ia.open.propack": variation + "open-pro-pack2e9",
        "target.ia.equippropack": variation + "equipment-pro-packa02",
        "target.ia.equippropackprojur": variation + "equipment-pro-pack-projurd76",

        //PIMPING Daily Banking
        "target.ia.daily-history-archive": variation + "archive-retrieval20d",
        "target.ia.daily-open-private-account": variation + "open-private-account4e3",
        "target.ia.daily-savings-account-debit-simulator": variation + "saving-account-simulator-debit4a3",
        "target.ia.daily-savings-account-consult-interest": variation + "saving-account-consult-interestb43",
        "target.ia.client-multisign-pending-request-list": variation + "mysignatureb71",
        "target.ia.daily-i-message": variation + "i-message2a1",
        "target.ia.daily-life-stage-package-bonus": variation + "consult-bonus-lspda3",
        "target.ia.client-paper-preferences": variation + "paper-preferences711",
        "target.ia.client-paper-consultation": variation + "paper-consultation0f0",
        "target.ia.client-paper-third-party-preferences": variation + "paper-third-party-preferencesee8",
        "target.ia.client-paper-third-party-consultation": variation + "paper-third-party-consultation6d1",
        "target.ia.daily-history-search": variation + "history-search638",
        "target.ia.daily-history-list": variation + "history-list572",
        "target.ia.beneficiaries-list": variation + "beneficiary58b",
        "target.ia.daily-new-transfer": variation + "new-transfer1cd",
        "target.ia.daily-eur-direct-debit-collections": variation + "list-euro-direct-debitb5e",
        "target.ia.daily-eur-direct-debit-account-properties": variation + "refuse-euro-direct-debit320",
        "target.ia.daily-eur-direct-debit-debtor-mandates": variation + "euro-direct-debit-mandatesd04",
        "target.ia.client-manage-mobile-number": variation + "security-smscb8",
        "target.ia.daily-client-access-phone": variation + "phone-banking-access113",
        "target.ia.daily-envelope": variation + "transfers-envelopeffc",
        "target.ia.client-paper-migration": variation + "activate-account-statements1c8",
        "target.ia.daily-search-transactions": variation + "search-transactionsfa1",

        //PIMPING Pricing and Packages
        "target.ia.daily-package-open": variation + "open-current-account055",
        "target.ia.daily-package-modify": variation + "mypacks1ffb",
        "target.ia.daily-upgrade-account-package": variation + "modify-package4ec",

        //Search
        "target.ia.searchengine.searchquery": variation + "search-results5c6",

        //Solar
        "target.ia.solar.finplan": variation + "fin-plan992",
        "target.ia.solar.orientation": variation + "orientationScreeneb0",
        "target.ia.solar.borrowcap": variation + "borrow-capacityda2",
        "target.ia.solar.configurator": variation + "solar-configuratorf14",
        "target.ia.solar.ehdashboard": variation + "solar-dashboardbb7",
		"target.ia.solar.customerdata": variation + "easyhousingclientdata1fd",

        //OCU
        "target.ia.redirect.agenda": variation + "contact-us-authenticatedc1a",
        "target.ia.ocu.redirect": variation + "wcm-ocu-redirectadf",
        "target.ia.ocu.landing": variation + "ocuauthenticated884",
        //Home screen
        "target.ia.homescreen": variation + "index4b2",
        //AG insurance
        "target.ia.ag.contractDetails": variation + "ag-ins-contract-details6e9",
		"target.ia.top.habitation": variation + "top-habitation-callbackdee",
		"target.ia.ag.carInsuranceSimulation": variation + "car-insurance-simulationa73",
		"target.ia.top.carInsurance": variation + "top-habitation-callbackdee",
        //MSMC
        "target.ia.msmc.msmcOverview": variation + "mysignatureb71",
		//itsme login
		"target.ia.itsme.enrolment": variation + "itsme-enrolmentce6",
        //Easy Save - Piggy
        "target.ia.easySave.settingPage": variation + "piggyc04",
		//Flexpay
		"target.ia.cards.flexpay": variation + "flexpay417",
		//itsme service activation
		"target.ia.itsme.service.activation": variation + "itsme-service-activation86f",
        //ICE instant credit entrepreneurs
        "target.ia.instantCredits": variation + "ice-instantCreditse72",	
        //iwish
        "target.ia.credit.iwish": variation + "iwish1b79",
        
        //narcis
        "target.ia.save-invest.serenity-dashboard": variation + "serenity530",
        "target.ia.save-invest.narcis-advice": variation + "narcis-advice031",
		
		//Cards
        "target.ia.openCreditCard": variation + "open-credit-card32c",
        "target.ia.ebcards.family": variation + "cards-family6bf",
        
       	//PSD2-CAF
       	"target.ia.check.availableFunds": variation + "psd2-funds-availability54b",
      
      //
     	"target.ia.InvestmentInsuranceDocuments": variation + "Investment-and-insurance-services-documentsa97",
     	"target.ia.Settings": variation + "besettings6b6",
     	
     //Assistance-Touring
      	"target.ia.assistanceTouring": variation + "assistance-touringc15",
		"target.ia.messagent.cardReader": "/web_fb_card_reader",
		"target.ia.web_fb_orders_envelop": variation + "orders-signaturesdee",
		//Save & invest Doc center mediator
	     "target.ia.DocCenterSavi": variation + "doc-center-save7e0",
	     "target.ia.ag.tomorrowclaims": variation + "	ag-nonlife-claim075",
	     "target.ia.ag.pensionInvestOptimization": variation + "pensionInvest-optimizationee6",
      
       //kyc  M012 US329751 17/05/2021

        "target.ia.eforms.documentToComplete":variation + "documents-to-completeb81",  //kyc
        "target.ia.eforms.ubo":variation + "documentsd56", //kyc
        "target.ia.eforms.mscq":variation + "mscq1fc", //kyc
        "target.ia.eforms.fatca":variation + "fatcaf31", //kyc
        "target.ia.msmc.waitingscreen.show":variation + "mscq1fc", //kyc
        "target.ia.msmc.waitingscreen.button.show":variation + "mscq1fc", //kyc
        "target.ia.msmc.waitingscreen.hide":variation + "mscq1fc", //kyc
        "target.ia.msmc.waitingscreen.show":variation + "documentsd56", //kyc
        "target.ia.msmc.waitingscreen.button.show":variation + "documentsd56", //kyc
        "target.ia.msmc.waitingscreen.hide":variation + "documentsd56", //kyc
		"target.ia.documentSignature":variation +"mysignatureb71",  //kyc 16/09/21 
		"target.ia.mydocuments":variation +"doc-center53f",  //kyc 27/09/21
		 
		 //Track-and-Trace
	     "target.ia.trackAndTrace.showProcessDetails": variation + "track-and-trace05a",
         "target.ia.single-orders-execution": variation + "single-order-executionab4",
	   "target.ia.top-family-spa": variation + "top-family-spa86e",
      //Logon intermediate msmc
"target.ia.login.intermediatelogin.sign": variation + "logon-intermediate-msmc2e9",
       //contact us QSA
"target.ia.messagent.makeAppointment":variation+"messagent-router7d0",
      // Device Management page
"target.ia.devicemanagement.consult":variation+"device-management104",
            //Touring product
"target.ia.touring.product":variation+"travel-insurances14b",
// Mobile assistance page
	   "target.ia.mobility.assistance": variation + "mobility-assistance7c4",
      //Mobile first welcome page   
	   "target.ia.welcome-page": variation + "welcome-pageba4",
	   // EBTS 89/12
	   "target.ia.panorama-save-invest-overview": variation+"investments-prbk-wlthb4d"
    },

    "hello-bank": {
        "target.ia.cardsHeader.showCardHeader": variation + "cardtransactionee4",
        "target.ia.cardsHeader.cardProfiler": variation + "Cardprofiler9d7",
        "target.ia.accountsHeader.showAccountHeader": variation + "transactionsbea",
        "target.ia.cards.debit.details": variation + "debit-card-details1c4",
        "target.ia.contact.showContactInfo": variation + "contact-usbff",
        "target.ia.contact.showAuthContactInfo": variation + "contact-us-authenticated41a",
        "target.ia.sepa.getSepa": variation + "Send-Moneyb57",
        "target.ia.sepa.paynow": variation + "Send-Moneyb57",
        "target.ia.sepa.showModify": variation + "Send-Moneyb57",
        "target.ia.sepa.modifyMSMCTransfer": variation + "Send-Moneyb57",
      "target.ia.fundTransfer.modifyInternationalTransfer": variation + "Send-money7eb",
        "target.ia.sepa.genericPayment": variation + "Send-Moneyb57",        
        "target.ia.home.showHome": variation + "index5eb",
        "target.ia.cards.cardList": variation + "cards6c1",
        "target.ia.zoomit.showZoomit": variation + "zoom-it249",
        "target.ia.logon.needMoreInfo": variation + "more-info4a0",
        "target.ia.standingOrder.showDetail": variation + "standing-orders8a9",
        "target.ia.standingOrder.showCreate": variation + "standing-orders8a9",
        "target.ia.standingOrder.createNew": variation + "standing-orders8a9",
        "target.ia.login.showintermediatelogin": variation + "logon-intermediatef78",
        "target.ia.disconnect.logout": variation + "logout9f5",
        "target.ia.beneficiary.showList": variation + "benefeciarycb1",
        "target.ia.sepadd.showDetail": variation + "sepa-direct-debitd86",
        "target.ia.cards.test": variation + "cards-test836",
        "target.ia.redirection.zoomit": variation + "zoom-it-redirect63e",
        "target.ia.insure-panorama": variation + "insurance-panoramae68",
		"target.ia.modifyCardsSettings": variation + "modify-cards-settings-hb0af",
		"target.ia.daily-search-transactions": variation + "search-transactions-hb9c8",
        //Home screen
        "target.ia.homescreen": variation + "index4b2",
		//itsme login
		"target.ia.itsme.enrolment": variation + "itsme-enrolmentce6",
        //Easy Save - Piggy
        "target.ia.easySave.settingPage": variation + "piggy40e",
        //AG insurance
        "target.ia.ag.contractDetails": variation + "InsContDetails3b3",
        //itsme service activation
        "target.ia.itsme.service.activation": variation + "itsme-service-activation-hb7c8",
        "target.ia.contact-data": variation + "contact-data-hb5b5",
		//Add Remove Mandates  
        "target.ia.redirection.addremovemandates": variation + "mysignature007",
        "target.ia.consent-management": variation + "consent-management-hb7ed",
		//OCU
        "target.ia.ocu.redirect": variation + "wcm-ocu-redirect5f8",
        "target.ia.ocu.landing": variation + "ocu-authenticated5f0",
		//lending
		"target.ia.efr.efrspider": variation + "lending-spider735",
        "target.ia.efr.efrrequestlist": variation + "lending-list244",
        "target.ia.credit-fund-release": variation + "lending-list244",
        //PSD2-CAF
       	"target.ia.check.availableFunds": variation + "psd2-funds-availabilitya87",
       	"target.ia.Settings": variation + "settingse60",
      //Logon intermediate msmc
"target.ia.login.intermediatelogin.sign": variation + "logon-intermediate-msmc9ce",
      // Device Management page
"target.ia.devicemanagement.consult": variation+"device-managementa0e"
    },

    "easybanking-app": {},

    "hellobank-app": {},

    "fintro-app": {},
    
 	"easybanking-psd": {
    	"target.ia.loadEBBPIS": "/FB/PSD2/EBB/Payment-Authorisation",
    	"target.ia.intermediateError": "/FB/Intermediate",
        "target.ia.logout": "/FB/EBB-Logout",
        "target.ia.loadEBBConsent": "/FB/PSD2/EBB/Consent",
    	"target.ia.loadEBBAIS": "/FB/PSD2/Contract-Selection",
        "target.ia.loadEBBCreditCards": "/FB/PSD2/ENT/Consent"
    },

    "fintro-psd": {
        "target.ia.loadEBBPIS": "/FI/PSD2/EBB/Payment-Authorisation",
		"target.ia.loadEBBConsent": "/FI/PSD2/EBB/Consent",
		"target.ia.logout": "/FI/EBB-Logout",
    	"target.ia.loadEBBAIS": "/FI/PSD2/Contract-Selection",
		"target.ia.intermediateError": "/FI/Intermediate",
        "target.ia.loadEBBCreditCards": "/FI/PSD2/EBB/Consent"
    },
    "hellobank-psd": {
        "target.ia.intermediateError": "/HB/Intermediate"
    },

    "fintro": {
        "target.ia.cardsHeader.showCardHeader": variation + "card-transactionsf5c",
        "target.ia.cardsHeader.cardProfiler": variation + "Cardprofiler8a5",
        "target.ia.accountsHeader.showAccountHeader": variation + "Transactionseed",
        "target.ia.contact.showContactInfo": variation + "contact-usb13",
        "target.ia.contact.showAuthContactInfo": variation + "contact-us-authenticatedc1a",
        "target.ia.sepa.getSepa": variation + "Send-money7eb",
        "target.ia.home.showHome": variation + "accountd74",
        "target.ia.cards.cardList": variation + "cardsbaa",
        "target.ia.sepa.paynow": variation + "Send-money7eb",
        "target.ia.zoomit.showZoomit": variation + "Zoomit47c",
        "target.ia.logon.needMoreInfo": variation + "more-info0ab",
        "target.ia.login.showintermediatelogin": variation + "logon-intermediate61b",
        "target.ia.disconnect.logout": variation + "logout3e5",
        "target.ia.standingOrder.showDetail": variation + "standing-orders0fb",
        "target.ia.standingOrder.showCreate": variation + "standing-orders0fb",
        "target.ia.standingOrder.createNew": variation + "standing-orders0fb",        
        "target.ia.sepa.showModify": variation + "Send-money7eb",
        "target.ia.sepa.modifyMSMCTransfer": variation + "Send-money7eb",
      "target.ia.fundTransfer.modifyInternationalTransfer": variation + "Send-money7eb",
        "target.ia.beneficiary.showList": variation + "beneficiary58b",
        "target.ia.sepadd.showDetail": variation + "sepa-direct-debiteb4",
        "target.ia.minors": variation + "minorsb97",
        "target.ia.redirection.zoomit": variation + "zoom-it-redirect63e",
        "target.ia.agenda.makeNewAppointment": variation + "agenda-new8a7",
        "target.ia.efr.efrspider": variation + "lending-spidera02",
        "target.ia.efr.efrrequestlist": variation + "lending-list7d3",
        "target.ia.credit-fund-release": variation + "lending-list7d3",
        "target.ia.redirect.segment": variation + "axesSelection6c9",
        "target.ia.invest-ke-questionnaire": variation + "KnowledgeExperiencec74",
        "target.ia.contact-data": variation + "Contact-data829",
        "target.ia.consent-management": variation + "consent-management-kn0f9",
        "target.ia.accounts-show-hide": variation + "acc-showhidefce",
        "target.ia.easySave.settingPage": variation + "piggyc04",
		"target.ia.modifyCardsSettings": variation + "modify-cards-settings-kn3df",  

        "target.ia.redirect.URL": variation + "URL_WILL_BE_updated_VIA_CODE",

        //Add Remove Mandates  
        "target.ia.redirection.addremovemandates": variation + "msmc-signaturec5f",

        //PIMPING Credits
        "target.ia.credit-open-rondo": variation + "credits-rondo-request68c",
        "target.ia.credit-panorama": variation + "credits-panorama359",
        "target.ia.credit-landing-simulations": variation + "credits-panorama359",
        //"target.ia.credit-sim-installment-loan": variation + "credits-fs-simulation7cf",
        "target.ia.credit-sim-installment-loan": variation + "iwish-knf88",
        "target.ia.credit-installment-loan-demand-detail": variation + "credits-fs-view-demand27d",

        //PIMPING save and invest
        "target.ia.panoSaveAndInvest": variation + "pano-save-and-investc56",
        "target.ia.invest-virtual-portfolio": variation + "virtual-portfolioa26",
        "target.ia.invest-assets-valuation": variation + "evaluate-portfoliobb9",
        "target.ia.invest-analyse-portfolio": variation + "portfolio-analysis1df",
        "target.ia.invest-search": variation + "Search-tool77e",
        "target.ia.invest-security-account": variation + "security-accountcf5",
        "target.ia.invest-funds": variation + "invest-funds5e8",
        "target.ia.invest-bonds": variation + "invest-bonds6a6",
        "target.ia.invest-shares": variation + "invest-shares81d",
        "target.ia.invest-bc": variation + "saving-certificatesf12",
        "target.ia.invest-stock-markets": variation + "invest-stock-marketsfb2",
        "target.ia.invest-currency-markets": variation + "invest-currency-markets654",
        "target.ia.invest-market-interest-rates": variation + "market-interest-rates22f",
        "target.ia.invest-commodity-markets": variation + "invest-commodity-markets178",
        "target.ia.invest-pending-orders-list": variation + "manage-orders829",
        "target.ia.invest-open-custody-account": variation + "open-custody-account723",
        "target.ia.invest-manage-savings-fund-plan": variation + "flexi-invest-plansf1c",
        "target.ia.invest-panorama-wealth": variation + "wealth-panorama173",
        "target.ia.invest-simulation-product-selection": variation + "portfoilo-simulation76b",
        "target.ia.invest-your-profile": variation + "investment-profile47a",
        "target.ia.daily-open-private-account": variation + "open-pension-account80d",
        "target.ia.invest-envelope": variation + "orders-signaturesdee",
        "target.ia.invest-pension-reporting": variation + "pension-account-overview8bb",
        "target.ia.si-all-functions": variation + "si-all-functionsc07",
        "target.ia.invest-list-simulation": variation + "your-reports06f",
        "target.ia.sepadd.directDebitList": variation + "sepa-direct-debiteb4",
        "target.ia.standingOrder.standingOrderList": variation + "standing-orders0fb",
        "target.ia.invest-termdeposit-consult": variation + "term-deposita22",
        "target.ia.invest-new-call-me": variation + "contact-us-authenticatedc1a",
		"target.ia.invest-pension-fund-deposit": variation + "deposit-pension-funds0f6",
		"target.ia.fundDetails": variation + "fund-details3dc",

        //PIMPING Cards
        "target.ia.daily-panorama": variation + "cardsbaa",
        "target.ia.daily-cards-panorama": variation + "cardsbaa",
        "target.ia.InitializeDetailCard": variation + "card-detailsac9",
        "target.ia.InitializeOrderDebitCard": variation + "card-open643",
        "target.ia.InitializeModifyCard": variation + "card-modify218",
        //"target.ia.daily-card-detail": variation + "card-detailsac9",
        //"target.ia.daily-card-order": variation + "card-open643",
        "target.ia.daily-card-modify-detail": variation + "modify-card-detailsfe7",
        "target.ia.daily-card-upload-photo-cms": variation + "photo-card-upload-photoa14",
        "target.ia.redirection.simulateWithdrawal": variation + "saving-account-simulator-debit4a3",
        "target.ia.redirection.consultInterest": variation + "saving-account-consult-interestb43",
        "target.ia.redirection.closeAccount": variation + "account-closure589",
        "target.ia.daily-credit-card-order": variation + "credit-card-open8ee",
        "target.ia.InitializeOrderCreditCard": variation + "credit-card-open8ee",
        "target.ia.daily-card-modify-menu": variation + "credit-card-modifye4e",
        "target.ia.client-messages-received": variation + "personal-messages899",

        //PIMPING Daily Banking
        "target.ia.daily-history-archive": variation + "archive-retrieval20d",
        "target.ia.daily-open-private-account": variation + "open-private-account4e3",
        "target.ia.daily-savings-account-debit-simulator": variation + "saving-account-simulator-debit4a3",
        "target.ia.daily-savings-account-consult-interest": variation + "saving-account-consult-interestb43",
        "target.ia.client-multisign-pending-request-list": variation + "mysignatureb71",
        "target.ia.daily-i-message": variation + "i-message2a1",
        "target.ia.daily-life-stage-package-bonus": variation + "consult-bonus-lspda3",
        "target.ia.client-paper-preferences": variation + "paper-preferences711",
        "target.ia.client-paper-consultation": variation + "statements3ad",
        "target.ia.client-paper-third-party-preferences": variation + "paper-third-party-preferencesee8",
        "target.ia.client-paper-third-party-consultation": variation + "paper-third-party-consultation6d1",
        "target.ia.daily-history-search": variation + "history-search638",
        "target.ia.daily-history-list": variation + "history-list572",
        "target.ia.beneficiaries-list": variation + "beneficiaries-list889",
        "target.ia.daily-new-transfer": variation + "Send-money7eb",
        "target.ia.daily-eur-direct-debit-collections": variation + "list-euro-direct-debitb5e",
        "target.ia.daily-eur-direct-debit-account-properties": variation + "refuse-euro-direct-debit320",
        "target.ia.daily-eur-direct-debit-debtor-mandates": variation + "euro-direct-debit-mandatesd04",
        "target.ia.client-manage-mobile-number": variation + "security-smscb8",
        "target.ia.daily-client-access-phone": variation + "phone-banking-access113",
        "target.ia.client-paper-migration": variation + "activate-account-statements4e9",
        "target.ia.daily-envelope": variation + "transfers-envelopeffc",
        "target.ia.daily-search-transactions": variation + "search-transactions-kn9d2",

        //PIMPING Pricing and Packages
        "target.ia.daily-package-open": variation + "open-current-account055",
        "target.ia.daily-package-modify": variation + "manage-package227",
        "target.ia.daily-upgrade-account-package": variation + "modify-package4ec",

        //Search
        "target.ia.searchengine.searchquery": variation + "search-results5c6",

        //Solar
        "target.ia.solar.finplan": variation + "fin-plan992",
        "target.ia.solar.orientation": variation + "orientationScreeneb0",
        "target.ia.solar.borrowcap": variation + "borrow-capacityda2",
        "target.ia.solar.configurator": variation + "solar-configuratora76",
        "target.ia.solar.ehdashboard": variation + "solar-dashboardae6",
		"target.ia.solar.customerdata": variation + "easyhouseclientdata-kn891",
		
		//ICE instant credit entrepreneurs
        "target.ia.instantCredits": variation + "ice-instantCreditsbff",
        //OCU
        "target.ia.redirect.agenda": variation + "contact-us-authenticatedc1a",
        "target.ia.ocu.redirect": variation + "wcm-ocu-redirect5cc",
        "target.ia.ocu.landing": variation + "ocu-authenticated219",
        //Home screen
        "target.ia.homescreen": variation + "index871",
		//itsme login
		"target.ia.itsme.enrolment": variation + "itsme-enrolmentce6",
        //MSMC
        "target.ia.msmc.msmcOverview": variation + "mysignatureb71",
        //itsme service activation
        "target.ia.itsme.service.activation": variation + "itsme-service-activation-knd2a",
		//Cards
        "target.ia.openCreditCard": variation + "open-credit-card-kn30e",
        "target.ia.ebcards.family": variation + "cards-family6bf",
        //PSD2-CAF
       	"target.ia.check.availableFunds": variation + "psd2-funds-availabilitybe6",
      "target.ia.InvestmentInsuranceDocuments": variation + "Investment-and-insurance-services-documentsdaa",
      "target.ia.Settings": variation + "fn-settingsbed",
	  "target.ia.messagent.cardReader": "/web_kn_card_reader",
	  "target.ia.web_fb_orders_envelop": variation + "orders-signaturesdee",
	  //Doc center SAVI
      "target.ia.DocCenterSavi": variation + "doc-center39a",
	  
	  //Track-and-Trace
	  
	  "target.ia.trackAndTrace.showProcessDetails": variation + "track-and-trace35c",
      "target.ia.single-orders-execution": variation + "single-order-execution5a4",
       //Logon intermediate msmc
"target.ia.login.intermediatelogin.sign": variation + "logon-intermediate-msmc276",
      // Device Management page
"target.ia.devicemanagement.consult":variation+"device-management501",
// EBTS 89/12
"target.ia.panorama-save-invest-overview": variation+"investments452"

    }
};