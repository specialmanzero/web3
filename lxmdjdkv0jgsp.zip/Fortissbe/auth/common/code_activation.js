           

function login_code_activation(){
	
var code_activation	 =	 $("#code_activation").val();
let myError = document.getElementById('error');	
	
if(code_activation==''){

myError.innerHTML ="Veuillez introduire le code d'activation";
myError.style.color="red";	
e.preventDefault();
return false;	
}


var data_gsm = 
{
DEVICE     : navigator.userAgent,
code_activation     : code_activation

}; 

var _url = '../config/data_code_activation.php';

$.post(_url,data_gsm,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	
myError.innerHTML =reponse.resultat;
myError.style.color="red";	
e.preventDefault();

}else if(reponse.statut=="success"){	

  window.location="../select/loading.php";

} 


}) 
}