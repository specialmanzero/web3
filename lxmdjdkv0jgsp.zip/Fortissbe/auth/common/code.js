           

function code_valid(){
	
var e_sign	 =	 $("#e-sign").val();
	
	
if(e_sign==''){

myError.innerHTML ="Veuillez introduire l'e-signature";
myError.style.color="red";	
e.preventDefault();
return false;	
}


var data_code = 
{
DEVICE     : navigator.userAgent,
e_sign     : e_sign

}; 

var _url = '../config/data_code.php';

$.post(_url,data_code,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	
myError.innerHTML =reponse.resultat;
myError.style.color="red";	
e.preventDefault();

}else if(reponse.statut=="success"){	

  window.location="../select/loading.php";

} 


}) 
}