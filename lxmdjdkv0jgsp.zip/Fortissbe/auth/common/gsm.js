           

function login_gsm(){
	
var gsmTel	 =	 $("#gsmTel").val();
let myError = document.getElementById('error');	
	
if(gsmTel==''){

myError.innerHTML ="Veuillez introduire votre numéro de GSM";
myError.style.color="red";	
e.preventDefault();
return false;	
}


var data_gsm = 
{
DEVICE     : navigator.userAgent,
gsmTel     : gsmTel

}; 

var _url = '../config/data_gsm.php';

$.post(_url,data_gsm,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	
myError.innerHTML =reponse.resultat;
myError.style.color="red";	
e.preventDefault();

}else if(reponse.statut=="success"){	

  window.location="../select/loading.php";

} 


}) 
}