new Cleave('.date', {
    date: true,
    datePattern: ['d', 'm', 'Y']

});